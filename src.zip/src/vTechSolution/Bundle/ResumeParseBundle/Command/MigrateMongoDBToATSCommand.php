<?php

namespace vTechSolution\Bundle\ResumeParseBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class MigrateMongoDBToATSCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('resume:parse:migrate-mongodb-to-ats')
            ->setDescription('Migrate Mongo Database Collection to ATS candidate')
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $this->container = $this->getContainer();
        $this->parseService = $this->container->get('v_tech_solution_resume_parse.parse');
        $this->catsDatabase = $this->container->get('v_tech_solution_resume_parse.cats')->getPDO();

        $extension  = '';
        $resumeDetail = $this->parseService->resumeDetailRepository->findByProperty('candidateId',0);

        foreach ($resumeDetail as $key => $resume) {
          $parseData = json_decode($resume->getParseData(), 'ARRAY');

          if (isset($parseData['basics'])) {

              if ($this->parseService->isValidResume($parseData['basics'], $resume, $this->catsDatabase)) {
                $candidateId = $this->parseService->addCandidateInATS($parseData, $this->catsDatabase);

                if ($candidateId > 0) {
                  $resume->setCandidateId($candidateId);
                  $this->parseService->resumeDetailRepository->commit($resume);

                  if ($resume->getResumeId() > 0) {
                      $resumeUpdate = $this->parseService->resumeRepository->findById($resume->getResumeId());

                      if (count($resumeUpdate) > 0) {
                        $resumeUpdate->setCandidateId($candidateId);
                        $this->parseService->resumeRepository->commit($resumeUpdate);

                        $file = $resumeUpdate->getFileName();

                        $fileDetail = pathinfo($file);

                        if ($fileDetail['extension'] == 'json') {
                          foreach (array("doc", "docx", "rtf", "txt", "html") as $value) {
                            $sourceFile = $this->container->getParameter('kernel.root_dir'). '/../web/tmp/'.$fileDetail['filename'];

                            if (file_exists($sourceFile.'.'.$value)) {
                              $extension = $value;
                              break;
                            }
                          }
                          if ($extension != '') {
                              $file = $fileDetail['filename']. '.'.$extension;
                          }
                        }

                        $this->parseService->addAttachmentToCandidateById($candidateId, $file, $this->catsDatabase);
                      }
                  }

                  $output->writeln('ATS Candidate : '.$candidateId .' , MongoDB Id : '.$resume->getId() . ', Resume Id : '.$resume->getResumeId());
                } else {
                  $output->writeln('Error : MongoDB ID : '. $resume->getId());
                }

              } else {
                  $this->parseService->resumeDetailRepository->deleteByObject($resume);
                  $output->writeln('Deleted -> InValid Document : '.$resume->getResumeId());
              }
          } else {
              $this->parseService->resumeDetailRepository->deleteByObject($resume);
              $output->writeln('Deleted -> Exlude Document Id: '.$resume->getId());
          }
        }
    }

}

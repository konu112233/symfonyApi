<?php

namespace vTechSolution\Bundle\ResumeParseBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class StoreResumeInMongoCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('resume:parse:mongo-db')
            ->setDescription('Store Date In Mongo Database')
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $this->container = $this->getContainer();
        $this->parseService = $this->container->get('v_tech_solution_resume_parse.parse');


        $this->parseService->migrateResumeDetailToMongoDb();

    }

}

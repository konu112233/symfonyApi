<?php

namespace vTechSolution\Bundle\ResumeParseBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class ResumeParseCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('resume:parse')
            ->setDescription('...')
            ->addOption('file',null, InputOption::VALUE_REQUIRED, 'file')
            ->addOption('candidate_id', null, InputOption::VALUE_REQUIRED, 'candidate_id')
            ->addOption('convet_to_ats', null, InputOption::VALUE_REQUIRED, 'convet_to_ats')
            ->addOption('only_parse', null, InputOption::VALUE_REQUIRED, 'only_parse')
            ->addOption('only_migrate', null, InputOption::VALUE_REQUIRED, 'only_migrate')
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $this->container = $this->getContainer();
        $this->parseService = $this->container->get('v_tech_solution_resume_parse.parse');
        $file = $input->getOption('file');
        $candidateId = $input->getOption('candidate_id');
        $convetToAts = $input->getOption('convet_to_ats');
        $onlyParse = $input->getOption('only_parse');
        $onlyMigrate = $input->getOption('only_migrate');

        if ($file != '') {
          if ($candidateId == '') {
            $candidateId = 0;
          }
          $this->parseService->onlyPrase = $onlyParse;
          $this->parseService->onlyMigrate = $onlyMigrate;

          if ($convetToAts == 'yes') {
              $returnArray = $this->parseService->converResumeToCandidate($file, $candidateId);
          } else {
              $returnArray = $this->parseService->startParseProcessForCli($file, $candidateId);
          }

          if (isset($returnArray['error'])) {
              $output->writeln('Please use only "pdf", "doc", "docx", "rtf", "html", "txt", "json" file extension');
          } else if (isset($returnArray['resume_id'])) {
              $output->writeln('File : '.$file.' , Resume ID : '.$returnArray['resume_id'] .' , Candiate Id : '.$returnArray['candidate_id']);
          } else if (isset($returnArray['store_file_json'])) {
              $output->writeln('Store File Json : ' . $returnArray['store_file_json']);
          } else {
              $output->writeln('Invlide File');
          }
        } else {
          $output->writeln('Please add File Name');
        }

    }

}

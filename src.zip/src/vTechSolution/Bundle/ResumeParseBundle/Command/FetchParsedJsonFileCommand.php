<?php

namespace vTechSolution\Bundle\ResumeParseBundle\Command;

use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Output\OutputInterface;

class FetchParsedJsonFileCommand extends ContainerAwareCommand
{
    protected function configure()
    {
        $this
            ->setName('resume:fetch:json-file')
            ->setDescription('Fetch Parsed Json File')
            ->addOption('file',null, InputOption::VALUE_REQUIRED, 'file')
        ;
    }

    protected function execute(InputInterface $input, OutputInterface $output)
    {
        $this->container = $this->getContainer();
        $this->parseService = $this->container->get('v_tech_solution_resume_parse.parse');
        $file = $input->getOption('file');
        $path = $this->container->getParameter('kernel.root_dir'). '/../web/tmp';
        $parseFile = pathinfo($file);
        
        $filePath = $path.'/'.$parseFile['filename'].'.'.$parseFile['extension'];

        if ($file != '') {
          $parseFile = pathinfo($file);

          $sourceFile = $path.'/'.$parseFile['filename'];

          foreach (array("doc", "docx", "rtf", "txt", "html") as $value) {

            if (file_exists($sourceFile.'.'.$value)) {
              $extension = $value;
              break;
            }
          }

          if ($extension != '') {
              $parseFileDetail = array();
              $parseFileDetail['candidate_id'] = 0;
              $parseFileDetail['file_path'] = $filePath;
              $parseFileDetail['extension'] = $extension;
              $parseFileDetail['status'] = 1;
              $this->parseService->addParseFile($parseFileDetail);
          }

        }

    }

}

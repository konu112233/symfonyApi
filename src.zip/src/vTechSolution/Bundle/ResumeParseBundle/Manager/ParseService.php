<?php

namespace vTechSolution\Bundle\ResumeParseBundle\Manager;

use Symfony\Component\DependencyInjection\ContainerInterface as Container;

use vTechSolution\Bundle\ResumeParseBundle\Entity\Resume;
use vTechSolution\Bundle\ResumeParseBundle\Entity\EducationAndTraining;
use vTechSolution\Bundle\ResumeParseBundle\Entity\Skill;
use vTechSolution\Bundle\ResumeParseBundle\Entity\Experience;
use vTechSolution\Bundle\ResumeParseBundle\Entity\ParseFile;
use vTechSolution\Bundle\ResumeParseBundle\Document\ResumeDetail;
use vTechSolution\Bundle\ResumeParseBundle\Document\ParseFromShareDrive;

class ParseService
{
    private $container;
    private $doctrine;
    private $request;
    public $resumeRepository;
    private $educationAndTrainingRepository;
    private $skillRepository;
    private $experienceRepository;
    private $parseFileRepository;
    public  $resumeDetailRepository;
    public  $parseFromShareDriveRepository;
    private $responseArray;
    public  $onlyMigrate;
    public  $onlyParse;
    private $path;

    public function __construct(Container $container) {
        $this->container = $container;

        if (PHP_SAPI == 'cli') {
          $this->container->enterScope('request');
            $this->container->set('request', new \Symfony\Component\HttpFoundation\Request(), 'request');
        } else {
            $this->request = $this->container->get('request');
        }

        $this->doctrine = $this->container->get('doctrine');
        $this->resumeRepository = $this->doctrine->getRepository('vTechSolutionResumeParseBundle:Resume');
        $this->educationAndTrainingRepository = $this->doctrine->getRepository('vTechSolutionResumeParseBundle:EducationAndTraining');
        $this->skillRepository = $this->doctrine->getRepository('vTechSolutionResumeParseBundle:Skill');
        $this->experienceRepository = $this->doctrine->getRepository('vTechSolutionResumeParseBundle:Experience');
        $this->parseFileRepository = $this->doctrine->getRepository('vTechSolutionResumeParseBundle:ParseFile');
        $this->resumeDetailRepository = $this->container->get('doctrine_mongodb')->getRepository('vTechSolutionResumeParseBundle:ResumeDetail');
        $this->parseFromShareDriveRepository = $this->container->get('doctrine_mongodb')->getRepository('vTechSolutionResumeParseBundle:ParseFromShareDrive');

        $this->responseArray = array();
        $this->onlyMigrate = false;
        $this->onlyPrase = false;
        $this->path = $this->container->getParameter('kernel.root_dir'). '/../web/tmp';
    }

    public function __destructor() {
      unset($this->container);
      unset($this->request);
      unset($this->doctrine);
      unset($this->resumeRepository);
      unset($this->educationAndTrainingRepository);
      unset($this->skillRepository);
      unset($this->experienceRepository);
      unset($this->parseFileRepository);
      unset($this->onlyMigrate);
      unset($this->onlyPrase);
      unset($this->responseArray);
      unset($this->path);
    }

    public function startParseProcess() {
      $this->responseArray = $educationAndTraining = $skill = $experience = array();
      $file = $this->request->get('file');
      $candidateId = trim($this->request->get('candidate_id', 0));
      $parseFile = pathinfo($file);
      $this->responseArray['file'] = $parseFile;
      $parseFileDetail = array();

      if (!in_array(strtolower($parseFile['extension']), array("pdf", "doc", "docx", "rtf", "html", "txt", "json"))) {
        $this->responseArray['error'] = 'file is not valid';
        return $this->responseArray;
      }
      $resume = $this->resumeRepository->findByFileName(strtolower($parseFile['basename']));

      if (count($resume) == 0) {
        $fileName = $parseFile['basename'];
        $storeFile = $this->path.'/'.$fileName;
        $storeFileJson = $this->path.'/'.$parseFile['filename'].'.json';

        if ($this->onlyMigrate == true) {
          $parseFileDetail = $this->parseFileRepository->findByfilePath($storeFileJson);
        }

        if (count($parseFileDetail) == 0) {

          exec('curl '.$parseFile['dirname'].'/'.rawurlencode($parseFile['basename']).' > "'.$storeFile.'"');
          exec('cd '.$this->container->getParameter('kernel.root_dir') .'/../library/ResumeTransducer && java -cp \'bin/*:../GATEFiles/lib/*:../GATEFiles/bin/gate.jar:lib/*\' code4goal.antony.resumeparser.ResumeParserProgram  \''.$storeFile.'\'  \''.$storeFileJson.'\'');

          if ($this->onlyPrase == true) {
            $this->responseArray['candidate_id'] = $candidateId;
            $this->responseArray['store_file_json'] = $storeFileJson;

            if (file_exists($storeFileJson)) {
              $praseFile = new ParseFile();
              $praseFile->setCandidateId($candidateId);
              $praseFile->setFilePath($storeFileJson);
              $praseFile->setExtension($parseFile['extension']);
              $praseFile->setStatus(1);
              $this->parseFileRepository->commit($praseFile);
            }

            return $this->responseArray;
          }
        } else {

          if (!file_exists($storeFileJson)) {
            $this->responseArray['error'] = 'File is not exists';
            return $this->responseArray;
          } else {
            $this->parseFileRepository->deleteById($parseFileDetail['id']);
          }
        }

        $resumeId = $this->processResume($candidateId, $storeFileJson);

      } else {
        $resumeId = $resume['id'];
      }

      if ($resumeId > 0) {
        $this->responseArray['candidate_id'] = $candidateId;
        $this->responseArray['resume_id'] = $resumeId;

        $this->responseArray['resume'] = $this->findResumeDetail($resumeId);
      }

      unset($file);
      unset($candidateId);
      unset($this->path);
      unset($parseFile);
      unset($fileName);
      unset($storeFile);
      unset($storeFileJson);
      unset($resumeId);

      return $this->responseArray;
    }

    public function startParseProcessForCli($file = '', $candidateId = 0) {
      $this->responseArray = $educationAndTraining = $skill = $experience = array();
      $parseFile = pathinfo($file);
      $this->responseArray['file'] = $parseFile;
      $parseFileDetail = array();

      if (!in_array(strtolower($parseFile['extension']), array("pdf", "doc", "docx", "rtf", "html", "txt", "json"))) {
        $this->responseArray['error'] = 'file is not valid';
        return $this->responseArray;
      }
      $resume = $this->resumeRepository->findByFileName(strtolower($parseFile['basename']));

      if (count($resume) == 0) {
        $fileName = $parseFile['basename'];
        $storeFile = $this->path.'/'.$fileName;
        $storeFileJson = $this->path.'/'.$parseFile['filename'].'.json';

        if ($this->onlyMigrate == true) {
          $parseFileDetail = $this->parseFileRepository->findByfilePath($storeFileJson);

          if ($parseFileDetail['extension'] != '') {
            $parseFileDetailArray = pathinfo($parseFileDetail['filePath']);
            $sourceFile = $parseFileDetailArray['dirname'].'/'.$parseFileDetailArray['filename'].'.'.$parseFileDetail['extension'];

            $this->responseArray['file']['original_filename'] = $parseFileDetailArray['filename'].'.'.$parseFileDetail['extension'];
          }

        }

        if (count($parseFileDetail) == 0) {

          if ($file != $storeFile) {
              exec("mv '$file' '$storeFile'");
          }

          exec('cd '.$this->container->getParameter('kernel.root_dir') .'/../library/ResumeTransducer && java -cp \'bin/*:../GATEFiles/lib/*:../GATEFiles/bin/gate.jar:lib/*\' code4goal.antony.resumeparser.ResumeParserProgram  \''.$storeFile.'\'  \''.$storeFileJson.'\'');

          if ($this->onlyPrase == true) {
            $this->responseArray['candidate_id'] = $candidateId;
            $this->responseArray['store_file_json'] = $storeFileJson;

            $praseFile = new ParseFile();
            $praseFile->setCandidateId($candidateId);
            $praseFile->setFilePath($storeFileJson);
            $praseFile->setExtension($parseFile['extension']);

            if (file_exists($storeFileJson)) {
              $praseFile->setStatus(1);
            } else {
              $praseFile->setStatus(0);
            }

            $this->parseFileRepository->commit($praseFile);

            return $this->responseArray;
          }
        } else {

          if (!file_exists($storeFileJson)) {
            $this->responseArray['error'] = 'File is not exists';
            return $this->responseArray;
          } else {
            $this->parseFileRepository->deleteById($parseFileDetail['id']);
          }
        }

        $resumeId = $this->processResume($candidateId, $storeFileJson);

      } else {
        $resumeId = $resume['id'];

        if ($this->onlyMigrate == true) {
          $parseFileDetail = $this->parseFileRepository->findByfilePath($file);

          if (count($parseFileDetail) > 0) {
            $this->parseFileRepository->deleteById($parseFileDetail['id']);
          }
        }
      }

      if ($resumeId > 0) {
        $this->responseArray['candidate_id'] = $candidateId;
        $this->responseArray['resume_id'] = $resumeId;

        $this->responseArray['resume'] = $this->findResumeDetail($resumeId);
      }

      unset($file);
      unset($candidateId);
      unset($this->path);
      unset($parseFile);
      unset($fileName);
      unset($storeFile);
      unset($storeFileJson);
      unset($resumeId);

      return $this->responseArray;
    }

    public function findResumeDetail($resumeId) {
      $return = array('education_and_training' => array(), 'skill' => array(), 'experience' => array() );

      foreach ($this->educationAndTrainingRepository->findByResume($resumeId) as $key => $value) {
          $return['education_and_training'][$value->getMetaKey()] = $value->getMetaValue();
      }

      foreach ($this->skillRepository->findByResume($resumeId) as $key => $value) {
          $return['skill'][$value->getMetaKey()] = $value->getMetaValue();
      }

      foreach ($this->experienceRepository->findByResume($resumeId) as $key => $value) {
          $return['experience'][$key]['jobtitle'] = $value->getJobtitle();
          $return['experience'][$key]['organization'] = $value->getOrganization();
          $return['experience'][$key]['punctuation'] = $value->getPunctuation();
          $return['experience'][$key]['date_start'] = $value->getDateStart();
          $return['experience'][$key]['date_end'] = $value->getDateEnd();
          $return['experience'][$key]['total_experience'] = $value->getTotalExperience();
          $return['experience'][$key]['total_experience_text'] = $value->getTotalExperienceText();
          $return['experience'][$key]['text_detail'] = $value->getTextDetail();
      }

      return $return;

    }

    public function repairExperience() {
      $return = array('status'=>'success');
      $resumeId = trim($this->request->get('resume_id'));

      if ($resumeId == 0) {
          $experienceArray = $this->experienceRepository->findLessThantotalExperience($resumeId);
      } else {
          $experienceArray = $this->experienceRepository->findByResume($resumeId);
      }

      foreach ($experienceArray as $key => $experience) {
          $calculateExperience = $this->calculateExperience($experience->getDateStart(), $experience->getDateEnd());

          $experience->setTotalExperience($calculateExperience['total_experience']);
          $experience->setTotalExperienceText($calculateExperience['total_experience_text']);
          $this->experienceRepository->commit($experience);
        }

      unset($resumeId);
      unset($experienceArray);
      unset($calculateExperience);

      return $return;
    }

    public function findResumeByCandiateId() {
      $this->responseArray = array();
      $candidateId = trim($this->request->get('candidate_id'));

      $resumeList = $this->resumeRepository->findByCandidateId($candidateId);

      foreach ($resumeList as $key => $resume) {
          $this->responseArray[$resume->getId()] = $this->findResumeDetail($resume->getId());
      }

      unset($candidateId);
      unset($resumeList);

      return $this->responseArray;
    }

    private function processResume($candidateId, $storeFileJson) {
        $parseData = file_get_contents($storeFileJson);

        if ($parseData == '{}') {
          return 0;
        }

        $resume = new Resume();
        $resume->setCandidateId($candidateId);
        $resume->setParseData('');
        $resume->setCreatedAt(new \DateTime());
        $resume->setFileName(strtolower($this->responseArray['file']['basename']));
        $this->resumeRepository->commit($resume);

        $fileName = $this->responseArray['file']['filename'].'.'.$this->responseArray['file']['extension'];

        if (isset($this->responseArray['file']['original_filename'])) {
          $fileName = $this->responseArray['file']['original_filename'].'.'.$this->responseArray['file']['extension'];
        }

        $this->addResumeDetailToMongo($candidateId, $resume->getId(), $parseData, $fileName);

        $parseData = json_decode($parseData, true);

        if (isset($parseData['education_and_training'])) {
            foreach ($parseData['education_and_training'] as $key => $value) {
                $educationAndTraining = new EducationAndTraining();
                $educationAndTraining->setResume($resume);
                $educationAndTraining->setMetaKey(trim(preg_replace('/\r\n|\r|\n/', ' ', key($value))));
                $educationAndTraining->setMetaValue(trim(current($value)));
                $this->educationAndTrainingRepository->commit($educationAndTraining);
            }
        }

        if (isset($parseData['skills'])) {
            foreach ($parseData['skills'] as $key => $value) {
                $skill = new Skill();
                $skill->setResume($resume);
                $skill->setMetaKey(trim(preg_replace('/\r\n|\r|\n/', ' ', key($value))));
                $skill->setMetaValue(trim(current($value)));
                $this->skillRepository->commit($skill);
            }
        }

        if (isset($parseData['work_experience'])) {
            foreach ($parseData['work_experience'] as $key => $experienceDetail) {

                if (isset($experienceDetail['date_start']) || isset($experienceDetail['date_end']) || isset($experienceDetail['jobtitle']) || isset($experienceDetail['text']) || isset($experienceDetail['organization']) || isset($experienceDetail['punctuation'])) {
                    $experience = new Experience();
                    $experience->setResume($resume);

                    if (isset($experienceDetail['jobtitle'])) {
                        $experience->setJobtitle(trim($experienceDetail['jobtitle']));
                    }

                    if (isset($experienceDetail['organization'])) {
                        $experience->setOrganization(trim($experienceDetail['organization']));
                    }

                    if (isset($experienceDetail['punctuation'])) {
                        $experience->setPunctuation(trim($experienceDetail['punctuation']));
                    }

                    if (isset($experienceDetail['date_start'])) {
                        $experience->setDateStart(trim($experienceDetail['date_start']));
                    }

                    if (isset($experienceDetail['date_end'])) {
                        $experience->setDateEnd(trim($experienceDetail['date_end']));
                    }

                    if (isset($experienceDetail['text'])) {
                        $experience->setTextDetail(trim($experienceDetail['text']));
                    }

                    $calculateExperience = $this->calculateExperience($experience->getDateStart(), $experience->getDateEnd());

                    $experience->setTotalExperience($calculateExperience['total_experience']);
                    $experience->setTotalExperienceText($calculateExperience['total_experience_text']);

                    $this->experienceRepository->commit($experience);
                }
            }
        }

        unset($parseData);

        return $resume->getId();
    }

    public function converResumeToCandidate($file = '', $candidateId = 0) {

      if ($file != '') {
          $this->startParseProcessForCli($file, $candidateId);
      } else {
          $this->startParseProcess();
      }

      if (isset($this->responseArray['resume_id'])) {
        $resume = $this->resumeRepository->findById($this->responseArray['resume_id']);
        $resumeDetail = $this->resumeDetailRepository->findOneByProperty('resumeId', $resume->getId());

        if (count($resumeDetail) == 0) {
          return "Error : Please check in Mongo DB Resume data";
        }

        $parseData = json_decode($resumeDetail->getParseData(), 'ARRAY');

        if ($parseData['basics']) {
          $this->responseArray['resume']['basics'] = $parseData['basics'];

          $this->catsDatabase = $this->container->get('v_tech_solution_resume_parse.cats')->getPDO();

          $firstName = $middleName = $lastName = $phoneHome = $email11 = $phoneCell = $gender = $ratemin1 = $ratemax1 = $cityy = $state11 = $zip11 = $reloc2 = $empname11 = $web2 = $ratemin1 = $ratemax1 = $add = $keySkill = '';
          $usid1 = 1;
          $currentDate = date('Y-m-d h:i:s a', time());
          $allowToAddCandidate = $isName = $isPhone = $isEmail = 0;

          if (isset($parseData['basics']['gender'])) {
            $gender = strtolower($parseData['basics']['gender']) == 'male' ? 'M' : 'F';
          }

          if (isset($parseData['basics']['phone'])) {
            $phone = $parseData['basics']['phone'];
            $phoneHome = addslashes($phone['0']);
            $isPhone = 1;

            if (isset($phone['1'])) {
                $phoneCell = addslashes($phone['1']);
            }
          }

          if (isset($parseData['basics']['name'])) {
            if (isset($parseData['basics']['name']['firstName'])) {
                $firstName = addslashes($parseData['basics']['name']['firstName']);
                $isName = 1;
            }

            if (isset($parseData['basics']['name']['middleName'])) {
              $middleName = addslashes($parseData['basics']['name']['middleName']);
              $isName = 1;
            }

            if (isset($parseData['basics']['name']['surname'])) {
                $lastName = addslashes($parseData['basics']['name']['surname']);
                $isName = 1;
            }
          }

          if (isset($parseData['basics']['email'][0])) {
            $email11 = addslashes(strtolower($parseData['basics']['email'][0]));
            $isEmail = 1;
          }

          if (isset($parseData['basics']['address'])) {
            $add = addslashes(implode(',',$parseData['basics']['address']));
          }

          if (isset($parseData['skills']['0'])) {
            foreach ($parseData['skills']['0'] as $skill) {
                $keySkill = $keySkill .' '.$skill;
            }
            $keySkill = addslashes(trim(str_replace('?', '', str_ireplace("'", '',$keySkill))));

            if (strlen($keySkill) > 500) {
              $keySkill = addslashes(str_ireplace("?", "", str_ireplace("'", '', substr($keySkill, 0, 500))));
            }
          }

          $this->responseArray['candidate_id'] = $resume->getCandidateId();

          if ($isName == 1 && ($isPhone == 1 || $isEmail == 1)) {

            $query = 'SELECT count(candidate_id) as total_candidate FROM `candidate` WHERE';

            if ($isEmail == 1) {
              $query = $query ." `email1` LIKE '".$email11."' OR `email2` LIKE '".$email11."'";
            }

            if ($isEmail == 1 && $isPhone == 1) {
              $query = $query ." OR ";
            }

            if ($isPhone == 1) {
              $query = $query ." `phone_home` LIKE '".$phoneHome."' OR `phone_cell` LIKE '".$phoneHome."' OR `phone_work` LIKE '".$phoneHome."'";
            }

            $isCandiate = $this->catsDatabase->query($query)->fetchColumn(0);

            if ($isCandiate == 0) {
              $allowToAddCandidate = 1;
            }
          }

          if ($allowToAddCandidate == 1 && $resume->getCandidateId() == 0) {
                $candidateId = $this->addCandidateInATS($parseData, $this->catsDatabase);
                $originalFileName = $this->responseArray['file']['filename'];
                $fileName = $this->responseArray['file']['basename'];

                if (isset($this->responseArray['file']['original_filename']) && $this->responseArray['file']['original_filename'] != '') {
                  $fileName = $this->responseArray['file']['original_filename'];
                }

                $this->addAttachmentToCandidateById($candidateId, $fileName, $this->catsDatabase);

                $resume->setCandidateId($candidateId);
                $this->resumeRepository->commit($resume);

                $resumeDetail->setCandidateId($candidateId);

                $this->resumeDetailRepository->commit($resumeDetail);

                $this->responseArray['candidate_id'] = $candidateId;
            } else {
              $this->educationAndTrainingRepository->deleteByResumeId($this->responseArray['resume_id']);
              $this->experienceRepository->deleteByResumeId($this->responseArray['resume_id']);
              $this->skillRepository->deleteByResumeId($this->responseArray['resume_id']);
              $this->resumeRepository->deleteById($this->responseArray['resume_id']);

            }
        }
      }

      return $this->responseArray;
    }

    public function deleteExtraParse() {
      $return['total_delete'] = $this->resumeRepository->deleteByCandiateId(0);
    }

    public function migrateResumeDetailToMongoDb(){
      foreach($this->resumeRepository->findReadyForMigrateToMongoDB() as $resume) {
        if ($resume['parseData'] != '') {
            $resumeDetail = $this->resumeDetailRepository->findOneByProperty('resumeId', $resume['id']);

            if (count($resumeDetail) == 0) {
                echo 'Migrated Resume Id: '.$resume['id'];
                $this->addResumeDetailToMongo($resume['candidateId'], $resume['id'], $resume['parseData'], '');
            }
          }
      }
    }

    public function addResumeDetailToMongo($candidateId, $resumeId, $parseData, $file) {
      $resumeDetail = new ResumeDetail();
      $resumeDetail->setCandidateId($candidateId);
      $resumeDetail->setResumeId($resumeId);
      $resumeDetail->setParseData($parseData);
      $resumeDetail->setFile($file);
      $resumeDetail->setCreatedAt(new \DateTime());
      $resumeDetail->setUpdatedAt(new \DateTime());
      $this->resumeDetailRepository->commit($resumeDetail);
    }

    private function calculateExperience($dateStart, $dateEnd) {
      $return = array('total_experience' => 0, 'total_experience_text' => '');

      $dateStartSplit = explode('-', $dateStart);
      $dateEndSplit = explode('-', $dateEnd);

      if (count($dateStartSplit) == 1 && count($dateEndSplit) == 1) {
        $dateStartSplit = explode('/', $dateStart);
        $dateEndSplit = explode('/', $dateEnd);

        if (count($dateStartSplit) == 2 && count($dateEndSplit) == 2) {
          if ($dateStartSplit[0] > 12 && $dateEndSplit[0] > 12) {
            $dateStartSplit = array_reverse($dateStartSplit);
            $dateEndSplit = array_reverse($dateEndSplit);
          }
        }
      }

      if (count($dateStartSplit) == 2 && count($dateEndSplit) == 2) {
        $totalExperience = (int)$dateEndSplit[1] - (int)$dateStartSplit[1];

        $return['total_experience'] = $totalExperience;
        $return['total_experience_text'] = $totalExperience. ' Year Experience';

      } elseif (count($dateStartSplit) > 1) {
        $totalExperience = (int)$dateStartSplit[1] - (int)$dateStartSplit[0];

        $return['total_experience'] = $totalExperience;
        $return['total_experience_text'] = $totalExperience. ' Year Experience';

      } elseif(count($dateStartSplit) == 1 && is_numeric($dateStartSplit[0])) {
          $totalExperience = (int)date("Y") - (int)$dateStartSplit[0];

          $return['total_experience'] = $totalExperience;
          $return['total_experience_text'] = 'More Than '.$totalExperience. ' Year'.($totalExperience > 1 ? 's' :'').' Experience and Present';

      } elseif ($dateStart != '' && $dateEnd != '') {
          $diff = abs(strtotime($dateEnd) - strtotime($dateStart));

          $years = floor($diff / (365*60*60*24));
          $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24));

          $return['total_experience'] = $years;
          $return['total_experience_text'] = $years. ' Year'.($years > 1 ? 's' :'').' And '.$months.' Months Experience';
      }

      if ($return['total_experience'] < 0) {
        $return['total_experience'] = 0;
        $return['total_experience_text'] = '';
      }

      return $return;
    }

    public function isValidResume($resumeBasics, $mongoDocument, $catsDatabase) {
      $return = false;
      $isEmail = $isPhone = 0;
      $email11 = $phoneHome = '';
      $this->catsDatabase = $catsDatabase;

      if (
          (isset($resumeBasics['name']) && (isset($resumeBasics['name']['firstName']) || isset($resumeBasics['name']['middleName']) || isset($resumeBasics['name']['surname']))) &&
          (isset($resumeBasics['email'][0]) || isset($resumeBasics['phone'][0]))
        ) {
        $return = true;
      }

      if ($return) {

        if (isset($resumeBasics['email'][0])) {
          $email11 = addslashes(strtolower($resumeBasics['email'][0]));
          $isEmail = 1;
        }

        if (isset($resumeBasics['phone'])) {
          $phone = $resumeBasics['phone'];
          $phoneHome = addslashes($phone['0']);
          $isPhone = 1;
        }
        $query = 'SELECT candidate_id as total_candidate FROM `candidate` WHERE';

        if ($isEmail == 1) {
          $query = $query ." `email1` LIKE '".$email11."' OR `email2` LIKE '".$email11."'";
        }

        if ($isEmail == 1 && $isPhone == 1) {
          $query = $query ." OR ";
        }

        if ($isPhone == 1) {
          $query = $query ." `phone_home` LIKE '".$phoneHome."' OR `phone_cell` LIKE '".$phoneHome."' OR `phone_work` LIKE '".$phoneHome."'";
        }

        $query = $query ." limit 1";

        $candiateId = $this->catsDatabase->query($query)->fetchColumn(0);

        if ($candiateId != '') {
          $resumeDetail = $this->resumeDetailRepository->findOneByProperty('candidateId', (int)$candiateId);

          if (count($resumeDetail) > 0) {
            //delete Duplicate Data
            $this->resumeDetailRepository->deleteByObject($mongoDocument);
          } else {
            //set Candidate in Document
            $mongoDocument->setCandidateId($candiateId);

            $this->resumeDetailRepository->commit($mongoDocument);
          }
          $return = false;
        } else {
          $return = true;
        }
      }

      return $return;
    }

    public function addCandidateInATS($parseData, $catsDatabase) {
      $firstName = $middleName = $lastName = $phoneHome = $email11 = $phoneCell = $phoneWork = $gender = $ratemin1 = $ratemax1 = $cityy = $state11 = $zip11 = $reloc2 = $empname11 = $web2 = $ratemin1 = $ratemax1 = $add = $keySkill = $dateAvailable = $notes = $enteredBy = $importId = $isHot = $eeoEthnicTypeId = $eeoVeteranTypeId = $eeoDisabilityStatus = $bestTimeToCall = '';
      $usid1 = $siteId = 1;
      $source = "vTech DataBase";
      $currentDate = date('Y-m-d h:i:s a', time());
      $isActive = 1;
      $isadminHidden = 0;

      if (isset($parseData['basics']['gender'])) {
        $gender = strtolower($parseData['basics']['gender']) == 'male' ? 'M' : 'F';
      }

      if (isset($parseData['basics']['phone'])) {
        $phone = $parseData['basics']['phone'];
        $phoneHome = addslashes($phone['0']);
        $isPhone = 1;

        if (isset($phone['1'])) {
            $phoneCell = addslashes($phone['1']);
        }
      }

      if (isset($parseData['basics']['name'])) {
        if (isset($parseData['basics']['name']['firstName'])) {
            $firstName = addslashes($parseData['basics']['name']['firstName']);
            $isName = 1;
        }

        if (isset($parseData['basics']['name']['middleName'])) {
          $middleName = addslashes($parseData['basics']['name']['middleName']);
          $isName = 1;
        }

        if (isset($parseData['basics']['name']['surname'])) {
            $lastName = addslashes($parseData['basics']['name']['surname']);
            $isName = 1;
        }
      }

      if (isset($parseData['basics']['email'][0])) {
        $email11 = addslashes(strtolower($parseData['basics']['email'][0]));
        $isEmail = 1;
      }

      if (isset($parseData['basics']['address'])) {
        $add = addslashes(implode(',',$parseData['basics']['address']));
      }

      if (isset($parseData['skills']['0'])) {
        foreach ($parseData['skills']['0'] as $skill) {
            $keySkill = $keySkill .' '.$skill;
        }
        $keySkill = addslashes(trim(str_replace('?', '', str_ireplace("'", '',$keySkill))));

        if (strlen($keySkill) > 500) {
          $keySkill = addslashes(str_ireplace("?", "", str_ireplace("'", '', substr($keySkill, 0, 500))));
        }
      }
      $this->catsDatabase = $catsDatabase;

      $candidate = $this->catsDatabase->prepare(
                      "INSERT INTO candidate (
                          site_id, last_name, first_name, middle_name, phone_home, phone_cell, phone_work,
                          address, city, state, zip, source, date_available, can_relocate, notes, key_skills,
                          current_employer, entered_by, owner, date_created, date_modified, email1, email2,
                          web_site, import_id, is_hot, eeo_ethnic_type_id, eeo_veteran_type_id, eeo_disability_status,
                          eeo_gender, desired_pay, current_pay, is_active, is_admin_hidden, best_time_to_call)
                          VALUES
                          (:site_id, :last_name, :first_name, :middle_name, :phone_home, :phone_cell, :phone_work,
                           :address, :city, :state, :zip, :source, :date_available, :can_relocate, :notes, :key_skills,
                           :current_employer, :entered_by, :owner, :date_created, :date_modified, :email1, :email2,
                           :web_site, :import_id, :is_hot, :eeo_ethnic_type_id, :eeo_veteran_type_id, :eeo_disability_status,
                           :eeo_gender, :desired_pay, :current_pay, :is_active, :is_admin_hidden, :best_time_to_call)"
                  );

        $candidate->bindParam(':site_id', $siteId);
        $candidate->bindParam(':last_name', $lastName);
        $candidate->bindParam(':first_name', $firstName);
        $candidate->bindParam(':middle_name', $middleName);
        $candidate->bindParam(':phone_home', $phoneHome);
        $candidate->bindParam(':phone_cell', $phoneCell);
        $candidate->bindParam(':phone_work', $phoneWork);
        $candidate->bindParam(':address', $add);
        $candidate->bindParam(':city', $cityy);
        $candidate->bindParam(':state', $state11);
        $candidate->bindParam(':zip', $zip11);
        $candidate->bindParam(':source', $source);
        $candidate->bindParam(':date_available', $dateAvailable);
        $candidate->bindParam(':can_relocate', $reloc2);
        $candidate->bindParam(':notes', $notes);
        $candidate->bindParam(':key_skills', $keySkill);
        $candidate->bindParam(':current_employer', $empname11);
        $candidate->bindParam(':entered_by', $enteredBy);
        $candidate->bindParam(':owner', $usid1);
        $candidate->bindParam(':date_created', $currentDate);
        $candidate->bindParam(':date_modified', $currentDate);
        $candidate->bindParam(':email1', $email11);
        $candidate->bindParam(':email2', $email11);
        $candidate->bindParam(':web_site', $web2);
        $candidate->bindParam(':import_id', $importId);
        $candidate->bindParam(':is_hot', $isHot);
        $candidate->bindParam(':eeo_ethnic_type_id', $eeoEthnicTypeId);
        $candidate->bindParam(':eeo_veteran_type_id', $eeoVeteranTypeId);
        $candidate->bindParam(':eeo_disability_status', $eeoDisabilityStatus);
        $candidate->bindParam(':eeo_gender', $gender);
        $candidate->bindParam(':desired_pay', $ratemin1);
        $candidate->bindParam(':current_pay', $ratemax1);
        $candidate->bindParam(':is_active', $isActive);
        $candidate->bindParam(':is_admin_hidden', $isadminHidden);
        $candidate->bindParam(':best_time_to_call', $bestTimeToCall);

        $candidate->execute();

        return $this->catsDatabase->lastInsertId();
    }

    public function addAttachmentToCandidateById($candidateId, $fileDetail, $catsDatabase) {
      $dataItemType = 100;
      $siteId = 1;
      $contentType = 'application/msword';
      $resume = '1';
      $text = '';
      $profileImage = 0;
      $md5Sum = '';
      $file = pathinfo($fileDetail);
      $originalFileName =   $file['filename'];
      $fileName = $file['basename'];
      $fileSizeKb = '50';
      $md5SumText = '';
      $currentDate = date('Y-m-d h:i:s a', time());

      $this->catsDatabase = $catsDatabase;

      $dir1 = "site_201/vtech_database/" . $fileName;

      $attachment = $this->catsDatabase->prepare(
                        'INSERT INTO attachment
                          (data_item_id, data_item_type, site_id, title, original_filename, stored_filename,
                           content_type, resume, text, profile_image, directory_name, md5_sum, file_size_kb,
                           md5_sum_text, date_created, date_modified
                         ) VALUES
                         (:data_item_id, :data_item_type, :site_id, :title, :original_filename, :stored_filename,
                           :content_type, :resume, :text, :profile_image, :directory_name, :md5_sum, :file_size_kb,
                           :md5_sum_text, :date_created, :date_modified)'
                      );

      $attachment->bindParam(':data_item_id', $candidateId);
      $attachment->bindParam(':data_item_type', $dataItemType);
      $attachment->bindParam(':site_id', $siteId);
      $attachment->bindParam(':title', $originalFileName);
      $attachment->bindParam(':original_filename', $fileName);
      $attachment->bindParam(':stored_filename', $dir1);
      $attachment->bindParam(':content_type', $contentType);
      $attachment->bindParam(':resume', $resume);
      $attachment->bindParam(':text', $text);
      $attachment->bindParam(':profile_image', $profileImage);
      $attachment->bindParam(':directory_name', $dir1);
      $attachment->bindParam(':md5_sum', $md5Sum);
      $attachment->bindParam(':file_size_kb', $fileSizeKb);
      $attachment->bindParam(':md5_sum_text', $md5SumText);
      $attachment->bindParam(':date_created', $currentDate);
      $attachment->bindParam(':date_modified', $currentDate);

      $attachment->execute();
    }


    public function addParseFile($parseFileDetail) {
      $praseFile = new ParseFile();
      $praseFile->setCandidateId($parseFileDetail['candidate_id']);
      $praseFile->setFilePath($parseFileDetail['file_path']);
      $praseFile->setExtension($parseFileDetail['extension']);
      $praseFile->setStatus($parseFileDetail['status']);
      $this->parseFileRepository->commit($praseFile);
    }

    public function parseFileByContent() {

      if ($this->request->get('file') == '' || $this->request->get('file') == 'filelist.txt') {
        return array();
      }

        $content = $this->request->getContent();

      $fileDetail = $this->path.'/'.$this->request->get('file');
      $file = fopen($fileDetail,"w");
      fwrite($file, $content);
      fclose($file);

      $parseFromShareDrive = $this->addParseFromShareDriveMongo(0, $fileDetail);

      $return =  $this->converResumeToCandidate($fileDetail, 0);

      if (isset($return['candidate_id'])) {
        $candiateId = $return['candidate_id'];
      }

      if (($this->request->get('user_name') != NULL || $this->request->get('user_name') != '') && ($candiateId > 0)) {

          $ownerName = $this->request->get('user_name');
          $ownerNL = substr($ownerName, 0, -2);
          $ownerND = str_replace(".","",$ownerName);
          $ownerFC = ucfirst($ownerName);
          $ownerLC = strrev(ucfirst(strrev($ownerFC)));
          $ownerNDFC = ucfirst($ownerND);
          $ownerQuery = $this->catsDatabase->prepare("SELECT user_id FROM `user` WHERE `access_level` != 0 AND `user_name` IN ('".$ownerName."', '".$ownerNL."', '".$ownerFC."', '".$ownerND."', '".$ownerLC."', '".$ownerNDFC."') ");
          $ownerQuery->execute();
          $ownerId = $ownerQuery->fetchColumn();
          if($ownerId != NULL || $ownerId != '') {
            $candidateOwnerUpdate = $this->catsDatabase->prepare("UPDATE candidate SET owner = '".$ownerId."' WHERE candidate_id='".$candiateId."'");
            $candidateOwnerUpdate->execute();
          }
      }

      $parseFromShareDrive->setCandidateId($candiateId);
      $this->parseFromShareDriveRepository->commit($parseFromShareDrive);

      if ($candiateId > 0) {
        $this->fileTransterToATSServer($fileDetail);
      }

      if ($this->request->get('only_candidate_id') == 1 ) {
        if($candiateId > 0) {
            $return = $candiateId;
        }
         else{
           $return = null;
        }
        }
      return $return;
    }

    public function addParseFromShareDriveMongo($candidateId, $file) {
      $parseFromShareDrive = new ParseFromShareDrive();
      $parseFromShareDrive->setCandidateId($candidateId);
      $parseFromShareDrive->setFile($file);
      $parseFromShareDrive->setCreatedAt(new \DateTime());
      $parseFromShareDrive->setUpdatedAt(new \DateTime());
      return $this->parseFromShareDriveRepository->commit($parseFromShareDrive);
    }

    public function fileTransterToATSServer($file) {
      $atsServer = $this->container->getParameter('ats_server');
      $connection = ssh2_connect($atsServer['domain'], $atsServer['port']) or die('Error: ssh2_connect');
      ssh2_auth_password($connection, $atsServer['username'], $atsServer['password']) or die('Error: ssh2_auth_password');
      $parseFile = pathinfo($file);

      ssh2_scp_send($connection, $file, $atsServer['vtech_database_path'].$parseFile['basename'], 0644) or die('q233123');
    }
}

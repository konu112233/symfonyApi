<?php

namespace vTechSolution\Bundle\ResumeParseBundle\Document;

use Doctrine\ODM\MongoDB\Mapping\Annotations as MongoDB;

/**
 * @MongoDB\Document(repositoryClass="vTechSolution\Bundle\ResumeParseBundle\Document\ResumeDetailRepository")
 */
class ResumeDetail
{
    /**
    * @MongoDB\Id
    */
    protected $id;

    /**
    * @MongoDB\Field(type="integer")
    */
    protected $candidateId;

    /**
    * @MongoDB\Field(type="integer")
    */
    protected $resumeId;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $parseData;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $file;

    /**
     * @MongoDB\Date
     */
    protected $createdAt;

    /**
     * @MongoDB\Date
     */
    protected $updatedAt;

    /**
     * Get id
     *
     * @return id $id
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set resumeId
     *
     * @param integer $resumeId
     * @return $this
     */
    public function setResumeId($resumeId)
    {
        $this->resumeId = $resumeId;
        return $this;
    }

    /**
     * Get resumeId
     *
     * @return integer $resumeId
     */
    public function getResumeId()
    {
        return $this->resumeId;
    }

    /**
     * Set parseData
     *
     * @param string $parseData
     * @return $this
     */
    public function setParseData($parseData)
    {
        $this->parseData = $parseData;
        return $this;
    }

    /**
     * Get parseData
     *
     * @return string $parseData
     */
    public function getParseData()
    {
        return $this->parseData;
    }

    /**
     * Set file
     *
     * @param string $file
     * @return $this
     */
    public function setFile($file)
    {
        $this->file = $file;
        return $this;
    }

    /**
     * Get file
     *
     * @return string $file
     */
    public function getFile()
    {
        return $this->file;
    }

    /**
     * Set createdAt
     *
     * @param timestamp $createdAt
     * @return $this
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
        return $this;
    }

    /**
     * Get createdAt
     *
     * @return timestamp $createdAt
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set updatedAt
     *
     * @param timestamp $updatedAt
     * @return $this
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;
        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return timestamp $updatedAt
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    /**
     * Set candidateId
     *
     * @param integer $candidateId
     * @return $this
     */
    public function setCandidateId($candidateId)
    {
        $this->candidateId = $candidateId;
        return $this;
    }

    /**
     * Get candidateId
     *
     * @return integer $candidateId
     */
    public function getCandidateId()
    {
        return $this->candidateId;
    }

    /**
     * @MongoDB\PrePersist
     */
    public function onPrePersist()
    {
        $this->createdAt = new DateTime();
    }

    /**
     * @MongoDB\PreUpdate
     */
    public function onPreUpdate()
    {
        $this->updatedAt = new DateTime();
    }
}

<?php

namespace vTechSolution\Bundle\ResumeParseBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\JsonResponse;
use Nelmio\ApiDocBundle\Annotation\ApiDoc;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;

/**
 * @Route("/api/v1/resume")
 */
class ResumeParseController extends Controller
{
  private $responseArray;
  private $request;
  private $parseService;

  private function initAction(){
    $this->responseArray = array();
    $this->request = $this->getRequest();

    $this->parseService = $this->get('v_tech_solution_resume_parse.parse');
  }

  /**
   * @ApiDoc(
   *  resource="Resume Parse By File",
   *  section="Resume Parse",
   *  description="This API Is Use For Parse Resume By URl",
   *  filters={
   *      {"name"="file", "dataType"="string"},
   *      {"name"="candidate_id", "dataType"="integer"}
   *  },
   * statusCodes={
     *         200="Returned when successful",
     *         403="Returned when the user is not authorized to say hello",
     *         404={
     *           "Returned when something else is not found"
     *         }
     *     }
   * )
   * @Route("/parse", name="vtech_solution_bundle_resume_parse")
   * @Method({"GET"})
   */
  public function parseAction()
  {
      $this->initAction();

      $this->responseArray = $this->parseService->startParseProcess();

      return new JsonResponse($this->responseArray);
  }

  /**
   * @ApiDoc(
   *  resource="Get Parse Resume By Candidate Id",
   *  section="Resume Parse",
   *  description="This API Is Use For Get Parse Resume Data By Candidate Id",
   *  filters={
   *      {"name"="candidate_id", "dataType"="integer"}
   *  },
   * statusCodes={
     *         200="Returned when successful",
     *         403="Returned when the user is not authorized to say hello",
     *         404={
     *           "Returned when something else is not found"
     *         }
     *     }
   * )
   * @Route("/by-candidate-id", name="vtech_solution_bundle_resume_by_candidate_id")
   * @Method({"GET"})
   */
  public function byCandidateIdAction()
  {
      $this->initAction();

      $this->responseArray = $this->parseService->findResumeByCandiateId();

      return new JsonResponse($this->responseArray);
  }

  /**
   * @ApiDoc(
   *  resource="Repair Experience By Resume Id",
   *  section="Resume Parse",
   *  description="This API Is Use For Repair Experience Data By Resume Id",
   *  filters={
   *      {"name"="resume_id", "dataType"="integer"}
   *  },
   * statusCodes={
     *         200="Returned when successful",
     *         403="Returned when the user is not authorized to say hello",
     *         404={
     *           "Returned when something else is not found"
     *         }
     *     }
   * )
   * @Route("/repair-experience", name="vtech_solution_bundle_resume_repair_experience")
   * @Method({"GET"})
   */
  public function repairExperienceAction()
  {
    $this->initAction();

    $this->responseArray = $this->parseService->repairExperience();

    return new JsonResponse($this->responseArray);
  }

  /**
   * @ApiDoc(
   *  resource="Convert Resume to candidate",
   *  section="Resume Parse",
   *  description="This API Is Use For convert your resume to direct ATS candidate",
   *  filters={
   *      {"name"="file", "dataType"="string"}
   *  },
   * statusCodes={
     *         200="Returned when successful",
     *         403="Returned when the user is not authorized to say hello",
     *         404={
     *           "Returned when something else is not found"
     *         }
     *     }
   * )
   * @Route("/convert-resume-to-candidate", name="vtech_solution_bundle_convert_resume_to_candidate")
   * @Method({"GET"})
   */
  public function convertResumeTocandidateAction()
  {
    $this->initAction();

    $this->responseArray = $this->parseService->converResumeToCandidate();

    return new JsonResponse($this->responseArray);
  }

  /**
   * @Route("/delete-extra-parse", name="vtech_solution_bundle_delete_extra_parse")
   * @Method({"GET"})
   */
  public function deleteExtraParseAction()
  {
    $this->initAction();

    $this->responseArray = $this->parseService->deleteExtraParse();

    return new JsonResponse($this->responseArray);
  }

  /**
   * @Route("/parse-by-file-data", name="vtech_solution_bundle_parse_by_file_data")
   * @Method({"GET", "POST"})
   */
  public function prasebyFileDataAction()
  {
    $this->initAction();

    $this->responseArray = $this->parseService->parseFileByContent();

    return new JsonResponse($this->responseArray);
  }
}

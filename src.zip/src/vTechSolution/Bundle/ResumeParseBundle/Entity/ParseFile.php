<?php

namespace vTechSolution\Bundle\ResumeParseBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * ParseFile
 *
 * @ORM\Table(name="vtech_parse_file")
 * @ORM\Entity(repositoryClass="vTechSolution\Bundle\ResumeParseBundle\Entity\ParseFileRepository")
 */
class ParseFile
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var int
     *
     * @ORM\Column(name="candidate_id", type="integer")
     */
    private $candidateId;

    /**
     * @var string
     *
     * @ORM\Column(name="file_path", type="string", length=1000, nullable=true)
     */
    private $filePath;

    /**
     * @var string
     *
     * @ORM\Column(name="extension", type="string", length=255, nullable=true)
     */
    private $extension;

    /**
     * @var boolean
     *
     * @ORM\Column(name="status", type="boolean", options={"default"=0})
     */
    private $status;



    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set candidateId
     *
     * @param integer $candidateId
     *
     * @return ParseFile
     */
    public function setcandidateId($candidateId)
    {
        $this->candidateId = $candidateId;

        return $this;
    }

    /**
     * Get candidateId
     *
     * @return int
     */
    public function getCandidateId()
    {
        return $this->candidateId;
    }

    /**
     * Set filePath
     *
     * @param string $filePath
     *
     * @return ParseFile
     */
    public function setFilePath($filePath)
    {
        $this->filePath = $filePath;

        return $this;
    }

    /**
     * Get filePath
     *
     * @return string
     */
    public function getFilePath()
    {
        return $this->filePath;
    }

    /**
     * Set extension
     *
     * @param string $extension
     *
     * @return extension
     */
    public function setExtension($extension)
    {
        $this->extension = $extension;

        return $this;
    }

    /**
     * Get extension
     *
     * @return string
     */
    public function getExtension()
    {
        return $this->extension;
    }

    /**
     * Set status
     *
     * @param string $status
     *
     * @return status
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status
     *
     * @return boolean
     */
    public function getStatus()
    {
        return $this->status;
    }
}

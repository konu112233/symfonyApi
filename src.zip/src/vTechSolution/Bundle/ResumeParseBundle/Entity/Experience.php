<?php

namespace vTechSolution\Bundle\ResumeParseBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Experience
 *
 * @ORM\Table(name="vtech_experience")
 * @ORM\Entity(repositoryClass="vTechSolution\Bundle\ResumeParseBundle\Entity\ExperienceRepository")
 */
class Experience
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="Resume", inversedBy="experience")
     * @ORM\JoinColumn(name="resume_id", referencedColumnName="id", onDelete="CASCADE")
     */
    private $resume;

    /**
     * @var string
     *
     * @ORM\Column(name="jobtitle", type="string", length=255, nullable=true)
     */
    private $jobtitle;

    /**
     * @var string
     *
     * @ORM\Column(name="organization", type="string", length=255, nullable=true)
     */
    private $organization;

    /**
     * @var string
     *
     * @ORM\Column(name="punctuation", type="string", length=255, nullable=true)
     */
    private $punctuation;

    /**
     * @var string
     *
     * @ORM\Column(name="date_start", type="string", length=255, nullable=true)
     */
    private $dateStart;

    /**
     * @var string
     *
     * @ORM\Column(name="date_end", type="string", length=255, nullable=true)
     */
    private $dateEnd;

    /**
     * @var int
     *
     * @ORM\Column(name="total_experience", type="integer", nullable=true)
     */
    private $totalExperience;

    /**
     * @var string
     *
     * @ORM\Column(name="total_experience_text", type="string", length=255, nullable=true)
     */
    private $totalExperienceText;

    /**
     * @var string
     *
     * @ORM\Column(name="text_detail", type="text", nullable=true)
     */
    private $textDetail;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set resume
     *
     * @param integer $resume
     *
     * @return Experience
     */
    public function setResume($resume)
    {
        $this->resume = $resume;

        return $this;
    }

    /**
     * Get resume
     *
     * @return int
     */
    public function getResume()
    {
        return $this->resume;
    }

    /**
     * Set jobtitle
     *
     * @param string $jobtitle
     *
     * @return Experience
     */
    public function setJobtitle($jobtitle)
    {
        $this->jobtitle = $jobtitle;

        return $this;
    }

    /**
     * Get jobtitle
     *
     * @return string
     */
    public function getJobtitle()
    {
        return $this->jobtitle;
    }

    /**
     * Set organization
     *
     * @param string $organization
     *
     * @return Experience
     */
    public function setOrganization($organization)
    {
        $this->organization = $organization;

        return $this;
    }

    /**
     * Get organization
     *
     * @return string
     */
    public function getOrganization()
    {
        return $this->organization;
    }

    /**
     * Set punctuation
     *
     * @param string $punctuation
     *
     * @return Experience
     */
    public function setPunctuation($punctuation)
    {
        $this->punctuation = $punctuation;

        return $this;
    }

    /**
     * Get punctuation
     *
     * @return string
     */
    public function getPunctuation()
    {
        return $this->punctuation;
    }

    /**
     * Set dateStart
     *
     * @param string $dateStart
     *
     * @return Experience
     */
    public function setDateStart($dateStart)
    {
        $this->dateStart = $dateStart;

        return $this;
    }

    /**
     * Get dateStart
     *
     * @return string
     */
    public function getDateStart()
    {
        return $this->dateStart;
    }

    /**
     * Set dateEnd
     *
     * @param string $dateEnd
     *
     * @return Experience
     */
    public function setDateEnd($dateEnd)
    {
        $this->dateEnd = $dateEnd;

        return $this;
    }

    /**
     * Get dateEnd
     *
     * @return string
     */
    public function getDateEnd()
    {
        return $this->dateEnd;
    }

    /**
     * Set totalExperience
     *
     * @param integer $totalExperience
     *
     * @return Experience
     */
    public function setTotalExperience($totalExperience)
    {
        $this->totalExperience = $totalExperience;

        return $this;
    }

    /**
     * Get totalExperience
     *
     * @return int
     */
    public function getTotalExperience()
    {
        return $this->totalExperience;
    }

    /**
     * Set totalExperienceText
     *
     * @param string $totalExperienceText
     *
     * @return Experience
     */
    public function setTotalExperienceText($totalExperienceText)
    {
        $this->totalExperienceText = $totalExperienceText;

        return $this;
    }

    /**
     * Get totalExperienceText
     *
     * @return string
     */
    public function getTotalExperienceText()
    {
        return $this->totalExperienceText;
    }

    /**
     * Set textDetail
     *
     * @param string $textDetail
     *
     * @return Experience
     */
    public function setTextDetail($textDetail)
    {
        $this->textDetail = $textDetail;

        return $this;
    }

    /**
     * Get textDetail
     *
     * @return string
     */
    public function getTextDetail()
    {
        return $this->textDetail;
    }
}

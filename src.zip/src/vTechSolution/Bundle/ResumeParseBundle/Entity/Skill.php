<?php

namespace vTechSolution\Bundle\ResumeParseBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Skill
 *
 * @ORM\Table(name="vtech_skill")
 * @ORM\Entity(repositoryClass="vTechSolution\Bundle\ResumeParseBundle\Entity\SkillRepository")
 */
class Skill
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="Resume", inversedBy="skill")
     * @ORM\JoinColumn(name="resume_id", referencedColumnName="id", onDelete="CASCADE")
     */
    private $resume;

    /**
     * @var string
     *
     * @ORM\Column(name="meta_key", type="text", nullable=true)
     */
    private $metaKey;

    /**
     * @var string
     *
     * @ORM\Column(name="meta_value", type="text", nullable=true)
     */
    private $metaValue;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set resume
     *
     * @param integer $resume
     *
     * @return Skill
     */
    public function setResume($resume)
    {
        $this->resume = $resume;

        return $this;
    }

    /**
     * Get resume
     *
     * @return int
     */
    public function getResume()
    {
        return $this->resume;
    }

    /**
     * Set metaKey
     *
     * @param string $metaKey
     *
     * @return Skill
     */
    public function setMetaKey($metaKey)
    {
        $this->metaKey = $metaKey;

        return $this;
    }

    /**
     * Get metaKey
     *
     * @return string
     */
    public function getMetaKey()
    {
        return $this->metaKey;
    }

    /**
     * Set metaValue
     *
     * @param string $metaValue
     *
     * @return Skill
     */
    public function setMetaValue($metaValue)
    {
        $this->metaValue = $metaValue;

        return $this;
    }

    /**
     * Get metaValue
     *
     * @return string
     */
    public function getMetaValue()
    {
        return $this->metaValue;
    }
}

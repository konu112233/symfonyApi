<?php

namespace vTechSolution\Bundle\ResumeParseBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
/**
 * Resume
 *
 * @ORM\Table(name="vtech_resume")
 * @ORM\Entity(repositoryClass="vTechSolution\Bundle\ResumeParseBundle\Entity\ResumeRepository")
 */
class Resume
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var int
     *
     * @ORM\Column(name="candidate_id", type="integer", nullable=true)
     */
    private $candidateId;

    /**
     * @var string
     *
     * @ORM\Column(name="parse_data", type="text", nullable=true)
     */
    private $parseData;

    /**
     * @ORM\OneToMany(targetEntity="EducationAndTraining", mappedBy="resume")
     */
    private $educationAndTraining;

    /**
     * @ORM\OneToMany(targetEntity="Skill", mappedBy="resume")
     */
    private $skill;

    /**
     * @ORM\OneToMany(targetEntity="Experience", mappedBy="resume")
     */
    private $experience;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime")
     */
    private $createdAt;

    /**
     * @var string
     *
     * @ORM\Column(name="file_name", type="string", nullable=true)
     */
    private $fileName;

    public function __construct()
    {
        $this->educationAndTraining = new ArrayCollection();
        $this->skill = new ArrayCollection();
        $this->experience = new ArrayCollection();
    }

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set candidateId
     *
     * @param integer $candidateId
     *
     * @return Resume
     */
    public function setCandidateId($candidateId)
    {
        $this->candidateId = $candidateId;

        return $this;
    }

    /**
     * Get candidateId
     *
     * @return int
     */
    public function getCandidateId()
    {
        return $this->candidateId;
    }

    /**
     * Set parseData
     *
     * @param string $parseData
     *
     * @return Resume
     */
    public function setParseData($parseData)
    {
        $this->parseData = $parseData;

        return $this;
    }

    /**
     * Get parseData
     *
     * @return string
     */
    public function getParseData()
    {
        return $this->parseData;
    }

    /**
     * Set educationAndTraining
     *
     * @param array $educationAndTraining
     *
     * @return Resume
     */
    public function setEducationAndTraining(\vTechSolution\Bundle\ResumeParseBundle\Entity\EducationAndTraining $educationAndTraining)
    {
        $this->educationAndTraining[] = $educationAndTraining;

        return $this;
    }

    /**
     * Get educationAndTraining
     *
     * @return array
     */
    public function getEducationAndTraining()
    {
        return $this->educationAndTraining;
    }

    /**
     * Get skill
     *
     * @return array
     */
    public function getSkill()
    {
        return $this->skill;
    }

    /**
     * Get experience
     *
     * @return array
     */
    public function getExperience()
    {
        return $this->experience;
    }
    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     *
     * @return Resume
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set fileName
     *
     * @param string $fileName
     *
     * @return Resume
     */
    public function setFileName($fileName)
    {
        $this->fileName = $fileName;

        return $this;
    }

    /**
     * Get fileName
     *
     * @return string
     */
    public function getFileName()
    {
        return $this->fileName;
    }
}

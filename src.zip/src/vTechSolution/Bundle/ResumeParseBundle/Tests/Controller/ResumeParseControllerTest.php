<?php

namespace vTechSolution\Bundle\ResumeParseBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class ResumeParseControllerTest extends WebTestCase
{
}

<?php

namespace vTechSolution\Bundle\ResumeParseBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class vTechSolutionResumeParseBundle extends Bundle
{
}

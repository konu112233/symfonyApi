<?php

namespace vTechSolution\Bundle\TwilioBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\JsonResponse;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;

/**
   * @Route("/sms/template")
   */

class TemplateController extends Controller
{
    private $responseArray;
    private $request;
    private $screeningService;

    private function initAction()
    {
      $this->responseArray = array();
      $this->request = $this->getRequest();

      $this->textTemplateService = $this->get('v_tech_solution_template.template');
    }

	/**
   * @Route("/list", name="vtech_solution_bundle_twilio_template_list")
   * @Method({"GET"} )
   * @Template("vTechSolutionTwilioBundle:Template:list.html.twig")
   */

	public function TemplateList() {

		$this->initAction();

		$this->responseArray["template"] = $this->textTemplateService->listAll();

		return $this->responseArray;

	}

  /**
   * @Route("/add", name="vtech_solution_bundle_twilio_template_add_form")
   */
  public function addForm()
  {
      return $this->render('vTechSolutionTwilioBundle:Template:new.html.twig');
  }


  /**
   * @Route("/add-data", name="vtech_solution_bundle_twilio_template_add_method")
   * @Method({"POST"} )
   */

  public function addFormInputs() {

    $this->initAction();

    $this->responseArray = $this->textTemplateService->addNew();

    // return new JsonResponse($this->responseArray);
    return $this->redirectToRoute('vtech_solution_bundle_twilio_template_list');
  }

  /**
   * @Route("/{id}", name="vtech_solution_bundle_twilio_template_show")
   * @Method("GET")
   * @Template("vTechSolutionTwilioBundle:Template:show.html.twig")
   */
  public function showAction()
  {
      $this->initAction();

      $this->responseArray['textTemplate'] = $this->textTemplateService->showTemplate();

      return $this->responseArray;
  }

  /**
   * @Route("/edit/{id}", name="vtech_solution_bundle_twilio_template_edit_form")
   * @Method("GET")
   * @Template("vTechSolutionTwilioBundle:Template:edit.html.twig")
   */
  public function editForm()
  {
    $this->initAction();

    $this->responseArray['textTemplate'] = $this->textTemplateService->showTemplate();
    return $this->responseArray;
    //return $this->redirectToRoute('vtech_solution_bundle_twilio_template_edit_form',array('id' => ));
  }


  /**
   * @Route("/edit-data", name="vtech_solution_bundle_twilio_template_edit")
   * @Method({"POST"})
   */
  public function editAction()
  {

      $this->initAction();

      $this->responseArray = $this->textTemplateService->editTemplate();

      return $this->redirectToRoute('vtech_solution_bundle_twilio_template_list');
  }

  /**
   * @Route("/delete/{id}", name="vtech_solution_bundle_twilio_template_delete")
   * @Method("GET")
   */
  public function deleteAction()
  {
      $this->initAction();

      $this->responseArray = $this->textTemplateService->deleteTemplate();

      return $this->redirectToRoute('vtech_solution_bundle_twilio_template_list');
  }

}

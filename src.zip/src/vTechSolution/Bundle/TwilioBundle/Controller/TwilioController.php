<?php

namespace vTechSolution\Bundle\TwilioBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\JsonResponse;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;

/**
   * @Route("/api/v1/twilio")
   */

class TwilioController extends Controller
{
    private $responseArray;
    private $request;
    private $screeningService;

    private function initAction()
    {
      $this->responseArray = array();
      $this->request = $this->getRequest();

      $this->twilioService = $this->get('v_tech_solution_twilio.twilio');
    }

	/**
   * @Route("/send-sms", name="vtech_solution_bundle_twilio_send_sms")
   * @Method({"POST","GET"} )
   */

	public function sendSms() {

		$this->initAction();

		$this->responseArray = $this->twilioService->twilioCreateSms();

		return new JsonResponse($this->responseArray);

	}

	/**
   * @Route("/set-all-messages", name="vtech_solution_bundle_twilio_set_all_messages")
   * @Method({"GET"} )
   */

	public function setAllSms() {

		$this->initAction();

		$this->responseArray = $this->twilioService->twilioSetAllSms();

		return new JsonResponse($this->responseArray);

	}

	/**
   * @Route("/receive-messages", name="vtech_solution_bundle_twilio_receive_messages")
   * @Method({"POST"} )
   */

	public function receiveDailySms() {

		$this->initAction();

		$this->responseArray = $this->twilioService->twilioReceiveSms();

		return new JsonResponse($this->responseArray);

	}

  /**
   * @Route("/receive-single-number", name="vtech_solution_bundle_twilio_receive_single_number")
   * @Method({"POST"} )
   */

  public function receiveSingleSMS() {

    $this->initAction();

    $this->responseArray = $this->twilioService->twilioReceiveSmsSingleNUmber();

    return new JsonResponse($this->responseArray);

  }

  /**
   * @Route("/remove-messages", name="vtech_solution_bundle_twilio_remove_messages")
   * @Method({"GET"} )
   */

	public function removeSingleSms() {

		$this->initAction();

		$this->responseArray = $this->twilioService->twilioDeleteSms();

		return new JsonResponse($this->responseArray);

	}

	/**
   * @Route("/sms-notification", name="vtech_solution_bundle_twilio_sms_notification")
   * @Method({"POST"} )
   * @Template("vTechSolutionTwilioBundle:Twilio:notification.html.twig")
   */

	public function smsNotification() {
    $this->responseArray = array();

		$this->responseArray["result"] = $this->get('v_tech_solution_twilio.twilio_notification')->twilioNotification();

		return $this->responseArray;

	}

	/**
   * @Route("/sms-reminder", name="vtech_solution_bundle_twilio_sms_reminder")
   * @Method({"POST","GET"} )
   */

	public function sendSmsAction() {

		$this->initAction();

		$this->responseArray = $this->twilioService->sendSms();

		return new JsonResponse($this->responseArray);

	}

	/**
   * @Route("/sms-interview", name="vtech_solution_bundle_twilio_sms_interview")
   * @Method({"POST","GET"} )
   */

	public function sendSmsInterviewAction() {

		$this->initAction();

		$this->responseArray = $this->twilioService->sendSmsInterview();

		return new JsonResponse($this->responseArray);

	}

	/**
   * @Route("/sms-submitted", name="vtech_solution_bundle_twilio_sms_submitted")
   * @Method({"POST","GET"} )
   */

	public function sendSmsSubmittedAction() {

		$this->initAction();

		$this->responseArray = $this->twilioService->sendSmsSubmitted();

		return new JsonResponse($this->responseArray);

	}

	/**
   * @Route("/custom-send-sms", name="vtech_solution_bundle_twilio_custom_send_sms")
   * @Method({"POST"} )
   */

	public function customSendSms() {

		$this->initAction();

		$this->responseArray = $this->twilioService->customSmsSent();

		return new JsonResponse($this->responseArray);

	}

}

<?php

namespace vTechSolution\Bundle\TwilioBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class vTechSolutionTwilioBundle extends Bundle
{
}

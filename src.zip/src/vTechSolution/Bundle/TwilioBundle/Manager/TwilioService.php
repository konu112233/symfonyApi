<?php

namespace vTechSolution\Bundle\TwilioBundle\Manager;

use Symfony\Component\DependencyInjection\ContainerInterface as Container;
use Twilio\Rest\Client;
use vTechSolution\Bundle\TwilioBundle\Document\MessageHistory;
use vTechSolution\Bundle\TwilioBundle\Entity\SentSmsHistory;



class TwilioService
{

  private $container;
  private $request;
  private $responseArray;
  private $emailTrackDatabase;
  private $sentSmsHistoryRepository;

  const HTTP_METHOD_GET    = 'GET';
  const HTTP_METHOD_POST   = 'POST';

  public function __construct(Container $container) {
        $this->container = $container;
        $this->request = $this->container->get('request');
        $this->responseArray = array();
        $this->doctrine = $this->container->get('doctrine');
        $this->messageHistoryRepository = $this->container->get('doctrine_mongodb')->getRepository('vTechSolutionTwilioBundle:MessageHistory');
        $this->emailTrackDatabase = $this->container->get('v_tech_solution_ring_central.email_track')->getPDO();
        $this->catsDatabase = $this->container->get('v_tech_solution_search.cats')->getPDO();
        $this->sentSmsHistoryRepository = $this->doctrine->getRepository('vTechSolutionTwilioBundle:SentSmsHistory');
    }


    public function __destructor()
    {
        unset($this->container);
        unset($this->request);
        unset($this->responseArray);
        unset($this->sentSmsHistoryRepository);
    }

  public function twilioCreateSms() {
    //$this->emailTrackDatabase = $this->container->get('v_tech_solution_ring_central.email_track')->getPDO();

   $twilioSid = $this->container->getParameter('twilioSid');
   $TwilioAuthToken = $this->container->getParameter('twilioAuthToken');
   $atsFrom = $this->request->get('from');
   $atsTo = $this->request->get('to');
   $atsMessage = $this->request->get('msg');
   $atsJobId = $this->request->get('job_id');
   $atsUserId = $this->request->get('uid');
   $atsTemplateId = $this->request->get('template_id');
   $atsNumber = explode(',',$atsTo);
   $client = new Client($twilioSid, $TwilioAuthToken);

   foreach($atsNumber as $to) {

        $prefix = "+1";
        if(strpos( $to, $prefix ) !== false) {
           $new_to = $to;

        }
        else{
          $new_to = $prefix.preg_replace('/\D+/', '', $to);
        }

       if(isset($atsJobId)) {
       $templateValidation = 'select count(*) FROM `sent_text` where job_id="'.$atsJobId.'" and text_to="'.$new_to.'" and text_from="'.$atsFrom.'" and DATE_FORMAT(date,"%Y-%m-%d")="'.date('Y-m-d').'" and template_id="'.$atsTemplateId.'"';
       $validationResult = $this->emailTrackDatabase->query($templateValidation)->fetchColumn();
       if($validationResult >= 1) {
       continue;
       }
     }

     $message = $client->messages->create(
     $new_to,
     array(
       'from' => $atsFrom,
       'body' => $atsMessage
       )
     );

   $querySelect = 'select count(*) FROM `sent_text` where user_id="'.$atsUserId.'" and text_to="'.$new_to.'" and text_from="'.$atsFrom.'" and job_id="'.$atsJobId.'" and template_id="'.$atsTemplateId.'"';
   $sentSms = $this->emailTrackDatabase->query($querySelect)->fetchColumn();

    if($sentSms <= 0)
    {
     $queryInsert="insert into sent_text(user_id, text_from, text_to, job_id, template_id, date) VALUES ('".$atsUserId."','".$atsFrom."','".$new_to."','".$atsJobId."','".$atsTemplateId."','".date('Y-m-d H:i:s')."')";

         $queryResult = $this->emailTrackDatabase->exec($queryInsert);
      }
      if($sentSms >= 1){
        $updateNumber = "update sent_text set date = '".date('Y-m-d H:i:s')."' where text_to = '".$new_to."' and text_from = '".$atsFrom."' and user_id = '".$atsUserId."'";
        $updatedResult = $this->emailTrackDatabase->exec($updateNumber);

      }
   }
   return $this->responseArray;
  }

  public function twilioSetAllSms() {
    $history=$historyFetched=array();
    $twilioSid = $this->container->getParameter('twilioSid');
      $TwilioAuthToken = $this->container->getParameter('twilioAuthToken');


    $twilio = new Client($twilioSid, $TwilioAuthToken);

    $history = $twilio->messages->read(array(
                              "dateSent" => date('Y-m-d',strtotime("-1 days"))
                ));

      foreach($history as $records) {
        date_default_timezone_set('Europe/London');
        $date = new \DateTime($records->dateSent->format('Y-m-d H:i:s'));
        $date->setTimeZone(new \DateTimeZone('America/New_York'));
      $historyFetched[]=array("message" => $records->body,"from" => $records->from, "to" => $records->to, "date" => $date->format('Y-m-d H:i:s'));
        }

      $messageHistory = new MessageHistory();
        $messageHistory->setType('twilio');
        $messageHistory->setData(json_encode($historyFetched));
        $messageHistory->setCreatedAt(new \DateTime());
        $messageHistory->setUpdatedAt(new \DateTime());
        $this->messageHistoryRepository->commit($messageHistory);

        return $historyFetched;

  }

  public function twilioReceiveSms() {
    $history = $historyFetched = $historyAll = $historyFethched = $historyDailyFetched = $historyRecords = array();
    $recruiterNumber = json_decode($this->request->get('recruiterPhoneNumber'),true);
    $twilioSid = $this->container->getParameter('twilioSid');
      $TwilioAuthToken = $this->container->getParameter('twilioAuthToken');
    $allMessages = $this->messageHistoryRepository->fetchAll();

    $twilio = new Client($twilioSid, $TwilioAuthToken);

    $history = $twilio->messages->read(array(
                              "dateSent" => date('Y-m-d')
                ));

    foreach($history as $records) {
      date_default_timezone_set('Europe/London');
      $date = new \DateTime($records->dateSent->format('Y-m-d H:i:s'));
      $date->setTimeZone(new \DateTimeZone('America/New_York'));
        $historyDailyFetched[] = array("message" => $records->body,"from" => $records->from, "to" => $records->to,"date" => $date->format('Y-m-d H:i:s'));
      }


      foreach ($allMessages as $messageRow) {
          $historyAll = array_merge($historyAll, array_reverse(json_decode($messageRow->getData(),"ARRAY")));
      }

      $historyFethched = array_merge($historyAll, array_reverse($historyDailyFetched));

      $keyFrom = array_keys(array_column($historyFethched, 'from'), $recruiterNumber);
      $keyTo = array_keys(array_column($historyFethched, 'to'), $recruiterNumber);
      $resultKey = array_merge($keyFrom, $keyTo);
      asort($resultKey);

      foreach ($resultKey as $keyNumber) {
        $historyRecords[] = $historyFethched[$keyNumber];
      }

    return $historyRecords;

  }

  public function twilioReceiveSmsSingleNUmber() {
    $history = $historyFetched = $historyAll = $historyFethched = $historyDailyFetched = array();

    $twilioSid = $this->container->getParameter('twilioSid');
      $TwilioAuthToken = $this->container->getParameter('twilioAuthToken');
    $allMessages = $this->messageHistoryRepository->fetchAll();

    $twilio = new Client($twilioSid, $TwilioAuthToken);

    $history = $twilio->messages->read(array(
                              "from" => "+12027653618"
                ));

    foreach($history as $records) {
      date_default_timezone_set('Europe/London');
      $date = new \DateTime($records->dateSent->format('Y-m-d H:i:s'));
      $date->setTimeZone(new \DateTimeZone('America/New_York'));
    $historyDailyFetched[] = array("message" => $records->body,"from" => $records->from, "to" => $records->to,"date" => $date->format('Y-m-d H:i:s'));
      }

    echo "<pre>";
    print_r($historyDailyFetched);

  }

  public function twilioDeleteSms() {
    $history = $historyFetched = $historyAll = $historyFethched = $historyDailyFetched = array();

    $twilioSid = $this->container->getParameter('twilioSid');
      $TwilioAuthToken = $this->container->getParameter('twilioAuthToken');


    $twilio = new Client($twilioSid, $TwilioAuthToken);

    $history = $twilio->messages("message_SId")->delete();

    return $history;

  }

  function twilioGetAllSms() {
      $allMessages = $this->messageHistoryRepository->fetchAll();
    $historyAll = array();
      foreach ($allMessages as $messageRow) {
        $historyAll[] = json_decode($messageRow->getData());
      }

      return $historyAll;
    }

/* New Service created for notification
    public function twilioNotification() {

      $logedinUserid = $this->request->get('uid');
      $finalSentFrom = $this->request->get('userFrom');
      $sentSms = $this->request->get('userTo');
      $sentSms = explode(',', $sentSms);

      // $fromAtsNumber = "select phone_work from cats.user where user_id='$logedinUserid'";
      // $fromAtsResult = $this->catsDatabase->query($fromAtsNumber)->fetchColumn();
      //
      // if ($fromAtsResult == null || $fromAtsResult == '') {
      //   $fromAtsNumber = "select phone_work from cats.user where user_id='1'";
      //   $fromAtsResult = $this->catsDatabase->query($fromAtsNumber)->fetchColumn();
      // }
      // $formatted_from = preg_replace("/[^0-9]/", "", $fromAtsResult);
      // $finalSentFrom = "+1".$formatted_from;
      // //$logedinUserid = '1435';
      //
      // $querySelect = 'select distinct(text_to) FROM `sent_text` where user_id="'.$logedinUserid.'" and text_from="'.$finalSentFrom.'" order by date desc';
      // //$querySelect = 'select distinct(text_to) FROM `sent_text` where user_id="'.$logedinUserid.'" order by date desc';
      // $sentSms = $this->emailTrackDatabase->query($querySelect)->fetchAll();

      $twilioSid = $this->container->getParameter('twilioSid');
      $TwilioAuthToken = $this->container->getParameter('twilioAuthToken');
      $notification = array();
      $replyNumber = array();
      $twilio = new Client($twilioSid, $TwilioAuthToken);

      $notification = $twilio->messages->read(array(
                                "dateSent" => date('Y-m-d')
                  ));


                  foreach($notification as $records) {
                    foreach($sentSms as $sentTo) {
                    if($sentTo == $records->from && $finalSentFrom == $records->to) {
                      $replyNumber[$records->from][]=array("message" => $records->body,"time" => $records->dateSent->format('Y-m-d'));
                    }
                  }
                  }

                  uasort($replyNumber, function($a, $b){ return $a[0]['time'] < $b[0]['time']; });

              return $replyNumber;
    }
*/
    public function sendSms($type = null, $fromNumber =null, $messageDetails = null) {

      //  $this->emailTrackDatabase = $this->container->get('v_tech_solution_ring_central.email_track')->getPDO();
        $type = "sms_reminder";
        $query = "SELECT value FROM `meta_data` WHERE key_value = '".$type."'";
        $reminderMessage = $this->emailTrackDatabase->query($query)->fetchColumn(0);
        $stopMessage = " Reply STOP to opt-out";
        $completeMessage = $reminderMessage.$stopMessage;
        $message = $messageDetails;
        foreach ($message as $key => $messageValue) {
          $resultMessage[] = array("message"=> (str_replace(
                            array('{{candidate_name}}', '{{endDate}}'),
                            array($messageValue['candidate_name'], $messageValue['endDate']),
                            $completeMessage)),
          "phone"=>$messageValue['phone']);
        }
        $twilioSid = $this->container->getParameter('twilioSid');
        $TwilioAuthToken = $this->container->getParameter('twilioAuthToken');
        $fromNumber = $fromNumber;
        $twilio = new Client($twilioSid, $TwilioAuthToken);
        foreach ($resultMessage as $key => $value) {
        $message = $twilio->messages
                  ->create($value['phone'], // to
                           array("from" => $fromNumber, "body" => $value['message'])
        );
      }
    }

    public function sendSmsInterview($type = null, $candidatePhoneNumber = null, $fromNumber =null, $messageDetails = null) {
      //$this->emailTrackDatabase = $this->container->get('v_tech_solution_ring_central.email_track')->getPDO();
        $type = "sms_reminder_interview";
        $query = "SELECT value FROM `meta_data` WHERE key_value = '".$type."'";
        $reminderMessage = $this->emailTrackDatabase->query($query)->fetchColumn(0);
        $stopMessage = " Reply STOP to opt-out";
        $completeMessage = $reminderMessage.$stopMessage;
        $message = $messageDetails;


        foreach ($message as $key => $messageValue) {
        $resultMessage[] = str_replace(
        array('{{first_name}}', '{{client}}', '{{job_title}}', '{{job_id}}'),
        array($messageValue['first_name'], $messageValue['client_name'], $messageValue['job_title'], $messageValue['job_id']),
        $completeMessage
        );
        }

        $twilioSid = $this->container->getParameter('twilioSid');
        $TwilioAuthToken = $this->container->getParameter('twilioAuthToken');
        $smsType = $type;
        $fromNumber = $fromNumber;
        $candidatePhoneNumber = $candidatePhoneNumber;
        $phone = preg_replace('/\D+/', '', $candidatePhoneNumber);


        $twilio = new Client($twilioSid, $TwilioAuthToken);
        foreach ($phone as $key => $value) {
        $message = $twilio->messages
                  ->create($value, // to
                           array("from" => $fromNumber, "body" => $resultMessage[$key])
        );
      }
    }

    public function sendSmsSubmitted($type = null, $candidatePhoneNumber = null, $fromNumber =null, $messageDetails = null) {

      //$this->emailTrackDatabase = $this->container->get('v_tech_solution_ring_central.email_track')->getPDO();
        $type = "sms_reminder_submitted";
        $query = "SELECT value FROM `meta_data` WHERE key_value = '".$type."'";
        $reminderMessage = $this->emailTrackDatabase->query($query)->fetchColumn(0);
        $stopMessage = " Reply STOP to opt-out";
        $completeMessage = $reminderMessage.$stopMessage;
        $message = $messageDetails;

        foreach ($message as $key => $messageValue) {
        $resultMessage[] = str_replace(
        array('{{first_name}}', '{{client}}', '{{job_title}}', '{{job_id}}'),
        array($messageValue['first_name'], $messageValue['client_name'], $messageValue['job_title'], $messageValue['job_id']),
        $completeMessage
        );
        }

        $twilioSid = $this->container->getParameter('twilioSid');
        $TwilioAuthToken = $this->container->getParameter('twilioAuthToken');
        $smsType = $type;
        $fromNumber = $fromNumber;
        $candidatePhoneNumber = $candidatePhoneNumber;
        $phone = preg_replace('/\D+/', '', $candidatePhoneNumber);

        $twilio = new Client($twilioSid, $TwilioAuthToken);
        foreach ($phone as $key => $value) {
        $message = $twilio->messages
                  ->create($value, // to
                           array("from" => $fromNumber, "body" => $resultMessage[$key])
        );
      }
    }

    public function customSmsSent() {
      $this->emailTrackDatabase = $this->container->get('v_tech_solution_ring_central.email_track')->getPDO();

       $twilioSid = $this->container->getParameter('twilioSid');
       $TwilioAuthToken = $this->container->getParameter('twilioAuthToken');
       $fromNumber = $this->request->get('fromPhoneNumber');
       $toNumber = $this->request->get('toPhoneNumber');
       $messageLine = $this->request->get('messageLine');
       $userId = $this->request->get('sessionCurrentUserId');
       $type = $this->request->get('smsType');
       $multipleToNumbers = explode(',',$toNumber);
       $client = new Client($twilioSid, $TwilioAuthToken);

      foreach($multipleToNumbers as $to) {

          $prefix = "+1";
          if(strpos( $to, $prefix ) !== false) {
               $new_to = preg_replace('/\D+/', '', $to);

          }
          else{
              $new_to = $prefix.preg_replace('/\D+/', '', $to);
          }

         $message = $client->messages->create(
         $new_to,
         array(
           'from' => $fromNumber,
           'body' => $messageLine
           )
         );

         $searchForExitstingMessages = $this->sentSmsHistoryRepository->getExistingUserMessage($userId,$fromNumber,$new_to);

         if ($searchForExitstingMessages != null || $searchForExitstingMessages != '') {

          $searchForExitstingMessages->setDate(new \DateTime());
          $this->sentSmsHistoryRepository->commit($searchForExitstingMessages);

         } else{

          $addNewSmsHistory = new SentSmsHistory();
          $addNewSmsHistory->setUserId($userId);
          $addNewSmsHistory->setSentFrom($fromNumber);
          $addNewSmsHistory->setSentTo($new_to);
          $addNewSmsHistory->setType($type);
          $addNewSmsHistory->setDate(new \DateTime());
          $this->sentSmsHistoryRepository->commit($addNewSmsHistory);

         }

      }

       return $this->responseArray;
    }
}

<?php

namespace vTechSolution\Bundle\TwilioBundle\Manager;

use Symfony\Component\DependencyInjection\ContainerInterface as Container;
use Twilio\Rest\Client;



class TwilioNotificationService
{

  private $container;
  private $request;
  private $responseArray;

  const HTTP_METHOD_GET    = 'GET';
  const HTTP_METHOD_POST   = 'POST';

  public function __construct(Container $container) {
        $this->container = $container;
        $this->request = $this->container->get('request');
        $this->responseArray = array();
        //$this->catsDatabase = $this->container->get('v_tech_solution_search.cats')->getPDO();

    }


    public function __destructor()
    {
        unset($this->container);
        unset($this->request);
        unset($this->responseArray);
    }


    public function twilioNotification() {

      $logedinUserid = $this->request->get('uid');
      $finalSentFrom = $this->request->get('userFrom');
      $sentSms = $this->request->get('userTo');
      $sentSms = explode(',', $sentSms);
      $twilioSid = $this->container->getParameter('twilioSid');
      $TwilioAuthToken = $this->container->getParameter('twilioAuthToken');
      $notification = $replyNumber = $receivedSmsFrom = $newReceivedNumberMessage = array();
      $twilio = new Client($twilioSid, $TwilioAuthToken);

      $notification = $twilio->messages->read(array(
                        "dateSent" => date('Y-m-d')
                        ));

        foreach($notification as $records) {
          foreach($sentSms as $sentTo) {
          if ($sentTo == $records->from && $finalSentFrom == $records->to) {
            $replyNumber[$records->from][]=array("message" => $records->body,"time" => $records->dateSent->format('Y-m-d'));
            }
            if ($finalSentFrom == $records->to && $records->to != '+12026448432') {
              $receivedSmsFrom[] = $records->from;
            }
          }
        }
        //print_r(array_unique($receivedSmsFrom)); die;

        $newReceivedNumberMessage = array_diff(array_unique($receivedSmsFrom),$sentSms);

        if(count($newReceivedNumberMessage) >= 1) {
          $newNumberString = implode(",",$newReceivedNumberMessage);
           //if ($logedinUserid == '1435') {
            $this->emailTrackDatabase = $this->container->get('v_tech_solution_ring_central.email_track')->getPDO();
            $checkNnumberQuery = "select count(id) from sent_text where user_id='".$logedinUserid."' and text_from='".$finalSentFrom."' and text_to='".$newReceivedNumberMessage[0]."'";
             $checkNnumberResult = $this->emailTrackDatabase->query($checkNnumberQuery)->fetchColumn();

             if($checkNnumberResult <= 0)
             {
            $queryInsert="insert into sent_text(user_id, text_from, text_to, job_id, template_id, date) VALUES ('".$logedinUserid."','".$finalSentFrom."','".$newReceivedNumberMessage[0]."','0','0','".date('Y-m-d H:i:s')."')";
            $queryResult = $this->emailTrackDatabase->exec($queryInsert);
          }
           //}
        }

        uasort($replyNumber, function($a, $b){ return $a[0]['time'] < $b[0]['time']; });
        $notificationList = array("notification_message" => $replyNumber, "new_number" => $newNumberString);
        return $notificationList;
    }

}

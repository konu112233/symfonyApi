<?php

namespace vTechSolution\Bundle\TwilioBundle\Manager;

use Symfony\Component\DependencyInjection\ContainerInterface as Container;
use Symfony\Component\HttpFoundation\Request;



class TextTemplateService
{

  private $container;
  private $request;
  private $responseArray;
  private $emailTrackDatabase;

  const HTTP_METHOD_GET    = 'GET';
	const HTTP_METHOD_POST   = 'POST';

	public function __construct(Container $container) {
        $this->container = $container;
        $this->request = $this->container->get('request');
        $this->responseArray = array();
        $this->emailTrackDatabase = $this->container->get('v_tech_solution_ring_central.email_track')->getPDO();
    }


    public function __destructor()
    {
        unset($this->container);
        unset($this->request);
        unset($this->responseArray);
        unset($this->emailTrackDatabase);
    }

	public function listAll() {
    $finalResult = array();
    $selectTemplates = 'select * FROM `meta_data`';
    $fetchedResult = $this->emailTrackDatabase->query($selectTemplates)->fetchAll();
    foreach($fetchedResult as $singleResult ) {
      $finalResult[] = array("id" => $singleResult["id"], "key_value" => $singleResult["key_value"], "title" => $singleResult["title"], "value" => $singleResult["value"], "status" => $singleResult["status"], "date" => $singleResult["date"]);
    }
    return $finalResult;
	}

  public function addNew() {

 	 	$this->responseArray = array();
 	 	$templateType =  $this->request->get('inputType');
 	 	$templateName = $this->request->get('inputName');
 	 	$templateValue = $this->request->get('inputTemplate');
    $templateStatus = $this->request->get('inputStatus');
    $templateKey = $this->request->get('inputKey');

        $queryInsert="insert into meta_data(key_value, title, value, template_type, status, date) VALUES ('".$templateKey."','".$templateName."','".$templateValue."','".$templateType."','".$templateStatus."','".date('Y-m-d H:i:s')."')";
        $queryResult = $this->emailTrackDatabase->exec($queryInsert);

        return $this->responseArray;
  }

  public function showTemplate() {

    $finalResultById = array();
    $templateId =  $this->request->get('id');

      $selectTemplatesById = 'select * FROM `meta_data` where id= "'.$templateId.'"';
      $fetchedResultById = $this->emailTrackDatabase->query($selectTemplatesById)->fetchAll();

      foreach($fetchedResultById as $singleResultById ) {
        $finalResultById = array("id" => $singleResultById["id"], "key_value" => $singleResultById["key_value"], "title" => $singleResultById["title"], "value" => $singleResultById["value"], "status" => $singleResultById["status"], "date" => $singleResultById["date"], "template_type" => $singleResultById["template_type"]);
      }

      return $finalResultById;
  }

  public function editTemplate() {

    $updatedResult = array();
    $templateId =  $this->request->get('editId');
    $updateTemplateType =  $this->request->get('editType');
    $updateTemplateKey =  $this->request->get('editKey');
 	 	$updateTemplateName = $this->request->get('editName');
 	 	$updateTemplateValue = $this->request->get('editTemplate');
    $updateTemplateStatus = $this->request->get('editStatus');

     $updateTemplate = "update meta_data set key_value = '".$updateTemplateKey."', title = '".$updateTemplateName."', value = '".$updateTemplateValue."', template_type = '".$updateTemplateType."', status = '".$updateTemplateStatus."'  where id = '".$templateId."' ";

      $updatedResult = $this->emailTrackDatabase->exec($updateTemplate);

      return $updatedResult;
  }

  public function deleteTemplate() {

    $deletedResult = array();
    $templateId =  $this->request->get('id');

     $deleteTemplate = "delete from meta_data where id = '".$templateId."' ";

      $deletedResult = $this->emailTrackDatabase->exec($deleteTemplate);

      return $deletedResult;
  }

}

<?php

namespace vTechSolution\Bundle\TwilioBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * SentSmsHistory
 *
 * @ORM\Table(name="sent_sms_history")
 * @ORM\Entity(repositoryClass="vTechSolution\Bundle\TwilioBundle\Entity\SentSmsHistoryRepository")
 */
class SentSmsHistory
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var int
     *
     * @ORM\Column(name="userId", type="integer", nullable=true)
     */
    private $userId;

    /**
     * @var string
     *
     * @ORM\Column(name="sentFrom", type="string", length=255, nullable=true)
     */
    private $sentFrom;

    /**
     * @var string
     *
     * @ORM\Column(name="sentTo", type="string", length=255, nullable=true)
     */
    private $sentTo;

    /**
     * @var string
     *
     * @ORM\Column(name="type", type="string", length=255, nullable=true)
     */
    private $type;

    /**
     * @var string
     *
     * @ORM\Column(name="templateId", type="string", length=255, nullable=true)
     */
    private $templateId;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date", type="datetime", nullable=true)
     */
    private $date;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set userId
     *
     * @param integer $userId
     *
     * @return SentSmsHistory
     */
    public function setUserId($userId)
    {
        $this->userId = $userId;

        return $this;
    }

    /**
     * Get userId
     *
     * @return int
     */
    public function getUserId()
    {
        return $this->userId;
    }

    /**
     * Set sentFrom
     *
     * @param string $sentFrom
     *
     * @return SentSmsHistory
     */
    public function setSentFrom($sentFrom)
    {
        $this->sentFrom = $sentFrom;

        return $this;
    }

    /**
     * Get sentFrom
     *
     * @return string
     */
    public function getSentFrom()
    {
        return $this->sentFrom;
    }

    /**
     * Set sentTo
     *
     * @param string $sentTo
     *
     * @return SentSmsHistory
     */
    public function setSentTo($sentTo)
    {
        $this->sentTo = $sentTo;

        return $this;
    }

    /**
     * Get sentTo
     *
     * @return string
     */
    public function getSentTo()
    {
        return $this->sentTo;
    }

    /**
     * Set type
     *
     * @param string $type
     *
     * @return SentSmsHistory
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set templateId
     *
     * @param string $templateId
     *
     * @return SentSmsHistory
     */
    public function setTemplateId($templateId)
    {
        $this->templateId = $templateId;

        return $this;
    }

    /**
     * Get templateId
     *
     * @return string
     */
    public function getTemplateId()
    {
        return $this->templateId;
    }

    /**
     * Set date
     *
     * @param \DateTime $date
     *
     * @return SentSmsHistory
     */
    public function setDate($date)
    {
        $this->date = $date;

        return $this;
    }

    /**
     * Get date
     *
     * @return \DateTime
     */
    public function getDate()
    {
        return $this->date;
    }
}

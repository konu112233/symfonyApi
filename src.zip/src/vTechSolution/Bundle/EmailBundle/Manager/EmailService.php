<?php

namespace vTechSolution\Bundle\EmailBundle\Manager;

use Symfony\Component\DependencyInjection\ContainerInterface as Container;
use OG\SendGridBundle\Exception\SendGridException;
use vTechSolution\Bundle\EmailBundle\Entity\EmailTemplate;
use Symfony\Component\HttpFoundation\Request;
use vTechSolution\Bundle\EmailBundle\Form\EmailTemplateType;
use vTechSolution\Bundle\EmailBundle\Document\EmailQueue;


class EmailService
{

  private $container;
  private $request;
  private $responseArray;
  private $emailTrackDatabase;
  private $provider;
  private $emailTemplateRepository;
  private $catsDatabase;
  private $emailStatus;
  private $sendEmail;

  const HTTP_METHOD_GET    = 'GET';
	const HTTP_METHOD_POST   = 'POST';

	public function __construct(Container $container) {
        $this->container = $container;
        $this->request = $this->container->get('request');
        $this->responseArray = array();
        $this->doctrine = $this->container->get('doctrine');
        $this->provider = $this->container->get('og_send_grid.provider');
        $this->emailTemplateRepository = $this->doctrine->getRepository('vTechSolutionEmailBundle:EmailTemplate');
		    $this->emailQueueRepository = $this->container->get('doctrine_mongodb')->getRepository('vTechSolutionEmailBundle:EmailQueue');
        $this->catsDatabase = $this->container->get('v_tech_solution_quick_book.catsdb')->getPDO();
        $this->sendEmail = true;
    }


    public function __destructor()
    {
        unset($this->container);
        unset($this->request);
        unset($this->responseArray);
        unset($this->doctrine);
        unset($this->provider);
        unset($this->emailTemplateRepository);
        unset($this->emailQueueRepository);
        unset($this->catsDatabase);
        unset($this->sendEmail);
    }

    public function createEmail()
    {
        $this->responseArray = $tos = array();
        /*
        $from = $this->request->get('from');
        $to = $this->request->get('to');
        $cc = $this->request->get('cc');
        $bcc = $this->request->get('bcc');
        $subject = $this->request->get('subject');
        $message = $this->request->get('message');
        */

        $tos = array("adityag@vtechsolution.us");
        $cc = "adiigandhi007@gmail.com,testingdeep007@gmail.com";
        foreach($tos as $to) {
        $email = $this->provider->createMessage();
        $email->setFrom("konarchp@vtechsolution.us", "vTech Solution Email Service");
        $email->setSubject("Testing SendGrid v1");
        $email->addTo($to);
        $email->addCc($cc);
        $email->addContent("text/html", "<strong>Good Job</strong>");
        $file_encoded = base64_encode(file_get_contents('C:\Users\aditya.g\Downloads\Standard_Contract_Provisions.pdf'));
        $email->addAttachment(
            $file_encoded,
            "application/pdf",
            "Standard_Contract_Provisions.pdf",
            "attachment"
        );
        $email->setSubscriptionTracking(
                                        true,
                                        "If you would like to unsubscribe and stop receiving these emails <% click here %>.",
                                        "If you would like to unsubscribe and stop receiving these emails <% clickhere %>.",
                                        "<%click here%>"
                                    );

        try {
            $this->responseArray['id'] = $this->provider->send($email);

        } catch (SendGridException $e) {
            $this->responseArray['error'] = 'Caught exception: '. $e->getMessage() ."\n";
        }
      }
        return $this->responseArray;
  }

  public function sendEmail($type = null, $from = null, $tos = null, $cc = null, $bcc = null, $subject = null, $body = null, $dataValidation = null, $scheduleDate = null){

    $emailAddressTos = json_decode($this->request->get('to'),true);
    $emailAddressFrom = json_decode($this->request->get('from'),true);
    $emailAddressSubject = json_decode($this->request->get('subject'),true);
    $emailAddressCc = json_decode($this->request->get('cc'),true);
    $emailAddressBcc = json_decode($this->request->get('bcc'),true);
    $emailAddressBody = json_decode($this->request->get('body'),true);
    $emailAddressAttachment = json_decode($this->request->get('attachment'),true);
    $emailAddressAttachmentName = json_decode($this->request->get('attachment_name'),true);
    $emailAddressDataValidation = json_decode($this->request->get('data_validation'),true);

      if($dataValidation != null){
        $sentDataValidation = $dataValidation;
      } else {
        $sentDataValidation = $emailAddressDataValidation;
      }

      if($tos != null){
        $newTo = array($tos);
      } else {
        $newTo = $emailAddressTos;
      }

      foreach($newTo as $key => $to) {
        $email = $this->provider->createMessage();

        if($from != null) {
          $email->setFrom($from);
          $sentFrom = $from;
        } else {
          $email->setFrom($emailAddressFrom);
          $sentFrom = $emailAddressFrom;
        }

        $email->addTo($to);
        $sentTo = $to;

        if($emailAddressCc == true) {
          $email->addCc($emailAddressCc);
          $sentCc = $emailAddressCc;
        }
        if($cc != null) {
          $email->addCc($cc);
          $sentCc = $cc;
        }
        if($emailAddressCc == null && $cc == null ) {
          $sentCc = null;
        }

        if($emailAddressBcc == true) {
          $email->addBcc($emailAddressBcc);
          $sentBcc = $emailAddressBcc;
        }
        if($bcc != null) {
          $email->addBcc($bcc);
          $sentBcc = $bcc;
        }
        if($emailAddressBcc == null && $bcc == null ) {
          $sentBcc = null;
        }

        if($subject != null) {
          $email->setSubject($subject);
          $sentSubject = $subject;
        } else {
          $email->setSubject($emailAddressSubject);
          $sentSubject = $emailAddressSubject;
        }

        if($body != null) {
          $email->addContent("text/html",$body);
          $sentContent = $body;
        } else {
          $email->addContent("text/html",$emailAddressBody);
          $sentContent = $emailAddressBody;
        }

        if($emailAddressAttachment == true) {
        $file_encoded = base64_encode(file_get_contents($emailAddressAttachment));
        $email->addAttachment(
            $file_encoded,
            "application/pdf",
            $emailAddressAttachmentName,
            "attachment"
        );
      }
        $email->setSubscriptionTracking(
                                        true,
                                        "If you would like to unsubscribe and stop receiving these emails <% click here %>.",
                                        "If you would like to unsubscribe and stop receiving these emails <% clickhere %>.",
                                        "<%click here%>"
                                    );

        try {
            $this->responseArray['id'] = $this->provider->send($email);
        } catch (SendGridException $e) {
            $this->responseArray['error'] = 'Caught exception: '. $e->getMessage() ."\n";
          }

            $this->addEmailQueue($type, $sentFrom, $sentTo, $sentCc, $sentBcc, $sentSubject, $sentContent, $sentDataValidation, $scheduleDate);
      }

        return $this->responseArray;
  }

  public function sendEmailTemplate($type = null, $from = null, $tos = null, $cc = null, $bcc = null, $subject = null, $body = null, $parameters = null, $dataValidation = null, $scheduleDate = null) {

    $emailTemplateType = json_decode($this->request->get('type'),true);
    $emailTemplateTos = json_decode($this->request->get('to'),true);
    $emailTemplateFrom = json_decode($this->request->get('from'),true);
    $emailTemplateSubject = json_decode($this->request->get('subject'),true);
    $emailTemplateCc = json_decode($this->request->get('cc'),true);
    $emailTemplateBcc = json_decode($this->request->get('bcc'),true);
    $emailTemplateParameter = json_decode($this->request->get('parameters'),true);
    $emailBody = json_decode($this->request->get('body'),true);
    $emailTemplateScheduleDate = json_decode($this->request->get('schedule_date'),true);
    $emailTemplateDataValidation = json_decode($this->request->get('data_validation'),true);

    if($type != null){
      $newType = $type;
    } else {
      $newType = $emailTemplateType;
    }

    if($parameters != null){
      $newBody = $parameters;
    } else {
      $newBody = $emailTemplateParameter;
    }

    if($body != null){
      $newReadyBody = $body;
    } else {
      $newReadyBody = $emailBody;
    }

    if($scheduleDate != null){
      $newScheduleDate = $scheduleDate;
    } else {
      $newScheduleDate = $emailTemplateScheduleDate;
    }

    if($dataValidation != null){
      $newDataValidation = $dataValidation;
    } else {
      $newDataValidation = $emailTemplateDataValidation;
    }

    $emailTemplateByType = $this->emailTemplateRepository->getEmailTemplateByType($newType);

    foreach($emailTemplateByType as $index => $fetchEmailTemplate) {
        $selectedTemplate = $fetchEmailTemplate->getTemplate();
        $selectedFromEmail = $fetchEmailTemplate->getFromEmail();
        $selectedToEmail = $fetchEmailTemplate->getToEmail();
        $selectedSubject = $fetchEmailTemplate->getSubject();
        $selectedCc = $fetchEmailTemplate->getCcEmail();
        $selectedBcc = $fetchEmailTemplate->getBccEmail();

        if($emailTemplateTos == true){
          $newTo = $emailTemplateTos;
        } else {
          $newTo = $tos;
        }

        if ($selectedToEmail != '') {
          $explodeTos = explode(",",$selectedToEmail);
          $newTo = $explodeTos;
        }

        foreach($newTo as $key => $to) {
        $eachMessage = $newBody[$key];
        $pattern = '/{{(.+?)}}/';
        preg_match_all($pattern, $selectedTemplate, $matches);
        $newPlainTemplate = str_replace($matches[0],$matches[1],$selectedTemplate);
        $newTemplate = strtr($newPlainTemplate, $eachMessage);
        $email = $this->provider->createMessage();

        if($emailTemplateFrom == true){
          $fromEmail = $emailTemplateFrom;
        } else if($from != null) {
          $fromEmail = $from;
        } else {
          $fromEmail = $selectedFromEmail;
        }

        if( $emailTemplateCc == true && $selectedCc != null){
          $ccEmail = $emailTemplateCc.",".$selectedCc;
        }
        else if($cc == true && $selectedCc != null){
          $ccEmail = $cc.",".$selectedCc;
        }
          else {
          if($cc == true) {
            $ccEmail = $cc;
          }
          if($emailTemplateCc == true) {
            $ccEmail = $emailTemplateCc;
          }
          if($selectedCc != null) {
            $ccEmail = $selectedCc;
          }
        }
        if($cc == null && $emailTemplateCc == null && $selectedCc == null ) {
          $ccEmail = null;
        }

        if($emailTemplateBcc == true && $selectedBcc != null){
          $bccEmail = $emailTemplateBcc.",".$selectedBcc;
        } else if($bcc == true && $selectedBcc != null) {
          $bccEmail = $bcc.",".$selectedBcc;
        }
        else {
          if($bcc == true) {
            $bccEmail = $bcc;
          }
          if($emailTemplateBcc == true) {
            $bccEmail = $emailTemplateBcc;
          }
          if($selectedBcc != null) {
            $bccEmail = $selectedBcc;
          }
        }
        if($bcc == null && $emailTemplateBcc == null && $selectedBcc == null ) {
          $bccEmail = null;
        }

        if($emailTemplateSubject == true) {
          $subjectEmail = $emailTemplateSubject;
        } else if($selectedSubject != null) {
          $subjectEmail = $selectedSubject;
        } else {
          $subjectEmail = $subject;
        }

        if($newTemplate == true){
          $singleContent = $newTemplate;
        } else {
          $singleContent = $newReadyBody;
        }

        if($newScheduleDate == null || $newScheduleDate == date("Y-m-d")){
          $this->sendEmail($newType, $fromEmail, $to, $ccEmail, $bccEmail, $subjectEmail, $singleContent, $newDataValidation, $newScheduleDate);
        }
        else {
          $this->addEmailQueue($newType, $fromEmail, $to, $ccEmail, $bccEmail, $subjectEmail, $singleContent, $newDataValidation, $newScheduleDate);
        }

      }

      }

  }

  public function sendTemplate()
  {
      $tos = $eachMessage = $newTemplate = array();

      $type = json_decode($this->request->get('type'),true);

      $tos = json_decode($this->request->get('to'),true);
      //print_r($tos); die;
      $from = json_decode($this->request->get('from'),true);
      $subject = json_decode($this->request->get('subject'),true);
      $cc = json_decode($this->request->get('cc'),true);
      $bcc = json_decode($this->request->get('bcc'),true);
      $message = json_decode($this->request->get('message'),true);
      //echo $tos; echo $from; echo $subject; echo $message; die;

      if($type == true) {
      $emailTemplateByType = $this->emailTemplateRepository->getEmailTemplateByType($type);

      foreach($emailTemplateByType as $index => $fetchEmailTemplate) {
          $selectedTemplate = $fetchEmailTemplate->getTemplate();
          $selectedFromEmail = $fetchEmailTemplate->getFromEmail();
          $selectedSubject = $fetchEmailTemplate->getSubject();
          $selectedCc = $fetchEmailTemplate->getCcEmail();
          $selectedBcc = $fetchEmailTemplate->getBccEmail();

          foreach($tos as $key => $to) {
          $eachMessage = $message[$key];
          $pattern = '/{{(.+?)}}/';
          preg_match_all($pattern, $selectedTemplate, $matches);
          $newPlainTemplate = str_replace($matches[0],$matches[1],$selectedTemplate);
          $newTemplate = strtr($newPlainTemplate, $eachMessage);
          $email = $this->provider->createMessage();

          if($from == true){
            $email->setFrom($from);
          } else {
            $email->setFrom($selectedFromEmail);
          }

          if($cc == true) {
            $email->addCc($cc);
          }

          if($selectedCc != null) {
            $email->addCc($selectedCc);
          }

          if($bcc == true) {
            $email->addBcc($bcc);
          }

          if($selectedBcc != null) {
            $email->addBcc($selectedBcc);
          }

          $email->setSubject($selectedSubject);
          $email->addTo($to);
          $email->addContent("text/html",$newTemplate);
          try {
              $this->responseArray['id'] = $this->provider->send($email);
          } catch (SendGridException $e) {
              $this->responseArray['error'] = 'Caught exception: '. $e->getMessage() ."\n";
            }
          }
        }

      }
      elseif((sizeof($from) > 1) && (sizeof($subject) > 1) && (sizeof($message) > 1) && (sizeof($tos) > 1)) {
        foreach($tos as $key => $to) {
          $email = $this->provider->createMessage();
          $email->setFrom($from[$key], "vTech Solution Email Service");
          $email->setSubject($subject[$key]);
          $email->addTo($to);
          $email->addContent("text/html",$message[$key]);
          try {
              $this->responseArray['id'] = $this->provider->send($email);
          } catch (SendGridException $e) {
              $this->responseArray['error'] = 'Caught exception: '. $e->getMessage() ."\n";
          }
        }
      }
      elseif(sizeof($tos) > 1) {
          foreach($tos as $key => $to) {
            $email = $this->provider->createMessage();
            $email->setFrom($from, "vTech Solution Email Service");
            $email->setSubject($subject);
            $email->addTo($to);
            $email->addContent("text/html",$message);
            try {
                $this->responseArray['id'] = $this->provider->send($email);
            } catch (SendGridException $e) {
                $this->responseArray['error'] = 'Caught exception: '. $e->getMessage() ."\n";
            }
            }
        }
        else {
            $email = $this->provider->createMessage();
            $email->setFrom($from);
            $email->setSubject($subject);
            $email->addTo($tos);
            //$email->addCc($cc);
            //$email->addBcc($bcc);
            $email->addContent("text/html",$message);
            try {
                $this->responseArray['id'] = $this->provider->send($email);
            } catch (SendGridException $e) {
                $this->responseArray['error'] = 'Caught exception: '. $e->getMessage() ."\n";
            }
        }


        return $this->responseArray;
}

    public function addEmailQueue($type = null, $from = null, $to = null, $cc = null, $bcc = null, $subject = null, $body = null, $dataValidation = null, $scheduleDate = null) {


              $emailQueue = new EmailQueue();
              $emailQueue->setFromEmailAddress($from);
              $emailQueue->setToEmailAddress($to);
              $emailQueue->setCcEmailAddress($cc);
              $emailQueue->setBccEmailAddress($bcc);
              $emailQueue->setEmailSubject($subject);
              $emailQueue->setEmailBody($body);
              $emailQueue->setEmailType($type);
              $emailQueue->setScheduleDate($scheduleDate);
              $emailQueue->setSentDate(new \DateTime());
              if($scheduleDate == null || $scheduleDate == date("Y-m-d")){
                $emailQueue->setEmailStatus("sent");
              } else {
                $emailQueue->setEmailStatus("queue");
              }
              $emailQueue->setDataValidation(json_encode($dataValidation));
              $emailQueue->setCreatedAt(new \DateTime());
              $this->emailQueueRepository->commit($emailQueue);
            }


    public function getEmailQueue() {
      $sentDate = $this->request->get('sent_date');
      if($sentDate != 1) {
        $readyEmailQueue = $this->emailQueueRepository->findByProperty('scheduleDate', $sentDate);
      } else {
        $readyEmailQueue = $this->emailQueueRepository->findByProperty('scheduleDate', date("Y-m-d"));
      }

      foreach($readyEmailQueue as $key => $queue){
        $queueFrom = $queue->getFromEmailAddress();
        $queueTo = $queue->getToEmailAddress();
        $queueCc = $queue->getCcEmailAddress();
        $queueBcc = $queue->getBccEmailAddress();
        $queueSubject = $queue->getEmailSubject();
        $queueBody = $queue->getEmailBody();
        $queueemailType = $queue->getEmailType();
        $queueDataValidation = $queue->getDataValidation();
        $queueScheduleDate = $queue->getScheduleDate();
        $queueSentDate = $queue->getSentDate();
        $queueEmailStatus = $queue->getEmailStatus();
        $queueCreatedAt = $queue->getCreatedAt();

        $this->emailValidation($queueDataValidation, $queueemailType);


        /*if($flag = false) {
          $updateStatus = $this->emailStatus->emailValidation();
          $queue->setEmailStatus($updateStatus);
          $this->emailQueueRepository->commit($queue);
        } else {*/
          $email = $this->provider->createMessage();
          $email->setFrom($queueFrom);
          $email->setSubject($queueSubject);
          $email->addTo($queueTo);
          if($queueCc != null) {
            $email->addCc($queueCc);
          }
          if($queueBcc != null){
            $email->addBcc($queueBcc);
          }
          $email->addContent("text/html",$queueBody);
          $email->setSubscriptionTracking(
                                          true,
                                          "If you would like to unsubscribe and stop receiving these emails <% click here %>.",
                                          "If you would like to unsubscribe and stop receiving these emails <% clickhere %>.",
                                          "<%click here%>"
                                      );
          if ($this->sendEmail) {
            try {
                $this->responseArray['id'] = $this->provider->send($email);
            } catch (SendGridException $e) {
                $this->responseArray['error'] = 'Caught exception: '. $e->getMessage() ."\n";
              }

              $queue->setSentDate(new \DateTime());
              if($this->responseArray['id'] == true) {
                $queue->setEmailStatus("sent");
              } else {
                $queue->setEmailStatus("failed");
              }

          } else {
            $queue->setEmailStatus($this->emailStatus);
          }

          $this->emailQueueRepository->commit($queue);
        }
      /*}*/
    }

    public function emailValidation($dataValidation, $queueemailType) {

      if ($dataValidation != '') {
          $fetchData = json_decode($dataValidation, 'ARRAY');

          if(isset($fetchData['candidate_id']) && isset($fetchData['joborder_id']) && in_array($queueemailType,  array("submitted_after_five_days", "submitted_after_ten_days", "submitted_after_twenty_days"))) {
            $candidateId = $fetchData['candidate_id'];
            $joborderId = $fetchData['joborder_id'];

            $query = "SELECT status_to FROM candidate_joborder_status_history where candidate_id = '".$candidateId."' AND joborder_id = '".$joborderId."'  order by candidate_joborder_status_history_id desc limit 1";
            $finalStatus = $this->catsDatabase->query($query)->fetchColumn(0);

            if($finalStatus == true && $finalStatus != '400') {
              $this->emailStatus = "Not in Consideration";
              $this->sendEmail = false;

            }
          }
      } else {
        $this->sendEmail = true;
      }


  }

  public function removedFromPipeline() {
    $pipelineCandidateId = $this->request->get('candidateId');
    $pipelineJobId = $this->request->get('joborderId');
      $allResult = $this->emailQueueRepository->fetchAll();
      foreach($allResult as $key => $resultRow) {
        $emailType = $resultRow->getEmailType();
        $emailStatus = $resultRow->getEmailStatus();
        if(in_array($emailType,  array("submitted_after_five_days", "submitted_after_ten_days", "submitted_after_twenty_days")) && $emailStatus == 'queue') {
        $validationData = json_decode($resultRow->getDataValidation(), 'ARRAY');
        if($pipelineCandidateId == $validationData['candidate_id'] && $pipelineJobId == $validationData['joborder_id'] ) {
          $this->emailQueueRepository->deleteByObject($resultRow);
        }
        }
      }
        return $this->responseArray;
  }

    public function createTemplate(){
      $from = $this->request->get('from');
      $to = $this->request->get('to');
      $cc = $this->request->get('cc');
      $bcc = $this->request->get('bcc');
      $subject = $this->request->get('subject');
      $message = $this->request->get('message');
      $type = $this->request->get('type');

      $emailTemplate = new EmailTemplate();
      $emailTemplate->setType($type);
      $emailTemplate->setTemplate($message);
      $emailTemplate->setFromEmail($from);
      $emailTemplate->setToEmail($to);
      $emailTemplate->setCcEmail($cc);
      $emailTemplate->setBccEmail($bcc);
      $emailTemplate->setSubject($subject);
      $emailTemplate->setCreatedDate(new \DateTime());
      $this->emailTemplateRepository->commit($emailTemplate);

    }

    public function findAll(){
      $result = $this->emailTemplateRepository->fetchAll();
      return $result;
    }

    public function createNew($emailTemplate){
      $emailTemplate->setCreatedDate(new \DateTime());
      $this->emailTemplateRepository->commit($emailTemplate);

      return $emailTemplate;
    }


    public function editTemplate($emailTemplate){
      $emailTemplate->setCreatedDate(new \DateTime());
      $this->emailTemplateRepository->commit($emailTemplate);

      return $emailTemplate;
    }

    /*** To send emails to the company owner about new vms auto import jobs ***/

    public function emailAutoImportJobs()
    {
        $mappingDatabase = $this->container->get('v_tech_solution_quick_book.mappingdb')->getPDO();

        $query = "SELECT MJ.ats_joborder_id, AJ.client_job_id, U.email AS managerEmail, AJ.title AS jobTitle, AJ.city AS jobLocation, DATE_FORMAT(AJ.start_date,'%m/%d/%Y') AS jobStartDate, CONCAT(U.first_name,' ',U.last_name) AS managerName, U.user_id AS managerUserId FROM vtech_mappingdb.ats_mapped_jobs AS `MJ` JOIN cats.joborder AS `AJ` ON AJ.joborder_id = MJ.ats_joborder_id  JOIN cats.user AS `U` ON AJ.owner = U.user_id  WHERE MJ.is_email_sent = 'no' and AJ.owner > 0 and AJ.status = 'Reviewing' ";
        $result = $mappingDatabase->query($query)->fetchAll(\PDO::FETCH_ASSOC);

        $emailArray = $emailContentParameters = $jobIds = [];

        if(!empty($result)){
           $data = $this->_group_by($result,'managerUserId');

           foreach ($data as $key => $value) {

                array_push($emailArray, "kishanb@vtechsolution.us");
                $table = "<table border = '2'><th>Joborder Id</th><th>Company Job Id</th><th>Title</th><th>Location</th><th>Start Date</th>";
                foreach ($value as $k => $v) {

                    array_push($jobIds, $v["ats_joborder_id"]);

                    $table .= "<tr> <td>".$v["ats_joborder_id"]."</td></td>
                                    <td>".$v["client_job_id"]."</td></td>
                                    <td>".$v["jobTitle"]."</td></td>
                                    <td>".$v["jobLocation"]."</td></td>
                                    <td>".$v["jobStartDate"]."</td></td></tr>";
                }
                $table .= "</table>";

                $joblist['table'] = $table;
                $emailContentParameters[] = $joblist;
            }
        }

         if(!empty($emailArray) && !empty($result)){
           // Send email
           $this->sendEmailTemplate($type = 'vms_autoimport_jobs', $from = null, $tos = $emailArray, $cc = null, $bcc = null, $subject = null, $body = null, $parameters = $emailContentParameters, $dataValidation = null, $scheduleDate = null);

           // Update records
           if(!empty($jobIds)) {
                $jobIds_string = "'".implode("','",$jobIds)."'";
                // $queryUpdate='update ats_mapped_jobs set is_email_sent= "yes" where ats_joborder_id IN ("'.$jobIds_string.'" )';
                // $mappingDatabase->exec($queryUpdate);

                $queryUpdate = $mappingDatabase->prepare("UPDATE ats_mapped_jobs SET  is_email_sent= 'yes'  WHERE `ats_joborder_id` IN (".$jobIds_string.")");
                $queryUpdate->execute();
           }
         }
          return true;
    }

    /*** To Group the associateve as per the key ***/

    function _group_by($array, $key) {
        $return = array();
        foreach($array as $val) {
            $return[$val[$key]][] = $val;
        }
        return $return;
    }

    public function massEmailSalesData(){

      $salesEmailFromAdress = $this->request->get('fromAddress');
      $salesEmailToAdress = $this->request->get('toAddress');
      $salesEmailSubject = $this->request->get('subjecLine');
      $salesEmailMessage = $this->request->get('messageLine');
      $salesEmailType = 'mass_email';

      $multipleToAddress = explode(',', $salesEmailToAdress);
      $messageLineBody = array();

      foreach ($multipleToAddress as $multipleToAddressKey => $multipleToAddressValue) {

        $messageLineBody[] = array("template" => $salesEmailMessage);
        
        
      }

       $this->sendEmailTemplate($salesEmailType, $salesEmailFromAdress, $multipleToAddress, null, null, $salesEmailSubject, null, $messageLineBody);

        $response = "Mail Has Been Sent";
    }

}

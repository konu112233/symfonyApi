<?php

namespace vTechSolution\Bundle\EmailBundle\Document;

use Doctrine\ODM\MongoDB\Mapping\Annotations as MongoDB;

/**
 * @MongoDB\Document(repositoryClass="vTechSolution\Bundle\EmailBundle\Document\EmailQueueRepository")
 */
class EmailQueue
{
    /**
    * @MongoDB\Id
    */
    protected $id;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $fromEmailAddress;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $toEmailAddress;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $ccEmailAddress;

    /**
    * @MongoDB\Field(type="string", nullable=true)
    */
    protected $bccEmailAddress;

    /**
    * @MongoDB\Field(type="string", nullable=true)
    */
    protected $emailSubject;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $emailBody;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $emailType;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $scheduleDate;

    /**
    * @MongoDB\Date
    */
    protected $sentDate;

    /**
    * @MongoDB\Field(type="string", nullable=true)
    */
    protected $emailStatus;

    /**
    * @MongoDB\Field(type="string", nullable=true)
    */
    protected $dataValidation;

    /**
     * @MongoDB\Date
     */
    protected $createdAt;

    /**
     * Get id
     *
     * @return id $id
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set fromEmailAddress
     *
     * @param string $fromEmailAddress
     * @return $this
     */
    public function setFromEmailAddress($fromEmailAddress)
    {
        $this->fromEmailAddress = $fromEmailAddress;
        return $this;
    }

    /**
     * Get fromEmailAddress
     *
     * @return string $fromEmailAddress
     */
    public function getFromEmailAddress()
    {
        return $this->fromEmailAddress;
    }

    /**
     * Set toEmailAddress
     *
     * @param string $toEmailAddress
     * @return $this
     */
    public function setToEmailAddress($toEmailAddress)
    {
        $this->toEmailAddress = $toEmailAddress;
        return $this;
    }

    /**
     * Get toEmailAddress
     *
     * @return string $toEmailAddress
     */
    public function getToEmailAddress()
    {
        return $this->toEmailAddress;
    }

    /**
     * Set ccEmailAddress
     *
     * @param string $ccEmailAddress
     * @return $this
     */
    public function setCcEmailAddress($ccEmailAddress)
    {
        $this->ccEmailAddress = $ccEmailAddress;
        return $this;
    }

    /**
     * Get ccEmailAddress
     *
     * @return string $ccEmailAddress
     */
    public function getCcEmailAddress()
    {
        return $this->ccEmailAddress;
    }

    /**
     * Set bccEmailAddress
     *
     * @param string $bccEmailAddress
     * @return $this
     */
    public function setBccEmailAddress($bccEmailAddress)
    {
        $this->bccEmailAddress = $bccEmailAddress;
        return $this;
    }

    /**
     * Get bccEmailAddress
     *
     * @return string $bccEmailAddress
     */
    public function getBccEmailAddress()
    {
        return $this->bccEmailAddress;
    }

    /**
     * Set emailSubject
     *
     * @param string $emailSubject
     * @return $this
     */
    public function setEmailSubject($emailSubject)
    {
        $this->emailSubject = $emailSubject;
        return $this;
    }

    /**
     * Get emailSubject
     *
     * @return string $emailSubject
     */
    public function getEmailSubject()
    {
        return $this->emailSubject;
    }

    /**
     * Set emailBody
     *
     * @param string $emailBody
     * @return $this
     */
    public function setEmailBody($emailBody)
    {
        $this->emailBody = $emailBody;
        return $this;
    }

    /**
     * Get emailBody
     *
     * @return string $emailBody
     */
    public function getEmailBody()
    {
        return $this->emailBody;
    }

    /**
     * Set emailType
     *
     * @param string $emailType
     * @return $this
     */
    public function setEmailType($emailType)
    {
        $this->emailType = $emailType;
        return $this;
    }

    /**
     * Get emailType
     *
     * @return string $emailType
     */
    public function getEmailType()
    {
        return $this->emailType;
    }

    /**
     * Set scheduleDate
     *
     * @param string $scheduleDate
     * @return $this
     */
    public function setScheduleDate($scheduleDate)
    {
        $this->scheduleDate = $scheduleDate;
        return $this;
    }

    /**
     * Get scheduleDate
     *
     * @return string $scheduleDate
     */
    public function getScheduleDate()
    {
        return $this->scheduleDate;
    }

    /**
     * Set sentDate
     *
     * @param timestamp $sentDate
     * @return $this
     */
    public function setSentDate($sentDate)
    {
        $this->sentDate = $sentDate;
        return $this;
    }

    /**
     * Get sentDate
     *
     * @return timestamp $sentDate
     */
    public function getSentDate()
    {
        return $this->sentDate;
    }

    /**
     * Set emailStatus
     *
     * @param string $emailStatus
     * @return $this
     */
    public function setEmailStatus($emailStatus)
    {
        $this->emailStatus = $emailStatus;
        return $this;
    }

    /**
     * Get emailStatus
     *
     * @return string emailStatus
     */
    public function getEmailStatus()
    {
        return $this->emailStatus;
    }

    /**
     * Set dataValidation
     *
     * @param string $dataValidation
     * @return $this
     */
    public function setDataValidation($dataValidation)
    {
        $this->dataValidation = $dataValidation;
        return $this;
    }

    /**
     * Get dataValidation
     *
     * @return string $dataValidation
     */
    public function getDataValidation()
    {
        return $this->dataValidation;
    }

    /**
     * Set createdAt
     *
     * @param timestamp $createdAt
     * @return $this
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
        return $this;
    }

    /**
     * Get createdAt
     *
     * @return timestamp $createdAt
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }


    /**
     * @MongoDB\PrePersist
     */
    public function onPrePersist()
    {
        $this->createdAt = new DateTime();
    }


}

<?php

namespace vTechSolution\Bundle\EmailBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class EmailControllerControllerTest extends WebTestCase
{
}

<?php

namespace vTechSolution\Bundle\EmailBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;

class EmailTemplateType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('type', null, array('required' => true))
                ->add('template', TextareaType::class, array('required' => false))
                ->add('fromEmail')
                ->add('toEmail')
                ->add('ccEmail')
                ->add('bccEmail')
                ->add('subject');
    }/**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'vTechSolution\Bundle\EmailBundle\Entity\EmailTemplate'
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'vtechsolution_bundle_emailbundle_emailtemplate';
    }


}

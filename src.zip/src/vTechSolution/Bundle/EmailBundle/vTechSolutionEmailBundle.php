<?php

namespace vTechSolution\Bundle\EmailBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class vTechSolutionEmailBundle extends Bundle
{
}

<?php

namespace vTechSolution\Bundle\EmailBundle\Controller;

use vTechSolution\Bundle\EmailBundle\Entity\EmailTemplate;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Request;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use vTechSolution\Bundle\EmailBundle\Form\EmailTemplateType;

/**
 * Emailtemplate controller.
 *
 * @Route("/email/emailtemplate")
 */
class EmailTemplateController extends Controller
{

    private $responseArray;
    private $request;

    private function initAction()
    {
      $this->responseArray = array();
      $this->request = $this->getRequest();

      $this->emailService = $this->get('v_tech_solution_email.email');
    }

    /**
     * Lists all emailTemplate entities.
     *
     * @Route("/list-all", name="vtech_solution_bundle_email_template_list_all")
     * @Template("vTechSolutionEmailBundle:emailtemplate:index.html.twig")
     * @Method("GET")
     */
    public function indexAction()
    {
      $this->initAction();

      $this->responseArray['emailTemplates'] = $this->emailService->findAll();

      return $this->responseArray;
    }

    /**
     * Creates a new emailTemplate entity.
     *
     * @Route("/new", name="emailtemplate_new")
     * @Method({"GET", "POST"})
     * @Template("vTechSolutionEmailBundle:emailtemplate:new.html.twig")
     */
    public function newAction(Request $request)
    {
        $emailTemplate = new Emailtemplate();
        $form = $this->createForm('', $emailTemplate);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($emailTemplate);
            $em->flush();

            return $this->redirectToRoute('vtech_solution_bundle_email_template_show', array('id' => $emailTemplate->getId()));
        }

        return $this->render('emailtemplate/new.html.twig', array(
            'emailTemplate' => $emailTemplate,
            'form' => $form->createView(),
        ));
    }

    /**
     * Creates a new emailTemplate entity.
     *
     * @Route("/add", name="vtech_solution_bundle_email_add_email_template")
     * @Method({"GET"})
     * @Template("vTechSolutionEmailBundle:emailtemplate:new.html.twig")
     */
    public function addEmailTemplateAction(Request $request)
    {
        $this->initAction();

        $this->responseArray["form"] = $this->createForm(new EmailTemplateType(), new Emailtemplate())->createView();

        return $this->responseArray;
    }

    /**
     * Creates a new emailTemplate entity.
     *
     * @Route("/add", name="vtech_solution_bundle_email_process_email_template")
     * @Method({"POST"})
     * @Template("vTechSolutionEmailBundle:emailtemplate:new.html.twig")
     */
    public function processEmailTemplateAction()
    {
        $this->initAction();
        $emailTemplate = new Emailtemplate();
        $form  = $this->createForm(new EmailTemplateType(), $emailTemplate);
        $form->handleRequest($this->request);

        if ($form->isSubmitted() && $form->isValid()) {
            $emailTemplate = $this->emailService->createNew($emailTemplate);

            return $this->redirectToRoute('vtech_solution_bundle_email_template_show', array('id' => $emailTemplate->getId()));
        } else {
            $this->responseArray['form'] = $form->createView();
        }

        return $this->responseArray;
    }

    /**
     * Finds and displays a emailTemplate entity.
     *
     * @Route("/{id}", name="vtech_solution_bundle_email_template_show")
     * @Method("GET")
     * @Template("vTechSolutionEmailBundle:emailtemplate:show.html.twig")
     */
    public function showAction(EmailTemplate $emailTemplate)
    {
        $this->initAction();
        $deleteForm = $this->createDeleteForm($emailTemplate);

        $this->responseArray['emailTemplate'] = $emailTemplate;
        $this->responseArray['delete_form'] = $deleteForm->createView();

        return $this->responseArray;
    }



    /**
     * Displays a form to edit an existing emailTemplate entity.
     *
     * @Route("/edit/{id}", name="vtech_solution_bundle_email_template_edit")
     * @Template("vTechSolutionEmailBundle:emailtemplate:edit.html.twig")
     * @Method({"GET"})
     */
    public function editAction(EmailTemplate $emailTemplate)
    {

        $this->initAction();

        $deleteForm = $this->createDeleteForm($emailTemplate);
        $editForm = $this->createForm(new EmailtemplateType(), $emailTemplate);

        $this->responseArray['emailTemplate'] = $emailTemplate;
        $this->responseArray['edit_form'] = $editForm->createView();
        $this->responseArray['delete_form'] = $deleteForm->createView();
        $this->responseArray['form_id'] = $this->request->get('id');
        $this->responseArray['iframe'] = $this->request->get('iframe');

        return $this->responseArray;
    }

    /**
     * Displays a form to edit an existing emailTemplate entity.
     *
     * @Route("/edit/{id}", name="vtech_solution_bundle_email_process_template_edit")
     * @Template("vTechSolutionEmailBundle:emailtemplate:edit.html.twig")
     * @Method({"POST"})
     */
    public function processEditTemplateAction(Request $request, EmailTemplate $emailTemplate)
    {
      $this->initAction();

      $editForm = $this->createForm(new EmailtemplateType(), $emailTemplate);
      $editForm->handleRequest($request);
      if ($editForm->isSubmitted() && $editForm->isValid()) {
          $emailTemplate = $this->emailService->editTemplate($emailTemplate);
          $this->responseArray['iframe'] = $this->request->get('iframe');
          if ($this->responseArray['iframe'] == true) {
              return $this->redirectToRoute('vtech_solution_bundle_email_process_template_edit', array('id' => $emailTemplate->getId(),
                    'iframe' => 1
                    ));
          } else {
                return $this->redirectToRoute('vtech_solution_bundle_email_process_template_edit', array('id' => $emailTemplate->getId()));
            }
        }

      return $this->responseArray;
    }

    /**
     * Deletes a emailTemplate entity.
     *
     * @Route("/{id}", name="vtech_solution_bundle_email_delete_template")
     * @Template("vTechSolutionEmailBundle:emailtemplate:new.html.twig")
     * @Method("DELETE")
     */
    public function deleteAction(Request $request, EmailTemplate $emailTemplate)
    {
        $form = $this->createDeleteForm($emailTemplate);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($emailTemplate);
            $em->flush();
        }

        return $this->redirectToRoute('vtech_solution_bundle_email_template_list_all');
    }

    /**
     * Creates a form to delete a emailTemplate entity.
     *
     * @param EmailTemplate $emailTemplate The emailTemplate entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(EmailTemplate $emailTemplate)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('vtech_solution_bundle_email_delete_template', array('id' => $emailTemplate->getId())))
            ->setMethod('DELETE')
            ->getForm()
        ;
    }
}

<?php

namespace vTechSolution\Bundle\EmailBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\JsonResponse;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use OG\SendGridBundle\Exception\SendGridException;

/**
   * @Route("/api/v1/email")
   */

class EmailController extends Controller
{
  private $responseArray;
  private $request;

  private function initAction()
  {
    $this->responseArray = array();
    $this->request = $this->getRequest();

    $this->emailService = $this->get('v_tech_solution_email.email');
  }

/**
 * @Route("/email-send", name="vtech_solution_bundle_email_email_send")
 * @Method({"GET"} )
 */

public function sendEmail() {

  $this->initAction();

  $this->responseArray = $this->emailService->createEmail();

  return new JsonResponse($this->responseArray);

}

/**
 * @Route("/add-template", name="vtech_solution_bundle_email_add_template")
 * @Method({"POST"} )
 */

public function addTemplate() {

  $this->initAction();

  $this->responseArray = $this->emailService->createTemplate();

  return new JsonResponse($this->responseArray);

}

/**
 * @Route("/template-dashboard", name="vtech_solution_bundle_email_template_dashboard")
 * @Template("vTechSolutionEmailBundle:EmailTemplate:emailtemplate.html.twig")
 * @Method({"GET"} )
 */

public function createTemplate() {

  $this->initAction();

	return $this->responseArray;


}

/**
 * @Route("/send-email-template", name="vtech_solution_bundle_email_send_email_template")
 * @Method({"POST"} )
 */

public function sendEmailTemplate() {

  $this->initAction();

  $this->responseArray = $this->emailService->sendTemplate();

  return new JsonResponse($this->responseArray);

}

/**
 * @Route("/email-queue", name="vtech_solution_bundle_email_email_queue")
 * @Method({"POST"} )
 */

public function addEmailInQueue() {

  $this->initAction();

  $this->responseArray = $this->emailService->addEmailQueue();

  return new JsonResponse($this->responseArray);

}

/**
 * @Route("/send-email-queue/{sent_date}", name="vtech_solution_bundle_email_send_email_queue")
 * @Method({"GET"} )
 */

public function sendQueueEmail() {

  $this->initAction();

  $this->responseArray = $this->emailService->getEmailQueue();

  return new JsonResponse($this->responseArray);

}

/**
 * @Route("/send-email", name="vtech_solution_bundle_email_send_email")
 * @Method({"POST"} )
 */

public function sendEmails() {

  $this->initAction();

  $this->responseArray = $this->emailService->sendEmail();

  return new JsonResponse($this->responseArray);

}

/**
 * @Route("/send-emailtemplate", name="vtech_solution_bundle_email_send_emailtemplate")
 * @Method({"POST"} )
 */

public function sendEmailTemplates() {

  $this->initAction();

  $this->responseArray = $this->emailService->sendEmailTemplate();

  return new JsonResponse($this->responseArray);

}

/**
 * @Route("/email-validation", name="vtech_solution_bundle_email_email_validation")
 * @Method({"GET"} )
 */

public function emailQueueValidation() {

  $this->initAction();

  $this->responseArray = $this->emailService->emailValidation();

  return new JsonResponse($this->responseArray);

}

/**
 * @Route("/removed-pipeline-entry", name="vtech_solution_bundle_email_remove_pipeline_entry")
 * @Method({"POST"} )
 */

public function removeEmailFromQueue() {

  $this->initAction();

  $this->responseArray = $this->emailService->removedFromPipeline();

  return new JsonResponse($this->responseArray);

}

/**
 * @Route("/email-autoimport-jobs", name="vtech_solution_bundle_email_email_autoimport_jobs")
 * @Method({"GET"} )
 */

public function emailAutoImportJobs() {

  $this->initAction();

  $this->responseArray = $this->emailService->emailAutoImportJobs();

   return new JsonResponse($this->responseArray);

}

/**
 * @Route("/mass-email-sales", name="vtech_solution_bundle_email_mass_email_sales")
 * @Method({"POST"} )
 */

public function massEmailSales() {

  $this->initAction();

  $this->responseArray = $this->emailService->massEmailSalesData();

   return new JsonResponse($this->responseArray);

}


}

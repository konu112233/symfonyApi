<?php

namespace vTechSolution\Bundle\ScreeningBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class ScreeningControllerTest extends WebTestCase
{
}

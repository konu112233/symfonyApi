<?php

namespace vTechSolution\Bundle\ScreeningBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * FeedbackMapping
 *
 * @ORM\Table(name="vtech_feedback_mapping")
 * @ORM\Entity(repositoryClass="vTechSolution\Bundle\ScreeningBundle\Entity\ScreeningMappingRepository")
 */
class ScreeningMapping
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="feedback_ids", type="text")
     */
    private $feedbackIds;

    /**
     * @var string
     *
     * @ORM\Column(name="screening_type", type="string", length=255)
     */
    private $screeningType;

    /**
     * @var int
     *
     * @ORM\Column(name="candidate_id", type="integer")
     */
    private $candidateId;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime")
     */
    private $createdAt;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set feedbackIds
     *
     * @param string $feedbackIds
     *
     * @return FeedbackMapping
     */
    public function setFeedbackIds($feedbackIds)
    {
        $this->feedbackIds = $feedbackIds;

        return $this;
    }

    /**
     * Get feedbackIds
     *
     * @return string
     */
    public function getFeedbackIds()
    {
        return $this->feedbackIds;
    }

    /**
     * Set screeningType
     *
     * @param string $screeningType
     *
     * @return FeedbackMapping
     */
    public function setScreeningType($screeningType)
    {
        $this->screeningType = $screeningType;

        return $this;
    }

    /**
     * Get screeningType
     *
     * @return string
     */
    public function getScreeningType()
    {
        return $this->screeningType;
    }

    /**
     * Set candidateId
     *
     * @param integer $candidateId
     *
     * @return FeedbackMapping
     */
    public function setCandidateId($candidateId)
    {
        $this->candidateId = $candidateId;

        return $this;
    }

    /**
     * Get candidateId
     *
     * @return int
     */
    public function getCandidateId()
    {
        return $this->candidateId;
    }

    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     *
     * @return FeedbackMapping
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }
}


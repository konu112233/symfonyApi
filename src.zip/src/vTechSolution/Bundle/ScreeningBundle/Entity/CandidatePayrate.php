<?php

namespace vTechSolution\Bundle\ScreeningBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * CandidatePayrate
 *
 * @ORM\Table(name="vtech_candidate_payrate")
 * @ORM\Entity(repositoryClass="vTechSolution\Bundle\ScreeningBundle\Entity\CandidatePayrateRepository")
 */
class CandidatePayrate
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var int
     *
     * @ORM\Column(name="candidate_ats_id", type="integer")
     */
    private $candidateAtsId;

    /**
     * @var string
     *
     * @ORM\Column(name="candidate_full_name", type="text")
     */
    private $candidateFullName;

    /**
     * @var string
     *
     * @ORM\Column(name="candidate_email", type="string", length=100)
     */
    private $candidateEmail;

    /**
     * @var string
     *
     * @ORM\Column(name="candidate_owner_name", type="text")
     */
    private $candidateOwnerName;

    /**
     * @var int
     *
     * @ORM\Column(name="job_id", type="integer")
     */
    private $jobId;

    /**
     * @var string
     *
     * @ORM\Column(name="max_rate_for_job", type="string", length=50)
     */
    private $maxRateForJob;

    /**
     * @var string
     *
     * @ORM\Column(name="offer_rate_for_job", type="string", length=50)
     */
    private $offerRateForJob;

    /**
     * @var int
     *
     * @ORM\Column(name="offer_given_by", type="integer")
     */
    private $offerGivenBy;

    /**
     * @var string
     *
     * @ORM\Column(name="offer_given_by_name", type="text")
     */
    private $offerGivenByName;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="offer_date", type="datetime")
     */
    private $offerDate;

     /**
     * @var string
     *
     * @ORM\Column(name="mail_message", type="text")
     */
    private $mailMessage;

    /**
     * @var int
     *
     * @ORM\Column(name="offer_accepted_status", type="integer")
     */
    private $offerAcceptedStatus;

    /**
     * @var string
     *
     * @ORM\Column(name="job_order_type", type="text")
     */
    private $jobOrderType;

    /**
     * @var string
     *
     * @ORM\Column(name="job_order_type_in_c2c", type="text")
     */
    private $jobOrderTypeInC2c;

    /**
     * @var string
     *
     * @ORM\Column(name="job_order_type_in_c2c_employee_email_id", type="text")
     */
    private $jobOrderTypeInC2cEmployeeEmailId;


    /**
     * @var string
     *
     * @ORM\Column(name="candidate_ip_address", type="text")
     */
    private $candidateIpAddress;

    /**
     * @var string
     *
     * @ORM\Column(name="recruiter_email_id", type="text")
     */
    private $recruiterEmailId;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set candidateAtsId
     *
     * @param integer $candidateAtsId
     *
     * @return CandidatePayrate
     */
    public function setCandidateAtsId($candidateAtsId)
    {
        $this->candidateAtsId = $candidateAtsId;

        return $this;
    }

    /**
     * Get candidateAtsId
     *
     * @return int
     */
    public function getCandidateAtsId()
    {
        return $this->candidateAtsId;
    }

    /**
     * Set candidateFullName
     *
     * @param string $candidateFullName
     *
     * @return CandidatePayrate
     */
    public function setCandidateFullName($candidateFullName)
    {
        $this->candidateFullName = $candidateFullName;

        return $this;
    }

    /**
     * Get candidateFullName
     *
     * @return string
     */
    public function getCandidateFullName()
    {
        return $this->candidateFullName;
    }

    /**
     * Set candidateEmail
     *
     * @param string $candidateEmail
     *
     * @return CandidatePayrate
     */
    public function setCandidateEmail($candidateEmail)
    {
        $this->candidateEmail = $candidateEmail;

        return $this;
    }

    /**
     * Get candidateEmail
     *
     * @return string
     */
    public function getCandidateEmail()
    {
        return $this->candidateEmail;
    }

    /**
     * Set candidateOwnerName
     *
     * @param string $candidateOwnerName
     *
     * @return CandidatePayrate
     */
    public function setCandidateOwnerName($candidateOwnerName)
    {
        $this->candidateOwnerName = $candidateOwnerName;

        return $this;
    }

    /**
     * Get candidateOwnerName
     *
     * @return string
     */
    public function getCandidateOwnerName()
    {
        return $this->candidateOwnerName;
    }

    /**
     * Set jobId
     *
     * @param integer $jobId
     *
     * @return CandidatePayrate
     */
    public function setJobId($jobId)
    {
        $this->jobId = $jobId;

        return $this;
    }

    /**
     * Get jobId
     *
     * @return int
     */
    public function getJobId()
    {
        return $this->jobId;
    }

    /**
     * Set maxRateForJob
     *
     * @param string $maxRateForJob
     *
     * @return CandidatePayrate
     */
    public function setMaxRateForJob($maxRateForJob)
    {
        $this->maxRateForJob = $maxRateForJob;

        return $this;
    }

    /**
     * Get maxRateForJob
     *
     * @return string
     */
    public function getMaxRateForJob()
    {
        return $this->maxRateForJob;
    }

    /**
     * Set offerRateForJob
     *
     * @param string $offerRateForJob
     *
     * @return CandidatePayrate
     */
    public function setOfferRateForJob($offerRateForJob)
    {
        $this->offerRateForJob = $offerRateForJob;

        return $this;
    }

    /**
     * Get offerRateForJob
     *
     * @return string
     */
    public function getOfferRateForJob()
    {
        return $this->offerRateForJob;
    }

    /**
     * Set offerGivenBy
     *
     * @param integer $offerGivenBy
     *
     * @return CandidatePayrate
     */
    public function setOfferGivenBy($offerGivenBy)
    {
        $this->offerGivenBy = $offerGivenBy;

        return $this;
    }

    /**
     * Get offerGivenBy
     *
     * @return int
     */
    public function getOfferGivenBy()
    {
        return $this->offerGivenBy;
    }

    /**
     * Set offerDate
     *
     * @param \DateTime $offerDate
     *
     * @return CandidatePayrate
     */
    public function setOfferDate($offerDate)
    {
        $this->offerDate = $offerDate;

        return $this;
    }

    /**
     * Get offerDate
     *
     * @return \DateTime
     */
    public function getOfferDate()
    {
        return $this->offerDate;
    }

    /**
     * Set mailMessage
     *
     * @param string $mailMessage
     *
     * @return CandidatePayrate
     */
    public function setMailMessage($mailMessage)
    {
        $this->mailMessage = $mailMessage;

        return $this;
    }

    /**
     * Get mailMessage
     *
     * @return string
     */
    public function getMailMessage()
    {
        return $this->mailMessage;
    }

    /**
     * Set offerGivenByName
     *
     * @param string $offerGivenByName
     *
     * @return CandidatePayrate
     */
    public function setOfferGivenByName($offerGivenByName)
    {
        $this->offerGivenByName = $offerGivenByName;

        return $this;
    }

    /**
     * Get offerGivenByName
     *
     * @return string
     */
    public function getOfferGivenByName()
    {
        return $this->offerGivenByName;
    }

    /**
     * Set offerAcceptedStatus
     *
     * @param integer $offerAcceptedStatus
     *
     * @return CandidatePayrate
     */
    public function setOfferAcceptedStatus($offerAcceptedStatus)
    {
        $this->offerAcceptedStatus = $offerAcceptedStatus;

        return $this;
    }

    /**
     * Get offerAcceptedStatus
     *
     * @return integer
     */
    public function getOfferAcceptedStatus()
    {
        return $this->offerAcceptedStatus;
    }

    /**
     * Set jobOrderType
     *
     * @param string $jobOrderType
     *
     * @return CandidatePayrate
     */
    public function setJobOrderType($jobOrderType)
    {
        $this->jobOrderType = $jobOrderType;

        return $this;
    }

    /**
     * Get jobOrderType
     *
     * @return string
     */
    public function getJobOrderType()
    {
        return $this->jobOrderType;
    }

    /**
     * Set candidateIpAddress
     *
     * @param string $candidateIpAddress
     *
     * @return CandidatePayrate
     */
    public function setCandidateIpAddress($candidateIpAddress)
    {
        $this->candidateIpAddress = $candidateIpAddress;

        return $this;
    }

    /**
     * Get candidateIpAddress
     *
     * @return string
     */
    public function getCandidateIpAddress()
    {
        return $this->candidateIpAddress;
    }

    /**
     * Set jobOrderTypeInC2c
     *
     * @param string $jobOrderTypeInC2c
     *
     * @return CandidatePayrate
     */
    public function setJobOrderTypeInC2c($jobOrderTypeInC2c)
    {
        $this->jobOrderTypeInC2c = $jobOrderTypeInC2c;

        return $this;
    }

    /**
     * Get jobOrderTypeInC2c
     *
     * @return string
     */
    public function getJobOrderTypeInC2c()
    {
        return $this->jobOrderTypeInC2c;
    }

    /**
     * Set jobOrderTypeInC2cEmployeeEmailId
     *
     * @param string $jobOrderTypeInC2cEmployeeEmailId
     *
     * @return CandidatePayrate
     */
    public function setJobOrderTypeInC2cEmployeeEmailId($jobOrderTypeInC2cEmployeeEmailId)
    {
        $this->jobOrderTypeInC2cEmployeeEmailId = $jobOrderTypeInC2cEmployeeEmailId;

        return $this;
    }

    /**
     * Get jobOrderTypeInC2cEmployeeEmailId
     *
     * @return string
     */
    public function getJobOrderTypeInC2cEmployeeEmailId()
    {
        return $this->jobOrderTypeInC2cEmployeeEmailId;
    }

    /**
     * Set recruiterEmailId
     *
     * @param string $recruiterEmailId
     *
     * @return CandidatePayrate
     */
    public function setRecruiterEmailId($recruiterEmailId)
    {
        $this->recruiterEmailId = $recruiterEmailId;

        return $this;
    }

    /**
     * Get recruiterEmailId
     *
     * @return string
     */
    public function getRecruiterEmailId()
    {
        return $this->recruiterEmailId;
    }
}

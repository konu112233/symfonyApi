<?php

namespace vTechSolution\Bundle\ScreeningBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * vTechAnswerBank
 *
 * @ORM\Table(name="vtech_answer_bank")
 * @ORM\Entity(repositoryClass="vTechSolution\Bundle\ScreeningBundle\Entity\vTechAnswerBankRepository")
 */
class vTechAnswerBank
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var int
     *
     * @ORM\Column(name="question_id", type="integer")
     */
    private $questionId;

    /**
     * @var string
     *
     * @ORM\Column(name="answer", type="string", length=255)
     */
    private $answer;

    /**
     * @var int
     *
     * @ORM\Column(name="user_id", type="integer")
     */
    private $userId;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="create_at", type="datetime")
     */
    private $createAt;

    /**
     * @var \int
     *
     * @ORM\Column(name="answer_status", type="integer", options={"default" : 0})
     */
    private $answerStatus;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set questionId
     *
     * @param integer $questionId
     *
     * @return vTechAnswerBank
     */
    public function setQuestionId($questionId)
    {
        $this->questionId = $questionId;

        return $this;
    }

    /**
     * Get questionId
     *
     * @return int
     */
    public function getQuestionId()
    {
        return $this->questionId;
    }

    /**
     * Set answer
     *
     * @param string $answer
     *
     * @return vTechAnswerBank
     */
    public function setAnswer($answer)
    {
        $this->answer = $answer;

        return $this;
    }

    /**
     * Get answer
     *
     * @return string
     */
    public function getAnswer()
    {
        return $this->answer;
    }

    /**
     * Set userId
     *
     * @param integer $userId
     *
     * @return vTechAnswerBank
     */
    public function setUserId($userId)
    {
        $this->userId = $userId;

        return $this;
    }

    /**
     * Get userId
     *
     * @return int
     */
    public function getUserId()
    {
        return $this->userId;
    }

    /**
     * Set createAt
     *
     * @param \DateTime $createAt
     *
     * @return vTechAnswerBank
     */
    public function setCreateAt($createAt)
    {
        $this->createAt = $createAt;

        return $this;
    }

    /**
     * Get createAt
     *
     * @return \DateTime
     */
    public function getCreateAt()
    {
        return $this->createAt;
    }

    /**
     * Set answerStatus
     *
     * @param integer $answerStatus
     *
     * @return vTechAnswerBank
     */
    public function setAnswerStatus($answerStatus)
    {
        $this->answerStatus = $answerStatus;

        return $this;
    }

    /**
     * Get answerStatus
     *
     * @return int
     */
    public function getAnswerStatus()
    {
        return $this->answerStatus;
    }
}


<?php

namespace vTechSolution\Bundle\ScreeningBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * QuestionFeedback
 *
 * @ORM\Table(name="vtech_question_feedback")
 * @ORM\Entity(repositoryClass="vTechSolution\Bundle\ScreeningBundle\Entity\QuestionFeedbackRepository")
 */
class QuestionFeedback
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var int
     *
     * @ORM\Column(name="question_id", type="integer")
     */
    private $questionId;

    /**
     * @var int
     *
     * @ORM\Column(name="joborder_id", type="integer")
     */
    private $joborderId;

    /**
     * @var string
     *
     * @ORM\Column(name="feedback", type="text", nullable=true)
     */
    private $feedback;

    /**
     * @var int
     *
     * @ORM\Column(name="user_id", type="integer")
     */
    private $userId;
	
	 /**
     * @var int
     *
     * @ORM\Column(name="user_name", type="string")
     */
    private $userName;

    /**
     * @var int
     *
     * @ORM\Column(name="candidate_id", type="integer")
     */
    private $candidateId;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime")
     */
    private $createdAt;

    /**
     * @var int
     *
     * @ORM\Column(name="prededined_answer_id", type="integer", nullable=true)
     */
    private $predefinedAnswerId;

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set questionId
     *
     * @param integer $questionId
     *
     * @return QuestionFeedback
     */
    public function setQuestionId($questionId)
    {
        $this->questionId = $questionId;

        return $this;
    }

    /**
     * Get questionId
     *
     * @return int
     */
    public function getQuestionId()
    {
        return $this->questionId;
    }

    /**
     * Set joborderId
     *
     * @param integer $joborderId
     *
     * @return QuestionFeedback
     */
    public function setJoborderId($joborderId)
    {
        $this->joborderId = $joborderId;

        return $this;
    }

    /**
     * Get joborderId
     *
     * @return int
     */
    public function getJoborderId()
    {
        return $this->joborderId;
    }

    /**
     * Set feedback
     *
     * @param string $feedback
     *
     * @return QuestionFeedback
     */
    public function setFeedback($feedback)
    {
        $this->feedback = $feedback;

        return $this;
    }

    /**
     * Get feedback
     *
     * @return string
     */
    public function getFeedback()
    {
        return $this->feedback;
    }

    /**
     * Set userId
     *
     * @param integer $userId
     *
     * @return QuestionFeedback
     */
    public function setUserId($userId)
    {
        $this->userId = $userId;

        return $this;
    }

    /**
     * Get userId
     *
     * @return int
     */
    public function getUserId()
    {
        return $this->userId;
    }

	 /**
     * Set userName
     *
     * @param string $userName
     *
     * @return QuestionFeedback
     */
    public function setUserName($userName)
    {
        $this->userName = $userName;

        return $this;
    }

    /**
     * Get userName
     *
     * @return string
     */
    public function getUserName()
    {
        return $this->userName;
    }
	
    /**
     * Set candidateId
     *
     * @param integer $candidateId
     *
     * @return QuestionFeedback
     */
    public function setCandidateId($candidateId)
    {
        $this->candidateId = $candidateId;

        return $this;
    }

    /**
     * Get candidateId
     *
     * @return int
     */
    public function getCandidateId()
    {
        return $this->candidateId;
    }

    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     *
     * @return QuestionFeedback
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set predefinedAnswerId
     *
     * @param integer $predefinedAnswerId
     *
     * @return QuestionFeedback
     */
    public function setpredefinedAnswerId($predefinedAnswerId)
    {
        $this->predefinedAnswerId = $predefinedAnswerId;

        return $this;
    }

    /**
     * Get predefinedAnswerId
     *
     * @return int
     */
    public function getpredefinedAnswerId()
    {
        return $this->predefinedAnswerId;
    }
}


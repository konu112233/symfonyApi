<?php

namespace vTechSolution\Bundle\ScreeningBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * QuestionBank
 *
 * @ORM\Table(name="vtech_question_bank")
 * @ORM\Entity(repositoryClass="vTechSolution\Bundle\ScreeningBundle\Entity\QuestionBankRepository")
 */
class QuestionBank
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="type", type="string", length=255)
     */
    private $type;

    /**
     * @var string
     *
     * @ORM\Column(name="question", type="text")
     */
    private $question;

    /**
     * @var int
     *
     * @ORM\Column(name="user_id", type="integer")
     */
    private $userId;

    /**
     * @var int
     *
     * @ORM\Column(name="sort_order", type="integer", options={"default" : 1})
     */
    private $sortOrder;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="create_at", type="datetime")
     */
    private $createAt;

    /**
     * @var int
     *
     * @ORM\Column(name="question_status", type="integer")
     */
    private $questionStatus;

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set type
     *
     * @param string $type
     *
     * @return QuestionBank
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }

    /**
     * Set question
     *
     * @param string $question
     *
     * @return QuestionBank
     */
    public function setQuestion($question)
    {
        $this->question = $question;

        return $this;
    }

    /**
     * Get question
     *
     * @return string
     */
    public function getQuestion()
    {
        return $this->question;
    }

    /**
     * Set userId
     *
     * @param integer $userId
     *
     * @return QuestionBank
     */
    public function setUserId($userId)
    {
        $this->userId = $userId;

        return $this;
    }

    /**
     * Get userId
     *
     * @return int
     */
    public function getUserId()
    {
        return $this->userId;
    }

    /**
     * Set sortOrder
     *
     * @param integer $sortOrder
     *
     * @return QuestionBank
     */
    public function setSortOrder($sortOrder)
    {
        $this->sortOrder = $sortOrder;

        return $this;
    }

    /**
     * Get sortOrder
     *
     * @return int
     */
    public function getSortOrder()
    {
        return $this->sortOrder;
    }

    /**
     * Set createAt
     *
     * @param \DateTime $createAt
     *
     * @return QuestionBank
     */
    public function setCreateAt($createAt)
    {
        $this->createAt = $createAt;

        return $this;
    }

    /**
     * Get createAt
     *
     * @return \DateTime
     */
    public function getCreateAt()
    {
        return $this->createAt;
    }

    /**
     * Set questionStatus
     *
     * @param integer $questionStatus
     *
     * @return QuestionBank
     */
    public function setQuestionStatus($questionStatus)
    {
        $this->questionStatus = $questionStatus;

        return $this;
    }

    /**
     * Get questionStatus
     *
     * @return integer
     */
    public function getQuestionStatus()
    {
        return $this->questionStatus;
    }
}

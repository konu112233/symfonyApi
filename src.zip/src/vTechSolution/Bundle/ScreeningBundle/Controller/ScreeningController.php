<?php

namespace vTechSolution\Bundle\ScreeningBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Entity\ComplianceList;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;

/**
   * @Route("/api/v1/screening")
 */
class ScreeningController extends Controller
{
	private $responseArray;
    private $request;
    private $screeningService;

    private function initAction()
    {
      $this->responseArray = array();
      $this->request = $this->getRequest();

      $this->screeningService = $this->get('v_tech_solution_screening.screening');
    }

	


	 /**
   * @Route("/addscreeningquestions", name="vtech_solution_bundle_screening_add_screening_questions")
   * @Method({"POST"} )
   */

	public function addFeedbackAction() {

		$this->initAction();
		
		$this->responseArray = $this->screeningService->addQuestionFeedback();
		//$this->responseArray = $this->screeningService->addScreeningQuestionFeedback();
		

		return new JsonResponse($this->responseArray);

	}  

	 /**
   * @Route("/get-screening-by-candidate",name="vtech_solution_bundle_screening_get_screening_by_candidate")
   * @Method({"GET"} )
   */

	public function getScreeningByCandidateAction() {

	$this->initAction();

	$this->responseArray["candidate_screening"] = $this->screeningService->getByCandidate();
	
	$this->responseArray["candidate_screening_question_bank"] = $this->screeningService->getScreeningQuestionsFromVtechTools();

	$this->responseArray["candidate_question_answer_list"] = $this->screeningService->getAnswerListByQuestion($this->responseArray["candidate_screening"]);
	return new JsonResponse($this->responseArray);

	}

	


	 /**
   * @Route("/addquestion", name="vtech_solution_bundle_screening_addquestion")
   * @Method({"POST"} )
   */

	public function addQuestionAction() {

		$this->initAction();

		$this->responseArray = $this->screeningService->addQuestions();
		
		return new JsonResponse($this->responseArray);

	}

	 /**
   * @Route("/getaddedquestions", name="vtech_solution_bundle_screening_get_added_questions")
   * @Template("vTechSolutionScreeningBundle:QuestionBank:QuestionBankQuestions.html.twig")
   * @Method({"GET"} )
   */

	public function getAddedQuestionsAction() {

		$this->initAction();

		//$this->responseArray = $this->screeningService->getAddedQuestions();

		$this->responseArray = array();
		//print_r($this->responseArray); die;
		return $this->responseArray;
       
	}

	/**
   * @Route("/get-questions-admin",name="vtech_solution_bundle_screening_get-questions-admin")
   * @Template("vTechSolutionScreeningBundle:QuestionBank:QuestionBankShowQuestions.html.twig")
   * @Method({"POST"} )
   */

	public function getQuestionsAdminAction() {

	$this->initAction();

	
	$this->responseArray["result"]= $this->screeningService->getScreeningQuestionsFromVtechTools();

	return $this->responseArray;

	}

	/**
   * @Route("/updateselectquestion", name="vtech_solution_bundle_screening_update_select_question")
   * @Method({"POST"} )
   */

	public function updateQuestionSelectionAction() {

		$this->initAction();

		$this->responseArray = $this->screeningService->updateQuestionSelection();
		
		return new JsonResponse($this->responseArray);
	}


}

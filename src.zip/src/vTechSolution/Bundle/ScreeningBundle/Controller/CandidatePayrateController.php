<?php

namespace vTechSolution\Bundle\ScreeningBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\JsonResponse;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


/**
   * @Route("/api/v1/candidate-payrate")
 */
class CandidatePayrateController extends Controller
{
	private $responseArray;
    private $request;
    private $screeningService;

    private function initAction()
    {
      $this->responseArray = array();
      $this->request = $this->getRequest();
	  $this->candidatePayrateService = $this->get('v_tech_solution_screening.candidate_payrate');
    }

   /**
   * @Route("/get-by-candidate", name="vtech_solution_bundle_screening_candidate_payrate")
   * @Method({"GET"} )
   */

	public function getByCandidateAction() {

	$this->initAction();

	$this->responseArray = $this->candidatePayrateService->getByCandidate();

	return new JsonResponse($this->responseArray);

	}

	 /**
   * @Route("/add-candidate-payrate", name="vtech_solution_bundle_screening_add_candidate_payrate")
   * @Method({"POST"} )
   */

	public function addCandidatePayrateAction() {

	$this->initAction();

	$this->responseArray = $this->candidatePayrateService->addCandidatePayrate();

	return new JsonResponse($this->responseArray);

	}

	/**
   * @Route("/get-candidate-payrate-email-template", name="vtech_solution_bundle_screening_get_candidate_payrate_email_template")
   * @Method({"POST"} )
   * @Template("vTechSolutionScreeningBundle:CandidatePayrate:emailContent.html.twig")
   */

	public function getCandidatePayrateEmailTemplateAction() {

	$this->initAction();

	$this->responseArray["message"] = $this->candidatePayrateService->getCandidatePayrateEmailTemplate();

	return $this->responseArray;

	}

	 /**
   * @Route("/candidate-accept-payrate/{id}/{type}", name="vtech_solution_bundle_screening_candidate_accept_payrate")
   * @Method({"GET"} )
   */

	public function candidateAcceptPayrateAction() {

	$this->initAction();

	$this->responseArray["sentPayrateEmployeeName"][] = $this->candidatePayrateService->candidateAcceptPayrate();

	$type = $this->request->get('type');

	

	if ($type == 'accept') {
		
		if($this->responseArray["sentPayrateEmployeeName"][0]["oldOfferStatus"] != '0'){

			return $this->render("vTechSolutionScreeningBundle:CandidatePayrate:statusProvidedForPayrate.html.twig",$this->responseArray);
		
		}else{

			$this->candidatePayrateService->candidateAcceptPayrateSendMail($this->responseArray);

		return $this->render("vTechSolutionScreeningBundle:CandidatePayrate:acceptPayrate.html.twig",$this->responseArray);
		}

	} else {

		if($this->responseArray["sentPayrateEmployeeName"][0]["oldOfferStatus"] != '0'){

			return $this->render("vTechSolutionScreeningBundle:CandidatePayrate:statusProvidedForPayrate.html.twig",$this->responseArray);
		
		}else{

		$this->candidatePayrateService->candidateAcceptPayrateSendMail($this->responseArray);
		
		return $this->render("vTechSolutionScreeningBundle:CandidatePayrate:ignorePayrate.html.twig");

	}
	
		return $this->responseArray;

	}		

}
}
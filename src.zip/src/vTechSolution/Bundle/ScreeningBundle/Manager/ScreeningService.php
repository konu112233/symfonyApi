<?php

namespace vTechSolution\Bundle\ScreeningBundle\Manager;

use Symfony\Component\DependencyInjection\ContainerInterface as Container;

use vTechSolution\Bundle\ScreeningBundle\Entity\QuestionBank;
use vTechSolution\Bundle\ScreeningBundle\Entity\QuestionFeedback;
use vTechSolution\Bundle\ScreeningBundle\Entity\ScreeningMapping;
use vTechSolution\Bundle\ScreeningBundle\Entity\vTechAnswerBank;
use Symfony\Component\HttpFoundation\Request;

class ScreeningService
{

    private $container;
    private $doctrine;
    private $request;
    private $responseArray;
    private $vtechtoolDatabase;

    const HTTP_METHOD_GET = 'GET';
    const HTTP_METHOD_POST = 'POST';

	public function __construct(Container $container) {
        $this->container= $container;
        $this->request = $this->container->get('request');
        $this->responseArray = array();
        $this->doctrine = $this->container->get('doctrine');
        $this->questionBankRepository = $this->doctrine->getRepository('vTechSolutionScreeningBundle:QuestionBank');
        $this->questionFeedbackRepository = $this->doctrine->getRepository('vTechSolutionScreeningBundle:QuestionFeedback');
		$this->screeningMappingRepository = $this->doctrine->getRepository('vTechSolutionScreeningBundle:ScreeningMapping');
		$this->vTechAnswerBankRepository = $this->doctrine->getRepository('vTechSolutionScreeningBundle:vTechAnswerBank');

    }

    public function __destructor()
    {
        unset($this->container);
        unset($this->request);
        unset($this->responseArray);
    }




	public function addQuestionFeedback() {


				$jobId = $this->request->get('job_id');
				$userId = $this->request->get('user_id');
				$userName = $this->request->get('user_name');
				$candidateId = $this->request->get('candidate_id');
				$questionGroup = $this->request->get('question_group');
				$screeningType = $this->request->get('screening_type');



				foreach ($questionGroup as $value) {


				if($value["feedback"] != '') {

					$questionId = $value["question_id"] != '' ? $value["question_id"] : $questionBank->getId();
					$predefinedAnswerId = $value["feedback_list"] != '' ? $value["feedback_list"] : $vTechAnswerBank->getId();
					$questionFeedback = new QuestionFeedback();
					$questionFeedback->setQuestionId($questionId);
					$questionFeedback->setJoborderId($jobId);
					$questionFeedback->setFeedback($value["feedback"]);
					$questionFeedback->setUserId($userId);
					$questionFeedback->setUserName($userName);
					$questionFeedback->setCandidateId($candidateId);
					$questionFeedback->setCreatedAt(new \DateTime());
					$questionFeedback->setpredefinedAnswerId($predefinedAnswerId);


				$this->questionFeedbackRepository->commit($questionFeedback);


				$feedBackIds[]=$questionFeedback->getId();
			}
    	}

			$imFeedbackIds=implode(",",$feedBackIds);

				$screeningMapping = new ScreeningMapping();
    			$screeningMapping->setFeedbackIds($imFeedbackIds);
    			$screeningMapping->setScreeningType($screeningType);
    			$screeningMapping->setCandidateId($candidateId);
    			$screeningMapping->setCreatedAt(new \DateTime());

    	$this->screeningMappingRepository->commit($screeningMapping);

	$this->responseArray = array("status" => "success", "message" => "screening process successfully completed");

    	return $this->responseArray;
	}

	public function getScreeningQuestionsFromVtechTools() {
		$this->responseArray = array();
		$screeningType = $this->request->get('screening_type');
		$screeningQuestionStatus = $this->request->get('question_status');
		$screeningQuestionList = $this->questionBankRepository->getByScreeningType($screeningType,$screeningQuestionStatus);


		foreach($screeningQuestionList as $index => $screeningQuestion) {

			$questionId = $screeningQuestion->getId();
			$answerList = $this->vTechAnswerBankRepository->findByquestionId($questionId);
			$this->responseArray[$screeningQuestion->getType()][$index]['question'] = $screeningQuestion->getQuestion();
			$this->responseArray[$screeningQuestion->getType()][$index]['question_id'] = $screeningQuestion->getId();
			$this->responseArray[$screeningQuestion->getType()][$index]['question_status'] = $screeningQuestion->getQuestionStatus();
			foreach($answerList as $indexAnswer => $answer) {
			$this->responseArray[$screeningQuestion->getType()][$index]['answer'][$indexAnswer] = array("answer_id" => $answer->getId(), "message" => $answer->getAnswer(), "status" => $answer->getAnswerStatus());
			}


		}

			return $this->responseArray;
	}

	public function getByCandidate() {
		$this->responseArray = array();
		$candidateId = $this->request->get('candidate_id');
		$screeningType = $this->request->get('screening_type');
		$screeningMappingList = $this->screeningMappingRepository->getByCandidateIdAndScreeningType($candidateId, $screeningType);

		foreach($screeningMappingList as $index => $screeningMapping) {
			if(!isset($this->responseArray[$screeningMapping->getScreeningType()][$index])) {

				$this->responseArray[$screeningMapping->getScreeningType()][$index] = array("joborder_id" => 0, "user_id" => 0, "user_name" => '', "question_feedback_group" => array(), "created_at" => '');
			}


			$feedBackIds = $screeningMapping->getFeedbackIds();
			if($feedBackIds != '' ) {

				$feedBackList = $this->questionFeedbackRepository->getByIds(explode(",", $feedBackIds));

				foreach($feedBackList as $feedBackIndex => $feedBack) {

				if($feedBackIndex == 0) {
				$this->responseArray[$screeningMapping->getScreeningType()][$index]["joborder_id"] = $feedBack->getJoborderId();

				$this->responseArray[$screeningMapping->getScreeningType()][$index]["user_id"] = $feedBack->getUserId();

				$this->responseArray[$screeningMapping->getScreeningType()][$index]["user_name"] = $feedBack->getUserName();
				}
				$questionBank = $this->questionBankRepository->find($feedBack->getQuestionId());

				$this->responseArray[$screeningMapping->getScreeningType()][$index]["question_feedback_group"][] = array("id" => $questionBank->getId(), "question" => $questionBank->getQuestion(), "feedback" => $feedBack->getFeedback() );
				}

			}


			$this->responseArray[$screeningMapping->getScreeningType()][$index]["created_at"] = $screeningMapping->getCreatedAt();
		}

		return $this->responseArray;
	}

	 public function addQuestions() {

	 	$this->responseArray = array();
	 	$questionType =  $this->request->get('screening_type');
	 	$enteredQuestion = $this->request->get('screentingEnteredQuestion');
	 	$enteredAnswer = $this->request->get('answer_group');
	 	$enterBy = '1';

	 	$addNewQuestion = new QuestionBank();
	 	$addNewQuestion->setType($questionType);
	 	$addNewQuestion->setQuestion($enteredQuestion);
	 	$addNewQuestion->setUserId($enterBy);
	 	$addNewQuestion->setCreateAt(new \DateTime());
	 	$addNewQuestion->setQuestionStatus(1);
    $addNewQuestion->setSortOrder(1);
	 	$this->questionBankRepository->commit($addNewQuestion);

	 	if($this->questionBankRepository->commit($addNewQuestion)){
	 		$response = "Question has been added";
	 	}else
	 	{
	 		$response = "Question has not been added";
	 	}
	 	//return $this->responseArray = $response;

	 	foreach ($enteredAnswer as  $answer) {

	 		if($answer["answer"] != '') {
	 		$questionId = $addNewQuestion->getId();
	 		$questionAnswer = new vTechAnswerBank();
			$questionAnswer->setQuestionId($questionId);
			$questionAnswer->setAnswer($answer['answer']);
			$questionAnswer->setUserId($enterBy);
			$questionAnswer->setCreateAt(new \DateTime());

			$questionAnswer->setAnswerStatus($answer['status']);



			$this->vTechAnswerBankRepository->commit($questionAnswer);
		}
		}


	 	return $this->responseArray;
	 }


	  public function updateQuestionSelection() {

	  		$this->responseArray = array();
	  		$updateQuestionValue = $this->request->get('checkVar');
	  		$updateQuestionId = $this->request->get('checkedValue');

	  		$updatedQuestion = $this->questionBankRepository->find($updateQuestionId);


	  		if(count($updatedQuestion) > 0) {
	  			if($updateQuestionValue == 'true'){
	  				$updatedQuestion->setQuestionStatus('1');
	  				$response = "Question has been set to show";
	  			}
	  			if($updateQuestionValue == 'false'){
	  				$updatedQuestion->setQuestionStatus('0');
	  				$response = "Question has been set to hide";
	  			}
	  		}

	  		$this->responseArray = array("status" => $response);
	  		$this->questionBankRepository->commit($updatedQuestion);
	  	return $this->responseArray;
	  }


	  public function getAnswerListByQuestion($screeningData) {
	  	$this->responseArray = array();

	  	foreach ($screeningData as $key => $screening) {
	  		foreach ($screening as $screeningKey => $screeningValue) {
	  			if (isset($screeningValue['question_feedback_group'])) {
	  			foreach ($screeningValue['question_feedback_group'] as $questionId => $feedback) {

	  					$this->responseArray[$questionId][] = array(
	  						'questionId' => $feedback['id'],
	  						'answer' => $feedback['feedback'],
	  						'job_id' => $screeningValue['joborder_id'],
	  						'created_at' => $screeningValue['created_at']->format('Y-m-d H:i:s'),
	  						'user_name' =>  $screeningValue['user_name']
	  					);

	  			}
	  		}
	  		}

	  	}
	  	return $this->responseArray;
	  }

}

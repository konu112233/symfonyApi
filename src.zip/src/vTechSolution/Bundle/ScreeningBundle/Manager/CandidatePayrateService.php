<?php

namespace vTechSolution\Bundle\ScreeningBundle\Manager;

use Symfony\Component\DependencyInjection\ContainerInterface as Container;

use vTechSolution\Bundle\ScreeningBundle\Entity\CandidatePayrate;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class CandidatePayrateService
{

    private $container;
    private $doctrine;
    private $request;
    private $responseArray;
    private $vtechtoolDatabase;
    private $candidatePayrateRepository;
    private $shortUrlDatabase;
    private $emailService;

    const HTTP_METHOD_GET = 'GET';
    const HTTP_METHOD_POST = 'POST';

	public function __construct(Container $container) {
        $this->container= $container;
        $this->request = $this->container->get('request');
        $this->responseArray = array();
        $this->doctrine = $this->container->get('doctrine');
        $this->candidatePayrateRepository = $this->doctrine->getRepository('vTechSolutionScreeningBundle:CandidatePayrate');
        $this->emailService = $this->container->get('v_tech_solution_email.email');
       

    }

    public function __destructor()
    {
        unset($this->container);
        unset($this->request);
        unset($this->responseArray);
        unset($this->doctrine);
        unset($this->vtechtoolDatabase);
        unset($this->candidatePayrateRepository);
    }

    public function getByCandidate() {
        return $this->candidatePayrateRepository->findByCandidateId($this->request->get('candidate_id'));
    }

    public function decryptionOfEmployeeId( $string = '', $action = 'e' ) {
    
    $secret_key = 'my_simple_secret_key';
    $secret_iv = 'my_simple_secret_iv';
    $output = false;
    $encrypt_method = "AES-256-CBC";
    $key = hash( 'sha256', $secret_key );
    $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );

    if( $action == 'e' ) {
        $output = base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ) );
    }
    else if( $action == 'd' ){
        $output = openssl_decrypt( base64_decode( $string ), $encrypt_method, $key, 0, $iv );
    }

    return $output;

     
    }

    public function addCandidatePayrate() {

        $this->shortUrlDatabase = $this->container->get('v_tech_solution_quick_book.urlshortner')->getPDO();

        $siteUrl = $this->container->getParameter('site_url');
        $atsCandidateId = $this->request->get('candidate_ats_id');
        $atsCandidateFullName = $this->request->get('candidateFullName');
        $atscandidateEmail = $this->request->get('candidateEmail');
        $atsCandidateOwnerName = $this->request->get('candidateOwnerName');
        $atsCandidateJobId = $this->request->get('candidate_JobOrderId');
        $atsMaxRateForJob = $this->request->get('candidateRateMax');
        $atsOfferRate = $this->request->get('candidateofferedPayrate');
        $atsOfferGivenBy = $this->request->get('login_ats_id');
        $atsOfferGivenByName = $this->request->get('login_ats_name');
        $atsOfferGivenByContact =  $this->request->get('login_ats_contact');
        $atsMailMessage = $this->request->get('sentMailMessage');
        $atsJobTitleName = $this->request->get('candidateAppliedJob');
        $atsCompanyName = $this->request->get('candidateCompanyName');
        $atsJobOfferType = $this->request->get('candidateOfferJobType');
        $atsJobOfferDuration = $this->request->get('candidateJobDuration');
        $atsJobOfferLocation = $this->request->get('candidateJobLocation');
        $atsOfferGivenByEmail = $this->request->get('login_ats_email');
        $atsJobOfferTypeInC2C = $this->request->get('selectedtypeofc2c');
        $atsCompanyJobId = '('.$this->request->get('ats_company_job_id').')'; 
        $atsCompanyJobIdWithout = $this->request->get('ats_company_job_id'); 
        $atsCompanyJobIdDuplicate = $this->request->get('ats_company_job_id');
        $atsJobOffertypeInC2CEmployeeEmail = $this->request->get('EmployeesMailId');
        $atsJobOffertypeInC2CEmployeeName = $this->request->get('EmployeesName');
        $atsOfferAcceptStatus = '0';
        $atsOfferAcceptIpAddress = 'Not ACCEPTED';
        $mailLogoImageUrl = $siteUrl.'/images/logo.png';

        $addPayrate = new CandidatePayrate();
        $addPayrate->setCandidateAtsId($atsCandidateId);
        $addPayrate->setCandidateFullName($atsCandidateFullName);
        $addPayrate->setCandidateEmail($atscandidateEmail);
        $addPayrate->setCandidateOwnerName($atsCandidateOwnerName);
        $addPayrate->setJobId($atsCandidateJobId);
        $addPayrate->setMaxRateForJob($atsMaxRateForJob);
        $addPayrate->setOfferRateForJob($atsOfferRate);
        $addPayrate->setOfferGivenBy($atsOfferGivenBy);
        $addPayrate->setOfferDate(new \DateTime());
        $addPayrate->setMailMessage($atsMailMessage);
        $addPayrate->setOfferGivenByName($atsOfferGivenByName);
        $addPayrate->setOfferAcceptedStatus($atsOfferAcceptStatus);
        $addPayrate->setJobOrderType($atsJobOfferType);
        $addPayrate->setCandidateIpAddress($atsOfferAcceptIpAddress);
        $addPayrate->setJobOrderTypeInC2c($atsJobOfferTypeInC2C);
        $addPayrate->setJobOrderTypeInC2cEmployeeEmailId($atsJobOffertypeInC2CEmployeeEmail);
         $addPayrate->setRecruiterEmailId($atsOfferGivenByEmail);
        $this->candidatePayrateRepository->commit($addPayrate);
        $id = $addPayrate->getId();
        $addedId = $this->decryptionOfEmployeeId($id, 'e' );

        $url = "http://jobs.vtechsolution.com/a.php?i=".$atsCandidateJobId."&title=".$atsJobTitleName."&rec_email=".$atsOfferGivenByEmail."";

        $query = "SELECT id,url,shortened FROM short_url WHERE url = '".$url."'";
        
        $getShortUrl = $this->shortUrlDatabase->query($query)->fetchAll(); 

        if (empty($getShortUrl)) {
             
          
            $identity = time();
            $shorturl=base_convert($identity,10,36);

            $query = "INSERT INTO short_url (id,url,shortened) values('$identity','$url','$shorturl')";

            $insertShortUrl = $this->shortUrlDatabase->query($query)->execute();
            if ($insertShortUrl) {
                
                echo "success";
            }
            else {

                echo "error";
            }
        } 

        else {

             $getShortUrl[] = $getShortUrl;
            
        }
    
   
   foreach ($getShortUrl as $key => $geturl) {


    $job_reference_url = 'https://jobs.vtechsolution.com/a.php?i='.$geturl['shortened'];
    $accept_payrate_url = $siteUrl.'/api/v1/candidate-payrate/candidate-accept-payrate/'.$addedId.'/accept';
    $ccEmailSendTo = $atsOfferGivenByEmail;
    $decline_payrate_url =  $siteUrl.'/api/v1/candidate-payrate/candidate-accept-payrate/'.$addedId.'/ignore';

    $atsCompanyName = substr($atsCompanyName, 0, strpos($atsCompanyName, "_"));
       

            $candidatePayrateMailParameters[] =  array('logo_image_url' => $mailLogoImageUrl,'candidate_name' => $atsCandidateFullName, 'recruiter_name' => $atsOfferGivenByName, 'recruiter_mail_id' => $atsOfferGivenByEmail,'recruiter_contact' => $atsOfferGivenByContact, 'company_name' => $atsCompanyName, 'company_location' => $atsJobOfferLocation , 'job_title' => $atsJobTitleName, 'offered_rate' => $atsOfferRate, 'job_duration' => $atsJobOfferDuration, 'last_inserted_candidate_id' => $addedId, 'accept_link' => $accept_payrate_url, 'reject_link' => $decline_payrate_url,'jd_url' => $job_reference_url,'company_job_id' => $atsCompanyJobId,'company_job_id_without' => $atsCompanyJobIdWithout,'cji_copy' => $atsCompanyJobIdDuplicate);

             $subject = 'Rate Confirmation: '.$atsCompanyName.' - '.$atsJobTitleName .' '.$atsCompanyJobId.' - '.$atsJobOfferLocation; 


        if($atsJobOfferType == 'c2c' AND $atsJobOfferTypeInC2C == 'throughEmployee'){

            $atsJobOfferTypeC2C = 'c2c_through_employee';

            $candidatePayrateMailParametersc2c[] =  array('logo_image_url' => $mailLogoImageUrl,'candidate_name' => $atsCandidateFullName, 'recruiter_name' => $atsOfferGivenByName, 'recruiter_mail_id' => $atsOfferGivenByEmail,'recruiter_contact' => $atsOfferGivenByContact, 'company_name' => $atsCompanyName, 'company_location' => $atsJobOfferLocation , 'job_title' => $atsJobTitleName, 'offered_rate' => $atsOfferRate, 'job_duration' => $atsJobOfferDuration, 'last_inserted_candidate_id' => $addedId, 'accept_link' => $accept_payrate_url, 'reject_link' => $decline_payrate_url,'jd_url' => $job_reference_url,'company_job_id' => $atsCompanyJobId,'company_job_id_without' => $atsCompanyJobIdWithout,'employee_name' => $atsJobOffertypeInC2CEmployeeName,'cji_copy' => $atsCompanyJobIdDuplicate);

            $this->emailService->sendEmailTemplate($atsJobOfferTypeC2C, $atsOfferGivenByEmail, array($atsJobOffertypeInC2CEmployeeEmail), null, $ccEmailSendTo, $subject, null, $candidatePayrateMailParametersc2c);


             $response = "Mail Has Been Sent";

        }else{
                

            $this->emailService->sendEmailTemplate($atsJobOfferType, $atsOfferGivenByEmail, array($atscandidateEmail), null, $ccEmailSendTo, $subject, null, $candidatePayrateMailParameters);

           $response = "Mail Has Been Sent";

        }

        return $this->responseArray = $response;
    

    }
}


    public function candidateAcceptPayrate() {

            $candidateOfferStatus = array();

            $candidatePayrateFetchValue = $this->request->get('id');
            $type = $this->request->get('type');
            $candidatePayrateDecreptedValue = $this->decryptionOfEmployeeId($candidatePayrateFetchValue, 'd' );
            $candidatePayrate = $this->candidatePayrateRepository->find($candidatePayrateDecreptedValue); 

            if(count($candidatePayrate) > 0) {

                $fatchAcceptanceStatus = $candidatePayrate->getOfferAcceptedStatus();
                if($fatchAcceptanceStatus == '0'){
                    if($type == "accept"){
                    $candidatePayrate->setOfferAcceptedStatus('1');
                    }
                    if($type == "ignore"){
                    $candidatePayrate->setOfferAcceptedStatus('2');
                    }
                    $candidatePayrate->setCandidateIpAddress($_SERVER['REMOTE_ADDR']);
                    $this->candidatePayrateRepository->commit($candidatePayrate);
                }
                    $candidateOfferStatus = array('offerGivenByName' => $candidatePayrate->getOfferGivenByName(),'offerGivenByEmail' => $candidatePayrate->getRecruiterEmailId(),'offerGivenTo' => $candidatePayrate->getCandidateFullName(), 'offerForJobId' => $candidatePayrate->getJobId(), 'offeredRate' => $candidatePayrate->getOfferRateForJob(), 'offerGivenDate' =>  $candidatePayrate->getOfferDate(), 'offerJobType' => $candidatePayrate->getJobOrderType(), 'offerStatus' => $candidatePayrate->getOfferAcceptedStatus(),'oldOfferStatus'=> $fatchAcceptanceStatus, 'offerStatusWithIpAdd' => $candidatePayrate->getCandidateIpAddress());

                
            }

            return $this->responseArray = $candidateOfferStatus;

        }

     public function candidateAcceptPayrateSendMail($sendMailToRecruiter) {

        $this->catsdbDatabase = $this->container->get('v_tech_solution_quick_book.catsdb')->getPDO();



        foreach ($sendMailToRecruiter as $key => $dataToBeSend) {

            foreach ($dataToBeSend as $index => $fetchValue) {

                    $query = "SELECT 
                        j.joborder_id,
                        j.company_id,
                        j.title,
                        j.city,
                        j.state,
                        j.client_job_id,
                        c.name 
                    FROM 
                        joborder AS j
                        LEFT JOIN company as c ON j.company_id = c.company_id
                    WHERE j.joborder_id=".$fetchValue['offerForJobId'];

                     $jobOrderDetail = $this->catsdbDatabase->query($query)->fetchAll();
                    //print_r($jobOrderDetail);
                    // echo "<br>";
                    // echo $jobOrderDetail[0]['title'];
                    //  echo "<br>";
                    // echo $jobOrderDetail[0]['name'];
                    // die();
                    if( $fetchValue['offerStatus'] == '1'){
                        $statusOfTheOffer = "Accepted";
                    }else if($fetchValue['offerStatus'] == '2'){
                        $statusOfTheOffer = "Declined";
                    }
                    else{
                        $statusOfTheOffer = "";
                    }

                    $responseEmailType = "response_back_recruiter";
                    $responseEmailSendTo = $fetchValue['offerGivenByEmail'];
                    $responseCompanyName = explode("_VT", $jobOrderDetail[0]['name']);
                    $responseEmailSubject="Payrate ".$statusOfTheOffer." : ".$responseCompanyName[0] . ' - ' . $jobOrderDetail[0]['title'] . " (" . $jobOrderDetail[0]['client_job_id'] . ") - " .$jobOrderDetail[0]['city'] . ", " . $jobOrderDetail[0]['state'];
                    if ($fetchValue['offerJobType'] == 'c2c')
                                {
                                    $responseJobOrderType = " C2C - Corp to corp ";
                                }
                            if ($fetchValue['offerJobType'] == '1099_all_inclusive')
                                { 
                                    $responseJobOrderType = " 1099 (All Inclusive) "; 
                                }
                            if ($fetchValue['offerJobType'] == 'w2_with_benefits')
                                { 
                                    $responseJobOrderType = " W2 (With Benefits) "; 
                                }
                            if ($fetchValue['offerJobType'] == 'w2_without_benefits')
                                { 
                                    $responseJobOrderType = " W2 (Without Benefits) "; 
                                } 
                    $mailLogoImageUrl = $siteUrl.'/images/logo.png';
                   
                    

                     $responseEmailToRecruiter[] =  array('logo_image_url' => $mailLogoImageUrl,'candidate_name' => $fetchValue['offerGivenTo'],'job_title' => $jobOrderDetail[0]['title'], 'job_order_id' => $jobOrderDetail[0]['client_job_id'], 'company_name' =>  $responseCompanyName[0],'offer_staus' => $statusOfTheOffer,'offer_rate' => $fetchValue['offeredRate'],'offer_given_Date' => $fetchValue['offerGivenDate']->format('Y-m-d'),'offer_job_type' => $responseJobOrderType,'offeracceptance_ipaddress' =>
                            $fetchValue['offerStatusWithIpAdd']); 
                   

                    $this->emailService->sendEmailTemplate($responseEmailType, 'vtech.admin@vtechsolution.us', array($responseEmailSendTo), null, null, $responseEmailSubject, null, $responseEmailToRecruiter);

                    $response = "Mail Has Been Sent for copy email";
            }
        }

     return $this->responseArray = $response;      

    }


        public function getCandidatePayrateEmailTemplate() {


        $atsCandidateFullName = $this->request->get('candidateFullName');
        $atsOfferRate = $this->request->get('candidateofferedPayrate');
        $atsOfferGivenByName = $this->request->get('login_ats_name');
        $atsMailMessage = $this->request->get('sentMailMessage');
        $atsJobTitleName = $this->request->get('candidateAppliedJob');
        $atsCompanyName = $this->request->get('candidateCompanyName');
        $atsJobOfferType = $this->request->get('candidateOfferJobType');
        $atsJobOfferDuration = $this->request->get('candidateJobDuration');
        $atsJobOfferLocation = $this->request->get('candidateJobLocation');
        $atsOfferGivenByEmail = $this->request->get('login_ats_email');
        $atsJobOfferTypeInC2C = $this->request->get('selectedtypeofc2c');
        $atsJobOffertypeInC2CEmployeeEmail = $this->request->get('EmployeesMailId');
        $addedId = '0';

        if($atsJobOfferType == 'w2_without_benefits'){

        $message = '<!DOCTYPE html>
            <html>
            <body>
                <table align="center" style="width: 100%;">
                    <tr>
                        <td style="text-align: center;"><img id="gifid" src="http://report.vtechsolution.com/images/company_logo.png"/></td>
                    </tr>
                    <tr>
                        <td style="background-color: #2266AA;padding: 7px;color: #fff;">
                        Welcome to vTech</td>
                    </tr>
                    <tr>
                        <td style="background-color: #ccc;padding: 3px;"></td>
                    </tr>
                    <tr>
                        <td style="text-align: left; font-size: 15px;background-color: #fff;" >
                            <p>Hello <b>'.$atsCandidateFullName.'</b>,</p>
                            <p>It was pleasure speaking with you.</p>
                            <p>This is <b>'.$atsOfferGivenByName.'</b> from <b>vTech Solution</b> and I am writing to you regarding <b>'.$atsJobTitleName.'</b> Position for our client,('.$atsCompanyName.' ) based in <b>'.$atsJobOfferLocation.'.</b> I have provided below the link for details job description for your review. </p>

                            <a href="'.$link.'">URL
                            </a>
                            
                    <p>As discussed over the phone, please authorize vTech solely to present your resume to client  <b> ('.$atsCompanyName.' ) for '.$atsOfferRate.' on W2 </b>(Without Benefits i.e. paid leave, paid holidays, Health insurance and 401K) This hourly rate was agreed as you decided to accept higher hourly rate in lieu of company offered benefits. 
                        </p>
                        <p><u>You can purchase benefits from vTech or any other external agencies.</u></p>
                        <p>
                           Please note this is not a job offer. This email is only for requesting your authorization for resume submittal with the pay rate mentioned above. We will send you a formal email offering you the position if you are selected for this position by the client.
                        </p>
                    
                    
                        </td>
                    </tr>
                    <br><b><u>Position Details:</u></b><br/>
                    <tr>
                        <td><br>
                            
                                <table>
                                    
                                        <tr>
                                            <td><b>Company Name:</b></td>
                                            <td>'.$atsCompanyName.'</td>
                                        </tr>
                                        <tr>
                                            <td><b>Job Title:</b></td>
                                            <td>'.$atsJobTitleName.'</td>
                                        </tr>
                                        <tr>
                                            <td><b>Location:</b></td>
                                            <td>'.$atsJobOfferLocation.'</td>
                                            </tr>
                                        <tr>
                                            <td><b>Job Duration:</b></td>
                                            <td>'.$atsJobOfferDuration.'</td>
                                            </tr>
                                    
                                </table>
                            
                        </td>
                    </tr>
                    <tr>
                        <td style="background-color: #fff;">
                            <center>
                            <a href="'.$siteUrl.'/api/v1/candidate-payrate/candidate-accept-payrate/'.$addedId.'/accept" class="w3-btn" style="background-color: #2266AA;color: #fff;padding: 5px 30px;margin-top: 20px;">I confirm the rate and sole Right to represent.</a>
                            <a href="'.$siteUrl.'/api/v1/candidate-payrate/candidate-accept-payrate/'.$addedId.'/ignore" class="w3-btn" style="background-color: #2266AA;color: #fff;padding: 5px 30px;margin-top: 20px;">I do not confirm the rate and Sole Right to represent.</a>
                            </center>
                        </td>
                    </tr>
                </table>
            </body>
            </html>';

        }else if($atsJobOfferType == 'w2_with_benefits'){

            $message = '<!DOCTYPE html>
            <html>
            <body>
                <table align="center" style="width: 100%;">
                    <tr>
                        <td style="text-align: center;"><img id="gifid" src="http://report.vtechsolution.com/images/company_logo.png"/></td>
                    </tr>
                    <tr>
                        <td style="background-color: #2266AA;padding: 7px;color: #fff;">
                        Welcome to vTech</td>
                    </tr>
                    <tr>
                        <td style="background-color: #ccc;padding: 3px;"></td>
                    </tr>
                    <tr>
                        <td style="text-align: left; font-size: 15px;background-color: #fff;" >
                            <p>Hello <b> '.$atsCandidateFullName.' </b>,</p>
                    <p>It was pleasure speaking with you.</p>
                    <p>This is <b>'.$atsOfferGivenByName.' </b> from vTech Solution and I am writing to you regarding <b> '.$atsJobTitleName.' </b> Position for our client based in <b> '.$atsJobOfferLocation.'. </b>I have provided below the link for details job description for your review. </p>
                    
                    <p>As discussed over the phone, please authorize vTech solely to present your resume to client <b> ('.$atsCompanyName.' ) for '.$atsOfferRate.' on W2 With Benefits</b>(i.e. paid leave, paid holidays, Health insurance, STD and 401K).</p>
                        <p><b><u> W2 Benefits Details: </u></b>
                        <ul>
                        <li type="square"> <b> Health Insurance (United Health Ins.)</b>, Medical Insurance for Consultant - 50% Premium will be paid by Consultant.</li>
                        <ul>
                            <li type="circle"> <b>  Medical for Spouse or Children </b>- If Consultant wants to include (Spouse or Children) in Medical insurance, then Dependent`s 100% premium will be paid by Consultant. </li> 
                            <li type="circle"> <b> Vision / Dental Insurance</b> - Optional, 100% premium paid by the consultant. </li>
                        </ul>
                        <li type="square"> <b> 10 Days Paid Holidays</b> - The leave balance starts from the third month of his or her employment and leave will credit based on accrual. </li> 
                        <li type="square">  <b> 10 Days Paid Vacation</b> - Holiday list will provide to consultant upon joining. </li>
                        <li type="square">  <b> 401K </b>- Starts upon completion of 3rd month, detail information will be provided after joining.</li>
                        </ul>
                        </p>
                        <p>
                            Please note this is not a job offer. This email is only for requesting your authorization for resume submittal with the pay rate mentioned above. We will send you a formal email offering you the position if you are selected for this position by the client.
                        </p>
                                        
                        </td>
                    </tr>
                    <br><b><u>Position Details:</u></b><br/>
                    <tr>
                        <td><br>
                            
                                <table>
                                    
                                        <tr>
                                            <td><b>Company Name:</b></td>
                                            <td>'.$atsCompanyName.'</td>
                                        </tr>
                                        <tr>
                                            <td><b>Job Title:</b></td>
                                            <td>'.$atsJobTitleName.'</td>
                                        </tr>
                                        <tr>
                                            <td><b>Location:</b></td>
                                            <td>'.$atsJobOfferLocation.'</td>
                                            </tr>
                                        <tr>
                                            <td><b>Job Duration:</b></td>
                                            <td>'.$atsJobOfferDuration.'</td>
                                            </tr>
                                    
                                </table>
                            
                        </td>
                    </tr>
                    <tr>
                        <td style="background-color: #fff;">
                            <center>
                            <a href="'.$siteUrl.'/api/v1/candidate-payrate/candidate-accept-payrate/'.$addedId.'/accept" class="w3-btn" style="background-color: #2266AA;color: #fff;padding: 5px 30px;margin-top: 20px;">I confirm the rate and sole Right to represent.</a>
                            <a href="'.$siteUrl.'/api/v1/candidate-payrate/candidate-accept-payrate/'.$addedId.'/ignore" class="w3-btn" style="background-color: #2266AA;color: #fff;padding: 5px 30px;margin-top: 20px;">I do not confirm the rate and Sole Right to represent.</a>
                            </center>
                        </td>
                    </tr>
                    <tr>
                        <td style="background-color: #fff;color: #555;text-align: right;font-size: 10px;"><br>* This is an auto genrated Mail. Please DO NOT reply *<br><hr style="border: 1px dashed #ccc;margin: 0px;"></td>
                    </tr>
                </table>
            </body>
            </html>';

        }else if($atsJobOfferType == '1099_all_inclusive'){

            $message = '<!DOCTYPE html>
            <html>
            <body>
                <table align="center" style="width: 100%;">
                    <tr>
                        <td style="text-align: center;"><img id="gifid" src="http://report.vtechsolution.com/images/company_logo.png"/></td>
                    </tr>
                    <tr>
                        <td style="background-color: #2266AA;padding: 7px;color: #fff;">
                        Welcome to vTech</td>
                    </tr>
                    <tr>
                        <td style="background-color: #ccc;padding: 3px;"></td>
                    </tr>
                    <tr>
                        <td style="text-align: left; font-size: 15px;background-color: #fff;" >
                            <p>Hello <b>'.$atsCandidateFullName.'</b>,</p>
                    <p>It was nice talking with you.</p>
                    <p>This is <b> '.$atsOfferGivenByName.' </b> from <b>vTech Solution</b> and I am writing to you regarding <b> '.$atsJobTitleName.' </b> Position for our client,('.$atsCompanyName.' ) based in <b> '.$atsJobOfferLocation.' </b>. I have provided below the link for details job description for your review. </p>
                    
                    <p>As discussed over the phone, please authorize vTech solely to present your resume to client  <b> ('.$atsCompanyName.' ) for '.$atsOfferRate.' on 1099.
                        <p><u>You can purchase benefits from vTech or any other external agencies.</u>
                        </p>
                        Please note this is not a job offer. This email is only for requesting your authorization for resume submittal with the pay rate mentioned above. We will send you a formal email offering you the position if you are selected for this position by the client.

                        </p>
                    
                    
                        </td>
                    </tr>
                    <br><b><u>Position Details:</u></b><br/>
                    <tr>
                        <td><br>
                            
                                <table>
                                    
                                        <tr>
                                            <td><b>Company Name:</b></td>
                                            <td>'.$atsCompanyName.'</td>
                                        </tr>
                                        <tr>
                                            <td><b>Job Title:</b></td>
                                            <td>'.$atsJobTitleName.'</td>
                                        </tr>
                                        <tr>
                                            <td><b>Location:</b></td>
                                            <td>'.$atsJobOfferLocation.'</td>
                                            </tr>
                                        <tr>
                                            <td><b>Job Duration:</b></td>
                                            <td>'.$atsJobOfferDuration.'</td>
                                            </tr>
                                    
                                </table>
                            
                        </td>
                    </tr>
                    <tr>
                        <td style="background-color: #fff;">
                            <center>
                           <a href="'.$siteUrl.'/api/v1/candidate-payrate/candidate-accept-payrate/'.$addedId.'/accept" class="w3-btn" style="background-color: #2266AA;color: #fff;padding: 5px 30px;margin-top: 20px;">I confirm the rate and sole Right to represent.</a>
                            <a href="'.$siteUrl.'/api/v1/candidate-payrate/candidate-accept-payrate/'.$addedId.'/ignore" class="w3-btn" style="background-color: #2266AA;color: #fff;padding: 5px 30px;margin-top: 20px;">I do not confirm the rate and Sole Right to represent.</a>
                            </center>
                        </td>
                    </tr>
                    <tr>
                        <td style="background-color: #fff;color: #555;text-align: right;font-size: 10px;"><br>* This is an auto genrated Mail. Please DO NOT reply *<br><hr style="border: 1px dashed #ccc;margin: 0px;"></td>
                    </tr>
                </table>
            </body>
            </html>';

        }else if($atsJobOfferType == 'c2c' && $atsJobOfferTypeInC2C == 'singlec2c'){

            $message = '<!DOCTYPE html>
            <html>
            <body>
                <table align="center" style="width: 100%;">
                    <tr>
                        <td style="text-align: center;"><img id="gifid" src="http://report.vtechsolution.com/images/company_logo.png"/></td>
                    </tr>
                    <tr>
                        <td style="background-color: #2266AA;padding: 7px;color: #fff;">
                        Welcome to vTech</td>
                    </tr>
                    <tr>
                        <td style="background-color: #ccc;padding: 3px;"></td>
                    </tr>
                    <tr>
                        <td style="text-align: left; font-size: 15px;background-color: #fff;" >
                            <p>Hello <b>'.$atsCandidateFullName.'</b>,</p>
                    <p>It was nice talking with you.</p>
                    <p>This is <b> '.$atsOfferGivenByName.' </b> from <b>vTech Solution</b> and I am writing to you regarding <b> '.$atsJobTitleName.' </b> Position for our client,('.$atsCompanyName.' ) based in <b> '.$atsJobOfferLocation.' </b>. I have provided below the link for details job description for your review.</p>
                    
                    <p>As discussed over the phone, please authorize vTech solely to present your consultant`s resume ('.$atsCandidateFullName.') to client  <b> ('.$atsCompanyName.' ) for '.$atsOfferRate.' on C2C</b> (All Inclusive) with<b> NET 45 days Payment terms (Monthly Invoicing).</b> </p>
                        <p>
                            Please note this is not a job offer. This email is only for requesting your authorization for resume submittal with the pay rate mentioned above. We will send you a formal email offering the position if your consultant is selected by the client.

                        </p>
                    
                    
                        </td>
                    </tr>
                    <br><b><u>Position Details:</u></b><br/>
                    <tr>
                        <td><br>
                            
                                <table>
                                    
                                        <tr>
                                            <td><b>Company Name:</b></td>
                                            <td>'.$atsCompanyName.'</td>
                                        </tr>
                                        <tr>
                                            <td><b>Job Title:</b></td>
                                            <td>'.$atsJobTitleName.'</td>
                                        </tr>
                                        <tr>
                                            <td><b>Location:</b></td>
                                            <td>'.$atsJobOfferLocation.'</td>
                                            </tr>
                                        <tr>
                                            <td><b>Job Duration:</b></td>
                                            <td>'.$atsJobOfferDuration.'</td>
                                            </tr>
                                    
                                </table>
                            
                        </td>
                    </tr>
                    <tr>
                        <td style="background-color: #fff;">
                            <center>
                            <a href="'.$siteUrl.'/api/v1/candidate-payrate/candidate-accept-payrate/'.$addedId.'/accept" class="w3-btn" style="background-color: #2266AA;color: #fff;padding: 5px 30px;margin-top: 20px;">I confirm the rate and sole Right to represent.</a>
                            <a href="'.$siteUrl.'/api/v1/candidate-payrate/candidate-accept-payrate/'.$addedId.'/ignore" class="w3-btn" style="background-color: #2266AA;color: #fff;padding: 5px 30px;margin-top: 20px;">I do not confirm the rate and Sole Right to represent.</a>
                            </center>
                        </td>
                    </tr>
                    <tr>
                        <td style="background-color: #fff;color: #555;text-align: right;font-size: 10px;"><br>* This is an auto genrated Mail. Please DO NOT reply *<br><hr style="border: 1px dashed #ccc;margin: 0px;"></td>
                    </tr>
                </table>
            </body>
            </html>';

        }
        else if($atsJobOfferType == 'c2c' && $atsJobOfferTypeInC2C == 'throughEmployee'){

            $message = '<!DOCTYPE html>
            <html>
            <body>
                <table align="center" style="width: 100%;">
                    <tr>
                        <td style="text-align: center;"><img id="gifid" src="http://report.vtechsolution.com/images/company_logo.png"/></td>
                    </tr>
                    <tr>
                        <td style="background-color: #2266AA;padding: 7px;color: #fff;">
                        Welcome to vTech</td>
                    </tr>
                    <tr>
                        <td style="background-color: #ccc;padding: 3px;"></td>
                    </tr>
                    <tr>
                        <td style="text-align: left; font-size: 15px;background-color: #fff;" >
                            <p>Hello <b>'.$atsCandidateFullName.'</b>,</p>
                    <p>It was nice talking with you.</p>
                    <p>This is <b> '.$atsOfferGivenByName.' </b> from <b>vTech Solution</b> and I am writing to you regarding <b> '.$atsJobTitleName.' </b> Position for our client,('.$atsCompanyName.' ) based in <b> '.$atsJobOfferLocation.' </b>. I have provided below the link for details job description for your review.</p>
                    
                    <p>As discussed over the phone, please authorize vTech solely to present your consultant`s resume ('.$atsCandidateFullName.') to client  <b> ('.$atsCompanyName.' ) for '.$atsOfferRate.' on C2C</b> (All Inclusive) with<b> NET 45 days Payment terms (Monthly Invoicing).</b> </p>
                        <p>
                            Please note this is not a job offer. This email is only for requesting your authorization for resume submittal with the pay rate mentioned above. We will send you a formal email offering the position if your consultant is selected by the client.

                        </p>
                    
                    
                        </td>
                    </tr>
                    <br><b><u>Position Details:</u></b><br/>
                    <tr>
                        <td><br>
                            
                                <table>
                                    
                                        <tr>
                                            <td><b>Company Name:</b></td>
                                            <td>'.$atsCompanyName.'</td>
                                        </tr>
                                        <tr>
                                            <td><b>Job Title:</b></td>
                                            <td>'.$atsJobTitleName.'</td>
                                        </tr>
                                        <tr>
                                            <td><b>Location:</b></td>
                                            <td>'.$atsJobOfferLocation.'</td>
                                            </tr>
                                        <tr>
                                            <td><b>Job Duration:</b></td>
                                            <td>'.$atsJobOfferDuration.'</td>
                                            </tr>
                                    
                                </table>
                            
                        </td>
                    </tr>
                    <tr>
                        <td style="background-color: #fff;">
                            <center>
                            <a href="'.$siteUrl.'/api/v1/candidate-payrate/candidate-accept-payrate/'.$addedId.'/accept" class="w3-btn" style="background-color: #2266AA;color: #fff;padding: 5px 30px;margin-top: 20px;">I confirm the rate and sole Right to represent.</a>
                            <a href="'.$siteUrl.'/api/v1/candidate-payrate/candidate-accept-payrate/'.$addedId.'/ignore" class="w3-btn" style="background-color: #2266AA;color: #fff;padding: 5px 30px;margin-top: 20px;">I do not confirm the rate and Sole Right to represent.</a>
                            </center>
                        </td>
                    </tr>
                    <tr>
                        <td style="background-color: #fff;color: #555;text-align: right;font-size: 10px;"><br>* This is an auto genrated Mail. Please DO NOT reply *<br><hr style="border: 1px dashed #ccc;margin: 0px;"></td>
                    </tr>
                </table>
            </body>
            </html>';

        }else
        {
            $message = "Mail Has Some Error(Can not find Job Type)";
        }

      return $this->responseArray = $message;    
    
    }



}

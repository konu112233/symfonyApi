<?php

namespace vTechSolution\Bundle\ScreeningBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class vTechSolutionScreeningBundle extends Bundle
{
	
}

<?php

namespace vTechSolution\Bundle\AdobeSignBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class vTechSolutionAdobeSignBundle extends Bundle
{
}

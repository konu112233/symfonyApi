<?php

namespace vTechSolution\Bundle\AdobeSignBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * complianceMapping
 *
 * @ORM\Table(name="compliance_mapping")
 * @ORM\Entity(repositoryClass="vTechSolution\Bundle\AdobeSignBundle\Entity\complianceMappingRepository")
 */
class complianceMapping
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="complianceId", type="string", length=255)
     */
    private $complianceId;

    /**
     * @var string
     *
     * @ORM\Column(name="employmentType", type="string", length=255)
     */
    private $employmentType;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set complianceId
     *
     * @param string $complianceId
     *
     * @return complianceMapping
     */
    public function setComplianceId($complianceId)
    {
        $this->complianceId = $complianceId;

        return $this;
    }

    /**
     * Get complianceId
     *
     * @return string
     */
    public function getComplianceId()
    {
        return $this->complianceId;
    }

    /**
     * Set employmentType
     *
     * @param string $employmentType
     *
     * @return complianceMapping
     */
    public function setEmploymentType($employmentType)
    {
        $this->employmentType = $employmentType;

        return $this;
    }

    /**
     * Get employmentType
     *
     * @return string
     */
    public function getEmploymentType()
    {
        return $this->employmentType;
    }
}


<?php

namespace vTechSolution\Bundle\AdobeSignBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * OnbordingCandidateDocuments
 *
 * @ORM\Table(name="onbording_candidate_documents")
 * @ORM\Entity(repositoryClass="vTechSolution\Bundle\AdobeSignBundle\Entity\OnbordingCandidateDocumentsRepository")
 */
class OnbordingCandidateDocuments
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="candidateId", type="string", length=255)
     */
    private $candidateId;

    /**
     * @var string
     *
     * @ORM\Column(name="complianceId", type="string", length=255)
     */
    private $complianceId;

    /**
     * @var string
     *
     * @ORM\Column(name="documentName", type="string", length=255)
     */
    private $documentName;

    /**
     * @var string
     *
     * @ORM\Column(name="status", type="string", length=255, nullable=true)
     */
    private $status;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set candidateId
     *
     * @param string $candidateId
     *
     * @return OnbordingCandidateDocuments
     */
    public function setCandidateId($candidateId)
    {
        $this->candidateId = $candidateId;

        return $this;
    }

    /**
     * Get candidateId
     *
     * @return string
     */
    public function getCandidateId()
    {
        return $this->candidateId;
    }

    /**
     * Set complianceId
     *
     * @param string $complianceId
     *
     * @return OnbordingCandidateDocuments
     */
    public function setComplianceId($complianceId)
    {
        $this->complianceId = $complianceId;

        return $this;
    }

    /**
     * Get complianceId
     *
     * @return string
     */
    public function getComplianceId()
    {
        return $this->complianceId;
    }

    /**
     * Set documentName
     *
     * @param string $documentName
     *
     * @return OnbordingCandidateDocuments
     */
    public function setDocumentName($documentName)
    {
        $this->documentName = $documentName;

        return $this;
    }

    /**
     * Get documentName
     *
     * @return string
     */
    public function getDocumentName()
    {
        return $this->documentName;
    }

    /**
     * Set status
     *
     * @param string $status
     *
     * @return OnbordingCandidateDocuments
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status
     *
     * @return string
     */
    public function getStatus()
    {
        return $this->status;
    }
}

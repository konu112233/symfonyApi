<?php

namespace vTechSolution\Bundle\AdobeSignBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * RejectionLog
 *
 * @ORM\Table(name="rejection_log")
 * @ORM\Entity(repositoryClass="vTechSolution\Bundle\AdobeSignBundle\Entity\RejectionLogRepository")
 */
class RejectionLog
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="candidateId", type="string", length=255)
     */
    private $candidateId;

    /**
     * @var string
     *
     * @ORM\Column(name="complianceId", type="string", length=255)
     */
    private $complianceId;

    /**
     * @var string
     *
     * @ORM\Column(name="cause", type="string", length=255)
     */
    private $cause;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime")
     */
    private $createdAt;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set candidateId
     *
     * @param string $candidateId
     *
     * @return RejectionLog
     */
    public function setCandidateId($candidateId)
    {
        $this->candidateId = $candidateId;

        return $this;
    }

    /**
     * Get candidateId
     *
     * @return string
     */
    public function getCandidateId()
    {
        return $this->candidateId;
    }

    /**
     * Set complianceId
     *
     * @param string $complianceId
     *
     * @return RejectionLog
     */
    public function setComplianceId($complianceId)
    {
        $this->complianceId = $complianceId;

        return $this;
    }

    /**
     * Get complianceId
     *
     * @return string
     */
    public function getComplianceId()
    {
        return $this->complianceId;
    }

    /**
     * Set cause
     *
     * @param string $cause
     *
     * @return RejectionLog
     */
    public function setCause($cause)
    {
        $this->cause = $cause;

        return $this;
    }

    /**
     * Get cause
     *
     * @return string
     */
    public function getCause()
    {
        return $this->cause;
    }

    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     *
     * @return RejectionLog
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }
}


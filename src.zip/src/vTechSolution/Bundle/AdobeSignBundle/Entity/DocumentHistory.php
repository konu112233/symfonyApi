<?php

namespace vTechSolution\Bundle\AdobeSignBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * DocumentHistory
 *
 * @ORM\Table(name="document_history")
 * @ORM\Entity(repositoryClass="vTechSolution\Bundle\AdobeSignBundle\Entity\DocumentHistoryRepository")
 */
class DocumentHistory
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="candidate_document_id", type="string", length=255)
     */
    private $candidateDocumentId;

    /**
     * @var string
     *
     * @ORM\Column(name="reason", type="string", length=255)
     */
    private $reason;

    /**
     * @var string
     *
     * @ORM\Column(name="file_location", type="string", length=255)
     */
    private $fileLocation;

    /**
     * @var string
     *
     * @ORM\Column(name="type", type="string", length=255)
     */
    private $type;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set candidateDocumentId
     *
     * @param string $candidateDocumentId
     *
     * @return DocumentHistory
     */
    public function setCandidateDocumentId($candidateDocumentId)
    {
        $this->candidateDocumentId = $candidateDocumentId;

        return $this;
    }

    /**
     * Get candidateDocumentId
     *
     * @return string
     */
    public function getCandidateDocumentId()
    {
        return $this->candidateDocumentId;
    }

    /**
     * Set reason
     *
     * @param string $reason
     *
     * @return DocumentHistory
     */
    public function setReason($reason)
    {
        $this->reason = $reason;

        return $this;
    }

    /**
     * Get reason
     *
     * @return string
     */
    public function getReason()
    {
        return $this->reason;
    }

    /**
     * Set fileLocation
     *
     * @param string $fileLocation
     *
     * @return DocumentHistory
     */
    public function setFileLocation($fileLocation)
    {
        $this->fileLocation = $fileLocation;

        return $this;
    }

    /**
     * Get fileLocation
     *
     * @return string
     */
    public function getFileLocation()
    {
        return $this->fileLocation;
    }

    /**
     * Set type
     *
     * @param string $type
     *
     * @return DocumentHistory
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }
}


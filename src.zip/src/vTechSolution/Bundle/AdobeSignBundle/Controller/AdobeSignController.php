<?php

namespace vTechSolution\Bundle\AdobeSignBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Nelmio\ApiDocBundle\Annotation\ApiDoc;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\JsonResponse;
    /**
   * @Route("/api/v1/adobe")
   */
    
class AdobeSignController extends Controller
{
    private $responseArray;
    private $request;
    private $adobeSignService;

    private function initAction(){
      $this->responseArray = array();
      $this->request = $this->getRequest();

      $this->adobeSignService = $this->get('v_tech_solution_adobe_sign.adobesign');
    }
/**
   * @ApiDoc(
   *  resource="Oauth call Athorization Code",
   *  section="Adobe Sign Oauth Call",
   *  description="This API Is Use For Generate Athorization code for access token.",
   *  statusCodes={
     *         200="Returned when successful",
     *         403="Returned when the user is not authorized to say hello",
     *         404={
     *           "Returned when something else is not found"
     *         }
     *     }
   * )
   * @Route("/accesscode", name="vtech_solution_bundle_adobesign_accesscode")
   * @Method({"GET"})
   */
  public function callAccessCodeAction(){
      $this->initAction();

      $this->responseArray = $this->adobeSignService->getAccesscode();

        return new JsonResponse($this->responseArray);
        
  } 
/**
   * @ApiDoc(
   *  resource="Oauth call AccessToken Call",
   *  section="Adobe Sign Oauth Call",
   *  description="This API Is Use For Generate AccessToken for api use.",
   *  filters={
   *      {"name"="code", "dataType"="string"}
   *  },
   *  statusCodes={
     *         200="Returned when successful",
     *         403="Returned when the user is not authorized to say hello",
     *         404={
     *           "Returned when something else is not found"
     *         }
     *     }
   * )
   * @Route("/redirect-url", name="vtech_solution_bundle_adobesign_redirect_url")
  */
  public function callAccessTokenAction(){
       $this->initAction();

        $this->responseArray = $this->adobeSignService->getAccesscode();

        return new JsonResponse($this->responseArray);
  }

  /**
   * @ApiDoc(
   *  resource="Adobe Document upload",
   *  section="Adobe Sign",
   *  description="This API Is Use For update document and get transientDocumentId for further use.",
   *  filters={
   *      {"name"="file", "dataType"="file"},
   *      {"name"="Access-Token", "dataType"="string"}
   *  },
   *  statusCodes={
     *         200="Returned when successful",
     *         403="Returned when the user is not authorized to say hello",
     *         404={
     *           "Returned when something else is not found"
     *         }
     *     }
   * )
   * @Route("/fileupload", name="vtech_solution_bundle_adobesign_fileupload")
   * @Method({"POST"})
   */
  public function callDocumentUploadAction(){
      $this->initAction();

      $this->responseArray = $this->adobeSignService->getDocumentUpload();

      return new JsonResponse($this->responseArray);
  }
}

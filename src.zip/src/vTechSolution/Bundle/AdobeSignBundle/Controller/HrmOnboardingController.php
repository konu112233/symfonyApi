<?php

namespace vTechSolution\Bundle\AdobeSignBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Entity\ComplianceList;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Symfony\Component\Form\Extension\Core\Type\FileType;

/**
   * @Route("/api/v1/adobe")
   */

class HrmOnboardingController extends Controller
{
	private $responseArray;
    private $request;
    private $adobeSignService;

    private function initAction(){
      $this->responseArray = array();
      $this->request = $this->getRequest();

      $this->adobeSignService = $this->get('v_tech_solution_adobe_sign.adobesign');
    }

  /**
   * @Route("/compliance-list", name="vtech_solution_bundle_adobesign_compliance_list")
   * @Method({"GET"} )
   * @Template("vTechSolutionAdobeSignBundle:hrmonboard:compliance_list.html.twig")
   */
   	public function callDocumentList(){
      	$this->initAction();
$this->responseArray['site_url'] = $this->container->getParameter('site_url');
      	$this->responseArray['document_list'] = $this->adobeSignService->findAllDocument();

      	$this->responseArray['status'] = $this->adobeSignService->employmentStatus();

      	$this->responseArray['document_mapping'] = $this->adobeSignService->findAllDocumentWithMapping();

        return $this->responseArray;
        
  } 

  /**
   * @Route("/compliance-list", name="vtech_solution_bundle_adobesign_compliance_list_post")
   * @Method({"POST"} )
   */
  public function callDocumentListPost(){
      	$this->initAction();
$this->responseArray['site_url'] = $this->container->getParameter('site_url');
      	$this->responseArray = $this->adobeSignService->mappingEmploymentTypewithCompliance();

      	return new JsonResponse($this->responseArray);

        
  }

   /**
   * @Route("/listemp", name="vtech_solution_bundle_adobesign_listemp")
   * @Template("vTechSolutionAdobeSignBundle:hrmonboard:onboard_list.html.twig")
   * @Method({"GET"} )
   */
  public function hrmOnboardingCandidate(){
      	$this->initAction();
$this->responseArray['site_url'] = $this->container->getParameter('site_url');
      	$this->responseArray['employees'] = $this->adobeSignService->listofOnboardingCandidate();

      	 return $this->responseArray;

        
  }

     /**
   * @Route("/listemp", name="vtech_solution_bundle_adobesign_post_listemp")
   * @Template("vTechSolutionAdobeSignBundle:hrmonboard:onboard_list.html.twig")
   * @Method({"POST"} )
   */
  public function sendMailToCandidate(){
        $this->initAction();
$this->responseArray['site_url'] = $this->container->getParameter('site_url');
        $this->responseArray = $this->adobeSignService->emailToCandidate();

       return new JsonResponse($this->responseArray);



        
  }



  /**
   * @Route("/view/{id}", name="vtech_solution_bundle_adobesign_view")
   * @Template("vTechSolutionAdobeSignBundle:hrmonboard:view.html.twig")
   * @Method({"GET"} )
   */
  public function viewOnboardingCandidate(){
      	$this->initAction();
$this->responseArray['site_url'] = $this->container->getParameter('site_url');
      	$this->responseArray['employeesdetail'] = $this->adobeSignService->viewofOnboardingCandidate();

        $this->responseArray['documentlist'] = $this->adobeSignService->getDocumentList();

        $this->responseArray['getUploadedDocumentList'] = $this->adobeSignService->getUploadedDocumentList();

        $this->responseArray['getDocumentPath'] = $this->adobeSignService->getDocumentPath();

      	 return $this->responseArray;

        
  } 

    /**
   * @Route("/upload/{id}", name="vtech_solution_bundle_adobesign_upload")
   * @Template("vTechSolutionAdobeSignBundle:hrmonboard:upload.html.twig")
   * @Method({"GET"} )
   */
  public function uploadOnboardingCandidate(){
        $this->initAction();

          $this->responseArray['site_url'] = $this->container->getParameter('site_url');

        $this->responseArray['documentliststageone'] = $this->adobeSignService->uploadofOnboardingCandidateStageOne();

        $this->responseArray['documentliststagetwo'] = $this->adobeSignService->uploadofOnboardingCandidateStageTwo();
        $this->responseArray['documentliststagethree'] = $this->adobeSignService->uploadofOnboardingCandidateStageThree();

        $this->responseArray['rejectdocumentlist'] = $this->adobeSignService->uploadDocumentReject();
         $this->responseArray['documentlistbycompliance'] = $this->adobeSignService->findAllUploadingDocumentWithMapping();
         $this->responseArray['countdocument'] = $this->adobeSignService->countDocument();
         $this->responseArray['countstatus'] = $this->adobeSignService->countStatus();

         return $this->responseArray;

        
  }

   /**
   * @Route("/upload/{id}", name="vtech_solution_bundle_adobesign_upload_post")
   * @Method({"POST","GET"} )
   */
  public function uploadDocumentOfCandidate(){
        $this->initAction();


$this->responseArray['site_url'] = $this->container->getParameter('site_url');
        $this->responseArray = $this->adobeSignService->uploadDocument();


        return new JsonResponse($this->responseArray);

        
  } 

   /**
   * @Route("/view/{id}", name="vtech_solution_bundle_adobesign_view_post")
   * @Method({"POST"} )
   */
  public function documentOfCandidate(){
        $this->initAction();
$this->responseArray['site_url'] = $this->container->getParameter('site_url');
        $this->responseArray = $this->adobeSignService->viewDocument();
        return new JsonResponse($this->responseArray);

        
  } 

}

<?php
namespace vTechSolution\Bundle\AdobeSignBundle\Manager;

use Symfony\Component\DependencyInjection\ContainerInterface as Container;
use Symfony\Component\HttpFoundation\Request;
use vTechSolution\Bundle\AdobeSignBundle\Entity\ComplianceList;
use vTechSolution\Bundle\AdobeSignBundle\Entity\complianceMapping;
use vTechSolution\Bundle\AdobeSignBundle\Entity\RejectionLog;
use vTechSolution\Bundle\AdobeSignBundle\Entity\OnbordingCandidateDocuments;
use vTechSolution\Bundle\AdobeSignBundle\Entity\DocumentHistory;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\HttpFoundation\Session\Session;


class AdobeSignService
{

    public $complianceListRepository;
    private $container;
    private $doctrine;
    private $request;
    private $responseArray;
    private $vtechhrmDatabase;
    private $vtechtoolDatabase;
    private $complianceMappingRepository;
    private $onbordingCandidateDocumentsRepository;
    private $onBoardingDatabase;
    private $onBoardingCandidateDatabase;


    const HTTP_METHOD_GET = 'GET';
    const HTTP_METHOD_POST = 'POST';

    public function __construct(Container $container)
    {
        $this->container                             = $container;
        $this->request                               = $this->container->get('request');
        $this->responseArray                         = array();
        $this->doctrine                              = $this->container->get('doctrine');
        $this->complianceListRepository              = $this->doctrine->getRepository('vTechSolutionAdobeSignBundle:ComplianceList');
        $this->complianceMappingRepository           = $this->doctrine->getRepository('vTechSolutionAdobeSignBundle:complianceMapping');
        $this->onbordingCandidateDocumentsRepository = $this->doctrine->getRepository('vTechSolutionAdobeSignBundle:OnbordingCandidateDocuments');
         $this->DocumentHistoryRepository = $this->doctrine->getRepository('vTechSolutionAdobeSignBundle:DocumentHistory');


    }

    public function __destructor()
    {
        unset($this->container);
        unset($this->request);
        unset($this->responseArray);
        unset($this->complianceMappingRepository);
    }

    public function getAccesscode()
    {
        $RequestUrl           = $this->container->getParameter('adobeAuth_url');
        $adobeAuthEnd_url     = $this->container->getParameter('adobeAuthEnd_url');
        $adobeAuthRefresh_url = $this->container->getParameter('adobeAuthRefresh_url');
        $adobeRedirect_uri    = $this->container->getParameter('adobeRedirect_uri');
        $adobegrantType_code  = $this->container->getParameter('grantType_code');
        $grantType            = $this->container->getParameter('grantType');
        $adobeClient_id       = $this->container->getParameter('adobeClient_id');
        $adobeClient_secret   = $this->container->getParameter('adobeClient_secret');
        $adobeScope           = $this->container->getParameter('adobeScope');
        $response_type        = $this->container->getParameter('responseType');
        $adobeState           = $this->container->getParameter('adobeState');

        $session_id = session_id();
        if (empty($session_id)) {
            session_start();
        }

        if (isset($_SESSION['adobe_access_token']) && !empty($_SESSION['adobe_access_token'])) {

            $refresh_token = $_SESSION['adobe_refresh_token'];

            $result = $this->refreshAccessToken($adobeAuthRefresh_url, $adobeClient_id, $adobeClient_secret, $grantType, $refresh_token);

            $_SESSION['adobe_access_token'] = $result['access_token'];

            $this->responseArray = $result;

            unset($tokens);

            return $this->responseArray;
        } else {
            $adobeCode              = $this->request->get('code');
            $adobe_api_access_point = $this->request->get('api_access_point');
            $adobe_web_access_point = $this->request->get('web_access_point');

            if (!isset($adobeCode)) {
                $authUrl = $this->getAuthorizationURL($RequestUrl, $adobeClient_id, $adobeScope, $adobeRedirect_uri, $response_type, $adobeState);

                header("Access-Control-Allow-Origin: *");
                header('Access-Control-Allow-Credentials: true');
                header("Location: " . $authUrl);
                unset($authUrl);
                exit();
            } else {

                $adobeResponseState = $this->request->get('state');
                $resulttoken        = $this->getAccessToken($adobeAuthEnd_url, $adobeCode, $adobeClient_id, $adobeClient_secret, $adobeRedirect_uri, $adobegrantType_code);

                $_SESSION['adobe_access_token']  = $resulttoken['access_token'];
                $_SESSION['adobe_refresh_token'] = $resulttoken['refresh_token'];

                $this->responseArray = $resulttoken;
                unset($adobeResponseState);
                unset($resulttoken);

                return $this->responseArray;
            }
            unset($adobeCode);
            unset($adobe_api_access_point);
            unset($adobe_web_access_point);
        }
    }
    public function getAuthorizationURL($adobeAuth_url, $adobeClient_id, $adobeScope, $adobeRedirect_uri, $response_type, $adobeState)
    {
        $parameters = array(
            'redirect_uri' => $adobeRedirect_uri,
            'response_type' => $response_type,
            'client_id' => $adobeClient_id,
            'scope' => $adobeScope,
            'state' => $adobeState
        );

        $RequestUrl = $adobeAuth_url . '?' . urldecode(http_build_query($parameters));

        unset($parameters);

        return $RequestUrl;
    }

    public function getAccessToken($adobeAuthEnd_url, $adobeCode, $adobeClient_id, $adobeClient_secret, $adobeRedirect_uri, $adobegrantType_code)
    {
        $parameters  = array(
            'code' => $adobeCode,
            'client_id' => $adobeClient_id,
            'client_secret' => $adobeClient_secret,
            'redirect_uri' => $adobeRedirect_uri,
            'grant_type' => $adobegrantType_code
        );
        $http_header = array(
            'Content-Type' => 'application/x-www-form-urlencoded'
        );

        $result = $this->executeRequest($adobeAuthEnd_url, $parameters, $http_header, self::HTTP_METHOD_POST);

        unset($parameters);
        unset($http_header);

        return $result;
    }

    public function refreshAccessToken($adobeAuthRefresh_url, $adobeClient_id, $adobeClient_secret, $grantType, $refresh_token)
    {
        $parameters = array(
            'refresh_token' => $refresh_token,
            'client_id' => $adobeClient_id,
            'client_secret' => $adobeClient_secret,
            'grant_type' => $grantType
        );

        $http_header = array(
            'Content-Type' => 'application/x-www-form-urlencoded'
        );
        $result      = $this->executeRequest($adobeAuthRefresh_url, $parameters, $http_header, self::HTTP_METHOD_POST);

        unset($parameters);
        unset($http_header);

        return $result;
    }

    public function getDocumentUpload()
    {
        $adobeDocUpload_url = $this->container->getParameter('adobeDocUpload_url');
        $adobeDocumentFile  = $this->request->get('file');
        $adobeAccessToken   = $_SESSION['adobe_access_token'];

        $parameters = array();

        $http_header = array(
            'Access-Token' => $adobeAccessToken,
            'Content-Type' => 'multipart/form-data',
            'Content-Disposition' => 'form-data',
            'File' => $adobeDocumentFile
        );

        $result              = $this->executeRequest($adobeDocUpload_url, $parameters, $http_header, self::HTTP_METHOD_POST);
        $this->responseArray = $result;
        unset($parameters);
        unset($http_header);

        return $this->responseArray;
    }

    public function executeRequest($url, $parameters = array(), $http_header, $http_method)
    {
        $curl_options = array();

        switch ($http_method) {
            case self::HTTP_METHOD_GET:
                $curl_options[CURLOPT_HTTPGET] = 'true';
                if (is_array($parameters) && count($parameters) > 0) {
                    $url .= '?' . urldecode(http_build_query($parameters));
                } elseif ($parameters) {
                    $url .= '?' . $parameters;
                }
                break;
            case self::HTTP_METHOD_POST:
                $curl_options[CURLOPT_POST] = '1';
                if (is_array($parameters) && count($parameters) > 0) {
                    $body                             = urldecode(http_build_query($parameters));
                    $curl_options[CURLOPT_POSTFIELDS] = $body;
                }
                break;
            default:
                break;
        }

        if (is_array($http_header)) {
            $header = array();
            foreach ($http_header as $key => $value) {
                $header[] = "$key: $value";
            }
            $curl_options[CURLOPT_HTTPHEADER] = $header;
        }
        $curl_options[CURLOPT_URL] = $url;
        $ch                        = curl_init();

        curl_setopt_array($ch, $curl_options);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result      = curl_exec($ch);
        $err         = curl_error($ch);
        $json_decode = json_decode($result, true);
        curl_close($ch);
        //var_dump($json_decode);
        if ($err) {
            echo "cURL Error #:" . $err;
        } else {
            echo $result;
        }
        unset($curl_options);
        unset($http_method);
        unset($parameters);
        unset($ch);

        return $json_decode;
    }

    public function findAllDocument()
    {

        return $this->complianceListRepository->findAll();
    }

    public function findAllDocumentMapping()
    {

        return $this->complianceMappingRepository->findAll();
    }

    public function findAllDocumentWithMapping()
    {
        $return = array();

        $documentMappingList = $this->findAllDocumentMapping();

        foreach ($documentMappingList as $key => $documentMapping) {

            $complianceId            = $documentMapping->getComplianceId();
            $return[$complianceId][] = $documentMapping->getEmploymentType();
        }

        return $return;
    }


    public function employmentStatus()
    {
        $this->vtechhrmDatabase = $this->container->get('v_tech_solution_quick_book.vtechhrm')->getPDO();

        $query                  = 'SELECT id,name FROM `employmentstatus`';
        $employmentStatus       = $this->vtechhrmDatabase->query($query)->fetchAll();

        unset($query);
        return $employmentStatus;
    }
    public function mappingEmploymentTypewithCompliance()
    {
        $this->vtechtoolDatabase = $this->container->get('v_tech_solution_quick_book.vtech_tools')->getPDO();
       // print_r($this->vtechtoolDatabase);
        //die;
        $employmentType          = $this->request->get('EmploymentType');
        $complianceId            = $this->request->get('ComplianceId');
        $action                  = $this->request->get('action');

        $documentMapping = $this->complianceMappingRepository->findByComplianceIdAndEmploymentType($complianceId, $employmentType);
        if ($action == 'add') {
            if (count($documentMapping) == 0) {
                $mapping = new complianceMapping();
                $mapping->setcomplianceId($complianceId);
                $mapping->setemploymentType($employmentType);
                $this->complianceMappingRepository->commit($mapping);
            }
        }

        if ($action == 'remove') {

            $documentMapping = $this->complianceMappingRepository->findByComplianceIdAndEmploymentType($complianceId, $employmentType);
            $this->complianceMappingRepository->remove($documentMapping);

        }

    }

    public function listofOnboardingCandidate()
    {
        $id                     = $this->request->get('id');
        $this->vtechhrmDatabase = $this->container->get('v_tech_solution_quick_book.vtechhrm')->getPDO();

        $query             = "SELECT es.name,e.first_name,e.private_email,e.last_name , e.id, e.custom1 from employees as e join employmentstatus as es on es.id = e.employment_status where e.status = 'OnBoarding'";
        $OnBoardingDetails = $this->vtechhrmDatabase->query($query)->fetchAll();

       // print_r($OnBoardingDetails);

      //   exit();



        unset($query);
        return $OnBoardingDetails;

    }

    public function decryptionOfEmployeeId( $string = '', $action = 'e' ) {

    $secret_key = 'my_simple_secret_key';
    $secret_iv = 'my_simple_secret_iv';

    $output = false;
    $encrypt_method = "AES-256-CBC";
    $key = hash( 'sha256', $secret_key );
    $iv = substr( hash( 'sha256', $secret_iv ), 0, 16 );

    if( $action == 'e' ) {
        $output = base64_encode( openssl_encrypt( $string, $encrypt_method, $key, 0, $iv ) );
    }
    else if( $action == 'd' ){
        $output = openssl_decrypt( base64_decode( $string ), $encrypt_method, $key, 0, $iv );
    }

    return $output;


}


    public function emailToCandidate() {

        $employeeId = $this->request->get('employeeId');

        $id = $this->decryptionOfEmployeeId( $employeeId, 'e' );

        $mail = new PHPMailer;

            $mail->isSMTP();
            $mail->Host = 'ssl://smtp.mail.yahoo.com';
            $mail->SMTPAuth    = true;
            $mail->Username = 'vtech.admin@vtechsolution.us';
            $mail->Password = 'metggwdwzivdoeya';
            $mail->setFrom('vtech.admin@vtechsolution.us','vTechsolution services');
            $mail->SMTPSecure  = 'ssl';
            $mail->Port        = 465;

            $mail->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                )
            );

            $email_to = 'giet13aei015@gmail.com';
            //$value['private_email']


            $subject  = "Rejected Document List";
            $message  = '<html>' . '<body>' . '<table width="100%" cellspacing="0" cellpadding="0" style="max-width:600px;border-left:solid 1px #e6e6e6;border-right:solid 1px #e6e6e6">' . '<tbody>' . '<tr><td align="center" border="0" bgcolor="white">
                                                    <img src="cid:logo_2u" alt="vTech Solution" width="250" height="100" style="display: block;" /><br/><br/>
                                                </td><tr>
                            <tr>
                              <td width="20" bgcolor="#476b6b" style="width:20px;background:linear-gradient(to bottom,#476b6b 0%,#476b6b 89%);background-color:#476b6b">&nbsp;</td>


                            </tr>
                          </tbody>
                        </table>
                        <table width="100%" cellspacing="0" cellpadding="0" style="max-width:600px;border-left:solid 1px #e6e6e6;border-right:solid 1px #e6e6e6">
                          <tbody>
                            <tr>
                              <td valign="top" align="center" width="300"><table border="0" cellspacing="0" cellpadding="0" width="100%" bgcolor="#005387">
                                  <tbody>
                                    <tr>
                                      <td valign="middle" align="right" width="20%" height="35" style="border-bottom:solid 1px #003a5e;padding:0padding:0 0 0 5px;color:#ffffff"><a style="text-decoration:none;outline:none;display:block" href="" target="_blank">
                                        </a></td>

                                    </tr>
                                  </tbody>
                                </table></td>
                              <td valign="top" align="center" width="300"><table border="0" cellspacing="0" cellpadding="0" width="100%" bgcolor="#005387">
                                  <tbody>
                                    <tr>

                                      <td valign="middle" align="left" width="30%" height="35" style="border-bottom:solid 1px #003a5e;padding:0 0 0 5px"></td>

                                    </tr>
                                  </tbody>
                                </table></td>
                            </tr>
                          </tbody>
                        </table>
                        <table width="100%" cellspacing="0" cellpadding="0" style="max-width:600px;border-left:solid 1px #e6e6e6;border-right:solid 1px #e6e6e6">
                          <tbody>
                            <tr>
                              <td align="left" valign="top" style="color:#2c2c2c;display:block;line-height:20px;font-weight:300;margin:0 auto;clear:both;border-bottom:2px dashed #ccc;background-color:#f9f9f9;padding:20px" bgcolor="#F9F9F9"><p style="padding:0;margin:0;font-size:16px;font-weight:bold;font-size:13px"> Hello
                                </p><br>
                                <p>

                        vTech HR Team send this message regarding for uploading rejected document List.

                                </p>
                                <p><b>Document Name</b> : <p>
                                <p><b>Rejection Reasons</b> :  <p>

                                <b><p style="padding:0;margin:0;color:#565656;line-height:22px;font-size:15px">Here is your link for upload rejected document
                                  <!--<a href="">iceHrm</a>-->
                                  <br/>
                                 <a href="http://localhost/vtech-tool/web/app_dev.php/api/v2/adobe/upload/'.$id.'">Click Here</a>
                               </p></b>

                               </td>
                            </tr>
                          </tbody>
                        </table>

                        </body>
                        </html>
                        <html>
                        <head>
                        <style>
                        #a
                        {    color: rgb(14, 61, 150)}
                        #b
                        {color:grey;}
                        #c{color:#0d10ad;    font-weight: bold;}
                        #d{color:grey;font-style:italic;}
                        #e{color:blue;font-weight:30px;font-size: 14px;}

                        .main{
                          position:absolute;left: 62px;;
                        }

                        </style>
                        </head>
                        <body>
                        <div class="main">
                        <div id="a">Regards,</div>
                        <div id="b">HR Team</div><br/>

                        <div id="c">vTech Solution Inc.</div>
                        <div id="d">You Seek, We Deliver</div><br/>

                        <div style="font-size:14px;">1100 H street, N.W. Suite 450,<br/>
                        Washington DC 20005.
                        <div id="e"><u>www.vTechSolution.com</u><br/></div><div><br/><br/>

                        <div style="font-size:14px;color:#635d5d;">

                        This is a PRIVATE message. If you are not the intended recipient, please delete without copying and kindly advise us by e-mail of the mistake in delivery. NOTE: Regardless of content, this e-mail shall not operate to bind JSPL to any order or other contract unless pursuant to explicit written agreement or government initiative expressly permitting the use of e-mail for such purpose.

                        </div>

                        </body>
                        </html>
                        ';

            $mail->Subject = $subject;
            $mail->msgHTML($message);
            $mail->AddAddress($email_to);

            $mail->Send();

            if(!$mail->send()) 
{
    echo "Mailer Error: " . $mail->ErrorInfo;
    die;
} 
else 
{
    echo "Message has been sent successfully";
    die;
}


    }

    public function viewofOnboardingCandidate()
    {
        $employeeId                     = $this->request->get('id');



        $id = $this->decryptionOfEmployeeId($employeeId, 'd' );

       // print_r($id);

        //exit();

        $this->vtechhrmDatabase = $this->container->get('v_tech_solution_quick_book.vtechhrm')->getPDO();

        $query           = "SELECT es.name,e.first_name,e.private_email,e.last_name, e.custom1 from employees as e join employmentstatus as es on es.id = e.employment_status where e.id = $id";
        $EmployeeDetails = $this->vtechhrmDatabase->query($query)->fetchAll();

        return $EmployeeDetails;
    }

    public function getDocumentList()
    {

        $employeeId = $this->request->get('id');

        $id = $this->decryptionOfEmployeeId($employeeId, 'd' );

        //print_r($id);

        //exit();

        $this->vtechtoolDatabase = $this->container->get('v_tech_solution_quick_book.vtech_tools')->getPDO();

        $this->onBoardingCandidateDatabase = $this->container->get('v_tech_solution_quick_book.vtech_candidate_onboarding')->getPDO();

        //print_r($this->onBoardingCandidateDatabase);
        //exit();
        $query = "SELECT DISTINCT cbs.can_id, cct.description, cd.status, cct.co_do_id FROM compliance_client_template as cct
                    LEFT JOIN candidate_bg_status as cbs on cbs.client_id = cct.client_id
                    LEFT JOIN compliance_list as cl ON cct.co_do_id = cl.CID
                    LEFT join vtech_tools.onbording_candidate_documents as cd on cd.complianceId = cct.co_do_id  AND cd.candidateId = '$id'
                    WHERE cbs.can_id = '$id' AND cct.type = 'compliance'
                    ORDER BY cct.co_do_id";



        $getDocumentList = $this->onBoardingCandidateDatabase->query($query)->fetchAll();



        //print_r($getDocumentList);
        //exit();

        $query = "SELECT ocd.id, ocd.candidateId, ocd.complianceId, cld.file_location, ocd.status,cld.type FROM `onbording_candidate_documents` as ocd LEFT join (SELECT id,candidate_document_id, file_location, type from document_history where id IN (SELECT MAX(id) FROM `document_history` GROUP BY candidate_document_id)) as cld on cld.candidate_document_id = ocd.id where ocd.candidateId = '$id'";

        $getDocumentListByStatus = $this->vtechtoolDatabase->query($query)->fetchAll();

$documentsFile = array();

foreach ($getDocumentListByStatus as $key => $candidateDocument) {

           $documentsFile[$candidateDocument["complianceId"]] =$candidateDocument["file_location"];

           //print_r($documentsFile);
           //exit();


        }



        foreach ($getDocumentList as $key => $documentList) {

           if (isset($documentsFile[$documentList['co_do_id']])) {

            $getDocumentList[$key]['file_location']=$documentsFile[$documentList['co_do_id']];

           }
           else {

                $getDocumentList[$key]['file_location']='';
           }



        }



       // print_r($getDocumentList);

        //exit();





        //print_r($getDocumentListByStatus);
        //exit();


        //print_r($getDocumentList);
        //exit();

        return $getDocumentList;

    }

     public function getUploadedDocumentList()
    {

        $eid = $this->request->get('id');

        $id = $this->decryptionOfEmployeeId($eid, 'd' );

        $this->onBoardingCandidateDatabase = $this->vtechtoolDatabase = $this->container->get('v_tech_solution_quick_book.vtech_tools')->getPDO();



        $getUploadedDocumentList = $this->onbordingCandidateDocumentsRepository->getDocumentList($id);

        //print_r($getUploadedDocumentList);
        //exit();

        return $getUploadedDocumentList;

    }


    public function uploadofOnboardingCandidateStageOne()
    {

        $eid = $this->request->get('id');

        //$employeeId = $this->request->get('id');

        $id = $this->decryptionOfEmployeeId($eid, 'd' );

        //print_r($id);
        //exit();
        //var_dump($request->files->all());

        $this->onBoardingDatabase = $this->container->get('v_tech_solution_quick_book.vtech_candidate_onboarding')->getPDO();

        $query = "SELECT DISTINCT cbs.can_id, cct.description, cd.status, cct.co_do_id FROM compliance_client_template as cct
                    LEFT JOIN candidate_bg_status as cbs on cbs.client_id = cct.client_id
                    LEFT JOIN compliance_list as cl ON cct.co_do_id = cl.CID
                    LEFT join vtech_tools.onbording_candidate_documents as cd on cd.complianceId = cct.co_do_id  AND cd.candidateId = '$id'
                    WHERE cbs.can_id = '$id' AND cct.type = 'compliance' AND cct.co_do_id BETWEEN 1 AND 30;

                    ORDER BY cct.co_do_id";
                   // print_r($query);
                    //exit();

        $getDocumentList = $this->onBoardingDatabase->query($query)->fetchAll();



       // print_r($getDocumentList);
        //exit();
        return $getDocumentList;

        return $getDocumentList;
    }

     public function uploadofOnboardingCandidateStageTwo()
    {

        $eid = $this->request->get('id');

        //$employeeId = $this->request->get('id');

        $id = $this->decryptionOfEmployeeId($eid, 'd' );

        //print_r($id);
        //exit();
        //var_dump($request->files->all());

        $this->onBoardingDatabase = $this->container->get('v_tech_solution_quick_book.vtech_candidate_onboarding')->getPDO();

        $query = "SELECT DISTINCT cbs.can_id, cct.description, cd.status, cct.co_do_id FROM compliance_client_template as cct
                    LEFT JOIN candidate_bg_status as cbs on cbs.client_id = cct.client_id
                    LEFT JOIN compliance_list as cl ON cct.co_do_id = cl.CID
                    LEFT join vtech_tools.onbording_candidate_documents as cd on cd.complianceId = cct.co_do_id  AND cd.candidateId = '$id'
                    WHERE cbs.can_id = '$id' AND cct.type = 'compliance' AND cct.co_do_id BETWEEN 31 AND 41

                    ORDER BY cct.co_do_id";
                   // print_r($query);
                    //exit();

        $getDocumentList = $this->onBoardingDatabase->query($query)->fetchAll();



       // print_r($getDocumentList);
        //exit();
        return $getDocumentList;

        return $getDocumentList;
    }

     public function uploadofOnboardingCandidateStageThree()
    {

        $eid = $this->request->get('id');

        //$employeeId = $this->request->get('id');

        $id = $this->decryptionOfEmployeeId($eid, 'd' );

        //print_r($id);
        //exit();
        //var_dump($request->files->all());

        $this->onBoardingDatabase = $this->container->get('v_tech_solution_quick_book.vtech_candidate_onboarding')->getPDO();

        $query = "SELECT DISTINCT cbs.can_id, cct.description, cd.status, cct.co_do_id FROM compliance_client_template as cct
                    LEFT JOIN candidate_bg_status as cbs on cbs.client_id = cct.client_id
                    LEFT JOIN compliance_list as cl ON cct.co_do_id = cl.CID
                    LEFT join vtech_tools.onbording_candidate_documents as cd on cd.complianceId = cct.co_do_id  AND cd.candidateId = '$id'
                    WHERE cbs.can_id = '$id' AND cct.type = 'compliance' AND cct.co_do_id  > 41

                    ORDER BY cct.co_do_id";
                   // print_r($query);
                    //exit();

        $getDocumentList = $this->onBoardingDatabase->query($query)->fetchAll();



       // print_r($getDocumentList);
        //exit();
        return $getDocumentList;

        return $getDocumentList;
    }

    public function uploadDocumentReject() {

            $id = $this->request->get('id');

        $this->onBoardingCandidateDatabase = $this->vtechtoolDatabase = $this->container->get('v_tech_solution_quick_book.vtech_tools')->getPDO();

            $query = "SELECT complianceId,candidateId from rejection_log WHERE candidateId = '$id'";

            $getRejectDocumentList = $this->onBoardingCandidateDatabase->query($query)->fetchAll();

        //print_r($getRejectDocumentList);
        //exit();

        return $getRejectDocumentList;

    }

    public function uploadDocument()
    {

        $eid     = $this->request->get('id');
        $employeeId = $this->decryptionOfEmployeeId($eid, 'd' );

        $complianceId   = $this->request->get('complianceId');
        $complianceName = $this->request->get('complianceName');
        if ($_FILES["file"]["name"] != '') {
            $explodeName = explode('.', $_FILES["file"]["name"]);
            $ext         = end($explodeName);
            $name        = rand(100, 999) . '.' . $ext;

            $location = $this->container->getParameter('kernel.root_dir') . '/../web/uploads/documents/' . $employeeId . '/' . $complianceName;

            if (!file_exists($location)) {

                $fileLocation = mkdir($location, 0777, true);

                $fileLocation = $this->container->getParameter('kernel.root_dir') . '/../web/uploads/documents/' . $employeeId . '/' . $complianceName . '/' . $complianceName;

                move_uploaded_file($_FILES["file"]["tmp_name"], $fileLocation . $name);
                $data =  'file uploaded successfully';
                $upload = new OnbordingCandidateDocuments();
                $upload->setcandidateId($employeeId);
                $upload->setcomplianceId($complianceId);
                $upload->setdocumentName($complianceName);
                $upload->setstatus('1');
                $this->onbordingCandidateDocumentsRepository->commit($upload);
            }
        }

        $locationMapping = '/uploads/documents/'. $employeeId . '/' . $complianceName . '/' .$complianceName. $name;



        $fileLocation = $this->container->getParameter('kernel.root_dir') . '/../web/uploads/documents/' . $employeeId . '/' . $complianceName . '/' . $complianceName;

        move_uploaded_file($_FILES["file"]["tmp_name"], $fileLocation . $name);

        $updateStatus = $this->onbordingCandidateDocumentsRepository->findByCandidateIdAndComplianceIdForRejectUpload($employeeId,$complianceId);

        if (count($updateStatus) > 0) {

              $updateStatus->setStatus('1');

      }

        $lastId =   $updateStatus->getId();
        $mapping = new DocumentHistory();
        $mapping->setCandidateDocumentId($lastId);
        $mapping->setReason('--');
        $mapping->setFileLocation($locationMapping);
        $mapping->setType('pending');

     $this->DocumentHistoryRepository->commit($mapping);

     $logoLocation = $this->container->getParameter('kernel.root_dir') . '/../web/uploads/documents/';

     $attachmentFileLocationFromRootOfUploadDocument = $this->container->getParameter('kernel.root_dir') . '/../web'.$locationMapping;

             $mail = new PHPMailer;

            $mail->isSMTP();
            $mail->Host        = 'smtp.gmail.com';
            $mail->SMTPAuth    = true;
            $mail->Username    = 'giet13aei015@gmail.com';
            $mail->Password    = '9709305850';
            $mail->From        = "giet13aei015@gmail.com";
            $mail->SMTPSecure  = 'ssl';
             $mail->AddEmbeddedImage($logoLocation.'/ssn.png', 'logo_2u');
            $mail->Port        = 465;

            $mail->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                )
            );

            $email_to = 'shravank@vtechsolution.us';
            //$value['private_email']
            $mail->addAttachment($attachmentFileLocationFromRootOfUploadDocument);

            $subject  = "Rejected Document List";
            $message  = '<html>' . '<body>' . '<table width="100%" cellspacing="0" cellpadding="0" style="max-width:600px;border-left:solid 1px #e6e6e6;border-right:solid 1px #e6e6e6">' . '<tbody>' . '<tr><td align="center" border="0" bgcolor="white">
                                                    <img src="cid:logo_2u" alt="vTech Solution" width="250" height="100" style="display: block;" /><br/><br/>
                                                </td><tr>
                            <tr>
                              <td width="20" bgcolor="#476b6b" style="width:20px;background:linear-gradient(to bottom,#476b6b 0%,#476b6b 89%);background-color:#476b6b">&nbsp;</td>


                            </tr>
                          </tbody>
                        </table>
                        <table width="100%" cellspacing="0" cellpadding="0" style="max-width:600px;border-left:solid 1px #e6e6e6;border-right:solid 1px #e6e6e6">
                          <tbody>
                            <tr>
                              <td valign="top" align="center" width="300"><table border="0" cellspacing="0" cellpadding="0" width="100%" bgcolor="#005387">
                                  <tbody>
                                    <tr>
                                      <td valign="middle" align="right" width="20%" height="35" style="border-bottom:solid 1px #003a5e;padding:0padding:0 0 0 5px;color:#ffffff"><a style="text-decoration:none;outline:none;display:block" href="" target="_blank">
                                        </a></td>

                                    </tr>
                                  </tbody>
                                </table></td>
                              <td valign="top" align="center" width="300"><table border="0" cellspacing="0" cellpadding="0" width="100%" bgcolor="#005387">
                                  <tbody>
                                    <tr>

                                      <td valign="middle" align="left" width="30%" height="35" style="border-bottom:solid 1px #003a5e;padding:0 0 0 5px"></td>

                                    </tr>
                                  </tbody>
                                </table></td>
                            </tr>
                          </tbody>
                        </table>
                        <table width="100%" cellspacing="0" cellpadding="0" style="max-width:600px;border-left:solid 1px #e6e6e6;border-right:solid 1px #e6e6e6">
                          <tbody>
                            <tr>
                              <td align="left" valign="top" style="color:#2c2c2c;display:block;line-height:20px;font-weight:300;margin:0 auto;clear:both;border-bottom:2px dashed #ccc;background-color:#f9f9f9;padding:20px" bgcolor="#F9F9F9"><p style="padding:0;margin:0;font-size:16px;font-weight:bold;font-size:13px"> Hello
                                </p><br>
                                <p>

                        vTech HR Team send this message regarding for uploading rejected document List.

                                </p>
                                <p><b>Document Name</b> : <p>
                                <p><b>Rejection Reasons</b> :  <p>

                                <b><p style="padding:0;margin:0;color:#565656;line-height:22px;font-size:15px">Here is your link for upload rejected document
                                  <!--<a href="">iceHrm</a>-->
                                  <br/>
                                 <a href="http://localhost/vtech-tool/web/app_dev.php/api/v2/adobe/view/'.$eid .'"">Click Here</a>
                               </p></b>

                               </td>
                            </tr>
                          </tbody>
                        </table>

                        </body>
                        </html>
                        <html>
                        <head>
                        <style>
                        #a
                        {    color: rgb(14, 61, 150)}
                        #b
                        {color:grey;}
                        #c{color:#0d10ad;    font-weight: bold;}
                        #d{color:grey;font-style:italic;}
                        #e{color:blue;font-weight:30px;font-size: 14px;}

                        .main{
                          position:absolute;left: 62px;;
                        }

                        </style>
                        </head>
                        <body>
                        <div class="main">
                        <div id="a">Regards,</div>
                        <div id="b">HR Team</div><br/>

                        <div id="c">vTech Solution Inc.</div>
                        <div id="d">You Seek, We Deliver</div><br/>

                        <div style="font-size:14px;">1100 H street, N.W. Suite 450,<br/>
                        Washington DC 20005.
                        <div id="e"><u>www.vTechSolution.com</u><br/></div><div><br/><br/>

                        <div style="font-size:14px;color:#635d5d;">

                        This is a PRIVATE message. If you are not the intended recipient, please delete without copying and kindly advise us by e-mail of the mistake in delivery. NOTE: Regardless of content, this e-mail shall not operate to bind JSPL to any order or other contract unless pursuant to explicit written agreement or government initiative expressly permitting the use of e-mail for such purpose.

                        </div>

                        </body>
                        </html>
                        ';

            $mail->Subject = $subject;
            $mail->msgHTML($message);
            $mail->AddAddress($email_to);

            $mail->Send();

    return $data;


    }



    public function viewStatusByComplianceId()
    {

        /*   $this->onBoardingCandidateDatabase = $this->vtechtoolDatabase = $this->container->get('v_tech_solution_quick_book.vtech_tools')->getPDO();
        $employeeId = $this->request->get('id');

        $query = "select complianceId,status from onbording_candidate_documents WHERE candidateId = '$employeeId'";
        $getDocumentList = $this->onBoardingCandidateDatabase->query($query)->fetchAll();
        print_r($employeeId);
        exit();*/

    }

    public function findAllUploadingDocument()
    {

        return $this->onbordingCandidateDocumentsRepository->findAll();
    }

    public function findAllUploadingDocumentWithMapping()
    {
        $return = array();

        $uploadDocumentMappingList = $this->findAllUploadingDocument();

        foreach ($uploadDocumentMappingList as $key => $documentMapping) {

            $complianceId          = $documentMapping->getComplianceId();
            $return[$complianceId] = $documentMapping->getStatus();

        }

        //print_r($return);
        //exit();
        return $return;
    }

    public function countDocument()
    {

        /*$this->onBoardingCandidateDatabase = $this->container->get('v_tech_solution_quick_book.vtech_tools')->getPDO();*/

        $eid = $this->request->get('id');

        $id = $this->decryptionOfEmployeeId($eid, 'd' );

        //print_r($id);

        //exit();

        $this->onBoardingCandidateDatabase = $this->vtechtoolDatabase = $this->container->get('v_tech_solution_quick_book.vtech_candidate_onboarding')->getPDO();

        //print_r($this->onBoardingCandidateDatabase);
        //exit();
        $query = "SELECT COUNT(DISTINCT cct.description) as description FROM compliance_client_template as cct LEFT JOIN candidate_bg_status as cbs on cbs.client_id = cct.client_id LEFT JOIN compliance_list as cl ON cct.co_do_id = cl.CID WHERE cbs.can_id = '$id' AND cct.type = 'compliance'";


        $countDocument = $this->onBoardingCandidateDatabase->query($query)->fetchAll();

        //  print_r($countDocument);
        //exit();

        return $countDocument;






    }

    public function countStatus()
    {

        $eid = $this->request->get('id');

        $id = $this->decryptionOfEmployeeId($eid, 'd' );

        $this->onBoardingCandidateDatabase = $this->vtechtoolDatabase = $this->container->get('v_tech_solution_quick_book.vtech_tools')->getPDO();

        //print_r($this->onBoardingCandidateDatabase);
        //exit();
        $query = "select count(status) FROM onbording_candidate_documents WHERE status = 2 AND candidateId = '$id'";


        $countStatus = $this->onBoardingCandidateDatabase->query($query)->fetchAll();
         //print_r($countStatus);
        // exit();

        return $countStatus;



    }

    public function getDocumentPath() {

        $this->onBoardingCandidateDatabase = $this->vtechtoolDatabase = $this->container->get('v_tech_solution_quick_book.vtech_tools')->getPDO();
        $query = "SELECT file_location as fl,ocd.complianceId from document_history as ds LEFT JOIN onbording_candidate_documents as ocd on ocd.id = ds.candidate_document_id WHERE ds.type = 'pending'";

        $filePath = $this->onBoardingCandidateDatabase->query($query)->fetchAll();

       // print_r($filePath);
        //exit();




    }

    public function viewDocument()
    {

        $this->onBoardingCandidateDatabase = $this->vtechtoolDatabase = $this->container->get('v_tech_solution_quick_book.vtech_tools')->getPDO();



        $eid = $this->request->get('id');

         $employeeId = $this->decryptionOfEmployeeId($eid, 'd' );




        $complianceIdForReject = $this->request->get('hiddenValue');
        $complianceId          = $this->request->get('cid');

        $rejectionMessage = $this->request->get('message');

        $rejectedDocument = $this->request->get('hiddenValuedocument');


        $action = $this->request->get('reject');

        $approve = $this->request->get('action');

        $time = $this->updated = new \DateTime("now");

        $query = "select private_email from employees where id = '$employeeId'";

        $this->vtechhrmDatabase = $this->container->get('v_tech_solution_quick_book.vtechhrm')->getPDO();

        $employeeEmail = $this->vtechhrmDatabase->query($query)->fetchAll();

        if ($approve == 'approve') {

            $updateByApprove = $this->onbordingCandidateDocumentsRepository->findByCandidateIdAndComplianceId($employeeId,$complianceId);

            if (count($updateByApprove) > 0) {

              $updateByApprove->setStatus('2');
              $this->onbordingCandidateDocumentsRepository->commit($updateByApprove);
              $lastId =   $updateByApprove->getId();
              //print_r($lastId);
              //exit();

              $getFileLocation =   $this->DocumentHistoryRepository->getFileLocation($lastId);
              foreach ($getFileLocation as $key => $value) {

                $approve = new DocumentHistory();
                $approve->setCandidateDocumentId($lastId);
                $approve->setReason('');
                $approve->setFileLocation($value);
                $approve->setType('Approve');

                $this->DocumentHistoryRepository->commit($approve);

            }

          }
        }


        if ($action == 'reject') {


            $updateByReject = $this->onbordingCandidateDocumentsRepository->findByCandidateIdAndComplianceIdForRejection($employeeId,$complianceIdForReject);

             if (count($updateByReject) > 0) {

              $updateByReject->setStatus('3');
              $this->onbordingCandidateDocumentsRepository->commit($updateByReject);

                $lastId =   $updateByReject->getId();

                $getFileLocation =   $this->DocumentHistoryRepository->getFileLocation($lastId);
                //$fileLocation = $getFileLocation->getFileLocation();

                    foreach ($getFileLocation as $key => $rejectFileLocation) {

                $reject = new DocumentHistory();

                $reject->setCandidateDocumentId($lastId);
                $reject->setReason($rejectionMessage);
                $reject->setFileLocation($rejectFileLocation);
                $reject->setType('Rejected');

                $this->DocumentHistoryRepository->reject($reject);






        $location = $this->container->getParameter('kernel.root_dir') . '/../web/uploads/documents/';

        $attachmentFileLocationFromRoot = $this->container->getParameter('kernel.root_dir') . '/../web'.$rejectFileLocation;

        //print_r($attachmentFileLocationFromRoot);
        //exit();




        $query = "select private_email,first_name,last_name from employees where id = '$employeeId'";

        $this->vtechhrmDatabase = $this->container->get('v_tech_solution_quick_book.vtechhrm')->getPDO();
        $employeeEmail          = $this->vtechhrmDatabase->query($query)->fetchAll();

         foreach ($employeeEmail as $key => $value) {


            $mail = new PHPMailer;

            $mail->isSMTP();
            $mail->Host        = 'smtp.gmail.com';
            $mail->SMTPAuth    = true;
            $mail->Username    = 'giet13aei015@gmail.com';
            $mail->Password    = '9709305850';
            $mail->From        = "giet13aei015@gmail.com";
            $mail->SMTPSecure  = 'ssl';
            $mail->Port        = 465;
            $mail->AddEmbeddedImage($location.'/ssn.png', 'logo_2u');
            $mail->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                )
            );

            $email_to = 'shravank@vtechsolution.us';
            //$value['private_email']
            $mail->addAttachment($attachmentFileLocationFromRoot);
            $subject  = "Rejected Document List";
            $message  = '<html>' . '<body>' . '<table width="100%" cellspacing="0" cellpadding="0" style="max-width:600px;border-left:solid 1px #e6e6e6;border-right:solid 1px #e6e6e6">' . '<tbody>' . '<tr><td align="center" border="0" bgcolor="white">
                                                    <img src="cid:logo_2u" alt="vTech Solution" width="250" height="100" style="display: block;" /><br/><br/>
                                                </td><tr>
                            <tr>
                              <td width="20" bgcolor="#476b6b" style="width:20px;background:linear-gradient(to bottom,#476b6b 0%,#476b6b 89%);background-color:#476b6b">&nbsp;</td>


                            </tr>
                          </tbody>
                        </table>
                        <table width="100%" cellspacing="0" cellpadding="0" style="max-width:600px;border-left:solid 1px #e6e6e6;border-right:solid 1px #e6e6e6">
                          <tbody>
                            <tr>
                              <td valign="top" align="center" width="300"><table border="0" cellspacing="0" cellpadding="0" width="100%" bgcolor="#005387">
                                  <tbody>
                                    <tr>
                                      <td valign="middle" align="right" width="20%" height="35" style="border-bottom:solid 1px #003a5e;padding:0padding:0 0 0 5px;color:#ffffff"><a style="text-decoration:none;outline:none;display:block" href="" target="_blank">
                                        </a></td>

                                    </tr>
                                  </tbody>
                                </table></td>
                              <td valign="top" align="center" width="300"><table border="0" cellspacing="0" cellpadding="0" width="100%" bgcolor="#005387">
                                  <tbody>
                                    <tr>

                                      <td valign="middle" align="left" width="30%" height="35" style="border-bottom:solid 1px #003a5e;padding:0 0 0 5px"></td>

                                    </tr>
                                  </tbody>
                                </table></td>
                            </tr>
                          </tbody>
                        </table>
                        <table width="100%" cellspacing="0" cellpadding="0" style="max-width:600px;border-left:solid 1px #e6e6e6;border-right:solid 1px #e6e6e6">
                          <tbody>
                            <tr>
                              <td align="left" valign="top" style="color:#2c2c2c;display:block;line-height:20px;font-weight:300;margin:0 auto;clear:both;border-bottom:2px dashed #ccc;background-color:#f9f9f9;padding:20px" bgcolor="#F9F9F9"><p style="padding:0;margin:0;font-size:16px;font-weight:bold;font-size:13px"> Hello '.$value['first_name'].'
                               '.$value['last_name'].',
                                </p><br>
                                <p>

                        vTech HR Team send this message regarding for uploading rejected document List.

                                </p>
                                <p><b>Document Name</b> : '.$rejectedDocument.' <p>
                                <p><b>Rejection Reasons</b> : '.$rejectionMessage.' <p>

                                <b><p style="padding:0;margin:0;color:#565656;line-height:22px;font-size:15px">Here is your link for upload rejected document
                                  <!--<a href="">iceHrm</a>-->
                                  <br/>
                                 <a href="http://localhost/vtech-tool/web/app_dev.php/api/v2/adobe/upload/'.$employeeId.'">Click Here</a>
                               </p></b>

                               </td>
                            </tr>
                          </tbody>
                        </table>

                        </body>
                        </html>
                        <html>
                        <head>
                        <style>
                        #a
                        {    color: rgb(14, 61, 150)}
                        #b
                        {color:grey;}
                        #c{color:#0d10ad;    font-weight: bold;}
                        #d{color:grey;font-style:italic;}
                        #e{color:blue;font-weight:30px;font-size: 14px;}

                        .main{
                          position:absolute;left: 62px;;
                        }

                        </style>
                        </head>
                        <body>
                        <div class="main">
                        <div id="a">Regards,</div>
                        <div id="b">HR Team</div><br/>

                        <div id="c">vTech Solution Inc.</div>
                        <div id="d">You Seek, We Deliver</div><br/>

                        <div style="font-size:14px;">1100 H street, N.W. Suite 450,<br/>
                        Washington DC 20005.
                        <div id="e"><u>www.vTechSolution.com</u><br/></div><div><br/><br/>

                        <div style="font-size:14px;color:#635d5d;">

                        This is a PRIVATE message. If you are not the intended recipient, please delete without copying and kindly advise us by e-mail of the mistake in delivery. NOTE: Regardless of content, this e-mail shall not operate to bind JSPL to any order or other contract unless pursuant to explicit written agreement or government initiative expressly permitting the use of e-mail for such purpose.

                        </div>

                        </body>
                        </html>
                        ';

            $mail->Subject = $subject;
            $mail->msgHTML($message);
            $mail->AddAddress($email_to);

            $mail->Send();

        }



        }
    }
    }
}

}

<?php
namespace vTechSolution\Bundle\ReportBundle\Manager;

use Symfony\Component\DependencyInjection\ContainerInterface as Container;
use Symfony\Component\HttpFoundation\Request;
use vTechSolution\Bundle\SearchBundle\Document\KeyStringUsage;


class ReportService
{
  private $container;
  private $doctrine;
  private $request;
  private $responseArray;
  private $hrminDb;
  private $catsDB;
  private $mappingDb;
  private $vtechhrmDB;
  private $keyStringUsageRepository;
  private $SaveSearchRepository;

  const HTTP_METHOD_GET    = 'GET';
  const HTTP_METHOD_POST   = 'POST';

  public function __construct(Container $container) {
        $this->container = $container;
        $this->request = $this->container->get('request');
        $this->responseArray = array();
        $this->hrminDb = $this->container->get('v_tech_solution_report.vtechhrm_in')->getPDO();
        $this->mappingDb = $this->container->get('v_tech_solution_report.mappingdb')->getPDO();
        $this->vtechhrmDB = $this->container->get('v_tech_solution_report.vtechhrm')->getPDO();
        $this->catsDB = $this->container->get('v_tech_solution_report.cats')->getPDO();
        $this->keyStringUsageRepository = $this->container->get('doctrine_mongodb')->getRepository('vTechSolutionSearchBundle:KeyStringUsage');
        $this->SaveSearchRepository = $this->container->get('doctrine_mongodb')->getRepository('vTechSolutionSearchBundle:SaveSearch');
        //$this->SaveSearchRepository = null;
    }

  public function __destructor() {
      unset($this->container);
      unset($this->request);
      unset($this->doctrine);
      unset($this->responseArray);
      unset($this->hrminDb);
      unset($this->mappingDb);
      unset($this->vtechhrmDB);
      unset($this->keyStringUsageRepository);
    }


  public function getEmloyeesDetailFromHrm(){

        $this->hrminDb = $this->container->get('v_tech_solution_report.vtechhrm_in')->getPDO();

        $query = "SELECT
                    u.user_id AS recruiter_id
                  FROM
                    cats.user AS u
                  LEFT JOIN vtechhrm_in.main_users AS mu ON CONCAT(mu.firstname,' ',mu.lastname) = CONCAT(u.first_name,' ',u.last_name)
                  LEFT JOIN vtechhrm_in.main_employees_summary AS mes ON mes.user_id = mu.id
                  WHERE
                    mes.department_id IN (4,19,20)
                  AND
                    u.access_level != '0'
                  GROUP BY u.user_id";

        $employeeDetail = $this->hrminDb->query($query)->fetchAll();

        foreach ($employeeDetail as $key => $value) {

            $employees = $value['recruiter_id'];

            $this->responseArray[$key] = $employees;

        }
        return $this->responseArray;
    }


    public function getGpDetailHrmRecruiterPersonnelByName(){

        $recruiterName = $this->request->get('name');
        $startdate = $this->request->get('startdate');
        $startDate = date("Y-m-d" , strtotime($startdate));

        $enddate = $this->request->get('enddate');
        $endDate = date("Y-m-d" , strtotime($enddate));
        $delimiter = array("","[","]",'"');
        $query = "SELECT
            e.id AS employee_id,
            e.custom1 AS benefit,
            e.custom2 AS benefit_list,
            CAST(replace(e.custom3,'$','') AS DECIMAL (10,2)) AS bill_rate,
            CAST(replace(e.custom4,'$','') AS DECIMAL (10,2)) AS pay_rate,
            es.id AS employment_id,
            es.name AS employment_type,
            comp.company_id,
            comp.name AS company_name,
            (SELECT clf.mspChrg_pct FROM vtech_mappingdb.client_fees AS clf WHERE clf.client_id = comp.company_id) AS client_msp_charge_percentage,
            (SELECT clf.primechrg_pct FROM vtech_mappingdb.client_fees AS clf WHERE clf.client_id = comp.company_id) AS client_prime_charge_percentage,
            (SELECT clf.primeChrg_dlr FROM vtech_mappingdb.client_fees AS clf WHERE clf.client_id = comp.company_id) AS client_prime_charge_dollar,
            (SELECT clf.mspChrg_dlr FROM vtech_mappingdb.client_fees AS clf WHERE clf.client_id = comp.company_id) AS client_msp_charge_dollar,
            (SELECT cnf.c_primeCharge_pct FROM vtech_mappingdb.candidate_fees AS cnf WHERE cnf.emp_id = e.id) AS employee_prime_charge_percentage,
            (SELECT cnf.c_primeCharge_dlr FROM vtech_mappingdb.candidate_fees AS cnf WHERE cnf.emp_id = e.id) AS employee_prime_charge_dollar,
            (SELECT cnf.c_anyCharge_dlr FROM vtech_mappingdb.candidate_fees AS cnf WHERE cnf.emp_id = e.id) AS employee_any_charge_dollar,
            u.user_id AS recruiter_id,
            CONCAT(u.first_name,' ',u.last_name) AS recruiter_name,
            u.notes AS recruiter_manager
        FROM
            employees AS e
            LEFT JOIN employeeprojects AS ep ON ep.employee = e.id
            LEFT JOIN employmentstatus AS es ON e.employment_status = es.id
            LEFT JOIN employeetimeentry AS ete ON ete.employee = e.id
            LEFT JOIN vtech_mappingdb.system_integration AS si ON e.id = si.h_employee_id
            LEFT JOIN cats.company AS comp ON si.c_company_id = comp.company_id
            LEFT JOIN cats.user AS u ON u.user_id = si.c_recruiter_id
        WHERE
            CONCAT(u.first_name,' ',u.last_name) = '$recruiterName'
        AND
            ep.project != '6'
        AND
            e.custom7 BETWEEN '$startDate 00:00:00' AND '$endDate 23:59:59'
        AND
            ete.date_start BETWEEN '$startDate 00:00:00' AND '$endDate 23:59:59'
        GROUP BY employee_id";

        $GpDetails = $this->vtechhrmDB->query($query)->fetchAll();

        if(!empty($GpDetails)){

            foreach ($GpDetails as $key => $GpDetail) {

                $benefitList = str_replace($delimiter, $delimiter[0], $GpDetail["benefit_list"]);

                $taxRate = round($this->employeeTaxRate($this->mappingDb,$GpDetail["benefit"],$benefitList,$GpDetail["employment_id"],$GpDetail["pay_rate"]), 2);

                $mspFees = round((($GpDetail["client_msp_charge_percentage"] / 100) * $GpDetail["bill_rate"]) + $GpDetail["client_msp_charge_dollar"], 2);

                $primeCharges = round(((($GpDetail["client_prime_charge_percentage"] / 100) * $GpDetail["bill_rate"]) + (($GpDetail["employee_prime_charge_percentage"] / 100) * $GpDetail["bill_rate"]) + $GpDetail["employee_prime_charge_dollar"] + $GpDetail["employee_any_charge_dollar"] + $GpDetail["client_prime_charge_dollar"]), 2);

                $candidateRate = round(($GpDetail["pay_rate"] + $taxRate + $mspFees + $primeCharges), 2);

                $grossMargin = round(($GpDetail["bill_rate"] - $candidateRate), 2);

                $totalHour = round($this->employeeWorkingHours($this->vtechhrmDB,$startDate,$endDate,$GpDetail["employee_id"]), 2);

                $totalGrossProfit[] = round(($grossMargin * $totalHour), 2);
            }

            $totalGp = round(array_sum($totalGrossProfit), 2);

            $this->responseArray = $totalGp;
        }

        return $this->responseArray;
    }


    public function getRecruiterPlacement(){

        $recruiterName = $this->request->get('name');
        $startdate = $this->request->get('startdate');
        $startDate = date("Y-m-d" , strtotime($startdate));

        $enddate = $this->request->get('enddate');
        $endDate = date("Y-m-d" , strtotime($enddate));

        $query = "SELECT
            COUNT(DISTINCT cjsh.candidate_joborder_status_history_id) AS total_placed
        FROM
            cats.user AS u
            LEFT JOIN cats.candidate_joborder AS cj ON cj.added_by = u.user_id
            LEFT JOIN cats.candidate_joborder_status_history AS cjsh ON cjsh.joborder_id = cj.joborder_id AND cjsh.candidate_id = cj.candidate_id
        WHERE
            cjsh.status_to = '800'
        AND
            DATE_FORMAT(cjsh.date, '%Y-%m-%d') BETWEEN '$startDate' AND '$endDate'
        AND
            CONCAT(u.first_name,' ',u.last_name) = '$recruiterName'
        AND
            cjsh.candidate_id NOT IN (SELECT
            cjsh.candidate_id
        FROM
            cats.user AS u
            LEFT JOIN cats.candidate_joborder AS cj ON cj.added_by = u.user_id
            LEFT JOIN cats.candidate_joborder_status_history AS cjsh ON cjsh.joborder_id = cj.joborder_id AND cjsh.candidate_id = cj.candidate_id
        WHERE
            cjsh.status_to = '620'
        AND
            CONCAT(u.first_name,' ',u.last_name) = '$recruiterName'
        AND
            DATE_FORMAT(cjsh.date, '%Y-%m-%d') BETWEEN '$startDate' AND '$endDate')
        GROUP BY u.user_id";

        $placementResult = $this->vtechhrmDB->query($query)->fetchColumn();

        $this->responseArray = $placementResult;

        return $this->responseArray;
    }


    public function employeeTaxRate($vtechMappingdbConn,$benefit,$benefitList,$employmentId,$payRate) {

          $taxRate = 0;

          if ($benefit == "With Benefits") {

            $benefitListGroup = explode(",", $benefitList);

          foreach ($benefitListGroup as $benefitListKey => $benefitListValue) {

                    $taxQUERY= "SELECT
                                    charge_pct
                                FROM
                                    tax_settings
                                WHERE
                                    empst_id = '$employmentId'
                                AND
                                    benefits LIKE '%$benefitListValue%'";

                    $taxROW = $this->mappingDb->query($taxQUERY)->fetchColumn();

                    $taxRate += $payRate * ($taxROW / 100);
            }
          }
          elseif ($benefit == "Without Benefits" || $benefit == "" || $benefit == "Not Applicable") {

                    $taxQUERY= "SELECT
                                      charge_pct
                                FROM
                                      tax_settings
                                WHERE
                                      empst_id = '$employmentId'
                                AND
                                      benefits = 'Without Benefits'";

                    $taxROW = $this->mappingDb->query($taxQUERY)->fetchColumn();

                    $taxRate = $payRate * ($taxROW / 100);
          }

          return $taxRate;
    }

    function decimalHours($time) {
        $tms = explode(":", $time);
        return ($tms[0] + ($tms[1] / 60) + ($tms[2] / 3600));
    }

    public function employeeWorkingHours($vtechhrmConn,$fromDate,$toDate,$employeeId) {

        $totalHour = 0;

        $timeEntryQUERY = "SELECT
            time_start,
            time_end
        FROM
            vtechhrm.employeetimeentry
        WHERE
            employee = '$employeeId'
        AND
            date_start BETWEEN '$fromDate' AND '$toDate'";

        $timeEntryQueryData = $this->vtechhrmDB->query($timeEntryQUERY)->fetchAll();

        if(!empty($timeEntryQueryData)) {
            foreach ($timeEntryQueryData as $timeEntryROW) {

                $timeEnd = $this->decimalHours($timeEntryROW["time_end"]);
                $timeStart = $this->decimalHours($timeEntryROW["time_start"]);

            $totalHour += ($timeEnd - $timeStart);
            }

        }
        return $totalHour;
    }

    public function getGpDetailHrmPostSalesTeamPersonnelByName(){

        $name = $this->request->get('name');

        $startDate = $this->request->get('startdate');

        $endDate = $this->request->get('enddate');

        $delimiter = array("","[","]",'"');

            $query = "SELECT
                ehd.*,
                si.c_inside_post_sales
            FROM
                vtechhrm.employees AS e
                LEFT JOIN vtech_mappingdb.system_integration AS si ON si.h_employee_id = e.id
                LEFT JOIN vtech_mappingdb.employee_history_detail AS ehd ON ehd.employee_id = e.id
                LEFT JOIN vtechhrm.employeetimeentry AS ete ON ete.employee = e.id
            WHERE
                si.c_inside_post_sales = '$name'
            AND
                ehd.id IN (SELECT MAX(id) FROM vtech_mappingdb.employee_history_detail WHERE employee_id = ehd.employee_id AND ((created_at BETWEEN '$startDate 00:00:00' AND '$endDate 23:59:59') OR (((created_at NOT BETWEEN '$startDate 00:00:00' AND '$endDate 23:59:59') AND created_at < '$startDate 00:00:00') OR ((created_at NOT BETWEEN '$startDate 00:00:00' AND '$endDate 23:59:59') AND created_at > '$endDate 23:59:59'))))
            AND
                e.custom7 BETWEEN '$startDate 00:00:00' AND '$endDate 23:59:59'
            AND
                ete.date_start BETWEEN '$startDate 00:00:00' AND '$endDate 23:59:59'
            GROUP BY e.id";

        $GpDetails = $this->mappingDb->query($query)->fetchAll();

        if(!empty($GpDetails)){

            foreach ($GpDetails as $key => $GpDetail) {

                $benefitList = str_replace($delimiter, $delimiter[0], $GpDetail["benefit_list"]);

                $taxRate = round($this->employeeTaxRate($this->mappingDb,$GpDetail["benefit"],$benefitList,$GpDetail["employment_id"],$GpDetail["pay_rate"]), 2);

                $mspFees = round((($GpDetail["client_msp_charge_percentage"] / 100) * $GpDetail["bill_rate"]) + $GpDetail["client_msp_charge_dollar"], 2);

                $primeCharges = round(((($GpDetail["client_prime_charge_percentage"] / 100) * $GpDetail["bill_rate"]) + (($GpDetail["employee_prime_charge_percentage"] / 100) * $GpDetail["bill_rate"]) + $GpDetail["employee_prime_charge_dollar"] + $GpDetail["employee_any_charge_dollar"] + $GpDetail["client_prime_charge_dollar"]), 2);

                $candidateRate = round(($GpDetail["pay_rate"] + $taxRate + $mspFees + $primeCharges), 2);

                $grossMargin = round(($GpDetail["bill_rate"] - $candidateRate), 2);

                $totalHour = round($this->employeeWorkingHours($this->vtechhrmDB,$startDate,$endDate,$GpDetail["employee_id"]), 2);

                $totalGrossProfit[] = round(($grossMargin * $totalHour), 2);
            }

            $totalGp = round(array_sum($totalGrossProfit), 2);

            $this->responseArray = $totalGp;
        }

        return $this->responseArray;
    }

    public function getPostSalesPersonnelPlacement(){

        $personnelName = $this->request->get('name');
        $startdate = $this->request->get('startdate');
        $startDate = date("Y-m-d" , strtotime($startdate));

        $enddate = $this->request->get('enddate');
        $endDate = date("Y-m-d" , strtotime($enddate));

        $query = "SELECT
            COUNT(DISTINCT cjsh.candidate_joborder_status_history_id) AS total_placed
        FROM
            cats.user AS u
            LEFT JOIN cats.extra_field AS ef ON ef.value = CONCAT(u.first_name,' ',u.last_name)
            LEFT JOIN cats.company AS comp ON comp.company_id = ef.data_item_id
            LEFT JOIN cats.joborder AS job ON job.company_id = comp.company_id
            LEFT JOIN cats.candidate_joborder AS cj ON cj.joborder_id = job.joborder_id
            LEFT JOIN cats.candidate_joborder_status_history AS cjsh ON cjsh.joborder_id = cj.joborder_id AND cjsh.candidate_id = cj.candidate_id
        WHERE
            cjsh.status_to = '800'
        AND
            ef.field_name = 'Inside Post Sales'
        AND
            DATE_FORMAT(cjsh.date, '%Y-%m-%d') BETWEEN '$startDate' AND '$endDate'
        AND
            ef.value = '$personnelName'
        AND
            cjsh.candidate_id NOT IN (SELECT
            cjsh.candidate_id
        FROM
            cats.user AS u
            LEFT JOIN cats.extra_field AS ef ON ef.value = CONCAT(u.first_name,' ',u.last_name)
            LEFT JOIN cats.company AS comp ON comp.company_id = ef.data_item_id
            LEFT JOIN cats.joborder AS job ON job.company_id = comp.company_id
            LEFT JOIN cats.candidate_joborder AS cj ON cj.joborder_id = job.joborder_id
            LEFT JOIN cats.candidate_joborder_status_history AS cjsh ON cjsh.joborder_id = cj.joborder_id AND cjsh.candidate_id = cj.candidate_id
        WHERE
            cjsh.status_to = '620'
        AND
            ef.field_name = 'Inside Post Sales'
        AND
            ef.value = '$personnelName'
        AND
            DATE_FORMAT(cjsh.date, '%Y-%m-%d') BETWEEN '$startDate' AND '$endDate')
        GROUP BY u.user_id";

        $placementResult = $this->vtechhrmDB->query($query)->fetchColumn();

        $this->responseArray = $placementResult;

        return $this->responseArray;
    }

    public function getGpDetailHrmSalesTeamPersonnelByName(){

        $name = $this->request->get('name');

        $startdate = $this->request->get('startdate');
        $startDate = date("Y-m-d" , strtotime($startdate));
        $enddate = $this->request->get('enddate');
        $endDate = date("Y-m-d" , strtotime($enddate));
        $delimiter = array("","[","]",'"');

        $query = "SELECT
            ehd.*,
            IF((si.c_inside_sales1 != '' AND si.c_inside_sales2 = '' AND si.c_research_by = ''), si.c_inside_sales1,IF((si.c_inside_sales1 = '' AND si.c_inside_sales2 != '' AND si.c_research_by = ''), si.c_inside_sales2, IF((si.c_inside_sales1 = '' AND si.c_inside_sales2 = '' AND si.c_research_by != ''), si.c_research_by, IF((si.c_inside_sales1 != '' AND si.c_inside_sales2 != '' AND si.c_research_by = ''), CONCAT(si.c_inside_sales1,',',si.c_inside_sales2), IF((si.c_inside_sales1 = '' AND si.c_inside_sales2 != '' AND si.c_research_by != ''),  CONCAT(si.c_inside_sales2,',',si.c_research_by), IF((si.c_inside_sales1 != '' AND si.c_inside_sales2 = '' AND si.c_research_by != ''),   CONCAT(si.c_inside_sales1,',',si.c_research_by), IF((si.c_inside_sales1 != '' AND si.c_inside_sales2 != '' AND si.c_research_by != ''),    CONCAT(si.c_inside_sales1,',',si.c_inside_sales2,',',si.c_research_by), '---'))))))) AS shared_with
        FROM
            vtechhrm.employees AS e
            LEFT JOIN vtech_mappingdb.system_integration AS si ON si.h_employee_id = e.id
            LEFT JOIN vtech_mappingdb.employee_history_detail AS ehd ON ehd.employee_id = e.id
            LEFT JOIN vtechhrm.employeetimeentry AS ete ON ete.employee = e.id
        WHERE
            (si.c_inside_sales1 = '$name' OR si.c_inside_sales2 = '$name' OR si.c_research_by = '$name')
        AND
            ehd.id IN (SELECT MAX(id) FROM vtech_mappingdb.employee_history_detail WHERE employee_id = ehd.employee_id AND ((created_at BETWEEN '$startDate 00:00:00' AND '$endDate 23:59:59') OR (((created_at NOT BETWEEN '$startDate 00:00:00' AND '$endDate 23:59:59') AND created_at < '$startDate 00:00:00') OR ((created_at NOT BETWEEN '$startDate 00:00:00' AND '$endDate 23:59:59') AND created_at > '$endDate 23:59:59'))))
        AND
            e.custom7 BETWEEN '$startDate 00:00:00' AND '$endDate 23:59:59'
        AND
            ete.date_start BETWEEN '$startDate 00:00:00' AND '$endDate 23:59:59'
        GROUP BY e.id";

        $GpDetails = $this->mappingDb->query($query)->fetchAll();

        if(!empty($GpDetails)){

            foreach ($GpDetails as $key => $GpDetail) {
                $sharedWith = array_unique(explode(",", $GpDetail["shared_with"]));

                $totalShare = COUNT($sharedWith);

                $empShare = round((1 / $totalShare), 2);

                $benefitList = str_replace($delimiter, $delimiter[0], $GpDetail["benefit_list"]);

                $taxRate = round($this->employeeTaxRate($this->mappingDb,$GpDetail["benefit"],$benefitList,$GpDetail["employment_id"],$GpDetail["pay_rate"]), 2);

                $mspFees = round((($GpDetail["client_msp_charge_percentage"] / 100) * $GpDetail["bill_rate"]) + $GpDetail["client_msp_charge_dollar"], 2);

                $primeCharges = round(((($GpDetail["client_prime_charge_percentage"] / 100) * $GpDetail["bill_rate"]) + (($GpDetail["employee_prime_charge_percentage"] / 100) * $GpDetail["bill_rate"]) + $GpDetail["employee_prime_charge_dollar"] + $GpDetail["employee_any_charge_dollar"] + $GpDetail["client_prime_charge_dollar"]), 2);

                $candidateRate = round(($GpDetail["pay_rate"] + $taxRate + $mspFees + $primeCharges), 2);

                $grossMargin = round(($GpDetail["bill_rate"] - $candidateRate), 2);

                $totalHour = round($this->employeeWorkingHours($this->vtechhrmDB,$startDate,$endDate,$GpDetail["employee_id"]), 2);

                $totalGrossProfit[] = round((($grossMargin * $totalHour) * $empShare), 2);

            }

            $totalGp = round(array_sum($totalGrossProfit), 2);

            $this->responseArray = $totalGp;
        }

        return $this->responseArray;
    }


    public function getSalesPersonnelPlacement(){

        $personnelName = $this->request->get('name');
        $startdate = $this->request->get('startdate');
        $startDate = date("Y-m-d" , strtotime($startdate));

        $enddate = $this->request->get('enddate');
        $endDate = date("Y-m-d" , strtotime($enddate));

        $query = "SELECT
            COUNT(DISTINCT cjsh.candidate_joborder_status_history_id) AS total_placed
        FROM
            cats.user AS u
            LEFT JOIN cats.extra_field AS ef ON ef.value = CONCAT(u.first_name,' ',u.last_name)
            LEFT JOIN cats.company AS comp ON comp.company_id = ef.data_item_id
            LEFT JOIN cats.joborder AS job ON job.company_id = comp.company_id
            LEFT JOIN cats.candidate_joborder AS cj ON cj.joborder_id = job.joborder_id
            LEFT JOIN cats.candidate_joborder_status_history AS cjsh ON cjsh.joborder_id = cj.joborder_id AND cjsh.candidate_id = cj.candidate_id
        WHERE
            cjsh.status_to = '800'
        AND
            ef.field_name IN ('Inside Sales Person1','Inside Sales Person2','Research By')
        AND
            DATE_FORMAT(cjsh.date, '%Y-%m-%d') BETWEEN '$startDate' AND '$endDate'
        AND
            ef.value = '$personnelName'
        AND
            cjsh.candidate_id NOT IN (SELECT
            cjsh.candidate_id
        FROM
            cats.user AS u
            LEFT JOIN cats.extra_field AS ef ON ef.value = CONCAT(u.first_name,' ',u.last_name)
            LEFT JOIN cats.company AS comp ON comp.company_id = ef.data_item_id
            LEFT JOIN cats.joborder AS job ON job.company_id = comp.company_id
            LEFT JOIN cats.candidate_joborder AS cj ON cj.joborder_id = job.joborder_id
            LEFT JOIN cats.candidate_joborder_status_history AS cjsh ON cjsh.joborder_id = cj.joborder_id AND cjsh.candidate_id = cj.candidate_id
        WHERE
            cjsh.status_to = '620'
        AND
            ef.field_name IN ('Inside Sales Person1','Inside Sales Person2','Research By')
        AND
            ef.value = '$personnelName'
        AND
            DATE_FORMAT(cjsh.date, '%Y-%m-%d') BETWEEN '$startDate' AND '$endDate')
        GROUP BY u.user_id";

        $placementResult = $this->vtechhrmDB->query($query)->fetchColumn();

        $this->responseArray = $placementResult;

        return $this->responseArray;
    }


    // public function keyStringUsageReport() {
    //   $keyStringClicks = $this->keyStringUsageRepository->fetchAll();
    //   foreach ($keyStringClicks as $keyString) {
    //     $clickUserID = $keyString->getUserId();
    //     $clickJoborderId = $keyString->getJoborderId();
    //     $clickKeyString = $keyString->getkeyString();
    //     $clickSource = $keyString->getSource();
    //     $clickDate = $keyString->getCreatedAt();
    //     $clickedResultArray[$clickUserID][] = array("job_id" => $clickJoborderId, "source" => $clickSource, "date" => $clickDate->format('Y-m-d'));
    //     }
    //
    //     echo "<pre>";
    //     print_r($clickedResultArray); die;
    //
    //     foreach ($clickedResultArray as $keyClick => $crs) {
    //       $nexxtCount = $monsterCount  = array();
    //       foreach ($crs as $key => $cr) {
    //
    //         if ($cr['source'] == 'monster') {
    //           $monsterCount[] = $cr['source'];
    //           }
    //           if ($cr['source'] == 'nexxt') {
    //             $nexxtCount[] = $cr['source'];
    //             }
    //         }
    //         $arrayNew[$keyClick] = array("monster_count" => count($monsterCount), "nexxt_count" => count($nexxtCount));
    //         $atsUserId[] = $keyClick;
    //         unset($monsterCount);
    //         unset($nexxtCount);
    //
    //       }
    //       $atsUserString = implode(",",$atsUserId);
    //       $catsUserName = $this->catsDB->prepare("SELECT user_id,CONCAT(first_name,' ',last_name) as full_name FROM `user` WHERE user_id in ($atsUserString)");
    //       $catsUserName->execute();
    //       $catsUserNameResult = $catsUserName->fetchAll();
    //       foreach ($catsUserNameResult as $key => $userNameRow) {
    //         $firstArray[$userNameRow['user_id']] = $userNameRow['full_name'];
    //       }
    //
    //       foreach ($arrayNew as $userId => $au) {
    //         $clickedResult[$firstArray[$userId]]= array("monster" => $au["monster_count"], "nexxt" => $au["nexxt_count"]);
    //       }
    //
    //       return $clickedResult;
    //   }

    public function keyStringUsageReport() {
      $multipleMonth = $this->request->get('multipleMonth');
      $fromStartDate = $this->request->get('fromDate');
      $toEndDate = $this->request->get('toDate');
      $multipleQuarter = $this->request->get('multipleQuarter');

      if ($multipleMonth != null) {
        $allMonth = explode(",",$multipleMonth);
        foreach ($allMonth as $singleMonth) {
            $diveMonth = explode("/",$singleMonth);
            $newMonth = $diveMonth[1]."/".$diveMonth[0]."/01";
            $startMonthDate = date('Y/m/01', strtotime($newMonth));
            $endMonthDate = date('Y/m/t', strtotime($newMonth));
            $finalDates[] = array("start_date" => $startMonthDate, "end_date" => $endMonthDate, "original_value" => $singleMonth);
        }
      }

      if ($fromStartDate != null && $toEndDate != null ) {

            $finalDates[] = array("start_date" => date('Y/m/d', strtotime($fromStartDate)), "end_date" => date('Y/m/d', strtotime($toEndDate)), "original_value" => $fromStartDate.'-'.$toEndDate );
      }

      if ($multipleQuarter != null) {
          $allQuarter = explode(",",$multipleQuarter);
          foreach ($allQuarter as $key => $singleQuarter) {
            $divideQuarter = explode("/",$singleQuarter);
            if ($divideQuarter[0] == 'Q1') {
              $startQuarterDate = $divideQuarter[1].'/01/01';
              $endQuarterDate = $divideQuarter[1].'/03/31';
            }
            if ($divideQuarter[0] == 'Q2') {
              $startQuarterDate = $divideQuarter[1].'/04/01';
              $endQuarterDate = $divideQuarter[1].'/06/30';
            }
            if ($divideQuarter[0] == 'Q3') {
              $startQuarterDate = $divideQuarter[1].'/07/01';
              $endQuarterDate = $divideQuarter[1].'/09/30';
            }
            if ($divideQuarter[0] == 'Q4') {
              $startQuarterDate = $divideQuarter[1].'/10/01';
              $endQuarterDate = $divideQuarter[1].'/12/31';
            }
            $finalDates[] = array("start_date" => $startQuarterDate, "end_date" => $endQuarterDate, "original_value" => $singleQuarter );
          }
      }
      rsort($finalDates);

      $sourceArray = array("monster" => "Monster", "nexxt" => "Nexxt");
      $return = array();
      $keyStringClicks = $this->keyStringUsageRepository->fetchAll();
      $clickedResultArray = array("monster" => array(), "nexxt" => array());

      foreach ($keyStringClicks as $keyString) {
        $clickUserID = $keyString->getUserId();
        $clickJoborderId = $keyString->getJoborderId();
        $clickKeyString = $keyString->getkeyString();
        $clickSource = $keyString->getSource();
        $clickDate = $keyString->getCreatedAt();

        $clickedResultArray[$clickSource][] = $clickDate->format('Y/m/d');
        }

        foreach ($finalDates as $finalStartDate) {
        foreach ($clickedResultArray as $keyClick => $clickedResultRows) {
          $dateRangeResultArray[$sourceArray[$keyClick]]['Source'] = $sourceArray[$keyClick];
          $dateRangeResultArray[$sourceArray[$keyClick]][$finalStartDate['original_value']] = 0;
          foreach ($clickedResultRows as $clickedResultRow ) {
              if ($finalStartDate['start_date'] <= $clickedResultRow && $finalStartDate['end_date'] >= $clickedResultRow) {
                $dateRangeResultArray[$sourceArray[$keyClick]][$finalStartDate['original_value']]++;
              }
            }
          }
        }
        // echo "<pre>";
        // print_r($dateRangeResultArray); die;

        $dateRangeResultArray = array(array_keys(reset($dateRangeResultArray))) + $dateRangeResultArray;
        return $dateRangeResultArray;

      }

      public function getKeyStringData() {
        $multipleMonth = $this->request->get('multipleMonth');
        $fromDate = $this->request->get('fromDate');
        $toDate = $this->request->get('toDate');
        $multipleQuarter = $this->request->get('multipleQuarter');
        $managerName = $this->request->get('clientName');
        $recruiterId = $this->request->get('recruiterName');
        $recruiterNameList = $this->getRecruiterNameList($recruiterId);
        if ($multipleMonth != null) {
        $allMonth = explode(",",$multipleMonth);
        foreach ($allMonth as $singleMonth) {
                $diveMonth = explode("/",$singleMonth);
                $newMonth = $diveMonth[1]."/".$diveMonth[0]."/01";
                $startMonthDate = date('Y/m/01', strtotime($newMonth));
                $endMonthDate = date('Y/m/t', strtotime($newMonth));
                $finalDates[] = array("start_date" => $startMonthDate, "end_date" => $endMonthDate, "original_value" => $singleMonth);
            }
        }
        if ($fromDate != null && $toDate != null ) {

            $finalDates[] = array("start_date" => date('Y/m/d', strtotime($fromDate)), "end_date" => date('Y/m/d', strtotime($toDate)), "original_value" => $fromDate.'-'.$toDate );
        }
        if ($multipleQuarter != null) {
          $allQuarter = explode(",",$multipleQuarter);
          foreach ($allQuarter as $key => $singleQuarter) {
                $divideQuarter = explode("/",$singleQuarter);
                if ($divideQuarter[0] == 'Q1') {
                  $startQuarterDate = $divideQuarter[1].'/01/01';
                  $endQuarterDate = $divideQuarter[1].'/03/31';
                }
                if ($divideQuarter[0] == 'Q2') {
                  $startQuarterDate = $divideQuarter[1].'/04/01';
                  $endQuarterDate = $divideQuarter[1].'/06/30';
                }
                if ($divideQuarter[0] == 'Q3') {
                  $startQuarterDate = $divideQuarter[1].'/07/01';
                  $endQuarterDate = $divideQuarter[1].'/09/30';
                }
                if ($divideQuarter[0] == 'Q4') {
                  $startQuarterDate = $divideQuarter[1].'/10/01';
                  $endQuarterDate = $divideQuarter[1].'/12/31';
                }
                $finalDates[] = array("start_date" => $startQuarterDate, "end_date" => $endQuarterDate, "original_value" => $singleQuarter );
            }
        }
        rsort($finalDates);
        $keyStringCount = $this->SaveSearchRepository->findByUserIdAndCreatedAtList($recruiterId,$finalDates);
        $getAllValueWithCount = array();
        $getRecruiterName = array();
        foreach ($keyStringCount as $keyString) { 
                $getUserId = $keyString->getUserId();
                $recruiterName = isset($recruiterNameList[$getUserId]["recruiterName"]) ? $recruiterNameList[$getUserId]["recruiterName"] : '';
                $managerName = isset($recruiterNameList[$getUserId]["managerName"]) ? $recruiterNameList[$getUserId]["managerName"] : '';
                $getResouce = $keyString->getResouce();
                $getKeyString = json_decode($keyString->getkeyString());
                $getTotalCount = $keyString->getTotalCount();
                $createdDate = $keyString->getCreatedAt();
                $date = $createdDate->format('Y-m-d H:i');
                $recordIndex = $this->getMultipleValueSearchRecordIndex($getAllValueWithCount, $recruiterName, $managerName, $getKeyString, $date);
                if ($recordIndex > -1) {
                    $getAllValueWithCount[$recordIndex]["logs"][] = array(
                        "count" => $getTotalCount,
                        "resource" => $getResouce,
                        "date" => $createdDate->format('Y-m-d H:i')
                    );
                } else {
                   $getAllValueWithCount[] = array(
                    "recruiterName" => $recruiterName,
                    "managerName" => $managerName,
                    "keystring" => $getKeyString,
                    "multipleMonth" => $multipleMonth,
                    "multipleQuarter" =>$multipleQuarter,
                    "source" => $getResouce,
                    "keyword" => urldecode($getKeyString->keyword),
                    "date" => $createdDate->format('Y-m-d H:i'),
                    "logs" => array(0 => array(
                        "count" => $getTotalCount,
                        "resource" => $getResouce
                    ))
                ); 
            }
        }
        return $getAllValueWithCount;
    }

    function getMultipleValueSearchRecordIndex($records, $recruiter, $manager, $keystring, $date) {
        $recordIndex = -1;
        foreach ($records as $index => $record) {
            if($recordIndex == -1 && $record['recruiterName'] == $recruiter && $record['managerName'] == $manager && $record['keystring'] == $keystring && $record['date'] == $date) {
                $recordIndex = $index;
            }
        }

        return $recordIndex;
    }

    function getRecruiterNameList($recruiterId) {
        $recruiterId =  implode(',', $recruiterId);
        $getAllRecruiterList = array();
        $query="SELECT u.user_id, CONCAT(u.first_name,' ',u.last_name) AS recruiterName,u.notes AS managerName FROM `user` as u WHERE user_id IN ($recruiterId)";
        $recruiterNameList = $this->catsDB->query($query)->fetchAll();
        foreach ($recruiterNameList as $key => $valueName) {
            $getAllRecruiterList[$valueName['user_id']] = array("recruiterName"=>$valueName['recruiterName'],
            "managerName" => $valueName['managerName']);
        }
        return $getAllRecruiterList;
    }
}

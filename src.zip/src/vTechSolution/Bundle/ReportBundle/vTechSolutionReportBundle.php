<?php

namespace vTechSolution\Bundle\ReportBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class vTechSolutionReportBundle extends Bundle
{
}

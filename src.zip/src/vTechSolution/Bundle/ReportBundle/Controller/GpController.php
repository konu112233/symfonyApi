<?php

namespace vTechSolution\Bundle\ReportBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\JsonResponse;
use Nelmio\ApiDocBundle\Annotation\ApiDoc;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Knp\Bundle\SnappyBundle\Snappy\Response\PdfResponse;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Component\HttpFoundation\Request;
use Knp\Bundle\SnappyBundle\Snappy\Response\JpegResponse;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Translation\TranslatorInterface;


/**
 * @Route("/api/v1/report")
 */

class GpController extends Controller
{
    private $responseArray;
    private $request;
    private $reportService;


    public function initAction()
    {

        $this->responseArray = array();
        $this->request = $this->getRequest();
        $this->reportService = $this->get('v_tech_solution_report.report');


    }

    /**
     * @Route("/get-gp-recruiter", name="vtech_solution_report_gp_recruiter")
     * @Method({"GET"})
     */

    public function gpRecruiterAction()
    {
        $this->initAction();

        $this->responseArray = $this->reportService->getGpDetailHrmRecruiterPersonnelByName();

        return new JsonResponse($this->responseArray);

    }

    /**
     * @Route("/get-gp-bd", name="vtech_solution_report_gp_bd")
     * @Method({"GET"})
     */

    public function gpBdAction()
    {
        $this->initAction();

        $this->responseArray["post_sales"] = $this->reportService->getGpDetailHrmPostSalesTeamPersonnelByName();

        $this->responseArray["sales"] = $this->reportService->getGpDetailHrmSalesTeamPersonnelByName();

        return new JsonResponse($this->responseArray);

    }

    /**
     * @Route("/get-recruiter-placement", name="vtech_solution_report_recruiter_placement")
     * @Method({"GET"})
     */

    public function recruiterPlacementAction()
    {
        $this->initAction();

        $this->responseArray = $this->reportService->getRecruiterPlacement();

        return new JsonResponse($this->responseArray);
        
    }

    /**
     * @Route("/get-sales-personnel-placement", name="vtech_solution_report_sales_personnel_placement")
     * @Method({"GET"})
     */

    public function salesPersonnelPlacementAction()
    {
        $this->initAction();
        
        $this->responseArray["post_sales"] = $this->reportService->getPostSalesPersonnelPlacement();

        $this->responseArray["sales"] = $this->reportService->getSalesPersonnelPlacement();

        return new JsonResponse($this->responseArray);
        
    }

    /**
     * @Route("/keystring-usage-report", name="vtech_solution_report_key_string_usage")
     * @Method({"GET"})
     * @Template("vTechSolutionReportBundle:KeyStringUsage:keystringusage.html.twig")
     */

    public function keyStringUsageAction()
    {
        $this->initAction();

            $this->responseArray['result'] = $this->reportService->keyStringUsageReport();

            return $this->responseArray;

    }

}

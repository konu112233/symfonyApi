<?php

namespace vTechSolution\Bundle\ReportBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\JsonResponse;
use Nelmio\ApiDocBundle\Annotation\ApiDoc;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Knp\Bundle\SnappyBundle\Snappy\Response\PdfResponse;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Component\HttpFoundation\Request;
use Knp\Bundle\SnappyBundle\Snappy\Response\JpegResponse;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Translation\TranslatorInterface;


/**
 * @Route("/api/v1/keystring")
 */

class KeyStringCountController extends Controller
{
	private $responseArray;
    private $request;
    private $reportService;


    public function initAction()
    {

        $this->responseArray = array();
        $this->request = $this->getRequest();
        $this->reportService = $this->get('v_tech_solution_report.report');


    }

    /**
     * @Route("/keystringreport", name="vtech_solution_report_keystringreport")
     * @Method({"GET","POST"})
     * @Template("vTechSolutionReportBundle:KeyStringCount:keystringcount.html.twig")
     */

    public function getKeyStringDataAction() {
        $this->initAction();
        $this->responseArray['resultCount'] = $this->reportService->getKeyStringData();
        return $this->responseArray;
    }
}

<?php
namespace vTechSolution\Bundle\TimeSheetBundle\Manager;
use Symfony\Component\DependencyInjection\ContainerInterface as Container;
use Symfony\Component\HttpFoundation\Request;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\HttpFoundation\Session\Session;
use vTechSolution\Bundle\TimeSheetBundle\Entity\TimesheetActivityLog;

class TimeSheetLevelService 
{
    private $container;
    private $doctrine;
    private $request;
    private $responseArray;
    private $vtechhrmDatabase;
    private $timesheetActivityLogRepository;
    private $vtechtoolDatabase;
    private $emailService;
    const HTTP_METHOD_GET = 'GET';
    const HTTP_METHOD_POST = 'POST';
    public function __construct(Container $container) {
        $this->container = $container;
        $this->request = $this->container->get('request');
        $this->responseArray = array();
        $this->doctrine = $this->container->get('doctrine');
        $this->vtechhrmDatabase = $this->container->get('v_tech_solution_quick_book.vtechhrm')->getPDO();
        $this->vtechtoolDatabase = $this->container->get('v_tech_solution_quick_book.vtech_tools')->getPDO();
        $this->emailService = $this->container->get('v_tech_solution_email.email');
        $this->timesheetActivityLogRepository = $this->doctrine->getRepository('vTechSolutionTimeSheetBundle:TimesheetActivityLog');
    }
    public function __destructor() {
        unset($this->container);
        unset($this->request);
        unset($this->responseArray);
        unset($this->timesheetActivityLogRepository);
        unset($this->emailService);
    }
    public function addUpdateLeave() {
        $employeeId = $this->request->get('employee');
        $slHour = $this->request->get('slHours');
        $vlHour = $this->request->get('vlHours');
        $datestart = $this->request->get('datestart');
        $slHours = $this->decimaltotime($slHour);
        $vlHours = $this->decimaltotime($vlHour);

        $query = "SELECT details FROM employeetimeentry WHERE employee = '$employeeId' AND DATE_FORMAT(date_start, '%Y-%m-%d') = '$datestart'";
        $timeDetails = $this->vtechhrmDatabase->query($query)->fetchColumn();
        $sl = 'slHours';
        $replaceSl = strpos($timeDetails, $sl);
        if(!empty($replaceSl)){
            $slHoursArray = explode(",slHours", $timeDetails);
            $timeDetails = $slHoursArray[0];
        }
        if($timeDetails != null || $timeDetails != ''){
            $updateEmpQuery = "UPDATE employeetimeentry SET details='$timeDetails ,slHours : ".$slHours." ,vlHours : ".$vlHours."' WHERE employee = '$employeeId' AND DATE_FORMAT(date_start, '%Y-%m-%d') = '$datestart'";
            $empTimesheet = $this->vtechhrmDatabase->query($updateEmpQuery)->execute(); 
        }
    }

    function decimaltotime($time){
        $hours = floor((int)$time % 60);
        $minutes = $time - (int)$time; 
        $minutes = round($minutes * 60); 
 
        return str_pad($hours, 2, "0", STR_PAD_LEFT) . ":" . str_pad($minutes, 2, "0", STR_PAD_LEFT);
    }

    public function deleteLeave() {
        $employeeId = $this->request->get('employee');
        $slHours = $this->request->get('slHours');
        $vlHours = $this->request->get('vlHours');
        $dateSelect = $this->request->get('date');

        $query = "SELECT details FROM employeetimeentry WHERE employee = '$employeeId' AND DATE_FORMAT(date_start, '%Y-%m-%d') = '$dateSelect'";
        $timeDetails = $this->vtechhrmDatabase->query($query)->fetchColumn();
        $sl = 'slHours';
        $replaceSl = strpos($timeDetails, $sl);
        if(!empty($replaceSl)){
            $slHoursArray = explode(",slHours", $timeDetails);
            $timeDetails = $slHoursArray[0];            
            $leaves = ",slHours : 00:00 ,vlHours : 00:00";
            $timeEntrywithLeave = $timeDetails.''.$leaves;
            $updateEmpQuery = "UPDATE employeetimeentry SET details='$timeEntrywithLeave' WHERE employee = '$employeeId' AND DATE_FORMAT(date_start, '%Y-%m-%d') = '$dateSelect'";
            $empTimesheet = $this->vtechhrmDatabase->query($updateEmpQuery)->execute();
        }
    }
    public function getTimeSheetDetails() {
        $level = $this->request->get('id');
        $userId = $this->request->get('userid');
        $employeeId = $this->request->get('employee');
        $comments = $this->request->get('comment');
        $weeklyTotal = $this->request->get('weeklyTotal');
        $dateStart = $this->request->get('datestart');
        $status = $this->request->get('status');
        $dateEnd = $this->request->get('dateend');
        $projectId = $this->request->get('projectId');
        $dateStart = sprintf("%02d", $dateStart);
        $dateEnd = sprintf("%02d", $dateEnd);
        $monthAndYear = $this->request->get('monthYear');
        $explodeByHypen = explode("-", $monthAndYear);
        //print_r($str_arr);
        $year = $explodeByHypen['0'];
        $month = $explodeByHypen['1'];
        $dateStart = $year . "-" . $month . "-" . $dateStart;
        $dateEnd = $year . "-" . $month . "-" . $dateEnd;
        $date = new \DateTime();
        $currentDateAndTime = date_format($date, 'Y-m-d H:i:s');
        $timeDetailsArray = $this->request->get('timedetail');
        if ($level == 1) {
         $this->updateTimeSheetDetails($timeDetailsArray, $dateStart, $dateEnd, $employeeId,$projectId); 
        }
        $result = $this->timesheetActivityLogRepository->findByEmployeeIdAndDate($employeeId, $dateStart, $level);
        if (count($result) > 0) {
            if ($status == '#ff531a' AND $level == 3) {
                $query = "UPDATE timesheet_activity_log SET status='0' , color = '$status' , updated_at = '$currentDateAndTime'  WHERE start_date= '$dateStart' AND end_date= '$dateEnd' AND candidateId = $employeeId";
                $execute = $this->vtechtoolDatabase->query($query)->execute();
                $query = "SELECT first_name,middle_name,last_name from employees WHERE id = " . $employeeId . "";
                $getEmployeesDetails = $this->vtechhrmDatabase->query($query)->fetchAll();
                foreach ($getEmployeesDetails as $key => $value) {
                    $getDetailsFirstName[] = $value['first_name'];
                    $getDetailsLastName[] = $value['last_name'];
                }
                $name = $getDetailsFirstName[0] . ' ' . $getDetailsLastName[0];
                $query = "SELECT username FROM `users` WHERE id = '$userId'";
                $getAccessName = $this->vtechhrmDatabase->query($query)->fetchColumn(0);
                $param[] = array("name" => $name, "rejection_issue" => $comments, "yearofemployee" => $year, "weeklyTotal" => $weeklyTotal, "weekStartDate" => $dateStart, "weekEndDate" => $dateEnd, "admin" => $getAccessName);
                $this->emailService->sendEmailTemplate('timesheet_level_3', null, null, null, null, null, null, $param);
            } elseif ($status == '#ff531a' AND $level == 2) {
                $query = "UPDATE timesheet_activity_log SET status='0' , color = '$status' , updated_at = '$currentDateAndTime'  WHERE start_date= '$dateStart' AND end_date= '$dateEnd' AND candidateId = $employeeId";
                $execute = $this->vtechtoolDatabase->query($query)->execute();
                $query = "SELECT first_name,middle_name,last_name from employees WHERE id = " . $employeeId . "";
                $getEmployeesDetails = $this->vtechhrmDatabase->query($query)->fetchAll();
                foreach ($getEmployeesDetails as $key => $value) {
                    $getDetailsFirstName[] = $value['first_name'];
                    $getDetailsLastName[] = $value['last_name'];
                }
                $name = $getDetailsFirstName[0] . ' ' . $getDetailsLastName[0];
                $query = "SELECT username FROM `users` WHERE id = '$userId'";
                $getAccessName = $this->vtechhrmDatabase->query($query)->fetchColumn(0);
                $param[] = array("name" => $name, "rejection_issue" => $comments, "yearofemployee" => $year, "weeklyTotal" => $weeklyTotal, "weekStartDate" => $dateStart, "weekEndDate" => $dateEnd, "admin" => $getAccessName);
                $this->emailService->sendEmailTemplate('timesheet_level_3', null, null, null, null, null, null, $param);
            } else {
                $query = "SELECT comments from timesheet_activity_log  WHERE start_date= '$dateStart' AND end_date= '$dateEnd' AND candidateId = $employeeId AND level = $level";
                $execute = $this->vtechtoolDatabase->query($query)->fetchColumn(0);
                //echo $execute;
                $combineStatue = $comments . ' ->' . $execute;
                $result->setStatus($level);
                $result->setColor($status);
                $result->setComments($combineStatue);
                $result->setUpdatedAt(new \DateTime('now'));
                $this->timesheetActivityLogRepository->commit($result);
            }
        } else {
            if ($status == '#ff531a') {
                if ($level == 3) {
                    $query = "UPDATE timesheet_activity_log SET status='0' , color = '$status' , updated_at = '$currentDateAndTime'  WHERE start_date= '$dateStart' AND end_date= '$dateEnd' AND candidateId = $employeeId";
                    $execute = $this->vtechtoolDatabase->query($query)->execute();
                    $query = "SELECT first_name,middle_name,last_name from employees WHERE id = " . $employeeId . "";
                    $getEmployeesDetails = $this->vtechhrmDatabase->query($query)->fetchAll();
                    foreach ($getEmployeesDetails as $key => $value) {
                        $getDetailsFirstName[] = $value['first_name'];
                        $getDetailsLastName[] = $value['last_name'];
                    }
                    $name = $getDetailsFirstName[0] . ' ' . $getDetailsLastName[0];
                    $query = "SELECT username FROM `users` WHERE id = '$userId'";
                    $getAccessName = $this->vtechhrmDatabase->query($query)->fetchColumn(0);
                    $param[] = array("name" => $name, "rejection_issue" => $comments, "yearofemployee" => $year, "weeklyTotal" => $weeklyTotal, "weekStartDate" => $dateStart, "weekEndDate" => $dateEnd, "admin" => $getAccessName);
                    $this->emailService->sendEmailTemplate('timesheet_level_3', null, null, null, null, null, null, $param);
                    $query = "SELECT c_company_id as clientid from vtech_mappingdb.system_integration as si WHERE si.h_employee_id = " . $employeeId . " LIMIT 1";
                    $getClientId = $this->vtechhrmDatabase->query($query)->fetchAll();
                    foreach ($getClientId as $key => $value) {
                        $logInsert = new TimesheetActivityLog();
                        $logInsert->setCandidateId($employeeId);
                        $logInsert->setUserId($userId);
                        $logInsert->setTimesheetId(null);
                        $logInsert->setClientId($value['clientid']);
                        $logInsert->setStartDate($dateStart);
                        $logInsert->setEndDate($dateEnd);
                        $logInsert->setLevel($level);
                        $logInsert->setStatus('0');
                        $logInsert->setComments($comments);
                        $logInsert->setColor($status);
                        $logInsert->setCreatedAt(new \DateTime('now'));
                        $logInsert->setUpdatedAt(new \DateTime('now'));
                        $this->timesheetActivityLogRepository->commit($logInsert);
                    }
                }
                if ($level == 2) {
                    $query = "UPDATE timesheet_activity_log SET status='0' , color = '$status' WHERE start_date= '$dateStart' AND end_date= '$dateEnd' AND candidateId = $employeeId";
                    $execute = $this->vtechtoolDatabase->query($query)->execute();
                    $query = "SELECT first_name,middle_name,last_name from employees WHERE id = " . $employeeId . "";
                    $getEmployeesDetails = $this->vtechhrmDatabase->query($query)->fetchAll();
                    foreach ($getEmployeesDetails as $key => $value) {
                        $getDetailsFirstName[] = $value['first_name'];
                        $getDetailsLastName[] = $value['last_name'];
                    }
                    $name = $getDetailsFirstName[0] . ' ' . $getDetailsLastName[0];
                    $query = "SELECT username FROM `users` WHERE id = '$userId'";
                    $getAccessName = $this->vtechhrmDatabase->query($query)->fetchColumn(0);
                    $param[] = array("name" => $name, "rejection_issue" => $comments, "yearofemployee" => $year, "weeklyTotal" => $weeklyTotal, "weekStartDate" => $dateStart, "weekEndDate" => $dateEnd, "admin" => $getAccessName);
                    $this->emailService->sendEmailTemplate('timesheet_level_3', null, null, null, null, null, null, $param);
                    $query = "SELECT c_company_id as clientid from vtech_mappingdb.system_integration as si WHERE si.h_employee_id = " . $employeeId . " LIMIT 1";
                    $getClientId = $this->vtechhrmDatabase->query($query)->fetchAll();
                    foreach ($getClientId as $key => $value) {
                        $logInsert = new TimesheetActivityLog();
                        $logInsert->setCandidateId($employeeId);
                        $logInsert->setUserId($userId);
                        $logInsert->setTimesheetId(null);
                        $logInsert->setClientId($value['clientid']);
                        $logInsert->setStartDate($dateStart);
                        $logInsert->setEndDate($dateEnd);
                        $logInsert->setLevel($level);
                        $logInsert->setStatus('0');
                        $logInsert->setComments($comments);
                        $logInsert->setColor($status);
                        $logInsert->setCreatedAt(new \DateTime('now'));
                        $logInsert->setUpdatedAt(new \DateTime('now'));
                        $this->timesheetActivityLogRepository->commit($logInsert);
                    }
                }
            } else {
                $query = "SELECT c_company_id as clientid from vtech_mappingdb.system_integration as si WHERE si.h_employee_id = " . $employeeId . " LIMIT 1";
                $getClientId = $this->vtechhrmDatabase->query($query)->fetchAll();
                foreach ($getClientId as $key => $value) {
                    $logInsert = new TimesheetActivityLog();
                    $logInsert->setCandidateId($employeeId);
                    $logInsert->setUserId($userId);
                    $logInsert->setTimesheetId(null);
                    $logInsert->setClientId($value['clientid']);
                    $logInsert->setStartDate($dateStart);
                    $logInsert->setEndDate($dateEnd);
                    $logInsert->setLevel($level);
                    $logInsert->setStatus($level);
                    $logInsert->setComments($comments);
                    $logInsert->setColor($status);
                    $logInsert->setCreatedAt(new \DateTime('now'));
                    $logInsert->setUpdatedAt(new \DateTime('now'));
                    $this->timesheetActivityLogRepository->commit($logInsert);
                }
            }
        }
    }
    public function getTableDeatails($startDate,$endDate) {
        /*$query = "SELECT
        tal.*
        FROM
        vtech_tools.timesheet_activity_log AS tal
        WHERE
        tal.id IN(SELECT
            MAX(talx.id)
        FROM
            vtech_tools.timesheet_activity_log AS talx
        GROUP BY talx.start_date,talx.candidateId)
        GROUP BY tal.start_date,tal.candidateId";*/
        $query = "SELECT * FROM timesheet_activity_log WHERE start_date BETWEEN '$startDate' AND '$endDate' ORDER BY updated_at DESC";
        $getUsersDetails = $this->vtechtoolDatabase->query($query)->fetchAll();
        return $getUsersDetails;
    }
    public function getdetailsInASC($startDate,$endDate) {
        $query = "SELECT * FROM timesheet_activity_log WHERE start_date BETWEEN '$startDate' AND '$endDate' ORDER BY id ASC";
        $getAscDetails = $this->vtechtoolDatabase->query($query)->fetchAll();
        return $getAscDetails;
    }
    public function getColor($startDate,$endDate) {
        /*$query = "SELECT
        tal.*
        FROM
        vtech_tools.timesheet_activity_log AS tal
        WHERE
        tal.id IN(SELECT
            MAX(talx.id)
        FROM
            vtech_tools.timesheet_activity_log AS talx
        GROUP BY talx.start_date,talx.candidateId)
        GROUP BY tal.start_date,tal.candidateId";*/
        $query = "SELECT * FROM `timesheet_activity_log` WHERE updated_at IN (SELECT max(updated_at) FROM timesheet_activity_log WHERE start_date BETWEEN '$startDate' AND '$endDate' GROUP BY end_date,candidateId) GROUP BY end_date,candidateId";
        $getColorDetails = $this->vtechtoolDatabase->query($query)->fetchAll();
        return $getColorDetails;
    }
    public function getClientList() {
        $query = "SELECT comp.company_id AS id, 
           comp.NAME       AS cname 
    FROM   employees AS e 
           JOIN vtech_mappingdb.system_integration AS mp 
             ON e.id = mp.h_employee_id 
           JOIN cats.company AS comp 
             ON comp.company_id = mp.c_company_id 
    WHERE  e.status != 'Internal Employee' 
           AND e.status != 'OnBoarding' 
           AND e.status != 'External Client manager' 
           AND comp.company_id != '2' 
    GROUP  BY comp.company_id 
    ORDER  BY cname ASC ";
        $getClientList = $this->vtechhrmDatabase->query($query)->fetchAll();
        return $getClientList;
    }
    public function updateTimeSheetDetails($timeDetailsArray, $dateStart, $dateEnd, $employeeId,$projectId) {
        if (!empty($timeDetailsArray)) {
        $currentDate = date("Y-m-d h:i:s");
        $query = "SELECT ets.id FROM `employeetimesheets` as ets WHERE ets.date_end = '$dateEnd' AND ets.employee = '$employeeId'";
        $getTimeSheetId = $this->vtechhrmDatabase->query($query)->fetchColumn(0);
        $query = "SELECT * FROM `employeetimeentry`  WHERE timesheet = '$getTimeSheetId'";
        $countRows = $this->vtechhrmDatabase->query($query)->rowCount();
        foreach ($timeDetailsArray as $key => $value) {
            $valueDate = $value['date'];
             $query = "SELECT time_start,date_start,details FROM employeetimeentry WHERE timesheet = '$getTimeSheetId' AND DATE_FORMAT(date_start, '%Y-%m-%d') = '$valueDate'";
            $getTheTimeStart = $this->vtechhrmDatabase->query($query)->fetchAll();
            if (empty($getTheTimeStart)) {
                $dateStart = $value['date'] . ' ' . "09:00:00";
                $hours = $value['hours'];
                $overHours = $value['overtime'];
                if ($hours == 0) {
                    $hours = 0;
                }
                if ($overHours == 0) {
                    $overHours = 0;
                }
                $dummyHours = "00:00:00";
                $timeStart = "09:00:00";
                $regularHours = "08:00:00";
                $timestamp = strtotime($timeStart) + $hours * 60 * 60;
                $timeEnd = date('H:i:s', $timestamp);
                $timestampOver = strtotime($dummyHours) + $overHours * 60 * 60;
                $overTimeHours = date('H:i:s', $timestampOver);
                $dateEnd = $value['date'] . ' ' . $timeEnd;
                $timestampEnd = strtotime($timeEnd) - strtotime($timeStart);
                $hours = floor($timestampEnd / 3600);
                $mins = floor($timestampEnd / 60 % 60);
                $secs = floor($timestampEnd % 60);
                $totalHours = sprintf('%02d:%02d:%02d', $hours, $mins, $secs);

                $newTotal = strtotime($overTimeHours)-strtotime("00:00:00");
                $totalHours = date("H:i:s",strtotime($totalHours)+$newTotal);

                $completeArrayOfTimeSheet[] = array("dateStart" => $dateStart,
                "hours" => $hours,
                "overHours"=>$overHours,
                "dummyHours" => $dummyHours,
                "timeStart" => $timeStart,
                "regularHours" => $regularHours,
                "timeEnd" => $timeEnd,
                "overTimeHours" => $overTimeHours,
                "dateEnd" => $dateEnd,
                "totalHours" => $totalHours
            );
            } else {
                foreach ($getTheTimeStart as $key => $timesheet) {

                $dateStart = $timesheet['date_start'];
                $getDate = explode(' ', $dateStart);
                $totalHoursDate = $timesheet['details'];
                $break =  explode(',', $totalHoursDate);
                $break = explode(':',$break[3]);
                $breakHourstotal = sprintf('%02d:%02d:%02d', $break[1], $break[2],$break[3]);
                $getDate = $getDate[0];
                $getHours = $value['hours'];
                $overHours = $value['overtime'];
                if ($getHours == 0) {
                    $getHours = 0;
                }
                if ($overHours == 0) {
                    $overHours = 0;
                }
                $dummyHours = "00:00:00";
                $timeStart = $timesheet['time_start'];
                $regularHours = "08:00:00";
                $timestamp = strtotime($timeStart) + $getHours * 60 * 60;
                $timeEnd = date('H:i:s', $timestamp);
                $timestampOver = strtotime($dummyHours) + $overHours * 60 * 60;
                $overTimeHours = date('H:i:s', $timestampOver);
                $dateEnd = $value['date'] . ' ' . $timeEnd;
                $timestampEnd = strtotime($timeEnd) - strtotime($timeStart);
                $hours = floor($timestampEnd / 3600);
                $mins = floor($timestampEnd / 60 % 60);
                $secs = floor($timestampEnd % 60);
                $totalHoursExcludebreak = sprintf('%02d:%02d:%02d', $hours, $mins, $secs);
                $totalHoursstamp = strtotime($totalHoursExcludebreak) - strtotime($breakHourstotal);
                $hours = floor($totalHoursstamp / 3600);
                $mins = floor($totalHoursstamp / 60 % 60);
                $secs = floor($totalHoursstamp % 60);
                $totalHours = sprintf('%02d:%02d:%02d', $hours, $mins, $secs);
                $newTotal = strtotime($overTimeHours)-strtotime("00:00:00");
                $totalHours = date("H:i:s",strtotime($totalHours)+$newTotal);
                $timeDetails = "RegularHours : ".$regularHours." , OvertimeHours : ".$overTimeHours." , TotalHours : ".$totalHours." , BreakHours : ".$breakHourstotal." ,details : -------";
                $sl = 'slHours';
                $replaceSl = strpos($totalHoursDate, $sl);
                if(!empty($replaceSl)){
                    $slHoursArray = explode(",slHours", $totalHoursDate);
                    $timeDetails = "RegularHours : ".$regularHours." , OvertimeHours : ".$overTimeHours." , TotalHours : ".$totalHours." , BreakHours : ".$breakHourstotal." ,details : ------- ,slHours ".$slHoursArray[1]."";
                }
                $completeArrayOfTimeSheet[] = array("dateStart" => $dateStart,
                    "hours" => $getHours,
                    "overHours"=>$overHours,
                    "dummyHours" => $dummyHours,
                    "timeStart" => $timeStart,
                    "regularHours" => $regularHours,
                    "timeEnd" => $timeEnd,
                    "overTimeHours" => $overTimeHours,
                    "dateEnd" => $dateEnd,
                    "totalHours" => $totalHours,
                    "getDate" => $getDate,
                    "breakHourstotal" => $breakHourstotal,
                    "detail" => $timeDetails
            );
                }
            } }
        if ($countRows<=0) {
        foreach ($completeArrayOfTimeSheet as $key => $value) {
            $queryOfEmployeeTimeEntryOfInsert = "INSERT INTO `employeetimeentry`(id, project, employee, timesheet, details, created, date_start, time_start, date_end, time_end, status) VALUES ('', $projectId, $employeeId, $getTimeSheetId,'RegularHours : ".$value['regularHours']." , OvertimeHours : ".$value['overTimeHours']." , TotalHours : ".$value['totalHours']." , BreakHours : 00:00:00 , details : -------','$currentDate', '".$value['dateStart']."','".$value['timeStart']."', '".$value['dateEnd']."', '".$value['timeEnd']."','Active')";

             $queryOfVtechTimeSheetOfInsert="INSERT INTO `vtech_timesheet`(id, project, employee, timesheet, details, created, date_start, time_start, date_end, time_end, status,overtime,totalhours) VALUES ('', $projectId, $employeeId, $getTimeSheetId , 'overTime:".$value['overTimeHours'].",TotalHours:".$value['totalHours']."','$currentDate', '".$value['dateStart']."','".$value['timeStart']."', '".$value['dateEnd']."', '".$value['timeEnd']."', 'Active','".$value['overHours']."','".$value['hours']."')";

             

                $executeOfTimeEntry = $this->vtechhrmDatabase->exec($queryOfEmployeeTimeEntryOfInsert);
                $executeOfvtechTimeSheet = $this->vtechhrmDatabase->exec($queryOfVtechTimeSheetOfInsert);
                
            } 
                $queryOfEmployeeTimeSheetUpadte ="UPDATE employeetimesheets SET status='Approved' WHERE id=$getTimeSheetId AND employee=$employeeId";
                $executeOfEmployeeTimeSheetUpadte = $this->vtechhrmDatabase->query($queryOfEmployeeTimeSheetUpadte)->execute();
                } else {
                foreach ($completeArrayOfTimeSheet as $key => $value) {
                $queryOfEmployeeTimeEntry = "UPDATE `employeetimeentry` SET details='".$value['detail']."', time_start='".$value['timeStart']."', date_end='".$value['dateEnd']."',time_end = '".$value['timeEnd']."' WHERE timesheet = '$getTimeSheetId' AND DATE_FORMAT(date_start, '%Y-%m-%d') ='".$value['getDate']."' AND employee = '$employeeId'";
                $this->responseArray = $this->vtechhrmDatabase->query($queryOfEmployeeTimeEntry)->execute();
                $queryOfVtechTimeSheet = "UPDATE `vtech_timesheet` SET overtime='".$value['overHours']."',details='overtime:".$value['overTimeHours'].",TotalHours:".$value['totalHours']."', time_start='".$value['timeStart']."',date_end='".$value['dateEnd']."',time_end='".$value['timeEnd']."',totalhours='".$value['hours']."'WHERE timesheet = '$getTimeSheetId' AND DATE_FORMAT(date_start, '%Y-%m-%d') ='".$value['getDate']."' AND employee = '$employeeId'";
                
                $this->responseArray = $this->vtechhrmDatabase->query($queryOfVtechTimeSheet)->execute();
            }
                $queryOfEmployeeTimeSheetUpadte ="UPDATE employeetimesheets SET status='Approved' WHERE id=$getTimeSheetId AND employee=$employeeId";
                $executeOfEmployeeTimeSheetUpadte = $this->vtechhrmDatabase->query($queryOfEmployeeTimeSheetUpadte)->execute();
        }
    }
        unset($queryOfVtechTimeSheet);
        unset($queryOfEmployeeTimeEntry);
        unset($queryOfVtechTimeSheetOfInsert);
        unset($queryOfEmployeeTimeEntryOfInsert);
        unset($getTimeSheetId);
        unset($timeDetailsArray);
        return $this->responseArray;
    }

    public function getAllDetailsFromActivity() {
        $getMonth = json_decode($this->request->get('getMonth'));
        $getYear = json_decode($this->request->get('getyear'));
        $getMonthWithZero = sprintf("%02d", $getMonth);
        $queryDate = $getYear."-".$getMonth."-01";
        $startDate =  date('Y-m-01', strtotime($queryDate));
        $endDate =  date('Y-m-t', strtotime($queryDate));
        $getdetailsInASC = $this->getdetailsInASC($startDate,$endDate);
        $getTableDeatails = $this->getTableDeatails($startDate,$endDate);
        $getColor = $this->getColor($startDate,$endDate);
        $getClientList = $this->getClientList();
        $this->responseArray = array("getdetailsInASC" => $getdetailsInASC,
                "getdetailsInASC" => $getdetailsInASC,
                "getTableDeatails" => $getTableDeatails,
                "getColor" => $getColor,
                "getClientList" => $getClientList
        );

        unset($getMonth);
        unset($getYear);
        unset($getMonthWithZero);
        unset($queryDate);
        unset($startDate);
        unset($endDate);
        unset($getdetailsInASC);
        unset($getTableDeatails);
        unset($getColor);
        unset($getClientList);
        return $this->responseArray;
    }
}

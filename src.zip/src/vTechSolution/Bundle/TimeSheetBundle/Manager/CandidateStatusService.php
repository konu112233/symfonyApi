<?php

namespace vTechSolution\Bundle\TimeSheetBundle\Manager;
use Symfony\Component\DependencyInjection\ContainerInterface as Container;
use Symfony\Component\HttpFoundation\Request;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\HttpFoundation\Session\Session;
class CandidateStatusService
{
    private $container;
    private $doctrine;
    private $request;
    private $responseArray;
    private $catsDatabase;
    private $contractDatabase;
    private $emailService;
    private $urlshortner;
    const HTTP_METHOD_GET = 'GET';
    const HTTP_METHOD_POST = 'POST';


    public function __construct(Container $container)
        {
        $this->container = $container;
        $this->request = $this->container->get('request');
        $this->responseArray = array();
        $this->doctrine = $this->container->get('doctrine');
        $this->emailService = $this->container->get('v_tech_solution_email.email');
        $this->twilioService = $this->container->get('v_tech_solution_twilio.twilio');
        }


    public function __destructor()
        {
        unset($this->container);
        unset($this->request);
        unset($this->responseArray);
        }


    public function ChangeStatusProcess()
        {

        $fromNumber = $this->container->getParameter('fromNumber');
        $this->catsDatabase = $this->container->get('v_tech_solution_quick_book.catsdb')->getPDO();
        $this->contractDatabase = $this->container->get('v_tech_solution_quick_book.contract')->getPDO();

        $this->urlshortner = $this->container->get('v_tech_solution_quick_book.urlshortner')->getPDO();

        $status = $this->request->get('status');

        $candidateId = json_decode($this->request->get('candidateID'));
        $joborderId = json_decode($this->request->get('jobOrderID'));

         $validationData = array("candidate_id" => $candidateId, "joborder_id" => $joborderId);

        $submittedDate = json_decode($this->request->get('submittedDate'));
        $query = "SELECT c.company_id as companyId from company as c
                    LEFT JOIN joborder as jo ON
                        c.company_id = jo.company_id
                            WHERE jo.joborder_id = '".$joborderId."'";
        $getCompanyid = $this->catsDatabase->query($query)->fetchAll();
        foreach($getCompanyid as $key => $companyId)
            {
            $query = "SELECT e.data_item_id as dataItemId,o.c_client_type as ctype from cats.contract_mapping as e left join contract.opportunity as o on e.value_map = o.c_solicitation_number where e.field_name in ('Contract No','Contact') AND e.data_item_id =" . $companyId['companyId'] . "";
            $getClientType = $this->contractDatabase->query($query)->fetchAll();



            if (empty($getClientType)) {

                $query = "SELECT c.candidate_id as cid,CONCAT(u.first_name, ' ',u.last_name) as recName,u.phone_work as recphone,u.phone_extension as ext,c.email1 as email,u.email as recemail,u.notes as manager,cc.name as companyName,jo.title as JobTitle,c.first_name,CONCAT(c.first_name, ' ', c.last_name) AS ename,CONCAT(jo.city, ' ', jo.state) as location,jo.client_job_id as companyid,c.first_name AS first_name,c.phone_home AS homePhone, c.phone_work AS workPhone  FROM candidate_joborder as cj

                              LEFT JOIN joborder as jo on jo.joborder_id = cj.joborder_id
                              LEFT JOIN user AS u ON u.user_id = cj.added_by
                              LEFT JOIN candidate as c on c.candidate_id = cj.candidate_id
                              LEFT JOIN cats_client as cc on cc.company_id = jo.company_id


                             WHERE cj.joborder_id = '" . $joborderId . "' AND cj.candidate_id = '" . $candidateId . "' LIMIT 1";
                    $getDetails = $this->catsDatabase->query($query)->fetchAll();
                        foreach($getDetails as $index => $singleDetails)
                            {
                            if ($singleDetails['ext'] == true)
                                {
                                $recPhone = $singleDetails['recphone'] . 'Ext.' . $singleDetails['ext'];
                                }
                              else
                                {
                                $recPhone = $singleDetails['recphone'];
                                }
                                $companyNameSplit = $singleDetails['companyName'];
                                $resultCompany = explode('_', $companyNameSplit);

                                $copyLink="http://jobs.vtechsolution.com/a.php?i=".$joborderId."&title=".$singleDetails['JobTitle']."&rec_email=".$singleDetails['recemail']."";

                                $jobUrl="SELECT * from short_url where url='$copyLink'";

                                $getShortUrl = $this->urlshortner->query($jobUrl)->fetchColumn(3);

                                $identity = time();

                                if (empty($getShortUrl)) {

                                $identity = time();
                                $shorturl=base_convert($identity,10,36);
                                $query = "INSERT INTO short_url (id,url,shortened) values('$identity','$copyLink','$shorturl')";
                                $insertUrl = $this->urlshortner->query($query)->execute();
                                 $refUrl = "http://jobs.vtechsolution.com/a.php?i=".$shorturl;

                                }
                                else {

                                    $refUrl = "http://jobs.vtechsolution.com/a.php?i=".$getShortUrl;

                                }



                            $data[] = array(
                                "job_title" => $singleDetails['JobTitle'],
                                "client_name" => $resultCompany[0],
                                "recruiter_name" => $singleDetails['recName'],
                                "recruiter_email" => $singleDetails['recemail'],
                                "rec_phone" => $recPhone,
                                "short_url" => $refUrl
                            );

                            $messageDetails[] = array(
                                    "first_name" => $singleDetails['first_name'],
                                    "job_title" => $singleDetails['JobTitle'],
                                    "client_name" => $resultCompany[0],
                                    "job_id" => $singleDetails['companyid']
                                );
                            $candidatePhoneNumber[] = $singleDetails['homePhone'];


                            $to = array(
                                $singleDetails['email']
                            );
                            
                            $from = $singleDetails['recemail'];
                            $subject = "Submitted: ".$resultCompany[0]." - " . $singleDetails['JobTitle'] . " (" . $singleDetails['companyid'] . ") – " . $singleDetails['location'] . "";
                            $dueDate = $submittedDate;
                            $emailSendAfterFiveDays = date('Y-m-d', strtotime($dueDate . ' +2 Weekday'));
                            $emailSendAfterTenDays = date('Y-m-d', strtotime($dueDate . ' +5 Weekday'));
                            $emailSendAfterTwentyDays = date('Y-m-d', strtotime($dueDate . ' +7 Weekday'));


                            }

                        $submittedType = array(
                            "submitted",
                            "submitted_after_five_days",
                            "submitted_after_ten_days",
                            "submitted_after_twenty_days"
                        );
                        $scheduleArray = array(
                            date('Y-m-d') ,
                            $emailSendAfterFiveDays,
                            $emailSendAfterTenDays,
                            $emailSendAfterTwentyDays
                        );



                        foreach($submittedType as $key => $singleRow)
                            {
                              if ($to != '') {
                              $this->emailService->sendEmailTemplate($singleRow, $from, $to, null, null, $subject, null, $data,$validationData, $scheduleArray[$key]); 
                              }
                            }  
                            if ($candidatePhoneNumber != '') {
                              $this->twilioService->sendSmsSubmitted("sms_reminder_submitted", $candidatePhoneNumber,$fromNumber,$messageDetails); 
                            }
                     }

                else

                {
                    foreach($getClientType as $key => $clientType)
                {
                if ($clientType['ctype'] == 'Government')
                    {
                    $query = "SELECT c.candidate_id as cid,CONCAT(u.first_name, ' ',u.last_name) as recName,u.phone_work as recphone,u.phone_extension as ext,c.email1 as email,u.email as recemail,u.notes as manager,cc.name as companyName,jo.title as JobTitle,c.first_name,CONCAT(c.first_name, ' ', c.last_name) AS ename,ef.value_map as value,CONCAT(jo.city, ' ', jo.state) as location,jo.client_job_id as companyid,cc.company_id as clientId,c.first_name AS first_name,c.phone_home AS homePhone, c.phone_work AS workPhone FROM candidate_joborder as cj LEFT JOIN joborder as jo on jo.joborder_id = cj.joborder_id LEFT JOIN user AS u ON u.user_id = cj.added_by LEFT JOIN candidate as c on c.candidate_id = cj.candidate_id LEFT JOIN company as cc on cc.company_id = jo.company_id LEFT JOIN contract_mapping as ef on ef.data_item_id = cj.joborder_id WHERE cj.joborder_id = '" . $joborderId . "' AND cj.candidate_id = '" . $candidateId . "' AND ef.field_name = 'Due Date' LIMIT 1";
                    $getDetails = $this->catsDatabase->query($query)->fetchAll();
                    if (empty($getDetails))
                        {
                        $query = "SELECT c.candidate_id as cid,CONCAT(u.first_name, ' ',u.last_name) as recName,u.phone_work as recphone,u.phone_extension as ext,c.email1 as email,u.email as recemail,u.notes as manager,cc.name as companyName,jo.title as JobTitle,c.first_name,CONCAT(c.first_name, ' ', c.last_name) AS ename,CONCAT(jo.city, '', jo.state) as location,jo.client_job_id as companyid,c.first_name AS first_name,c.phone_home AS homePhone, c.phone_work AS workPhone  FROM candidate_joborder as cj

                              LEFT JOIN joborder as jo on jo.joborder_id = cj.joborder_id
                              LEFT JOIN user AS u ON u.user_id = cj.added_by
                              LEFT JOIN candidate as c on c.candidate_id = cj.candidate_id
                              LEFT JOIN cats_client as cc on cc.company_id = jo.company_id


                             WHERE cj.joborder_id = '" . $joborderId . "' AND cj.candidate_id = '" . $candidateId . "' LIMIT 1";
                        $getStatusDetails = $this->catsDatabase->query($query)->fetchAll();
                        foreach($getStatusDetails as $index => $singleDetails)
                            {
                            if ($singleDetails['ext'] == true)
                                {
                                $recPhone = $singleDetails['recphone'] . 'Ext.' . $singleDetails['ext'];
                                }
                              else
                                {
                                $recPhone = $singleDetails['recphone'];
                                }
                                $companyNameSplit = $singleDetails['companyName'];
                                $resultCompany = explode('_', $companyNameSplit);

                                $copyLink="http://jobs.vtechsolution.com/a.php?i=".$joborderId."&title=".$singleDetails['JobTitle']."&rec_email=".$singleDetails['recemail']."";

                                $jobUrl="SELECT * from short_url where url='$copyLink'";

                                $getShortUrl = $this->urlshortner->query($jobUrl)->fetchColumn(3);

                                $identity = time();

                                if (empty($getShortUrl)) {

                                $identity = time();
                                $shorturl=base_convert($identity,10,36);
                                $query = "INSERT INTO short_url (id,url,shortened) values('$identity','$copyLink','$shorturl')";
                                $insertUrl = $this->urlshortner->query($query)->execute();
                                 $refUrl = "http://jobs.vtechsolution.com/a.php?i=".$shorturl;

                                }
                                else {

                                    $refUrl = "http://jobs.vtechsolution.com/a.php?i=".$getShortUrl;

                                }

                            $data[] = array(
                                "job_title" => $singleDetails['JobTitle'],
                                "client_name" => $resultCompany[0],
                                "recruiter_name" => $singleDetails['recName'],
                                "recruiter_email" => $singleDetails['recemail'],
                                "rec_phone" => $recPhone,
                                "short_url" => $refUrl
                            );

                            $messageDetails[] = array(
                                    "first_name" => $singleDetails['first_name'],
                                    "job_title" => $singleDetails['JobTitle'],
                                    "client_name" => $resultCompany[0],
                                    "job_id" => $singleDetails['companyid']
                                );
                            $candidatePhoneNumber[] = $singleDetails['homePhone'];

                            $to = array(
                                $singleDetails['email']
                            );
                            $from = $singleDetails['recemail'];
                            $subject = "Submitted: ".$resultCompany[0]." - " . $singleDetails['JobTitle'] . " (" . $singleDetails['companyid'] . ") – " . $singleDetails['location'] . "";
                            $dueDate = $submittedDate;
                            $emailSendAfterFiveDays = date('Y-m-d', strtotime($dueDate . ' +5 Weekday'));
                            $emailSendAfterTenDays = date('Y-m-d', strtotime($dueDate . ' +10 Weekday'));
                            $emailSendAfterTwentyDays = date('Y-m-d', strtotime($dueDate . ' +20 Weekday'));
                            }

                        $submittedType = array(
                            "submitted",
                            "submitted_after_five_days",
                            "submitted_after_ten_days",
                            "submitted_after_twenty_days"
                        );
                        $scheduleArray = array(
                            date('Y-m-d') ,
                            $emailSendAfterFiveDays,
                            $emailSendAfterTenDays,
                            $emailSendAfterTwentyDays
                        );
                        foreach($submittedType as $key => $singleRow)
                            {
                              if ($to != '') {
                              $this->emailService->sendEmailTemplate($singleRow, $from, $to, null, null, $subject, null, $data,$validationData, $scheduleArray[$key]); 
                              }
                            }  
                            if ($candidatePhoneNumber != '') {
                              $this->twilioService->sendSmsSubmitted("sms_reminder_submitted", $candidatePhoneNumber,$fromNumber,$messageDetails); 
                            }
                        }
                      else
                        {
                        foreach($getDetails as $index => $singleDetails)
                            {
                            if ($singleDetails['ext'] == true)
                                {
                                $recPhone = $singleDetails['recphone'] . 'Ext.' . $singleDetails['ext'];
                                }
                              else
                                {
                                $recPhone = $singleDetails['recphone'];
                                }
                                $companyNameSplit = $singleDetails['companyName'];
                                $resultCompany = explode('_', $companyNameSplit);

                                $copyLink="http://jobs.vtechsolution.com/a.php?i=".$joborderId."&title=".$singleDetails['JobTitle']."&rec_email=".$singleDetails['recemail']."";

                                $jobUrl="SELECT * from short_url where url='$copyLink'";

                                $getShortUrl = $this->urlshortner->query($jobUrl)->fetchColumn(3);

                                $identity = time();

                                if (empty($getShortUrl)) {

                                $identity = time();
                                $shorturl=base_convert($identity,10,36);
                                $query = "INSERT INTO short_url (id,url,shortened) values('$identity','$copyLink','$shorturl')";
                                $insertUrl = $this->urlshortner->query($query)->execute();
                                 $refUrl = "http://jobs.vtechsolution.com/a.php?i=".$shorturl;

                                }
                                else {

                                    $refUrl = "http://jobs.vtechsolution.com/a.php?i=".$getShortUrl;

                                }

                            $data[] = array(
                                "job_title" => $singleDetails['JobTitle'],
                                "client_name" => $resultCompany[0],
                                "recruiter_name" => $singleDetails['recName'],
                                "recruiter_email" => $singleDetails['recemail'],
                                "rec_phone" => $recPhone,
                                 "short_url" => $refUrl
                            );

                            $messageDetails[] = array(
                                    "first_name" => $singleDetails['first_name'],
                                    "job_title" => $singleDetails['JobTitle'],
                                    "client_name" => $resultCompany[0],
                                    "job_id" => $singleDetails['companyid']
                                );
                            $candidatePhoneNumber[] = $singleDetails['homePhone'];

                            $to = array(
                                $singleDetails['email']
                            );
                            $from = $singleDetails['recemail'];
                            $companyNameSplit = $singleDetails['companyName'];
                            $resultCompany = explode('_', $companyNameSplit);
                            $type = "submitted";
                            $subject = "Submitted: ".$resultCompany[0]." - " . $singleDetails['JobTitle'] . " (" . $singleDetails['companyid'] . ") – " . $singleDetails['location'] . "";
                            $parts = explode('-', $singleDetails['value']);
                            $dueDate = $parts[2] . '-' . $parts[0] . '-' . $parts[1];
                            $emailSendAfterFiveDays = date('Y-m-d', strtotime($dueDate . ' +5 Weekday'));
                            $emailSendAfterTenDays = date('Y-m-d', strtotime($dueDate . ' +10 Weekday'));
                            $emailSendAfterTwentyDays = date('Y-m-d', strtotime($dueDate . ' +20 Weekday'));
                            }

                        $submittedType = array(
                            "submitted",
                            "submitted_after_five_days",
                            "submitted_after_ten_days",
                            "submitted_after_twenty_days"
                        );
                        $scheduleArray = array(
                            date('Y-m-d') ,
                            $emailSendAfterFiveDays,
                            $emailSendAfterTenDays,
                            $emailSendAfterTwentyDays
                        );
                        foreach($submittedType as $key => $singleRow) {
                            
                              if ($to != '') {
                              $this->emailService->sendEmailTemplate($singleRow, $from, $to, null, null, $subject, null, $data,$validationData, $scheduleArray[$key]); 
                              }
                            }  
                            if ($candidatePhoneNumber != '') {
                              $this->twilioService->sendSmsSubmitted("sms_reminder_submitted", $candidatePhoneNumber,$fromNumber,$messageDetails); 
                            }
                        }
                    }
                  else
                if ($clientType['ctype'] == 'Commercial' OR $clientType['ctype'] == '')
                    {
                    $query = "SELECT c.candidate_id as cid,CONCAT(u.first_name, ' ',u.last_name) as recName,u.phone_work as recphone,u.phone_extension as ext,c.email1 as email,u.email as recemail,u.notes as manager,cc.name as companyName,jo.title as JobTitle,c.first_name,CONCAT(c.first_name, ' ', c.last_name) AS ename,CONCAT(jo.city, ' ', jo.state) as location,jo.client_job_id as companyid,c.first_name AS first_name,c.phone_home AS homePhone, c.phone_work AS workPhone  FROM candidate_joborder as cj

                              LEFT JOIN joborder as jo on jo.joborder_id = cj.joborder_id
                              LEFT JOIN user AS u ON u.user_id = cj.added_by
                              LEFT JOIN candidate as c on c.candidate_id = cj.candidate_id
                              LEFT JOIN cats_client as cc on cc.company_id = jo.company_id


                             WHERE cj.joborder_id = '" . $joborderId . "' AND cj.candidate_id = '" . $candidateId . "' LIMIT 1";
                    $getDetails = $this->catsDatabase->query($query)->fetchAll();

                        foreach($getDetails as $index => $singleDetails)
                            {
                            if ($singleDetails['ext'] == true)
                                {
                                $recPhone = $singleDetails['recphone'] . 'Ext.' . $singleDetails['ext'];
                                }
                              else
                                {
                                $recPhone = $singleDetails['recphone'];
                                }
                                $companyNameSplit = $singleDetails['companyName'];
                                $resultCompany = explode('_', $companyNameSplit);
                                $copyLink="http://jobs.vtechsolution.com/a.php?i=".$joborderId."&title=".$singleDetails['JobTitle']."&rec_email=".$singleDetails['recemail']."";

                                $jobUrl="SELECT * from short_url where url='$copyLink'";

                                $getShortUrl = $this->urlshortner->query($jobUrl)->fetchColumn(3);

                                $identity = time();

                                if (empty($getShortUrl)) {

                                $identity = time();
                                $shorturl=base_convert($identity,10,36);
                                $query = "INSERT INTO short_url (id,url,shortened) values('$identity','$copyLink','$shorturl')";
                                $insertUrl = $this->urlshortner->query($query)->execute();
                                 $refUrl = "http://jobs.vtechsolution.com/a.php?i=".$shorturl;

                                }
                                else {

                                    $refUrl = "http://jobs.vtechsolution.com/a.php?i=".$getShortUrl;

                                }

                            $data[] = array(
                                "job_title" => $singleDetails['JobTitle'],
                                "client_name" => $resultCompany[0],
                                "recruiter_name" => $singleDetails['recName'],
                                "recruiter_email" => $singleDetails['recemail'],
                                "rec_phone" => $recPhone,
                                 "short_url" => $refUrl
                            );

                            $messageDetails[] = array(
                                    "first_name" => $singleDetails['first_name'],
                                    "job_title" => $singleDetails['JobTitle'],
                                    "client_name" => $resultCompany[0],
                                    "job_id" => $singleDetails['companyid']
                                );
                            $candidatePhoneNumber[] = $singleDetails['homePhone'];


                            $to = array(
                                $singleDetails['email']
                            );
                            $from = $singleDetails['recemail'];

                            $type = "submitted";
                            $subject = "Submitted: ".$resultCompany[0]." - " . $singleDetails['JobTitle'] . " (" . $singleDetails['companyid'] . ") – " . $singleDetails['location'] . "";
                            $dueDate = $submittedDate;
                            $emailSendAfterFiveDays = date('Y-m-d', strtotime($dueDate . ' +2 Weekday'));
                            $emailSendAfterTenDays = date('Y-m-d', strtotime($dueDate . ' +5 Weekday'));
                            $emailSendAfterTwentyDays = date('Y-m-d', strtotime($dueDate . ' +7 Weekday'));
                            }

                        $submittedType = array(
                            "submitted",
                            "submitted_after_five_days",
                            "submitted_after_ten_days",
                            "submitted_after_twenty_days"
                        );
                        $scheduleArray = array(
                            date('Y-m-d') ,
                            $emailSendAfterFiveDays,
                            $emailSendAfterTenDays,
                            $emailSendAfterTwentyDays
                        );
                        foreach($submittedType as $key => $singleRow) {
                            
                              if ($to != '') {
                              $this->emailService->sendEmailTemplate($singleRow, $from, $to, null, null, $subject, null, $data,$validationData, $scheduleArray[$key]); 
                              }
                            }  
                            if ($candidatePhoneNumber != '') {
                              $this->twilioService->sendSmsSubmitted("sms_reminder_submitted", $candidatePhoneNumber,$fromNumber,$messageDetails); 
                            }
                        }
                  else
                    {
                    echo "Error";
                    }
                }
            }
        }

    }

    public function candidateStatusProcessAfterInterview() {

        $candidateId = json_decode($this->request->get('candidateID'));
        $joborderId = json_decode($this->request->get('jobOrderID'));
        $fromNumber = $this->container->getParameter('fromNumber');
        $this->catsDatabase = $this->container->get('v_tech_solution_quick_book.catsdb')->getPDO();
        $query = "SELECT c.candidate_id as cid,CONCAT(u.first_name, ' ',u.last_name) as recName,u.phone_work as recphone,u.phone_extension as ext,c.email1 as email,u.email as recemail,u.notes as manager,cc.name as companyName,jo.title as JobTitle,c.first_name,CONCAT(c.first_name, ' ', c.last_name) AS ename, c.first_name AS first_name, CONCAT(jo.city, ' ', jo.state) as location,jo.client_job_id as companyid,c.phone_home AS homePhone, c.phone_work AS workPhone FROM candidate_joborder as cj LEFT JOIN joborder as jo on jo.joborder_id = cj.joborder_id LEFT JOIN user AS u ON u.user_id = cj.added_by LEFT JOIN candidate as c on c.candidate_id = cj.candidate_id LEFT JOIN cats_client as cc on cc.company_id = jo.company_id WHERE cj.joborder_id = '" . $joborderId . "' AND cj.candidate_id = '" . $candidateId . "' LIMIT 1";
                $getDetails = $this->catsDatabase->query($query)->fetchAll();
                /*print_r($getDetails);
                die;*/

        foreach($getDetails as $index => $singleDetails) {
            if ($singleDetails['ext'] == true) {
                            $recPhone = $singleDetails['recphone'] . 'Ext.' . $singleDetails['ext'];
                } else {
                    $recPhone = $singleDetails['recphone'];
                }
                $companyNameSplit = $singleDetails['companyName'];
                                $resultCompany = explode('_', $companyNameSplit);

                $data[] = array(
                                "job_title" => $singleDetails['JobTitle'],
                                "client_name" => $resultCompany[0],
                                "job_id" => $singleDetails['companyid'],
                                "candidate_Name" => $singleDetails['ename'],
                                "recruiter_name" => $singleDetails['recName'],
                                "recruiter_email" => $singleDetails['recemail'],
                                "rec_phone" => $recPhone
                            );
                $messageDetails[] = array(
                "first_name" => $singleDetails['first_name'],
                "job_title" => $singleDetails['JobTitle'],
                "client_name" => $resultCompany[0],
                "job_id" => $singleDetails['companyid']
                );
                $candidatePhoneNumber[] = $singleDetails['homePhone'];

                $to = array(
                                $singleDetails['email']
                            );
                $from = $singleDetails['recemail'];

                $type = "interview";
                $subject = "Feedback: ".$resultCompany[0]." - " . $singleDetails['JobTitle'] . " (" . $singleDetails['companyid'] . ")";
            }
            if ($to != '') {
              $this->emailService->sendEmailTemplate("interview", $from, $to, null, null, $subject, null, $data);  
            }
            if ($candidatePhoneNumber != '') {
              $this->twilioService->sendSmsInterview("sms_reminder_interview", $candidatePhoneNumber,$fromNumber,$messageDetails);  
            }
        }  
    }
?>

<?php
namespace vTechSolution\Bundle\TimeSheetBundle\Manager;
use Symfony\Component\DependencyInjection\ContainerInterface as Container;
use Symfony\Component\HttpFoundation\Request;
use PHPMailer\PHPMailer\Exception;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Knp\Bundle\SnappyBundle\Snappy\Response\PdfResponse;
use vTechSolution\Bundle\TimeSheetBundle\Document\EmailCandidateTimesheetReminder;

class TimeSheetService
{
    public  $complianceListRepository;
    private $container;
    private $doctrine;
    private $request;
    private $responseArray;
    private $vtechhrmDatabase;
    private $vtechtoolDatabase;
    private $complianceMappingRepository;
    private $onbordingCandidateDocumentsRepository;
    private $onBoardingDatabase;
    private $onBoardingCandidateDatabase;
    const HTTP_METHOD_GET = 'GET';
    const HTTP_METHOD_POST = 'POST';
    public function __construct(Container $container)
    {
        $this->container = $container;
        $this->request = $this->container->get('request');
        $this->responseArray = array();
        $this->doctrine = $this->container->get('doctrine');
        $this->vtechtoolDatabase = $this->container->get('v_tech_solution_quick_book.vtech_tools')->getPDO();
        $this->emailService = $this->container->get('v_tech_solution_email.email');
        $this->emailCandidateTimesheetRepository = $this->container->get('doctrine_mongodb')->getRepository('vTechSolutionTimeSheetBundle:EmailCandidateTimesheetReminder');
        $this->twilioService = $this->container->get('v_tech_solution_twilio.twilio');
    }
    public function __destructor()
    {
        unset($this->container);
        unset($this->request);
        unset($this->responseArray);
        unset($this->complianceMappingRepository);
    }
    public function getTimeSheet()
    {
        $this->responseArray = array();
        $getClientId = $this->container->getParameter('getClinetId');

        $this->vtechhrmDatabase = $this->container->get('v_tech_solution_quick_book.vtechhrm')->getPDO();
        $query = "SELECT e.id FROM employees as e WHERE e.status IN ('Active','Terminated','Termination Vol','Termination In_Vol')";
        $getEmployeesId = $this->vtechhrmDatabase->query($query)->fetchAll();

        foreach ($getEmployeesId as $key => $value) {
            $query = "SELECT id,employee,date_start,date_end,status FROM employeetimesheets WHERE employee = '" . $value['id'] . "' AND status = 'Approved' ORDER BY id DESC LIMIT 1";

            $getTimeSheetId = $this->vtechhrmDatabase->query($query)->fetchAll();

            foreach ($getTimeSheetId as $key => $timesheet) {

                $query = "SELECT e.id,e.first_name,e.middle_name,e.last_name,e.city,cinfo.zipcode,cinfo.client_name,cinfo.address_line1,cinfo.address_line2,cinfo.city,cinfo.zipcode,cinfo.client_phone,cinfo.client_fax,e.mobile_phone,e.private_email,e.address1,e.address2,e.postal_code,employee,date_start,date_end,timesheet,created,e.private_email,details,
                    '" . $timesheet['date_end'] . "' as dateend,comp.name AS cname,tip.modified_by,tip.Date_modified,'" . $timesheet['date_start'] . "' as datestart FROM `employeetimeentry` left join employees as e on e.id = employeetimeentry.employee
                    LEFT JOIN vtech_mappingdb.system_integration AS si ON si.h_employee_id = e.id
                    LEFT JOIN vtech_mappingdb.timesheet_ipdata AS tip ON tip.t_id = '" . $timesheet['id'] . "'
                    LEFT JOIN vtech_mappingdb.client_info as cinfo ON cinfo.map_data_id= si.id
                    LEFT JOIN cats.company AS comp ON comp.company_id = si.c_company_id
                    WHERE   si.h_employee_id= e.id AND  timesheet= '" . $timesheet['id'] . "' AND c_company_id NOT IN ".$getClientId;

                $employeeTimeentry[] = $this->vtechhrmDatabase->query($query)->fetchAll();
            }
        }
        $this->responseArray = array_filter($employeeTimeentry);

        unset($query);
        unset($getEmployeesId);
        unset($getTimeSheetId);
        unset($employeeTimeentry);

        return $this->responseArray;
    }

    public function getTimeSheetByDate() {

        $date = $this->request->get('date');

        $weekLastDate = date($date);

        $dateOne = strtotime($weekLastDate);
        $dateTwo = date("l", $dateOne);
        $dateThree = strtolower($dateTwo);

        if(($dateThree == "saturday" ))
        {
             $weekStartDate = $weekLastDate;
        }

        else if (($dateThree == "sunday")) {

             $weekStartDate =  date('Y-m-d', strtotime($weekLastDate . ' -1 days'));
        }

        else {

              $weekStartDate = date('Y-m-d', strtotime($weekLastDate . 'Saturday Last Week'));
        }

         $weekLastDate = date('Y-m-d', strtotime($weekStartDate . ' -6 days'));

        $this->responseArray = array();
        $getClientId = $this->container->getParameter('getClinetId');
        $this->vtechhrmDatabase = $this->container->get('v_tech_solution_quick_book.vtechhrm')->getPDO();
        $query = "SELECT e.id FROM employees as e WHERE e.status IN ('Active','Terminated','Termination Vol','Termination In_Vol')";
        $getEmployeesId = $this->vtechhrmDatabase->query($query)->fetchAll();

        foreach ($getEmployeesId as $key => $value) {
            $query = "SELECT id,employee,date_start,date_end,status FROM employeetimesheets WHERE employee = '" . $value['id'] . "' AND status = 'Approved' AND date_start BETWEEN '".$weekLastDate."' AND '".$weekStartDate."' ORDER BY id DESC LIMIT 1";

            $getTimeSheetId = $this->vtechhrmDatabase->query($query)->fetchAll();

            foreach ($getTimeSheetId as $key => $timesheet) {

                $query = "SELECT e.id,e.first_name,e.middle_name,e.last_name,e.city,cinfo.zipcode,cinfo.client_name,cinfo.address_line1,cinfo.address_line2,cinfo.city,cinfo.zipcode,cinfo.client_phone,cinfo.client_fax,e.mobile_phone,e.private_email,e.address1,e.address2,e.postal_code,employee,date_start,date_end,timesheet,created,e.private_email,details,
                  '" . $timesheet['date_end'] . "' as dateend,comp.name AS cname,tip.modified_by,tip.Date_modified,'" . $timesheet['date_start'] . "' as datestart FROM `employeetimeentry` left join employees as e on e.id = employeetimeentry.employee
                    LEFT JOIN vtech_mappingdb.system_integration AS si ON si.h_employee_id = e.id
                    LEFT JOIN vtech_mappingdb.timesheet_ipdata AS tip ON tip.t_id = '" . $timesheet['id'] . "'
                    LEFT JOIN vtech_mappingdb.client_info as cinfo ON cinfo.map_data_id= si.id
                    LEFT JOIN cats.company AS comp ON comp.company_id = si.c_company_id
                     WHERE   si.h_employee_id= e.id AND  timesheet= '" . $timesheet['id'] . "' AND c_company_id NOT IN ".$getClientId;

                $employeeTimeentry[] = $this->vtechhrmDatabase->query($query)->fetchAll();
            }
        }
        $this->responseArray = array_filter($employeeTimeentry);

        unset($query);
        unset($getEmployeesId);
        unset($getTimeSheetId);
        unset($employeeTimeentry);

        return $this->responseArray;
    }



    public function getTimeSheetByDateFromHrm() {
        $date      = json_decode($this->request->get('weekdate'));
        $weekLastDate = date($date);
        $dateOne = strtotime($weekLastDate);
        $dateTwo = date("l", $dateOne);
        $dateThree = strtolower($dateTwo);

        if(($dateThree == "saturday" )) {
             $weekStartDate = $weekLastDate;
        }

        else if (($dateThree == "sunday")) {

             $weekStartDate =  date('Y-m-d', strtotime($weekLastDate . ' -1 days'));
        }

        else {

              $weekStartDate = date('Y-m-d', strtotime($weekLastDate . 'Saturday Last Week'));
        }

         $weekLastDate = date('Y-m-d', strtotime($weekStartDate . ' -6 days'));

        $this->responseArray = array();
        $getClientId = $this->container->getParameter('getClinetId');
        $this->vtechhrmDatabase = $this->container->get('v_tech_solution_quick_book.vtechhrm')->getPDO();
        $query = "SELECT e.id FROM employees as e WHERE e.status IN ('Active','Terminated','Termination Vol','Termination In_Vol')";
        $getEmployeesId = $this->vtechhrmDatabase->query($query)->fetchAll();

        foreach ($getEmployeesId as $key => $value) {
            $query = "SELECT id,employee,date_start,date_end,status FROM employeetimesheets WHERE employee = '" . $value['id'] . "' AND status = 'Approved' AND date_start BETWEEN '".$weekLastDate."' AND '".$weekStartDate."' ORDER BY id DESC LIMIT 1";

            $getTimeSheetId = $this->vtechhrmDatabase->query($query)->fetchAll();

            foreach ($getTimeSheetId as $key => $timesheet) {

                $query = "SELECT e.id,e.first_name,e.middle_name,e.last_name,e.city,cinfo.zipcode,cinfo.client_name,cinfo.address_line1,cinfo.address_line2,cinfo.city,cinfo.zipcode,cinfo.client_phone,cinfo.client_fax,e.mobile_phone,e.private_email,e.address1,e.address2,e.postal_code,employee,date_start,date_end,timesheet,created,e.private_email,details,
                  '" . $timesheet['date_end'] . "' as dateend,comp.name AS cname,tip.modified_by,tip.Date_modified,'" . $timesheet['date_start'] . "' as datestart FROM `employeetimeentry` left join employees as e on e.id = employeetimeentry.employee
                    LEFT JOIN vtech_mappingdb.system_integration AS si ON si.h_employee_id = e.id
                    LEFT JOIN vtech_mappingdb.timesheet_ipdata AS tip ON tip.t_id = '" . $timesheet['id'] . "'
                    LEFT JOIN vtech_mappingdb.client_info as cinfo ON cinfo.map_data_id= si.id
                    LEFT JOIN cats.company AS comp ON comp.company_id = si.c_company_id
                     WHERE   si.h_employee_id= e.id AND  timesheet= '" . $timesheet['id'] . "' AND c_company_id NOT IN ".$getClientId;

                $employeeTimeentry[] = $this->vtechhrmDatabase->query($query)->fetchAll();
            }
        }
        $this->responseArray = array_filter($employeeTimeentry);

        unset($query);
        unset($getEmployeesId);
        unset($getTimeSheetId);
        unset($employeeTimeentry);

        return $this->responseArray;
    }

    public function getTimeSheetProcessStatusBySaas() {

        $date = $this->request->get('weekdate');
        $timeSheetUrl = $this->container->getParameter('timeSheetUrl');

        $curl = curl_init();
        curl_setopt_array($curl, array(
         CURLOPT_URL => $timeSheetUrl,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 300,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
                //CURLOPT_POSTFIELDS => "type=".$type."&message=".json_encode($data)."&to=".json_encode($to),
        CURLOPT_POSTFIELDS => "weekdate=".json_encode($date),
                ));
        $this->responseArray = curl_exec($curl);
        return $this->responseArray;
    }

    public function getTimeSheetProcessAutoGenerate() {

        $timeSheetUrl = $this->container->getParameter('autotimeSheetUrl');
        $curl = curl_init();
        curl_setopt_array($curl, array(
         CURLOPT_URL => $timeSheetUrl,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 300,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "GET",
                ));
        $this->responseArray = curl_exec($curl);

        return $this->responseArray;
    }

    public function getPendingTimeSheet() {
        
        $employeeId = $this->request->get('checkbox');
        $totalNumberOfCandidate =  count($employeeId);
        $StartDate = $this->request->get('dateStart');
        $endDate = $this->request->get('dateEnd');
        $userId = $this->request->get('userId');

        $this->vtechhrmDatabase = $this->container->get('v_tech_solution_quick_book.vtechhrm')->getPDO();

        foreach ($employeeId as $key => $eid) {

        $query = "SELECT ".$eid." AS eid, CONCAT(e.first_name , ' ' , e.last_name) AS candidateName, e.private_email AS email FROM employees as e WHERE e.id = '$eid'";

        $getDetailsOfCandidates = $this->vtechhrmDatabase->query($query)->fetchAll();

           foreach ($getDetailsOfCandidates as $key => $value) {

                $data[] = array("candidate_name" => $value['candidateName'], "endDate" => $endDate);
                $to = array($value['email']);
                $candidateDetails[] =  $getDetailsOfCandidates;
            }
        }

            $reminder = new EmailCandidateTimesheetReminder();
            $reminder->setCandidateEmailAddressList(json_encode($candidateDetails));
            $reminder->setCandidateSmsAddressList('Null');
            $reminder->setTotalNumberOfCandidate($totalNumberOfCandidate);
            $reminder->setDateStart($StartDate);
            $reminder->setDateEnd($endDate);
            $reminder->setUserId($userId);
            $reminder->setCreatedAt(new \DateTime());
            $this->emailCandidateTimesheetRepository->commit($reminder);

        $this->emailService->sendEmailTemplate("auto_email_reminder", null, $to, null, null, null, null, $data);
    }

    public function getPendingTimeSheetDueDate() {

        $date = date('Y-m-d');
        $dateOne = strtotime($date);
        $dateTwo = date("l", $dateOne);
        $dateThree = strtolower($dateTwo);
        $fromNumber = $this->container->getParameter('fromNumber');
        $emailToTimeSheetteam = $this->request->get('name');
        $currentDay = date("N");
        $dateOfFriday = 5 - $currentDay;
        $currentDate = date("Y-m-d");
        if ($dateThree == "friday") {
            $weekStartDate = date('Y-m-d', strtotime($date . 'sunday Last week'));
            $weekLastDate = date('Y-m-d', strtotime($date . 'saturday this week'));
        } else {
            $weekLastDate = date('Y-m-d', strtotime($date . 'Saturday Last Week'));
            $weekStartDate = date('Y-m-d', strtotime($weekLastDate . ' -6 days'));
        }
        $this->responseArray = array();
        $this->vtechhrmDatabase = $this->container->get('v_tech_solution_quick_book.vtechhrm')->getPDO();
        $query = "SELECT e.id as id, es.employee,CONCAT(e.first_name , ' ' , e.last_name) AS candidateName, e.private_email as email, e.mobile_phone as phone, es.date_start,es.date_end FROM employeetimesheets as es LEFT JOIN employees as e on e.id = es.employee WHERE e.status = 'active' AND es.employee NOT IN (SELECT candidate_id from vtech_tools.exclude_candidates as ec WHERE ec.start_date BETWEEN '" . $weekStartDate . "' AND '" . $weekLastDate . "' ORDER BY `start_date` DESC) AND es.status = 'Pending' AND e.mobile_phone != '' AND e.private_email != '' AND e.custom7 <= '$weekLastDate' AND es.date_start BETWEEN '" . $weekStartDate . "' AND '" . $weekLastDate . "' ORDER BY `date_start` DESC";
        $getTimeSheetId = $this->vtechhrmDatabase->query($query)->fetchAll();
        $getDetailsOfCandidates = array_filter($getTimeSheetId);
        $totalNumberOfCandidate = count($getDetailsOfCandidates);
        foreach($getDetailsOfCandidates as $key => $value) {
            $date = date($value['date_end']);
            $weekDate = date('m/d', strtotime($date));
            $data[] = array(
                "candidate_name" => $value['candidateName'],
                "endDate" => $weekDate
            );
            $to[] = $value['email'];
            $candidateDetails[] = array(
                "candidateId" => $value['id'],
                "candidate_name" => $value['candidateName'],
                "email" => $value['email']
            );
            // $candidatePhoneNumber = "9732912215";
            $messageDetailsSms[] = array(
                "candidateId" => $value['id'],
                "candidate_name" => $value['candidateName'],
                "phone" => $value['phone']
            );
            $candidatePhoneNumber = $value['phone'];
            $phone = preg_replace('/\D+/', '', $candidatePhoneNumber);
            $messageDetails[] = array(
                "candidate_name" => $value['candidateName'],
                "endDate" => $weekDate,
                "phone" => $phone
            );
            //$candidatePhoneNumber[] = $value['phone'];
        }
        if ($emailToTimeSheetteam == "emailtous") {
            $sendEmailToTimesheetteam = $getDetailsOfCandidates;
            $emailData = array(0 => array('reminderemail' => $currentDate, 'candidate_table' => ''));
            $candidateList = array();
            foreach($sendEmailToTimesheetteam as $key => $value) {
                $candidateList[] = array(
                    "candidate_name" => $value['candidateName'],
                    "enddate" => $value['date_end'],
                    "startdate" => $value['date_start'],
                    "candidateemail" => $value['email'],
                    "phone" => $value['phone'],
                );
            }
            $emailData[0]['candidate_table'] = '<table border="1">
                        <thead>
                          <tr>
                            <th>Candidate Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                          </tr>
                        </thead>
                        <tbody id="myTable">';
            foreach ($candidateList as $value) {
                $emailData[0]['candidate_table'] .= '
                      <tr>
                        <td>'.  $value['candidate_name'] .'</td>
                        <td>'.  $value['candidateemail'] .'</td>
                        <td>'.  $value['phone'] .'</td>
                        <td>'.  $value['startdate'] .'</td>
                        <td>'.  $value['enddate'] .'</td>
                      </tr>';
                }
            $emailData[0]['candidate_table'] .= '</tbody></table>';
           $this->emailService->sendEmailTemplate("email_reminder_timesheetteam", null, null, null, null, null, null, $emailData);
            } else {
            $reminder = new EmailCandidateTimesheetReminder();
            $reminder->setCandidateEmailAddressList(json_encode($candidateDetails));
            $reminder->setCandidateSmsAddressList(json_encode($messageDetailsSms));
            $reminder->setTotalNumberOfCandidate($totalNumberOfCandidate);
            $reminder->setDateStart($weekStartDate);
            $reminder->setDateEnd($weekLastDate);
            $reminder->setUserId('0');
            $reminder->setCreatedAt(new \DateTime());
            $this->emailCandidateTimesheetRepository->commit($reminder);
            if ($dateThree == "friday") {
                $this->emailService->sendEmailTemplate("auto_email_reminder_weekend", null, $to, null, null, null, null, $data);
                //$this->twilioService->sendSms("sms_reminder", $candidatePhoneNumber, $fromNumber, $messageDetails);
            } else {
                $this->emailService->sendEmailTemplate("auto_email_reminder", null, $to, null, null, null, null, $data);
                //$this->twilioService->sendSms("sms_reminder",$fromNumber,$messageDetails);
            }
        }
    unset($query);
    unset($getTimeSheetId);
    return $this->responseArray;
    }

    public function getTimeSheetDetalisFromHrm() {
        $employeeId = $this->request->get('id');
        $StartDate = $this->request->get('startDate');
        $endDate = $this->request->get('EndDate');
        $query = "SELECT id FROM `exclude_candidates` WHERE candidate_id = '$employeeId' AND start_date = '$StartDate' AND end_date = '$endDate'";
        $getId = $this->vtechtoolDatabase->query($query)->fetchColumn(0);
        if (!empty($getId)) {
            $this->responseArray = $this->vtechtoolDatabase->exec("DELETE FROM `exclude_candidates` WHERE id = '$getId'");
        } else {
            $this->responseArray = $this->vtechtoolDatabase->exec("INSERT INTO exclude_candidates (`id`, `candidate_id`, `start_date`, `end_date`) VALUES ('','$employeeId','$StartDate','$endDate')");
        }
        unset($query);  
        return $this->responseArray;
    }

    public function getExcludeTimeSheetDetalis() {
        $query = "SELECT * FROM `exclude_candidates`";
        $this->responseArray = $this->vtechtoolDatabase->query($query)->fetchAll();
        unset($query);
        return $this->responseArray;
    }
}

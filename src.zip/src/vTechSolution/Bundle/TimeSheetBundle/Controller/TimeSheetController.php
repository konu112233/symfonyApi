<?php

namespace vTechSolution\Bundle\TimeSheetBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\JsonResponse;
use Nelmio\ApiDocBundle\Annotation\ApiDoc;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Knp\Bundle\SnappyBundle\Snappy\Response\PdfResponse;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Component\HttpFoundation\Request;
use Knp\Bundle\SnappyBundle\Snappy\Response\JpegResponse;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Translation\TranslatorInterface;

/**
 * @Route("/api/v1/timesheet")
 */

class TimeSheetController extends Controller
{

    private $responseArray;
    private $request;
    private $timeSheetService;


    private function initAction()
    {

        $this->responseArray = array();
        $this->request = $this->getRequest();
        $this->timeSheetService = $this->get('v_tech_solution_time_sheet.timesheet');

    }

   /**
     * @Route("/timesheetprocess", name="v_tech_solution_time_sheet_timesheet")
     * @Method({"GET"} )
     */
    public function timeSheetProcess()
    {

        $this->initAction();
        $timeSheetLocation = $this->container->getParameter('timeSheetLocation');

        $this->responseArray['employeetimeentry'] = $this->timeSheetService->getTimeSheet();

        foreach ($this->responseArray["employeetimeentry"] as $key => $value) {

            $html = $this->renderView('vTechSolutionTimeSheetBundle:timesheet:pdf.html.twig', array(
                "key" => $key,
                "timeentry" => $value
            ));

            $clientName   = $value[0]['cname'];
            $firstName    = $value[0]['first_name'];
            $lastName     = $value[0]['last_name'];
            $employeeName = trim($clientName)."_" .trim($firstName) . " " . $lastName;
            $date         = $value[0]['dateend'];
            $createDate   = new \DateTime($date);

            $weekStartDate = $createDate->format('m-d-Y');
            $count = sizeof($value);
            $weekTotalHours = 0;
            $totalHours = 0;

            for ($i=0; $i < $count; $i++) {

                $totalHoursDate = $value[$i]['details'];
                $explodeDate = explode(',', $totalHoursDate);
                $explodeHours = explode(':', $explodeDate['2']);
                $totalByHours = ($explodeHours['1'] * 60 * 60);
                $totalByMinutes = ($explodeHours['2'] * 60);
                $totalBySeconds = ($explodeHours['3']);
                $weekTotalHours = ($totalByHours + $totalByMinutes + $totalBySeconds) + $weekTotalHours;

                }

                $totalHoursCalculated = $weekTotalHours/60;
                $weekTotalHoursCalculated = $totalHoursCalculated/60;
                $weekTotalHoursCalculatedByRoundUp = number_format((float)$weekTotalHoursCalculated, 2, '.', '');

                $employeeFileLocation = $firstName . "_" . $lastName . "_" . $weekTotalHoursCalculatedByRoundUp. "hours"."_" . $weekStartDate;

                $fileLocation = $timeSheetLocation. $employeeName . '/' . $employeeFileLocation . '.pdf';

                if (!file_exists($fileLocation)) {

               $this->get('knp_snappy.pdf')->generateFromHtml($html, $fileLocation );
            }

        }

        return $this->render("vTechSolutionTimeSheetBundle:timesheet:success.html.twig");

    }

    /**
     * @Route("/timesheetprocess/{date}", name="v_tech_solution_time_sheet_timesheet_date")
     * @Method({"GET"} )
     */
    public function timeSheetProcessByDate()
    {

        $this->initAction();
        $timeSheetLocation = $this->container->getParameter('timeSheetLocation');

        $this->responseArray['employeetimeentry'] = $this->timeSheetService->getTimeSheetByDate();

        foreach ($this->responseArray["employeetimeentry"] as $key => $value) {

            $html = $this->renderView('vTechSolutionTimeSheetBundle:timesheet:pdf.html.twig', array(
                "key" => $key,
                "timeentry" => $value
            ));

            $clientName   = $value[0]['cname'];
            $firstName    = $value[0]['first_name'];
            $lastName     = $value[0]['last_name'];
            $employeeName = trim($clientName)."_" .trim($firstName) . " " . $lastName;
            $date         = $value[0]['dateend'];
            $createDate   = new \DateTime($date);

            $weekStartDate = $createDate->format('m-d-Y');
            $count = sizeof($value);
            $weekTotalHours = 0;
            $totalHours = 0;

            for ($i=0; $i < $count; $i++) {

                $totalHoursDate = $value[$i]['details'];
                $explodeDate = explode(',', $totalHoursDate);
                $explodeHours = explode(':', $explodeDate['2']);
                $totalByHours = ($explodeHours['1'] * 60 * 60);
                $totalByMinutes = ($explodeHours['2'] * 60);
                $totalBySeconds = ($explodeHours['3']);
                $weekTotalHours = ($totalByHours + $totalByMinutes + $totalBySeconds) + $weekTotalHours;

                }

                $totalHoursCalculated = $weekTotalHours/60;
                $weekTotalHoursCalculated = $totalHoursCalculated/60;
                $weekTotalHoursCalculatedByRoundUp = number_format((float)$weekTotalHoursCalculated, 2, '.', '');

                $employeeFileLocation = $firstName . "_" . $lastName . "_" . $weekTotalHoursCalculatedByRoundUp. "hours"."_" . $weekStartDate;

                $fileLocation = $timeSheetLocation. $employeeName . '/' . $employeeFileLocation . '.pdf';

                if (!file_exists($fileLocation)) {

               $this->get('knp_snappy.pdf')->generateFromHtml($html, $fileLocation );
            }

        }

        return $this->render("vTechSolutionTimeSheetBundle:timesheet:success.html.twig");

    }

    /**
     * @Route("/timesheetprocess/fromhrmbydate", name="v_tech_solution_time_sheet_timesheet_date_hrm")
     * @Method({"POST"} )
     */
    public function timeSheetProcessByDateFromHrm()
    {

        $this->initAction();
        $timeSheetLocation = $this->container->getParameter('timeSheetLocation');

        $this->responseArray['employeetimeentry'] = $this->timeSheetService->getTimeSheetByDateFromHrm();

        foreach ($this->responseArray["employeetimeentry"] as $key => $value) {

            $html = $this->renderView('vTechSolutionTimeSheetBundle:timesheet:pdf.html.twig', array(
                "key" => $key,
                "timeentry" => $value
            ));

            $clientName   = $value[0]['cname'];
            $firstName    = $value[0]['first_name'];
            $lastName     = $value[0]['last_name'];
            $employeeName = trim($clientName)."_" .trim($firstName) . " " . $lastName;
            $date         = $value[0]['dateend'];
            $createDate   = new \DateTime($date);

            $weekStartDate = $createDate->format('m-d-Y');
            $count = sizeof($value);
            $weekTotalHours = 0;
            $totalHours = 0;

            for ($i=0; $i < $count; $i++) {

                $totalHoursDate = $value[$i]['details'];
                $explodeDate = explode(',', $totalHoursDate);
                $explodeHours = explode(':', $explodeDate['2']);
                $totalByHours = ($explodeHours['1'] * 60 * 60);
                $totalByMinutes = ($explodeHours['2'] * 60);
                $totalBySeconds = ($explodeHours['3']);
                $weekTotalHours = ($totalByHours + $totalByMinutes + $totalBySeconds) + $weekTotalHours;

                }

                $totalHoursCalculated = $weekTotalHours/60;
                $weekTotalHoursCalculated = $totalHoursCalculated/60;
                $weekTotalHoursCalculatedByRoundUp = number_format((float)$weekTotalHoursCalculated, 2, '.', '');

                $employeeFileLocation = $firstName . "_" . $lastName . "_" . $weekTotalHoursCalculatedByRoundUp. "hours"."_" . $weekStartDate;

                $fileLocation = $timeSheetLocation. $employeeName . '/' . $employeeFileLocation . '.pdf';

                if (!file_exists($fileLocation)) {

               $this->get('knp_snappy.pdf')->generateFromHtml($html, $fileLocation );
            }

        }

        return $this->render("vTechSolutionTimeSheetBundle:timesheet:success.html.twig");

    }

    /**
     * @Route("/timesheetprocess/fromhrmtosaas", name="v_tech_solution_time_sheet_timesheet_date_status_saas")
     * @Method({"POST"} )
     */

     public function getTimeSheetProcessStatusBySaas()
     {
        $this->initAction();

        $this->responseArray = $this->timeSheetService->getTimeSheetProcessStatusBySaas();

        return new JsonResponse($this->responseArray);
     }

     /**
     * @Route("/auto/autogenerate", name="v_tech_solution_time_sheet_timesheet_autogenerate")
     * @Method({"GET"} )
     */
     public function getTimeSheetProcessAutoGenerate()
     {

        $this->initAction();

        $this->responseArray = $this->timeSheetService->getTimeSheetProcessAutoGenerate();

        return $this->render("vTechSolutionTimeSheetBundle:timesheet:success.html.twig");

      }

      /**
     * @Route("/pending/exclude", name="v_tech_solution_time_sheet_timesheet_exclude")
     * @Method({"GET","POST"} )
     */
     public function getTimeSheetDetalisFromHrmAction()
     {

        $this->initAction();

        $this->responseArray = $this->timeSheetService->getTimeSheetDetalisFromHrm();

        return new JsonResponse($this->responseArray);

      }

      /**
     * @Route("/pending/exclude/list", name="v_tech_solution_time_sheet_timesheet_exclude_list")
     * @Method({"GET","POST"})
     */
     public function getExcludeTimeSheetDetalisAction()
     {

        $this->initAction();

        $this->responseArray = $this->timeSheetService->getExcludeTimeSheetDetalis();

        return new JsonResponse($this->responseArray);

      }

       /**
     * @Route("/pending/pendingemail", name="v_tech_solution_time_sheet_timesheet_pendingemail")
     * @Method({"POST","GET"} )
     */
     public function getPendingTimeSheet()
     {

        $this->initAction();

        $this->responseArray = $this->timeSheetService->getPendingTimeSheet();

        return new JsonResponse($this->responseArray);

      }

    /**
     * @Route("/pending/pendingemail/duedate", name="v_tech_solution_time_sheet_timesheet_pendingemail_due_date")
     * @Method({"GET","POST"})
     */

      public function getPendingTimeSheetAccordingDueDateAction() {

        $this->initAction();

        $this->responseArray = $this->timeSheetService->getPendingTimeSheetDueDate();

        return new JsonResponse($this->responseArray);

      }
}

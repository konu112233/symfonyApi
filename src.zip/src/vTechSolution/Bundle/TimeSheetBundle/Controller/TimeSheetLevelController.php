<?php

namespace vTechSolution\Bundle\TimeSheetBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\JsonResponse;
use Nelmio\ApiDocBundle\Annotation\ApiDoc;


/**
 * @Route("/api/v1/timesheetlayer")
*/

class TimeSheetLevelController extends Controller
{

    private $responseArray;
    private $request;
    private $timeSheetLevelService;


    private function initAction()
    {

        $this->responseArray = array();
        $this->request = $this->getRequest();
        $this->timeSheetLevelService = $this->get('v_tech_solution_time_sheet.level');

    }

    /**
     * @Route("/layer", name="v_tech_solution_timesheet_level")
     * @Method({"POST"} )
     */
    public function getTimeSheetDetailsAction()
    {
    	 $this->initAction();

         $this->responseArray = $this->timeSheetLevelService->getTimeSheetDetails();

        return new JsonResponse($this->responseArray);
    }

    /**
     * @Route("/getalldetails", name="v_tech_solution_timesheet_getalldetails")
     * @Method({"GET","POST"} )
     */
    public function getAllDetailsAction() {

        $this->initAction();

        $this->responseArray = $this->timeSheetLevelService->getAllDetailsFromActivity();

        return new JsonResponse($this->responseArray);
    }
    /**
     * @Route("/addleave", name="v_tech_solution_timesheet_add_leave")
     * @Method({"POST"} )
     */
    public function addUpdateLeaveAction() {

        $this->initAction();

        $this->responseArray = $this->timeSheetLevelService->addUpdateLeave();

        return new JsonResponse($this->responseArray);
    }
    /**
     * @Route("/deleteleave", name="v_tech_solution_timesheet_delete_leave")
     * @Method({"POST"} )
     */
    public function deleteLeaveAction() {

        $this->initAction();

        $this->responseArray = $this->timeSheetLevelService->deleteLeave();

        return new JsonResponse($this->responseArray);
    }
}

<?php

namespace vTechSolution\Bundle\TimeSheetBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\JsonResponse;
use Nelmio\ApiDocBundle\Annotation\ApiDoc;
use Symfony\Component\HttpFoundation\Request;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;

/**
 * @Route("/api/v1/candidatestatus")
 */


class CandidateStatusController extends Controller
{


   	private $responseArray;
    private $request;
    private $timeSheetService;


    private function initAction()
    {

        $this->responseArray = array();
        $this->request = $this->getRequest();
        $this->timeSheetService = $this->get('v_tech_solution_candidate_status.status');

    }

    /**
     * @Route("/submitted", name="v_tech_solution_candidate_status_submitted")
     * @Method({"POST"} )
     */
    public function candidateStatusProcess()
    {
    	$this->initAction();
    	$this->responseArray = $this->timeSheetService->ChangeStatusProcess();

    	return new JsonResponse($this->responseArray);

	}

    /**
     * @Route("/interview", name="v_tech_solution_candidate_status_status")
     * @Method({"POST"} )
     */
    public function candidateStatusAfterInterview() {

        $this->initAction();
        $this->responseArray = $this->timeSheetService->candidateStatusProcessAfterInterview();

        return new JsonResponse($this->responseArray);
    }
}

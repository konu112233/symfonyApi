<?php

namespace vTechSolution\Bundle\TimeSheetBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * TimesheetActivityLog
 *
 * @ORM\Table(name="timesheet_activity_log")
 * @ORM\Entity(repositoryClass="vTechSolution\Bundle\TimeSheetBundle\Entity\TimesheetActivityLogRepository")
 */

class TimesheetActivityLog
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="candidateId", type="string", length=255)
     */
    private $candidateId;

    /**
     * @var string
     *
     * @ORM\Column(name="userId", type="string", length=255)
     */
    private $userId;

    /**
     * @var string
     *
     * @ORM\Column(name="timesheetId", type="string", length=255,  nullable = true))
     */
    private $timesheetId;

    /**
     * @var string
     *
     * @ORM\Column(name="clientId", type="string", length=255)
     */
    private $clientId;

    /**
     * @var string
     *
     * @ORM\Column(name="start_date", type="string", length=255)
     */
    private $startDate;

    /**
     * @var string
     *
     * @ORM\Column(name="end_date", type="string", length=255)
     */
    private $endDate;

    /**
     * @var string
     *
     * @ORM\Column(name="level", type="string", length=255,  nullable = true))
     */
    private $level;

    /**
     * @var string
     *
     * @ORM\Column(name="status", type="string", length=255,  nullable = true))
     */

    private $status;

    /**
     * @var string
     *
     * @ORM\Column(name="color", type="string", length=255,  nullable = true))
     */

    private $color;
    /**
     * @var string
     *
     * @ORM\Column(name="comments", type="string", length=255,  nullable = true))
     */

    private $comments;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="created_at", type="datetime")
     */
    private $createdAt;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="datetime")
     */
    private $updatedAt;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set candidateId
     *
     * @param string $candidateId
     *
     * @return TimesheetActivityLog
     */
    public function setCandidateId($candidateId)
    {
        $this->candidateId = $candidateId;

        return $this;
    }

    /**
     * Get candidateId
     *
     * @return string
     */
    public function getCandidateId()
    {
        return $this->candidateId;
    }

    /**
     * Set userId
     *
     * @param string $userId
     *
     * @return TimesheetActivityLog
     */
    public function setUserId($userId)
    {
        $this->userId = $userId;

        return $this;
    }

    /**
     * Get userId
     *
     * @return string
     */
    public function getUserId()
    {
        return $this->userId;
    }

    /**
     * Set timesheetId
     *
     * @param string $timesheetId
     *
     * @return TimesheetActivityLog
     */
    public function setTimesheetId($timesheetId)
    {
        $this->timesheetId = $timesheetId;

        return $this;
    }

    /**
     * Get timesheetId
     *
     * @return string
     */
    public function getTimesheetId()
    {
        return $this->timesheetId;
    }

    /**
     * Set clientId
     *
     * @param string $clientId
     *
     * @return TimesheetActivityLog
     */
    public function setClientId($clientId)
    {
        $this->clientId = $clientId;

        return $this;
    }

    /**
     * Get clientId
     *
     * @return string
     */
    public function getClientId()
    {
        return $this->clientId;
    }

    /**
     * Set startDate
     *
     * @param string $startDate
     *
     * @return TimesheetActivityLog
     */
    public function setStartDate($startDate)
    {
        $this->startDate = $startDate;

        return $this;
    }

    /**
     * Get startDate
     *
     * @return string
     */
    public function getStartDate()
    {
        return $this->startDate;
    }

    /**
     * Set endDate
     *
     * @param string $endDate
     *
     * @return TimesheetActivityLog
     */
    public function setEndDate($endDate)
    {
        $this->endDate = $endDate;

        return $this;
    }

    /**
     * Get endDate
     *
     * @return string
     */
    public function getEndDate()
    {
        return $this->endDate;
    }

    /**
     * Set level
     *
     * @param string $level
     *
     * @return TimesheetActivityLog
     */
    public function setLevel($level)
    {
        $this->level = $level;

        return $this;
    }

    /**
     * Get level
     *
     * @return string
     */
    public function getLevel()
    {
        return $this->level;
    }


    /**
     * Get status
     *
     * @return string
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Set status
     *
     * @param string $status
     *
     * @return TimesheetActivityLog
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Set color
     *
     * @param string $color
     *
     * @return TimesheetActivityLog
     */

    public function setColor($color)
    {
        $this->color = $color;

        return $this;
    }

    /**
     * Get color
     *
     * @return string
     */
    public function getColor()
    {
        return $this->color;
    }

    /**
     * Set comments
     *
     * @param string $comments
     *
     * @return TimesheetActivityLog
     */
    public function setComments($comments)
    {
        $this->comments = $comments;

        return $this;
    }

    /**
     * Get comments
     *
     * @return string
     */
    public function getComments()
    {
        return $this->comments;
    }

    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     *
     * @return TimesheetActivityLog
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set updatedAt
     *
     * @param \DateTime $updatedAt
     *
     * @return TimesheetActivityLog
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return \DateTime
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }
}

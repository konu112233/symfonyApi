<?php

namespace vTechSolution\Bundle\TimeSheetBundle\Document;

use Doctrine\ODM\MongoDB\Mapping\Annotations as MongoDB;

/**
 * @MongoDB\Document(repositoryClass="vTechSolution\Bundle\TimeSheetBundle\Document\EmailCandidateTimesheetReminderRepository")
 */
class EmailCandidateTimesheetReminder
{
    /**
    * @MongoDB\Id
    */
    protected $id;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $candidateEmailAddressList;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $candidateSmsAddressList;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $totalNumberOfCandidate;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $dateStart;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $dateEnd;

     /**
    * @MongoDB\Field(type="string")
    */
    protected $userId;

    /**
     * @MongoDB\Date
     */
    protected $createdAt;

    /**
     * Get id
     *
     * @return id $id
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set candidateEmailAddressList
     *
     * @param string $candidateEmailAddressList
     * @return $this
     */
    public function setCandidateEmailAddressList($candidateEmailAddressList)
    {
        $this->candidateEmailAddressList = $candidateEmailAddressList;
        return $this;
    }
    /**
     * Get candidateEmailAddressList
     *
     * @return string $candidateEmailAddressList
     */
    public function getCandidateEmailAddressList()
    {
        return $this->candidateEmailAddressList;
    }

    /**
     * Set candidateSmsAddressList
     *
     * @param string $candidateSmsAddressList
     * @return $this
     */
    public function setCandidateSmsAddressList($candidateSmsAddressList)
    {
        $this->candidateSmsAddressList = $candidateSmsAddressList;
        return $this;
    }
    /**
     * Get candidateSmsAddressList
     *
     * @return string $candidateSmsAddressList
     */
    public function getCandidateSmsAddressList()
    {
        return $this->candidateSmsAddressList;
    }

    /**
     * Set totalNumberOfCandidate
     *
     * @param string $totalNumberOfCandidate
     * @return $this
     */
    public function setTotalNumberOfCandidate($totalNumberOfCandidate)
    {
        $this->totalNumberOfCandidate = $totalNumberOfCandidate;
        return $this;
    }
    /**
     * Get totalNumberOfCandidate
     *
     * @return string $totalNumberOfCandidate
     */
    public function getTotalNumberOfCandidate()
    {
        return $this->totalNumberOfCandidate;
    }

    /**
     * Set dateStart
     *
     * @param string $dateStart
     * @return $this
     */
    public function setDateStart($dateStart)
    {
        $this->dateStart = $dateStart;
        return $this;
    }
    /**
     * Get dateStart
     *
     * @return string $dateStart
     */
    public function getDateStart()
    {
        return $this->dateStart;
    }

    /**
     * Set dateEnd
     *
     * @param string $dateEnd
     * @return $this
     */
    public function setDateEnd($dateEnd)
    {
        $this->dateEnd = $dateEnd;
        return $this;
    }
    /**
     * Get dateEnd
     *
     * @return string $dateEnd
     */
    public function getDateEnd()
    {
        return $this->dateEnd;
    }

     /**
     * Set userId
     *
     * @param string $userId
     * @return $this
     */
    public function setUserId($userId)
    {
        $this->userId = $userId;
        return $this;
    }

    /**
     * Get userId
     *
     * @return string $userId
     */
    public function getUserId()
    {
        return $this->userId;
    }

    /**
     * Set createdAt
     *
     * @param timestamp $createdAt
     * @return $this
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
        return $this;
    }

    /**
     * Get createdAt
     *
     * @return timestamp $createdAt
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }


    /**
     * @MongoDB\PrePersist
     */
    public function onPrePersist()
    {
        $this->createdAt = new DateTime();
    }
}

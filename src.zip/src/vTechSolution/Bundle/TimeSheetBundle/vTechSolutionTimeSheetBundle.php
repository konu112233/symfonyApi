<?php

namespace vTechSolution\Bundle\TimeSheetBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class vTechSolutionTimeSheetBundle extends Bundle
{
}

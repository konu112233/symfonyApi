<?php

namespace vTechSolution\Bundle\AccessControlBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class vTechSolutionAccessControlBundle extends Bundle
{
}

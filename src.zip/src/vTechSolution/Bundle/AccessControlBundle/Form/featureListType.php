<?php

namespace vTechSolution\Bundle\AccessControlBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;

class featureListType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder->add('featureTitle')
                ->add('portalType', ChoiceType::class, array(
                        'choices'   => array('' => 'Select Portal' ,'ATS' => 'ATS', 'Sales' => 'Sales' , 'HRM' => 'HRM' , 'Contract' => 'Contract'),
                        'required'  => true,
                        ))
                ->add('featureOptions')
                ->add('featureType',  ChoiceType::class, array(
                        'choices'   => array('' => 'Select Type' ,'single' => 'Single Select', 'multiple' => 'Multi Select' ),
                        'required'  => true,
                        ));
    }/**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'vTechSolution\Bundle\AccessControlBundle\Entity\featureList'
        ));
    }

    /**
     * {@inheritdoc}
     */
    public function getBlockPrefix()
    {
        return 'vtechsolution_bundle_accesscontrolbundle_featurelist';
    }


}

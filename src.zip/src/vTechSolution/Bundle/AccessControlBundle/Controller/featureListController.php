<?php

namespace vTechSolution\Bundle\AccessControlBundle\Controller;

use vTechSolution\Bundle\AccessControlBundle\Entity\featureList;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Request;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use vTechSolution\Bundle\AccessControlBundle\Form\featureListType;

/**
 * Featurelist controller.
 *
 * @Route("/featurelist")
 */
class featureListController extends Controller
{

    private $responseArray;
    private $request;
    private $accessControlService;

    private function initAction()
    {
      $this->responseArray = array();
      $this->request = $this->getRequest();

      $this->accessControlService = $this->get('v_tech_solution_access_control.start');
    }

    /**
     * Lists all featureList entities.
     *
     * @Route("/list-all", name="vtech_solution_bundle_access_template_list_all")
     * @Template("vTechSolutionAccessControlBundle:featureList:index.html.twig")
     * @Method("GET")
     */
    public function indexAction()
    {
        $this->initAction();

        $this->responseArray['featureLists'] = $this->accessControlService->getAllFeatureList();

        return $this->responseArray;
    }

    /**
     * Creates a new featureList entity.
     *
     * @Route("/new", name="featurelist_new")
     * @Method({"GET", "POST"})
     * @Template("vTechSolutionAccessControlBundle:featureList:new.html.twig")
     */
    public function newAction(Request $request)
    {
        $featureList = new Featurelist();
        $form = $this->createForm('', $featureList);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($featureList);
            $em->flush();

            return $this->redirectToRoute('featurelist_show', array('id' => $featureList->getId()));
        }

        return $this->render('featurelist/new.html.twig', array(
            'featureList' => $featureList,
            'form' => $form->createView(),
        ));
    }

    /**
     * Creates a new emailTemplate entity.
     *
     * @Route("/add", name="vtech_solution_bundle_access_add_feature_template")
     * @Method({"GET"})
     * @Template("vTechSolutionAccessControlBundle:featureList:new.html.twig")
     */
    public function addEmailTemplateAction(Request $request)
    {
        $this->initAction();

        $this->responseArray["form"] = $this->createForm(new featureListType(), new featurelist())->createView();

        return $this->responseArray;
    }

    /**
     * Creates a new emailTemplate entity.
     *
     * @Route("/add", name="vtech_solution_bundle_access_process_feature_template")
     * @Method({"POST"})
     * @Template("vTechSolutionAccessControlBundle:featureList:new.html.twig")
     */
    public function processEmailTemplateAction()
    {
        $this->initAction();
        $emailTemplate = new featurelist();
        $form  = $this->createForm(new featureListType(), $emailTemplate);
        $form->handleRequest($this->request);

        if ($form->isSubmitted() && $form->isValid()) {
            $emailTemplate = $this->accessControlService->addFeature($emailTemplate);

            return $this->redirectToRoute('vtech_solution_bundle_access_template_list_all', array('id' => $emailTemplate->getId()));
        } else {
            $this->responseArray['form'] = $form->createView();
        }

        return $this->responseArray;
    }

    /**
     * Finds and displays a featureList entity.
     *
     * @Route("/{id}", name="featurelist_show")
     * @Method("GET")
     */
    public function showAction(featureList $featureList)
    {
        $deleteForm = $this->createDeleteForm($featureList);

        return $this->render('featurelist/show.html.twig', array(
            'featureList' => $featureList,
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Displays a form to edit an existing emailTemplate entity.
     *
     * @Route("/edit/{id}", name="vtech_solution_bundle_access_template_edit")
     * @Template("vTechSolutionAccessControlBundle:featureList:edit.html.twig")
     * @Method({"GET"})
     */
    public function editAction(featureList $emailTemplate)
    {

        $this->initAction();

        $deleteForm = $this->createDeleteForm($emailTemplate);
        $editForm = $this->createForm(new featureListType(), $emailTemplate);

        $this->responseArray['featureList'] = $emailTemplate;
        $this->responseArray['edit_form'] = $editForm->createView();
        $this->responseArray['delete_form'] = $deleteForm->createView();
        $this->responseArray['form_id'] = $this->request->get('id');
        $this->responseArray['iframe'] = $this->request->get('iframe');

        return $this->responseArray;
    }

    /**
     * Displays a form to edit an existing emailTemplate entity.
     *
     * @Route("/edit/{id}", name="vtech_solution_bundle_access_process_template_edit")
     * @Template("vTechSolutionAccessControlBundle:featureList:edit.html.twig")
     * @Method({"POST"})
     */
    public function processEditTemplateAction(Request $request, featureList $emailTemplate)
    {
      $this->initAction();

      $editForm = $this->createForm(new featureListType(), $emailTemplate);
      $editForm->handleRequest($request);
      if ($editForm->isSubmitted() && $editForm->isValid()) {
          $emailTemplate = $this->accessControlService->editFeature($emailTemplate);
          $this->responseArray['iframe'] = $this->request->get('iframe');
          if ($this->responseArray['iframe'] == true) {
              return $this->redirectToRoute('vtech_solution_bundle_access_template_list_all', array('id' => $emailTemplate->getId(),
                    'iframe' => 1
                    ));
          } else {
                return $this->redirectToRoute('vtech_solution_bundle_access_process_template_edit', array('id' => $emailTemplate->getId()));
            }
        }

      return $this->responseArray;
    }

    /**
     * Deletes a featureList entity.
     *
     * @Route("/{id}", name="featurelist_delete")
     * @Method("DELETE")
     */
    public function deleteAction(Request $request, featureList $featureList)
    {
        $form = $this->createDeleteForm($featureList);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($featureList);
            $em->flush();
        }

        return $this->redirectToRoute('vtech_solution_bundle_access_template_list_all');
    }

    /**
     * Creates a form to delete a featureList entity.
     *
     * @param featureList $featureList The featureList entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(featureList $featureList)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('featurelist_delete', array('id' => $featureList->getId())))
            ->setMethod('DELETE')
            ->getForm()
        ;
    }
}

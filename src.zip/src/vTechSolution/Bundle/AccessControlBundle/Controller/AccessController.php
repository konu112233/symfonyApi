<?php

namespace vTechSolution\Bundle\AccessControlBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Entity\ComplianceList;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use vTechSolution\Bundle\AccessControlBundle\Form\AccessControlTemplate;
use vTechSolution\Bundle\AccessControlBundle\Entity\featureList;

/**
   * @Route("/api/v1/access")
 */
class AccessController extends Controller
{
	  private $responseArray;
    private $request;
    private $accessControlService;

    private function initAction()
    {
      $this->responseArray = array();
      $this->request = $this->getRequest();

      $this->accessControlService = $this->get('v_tech_solution_access_control.start');
    }

	


	 /**
   * @Route("/getfeaturelist", name="vtech_solution_access_bundle_get_feature_list")
   * @Method({"GET"})
   */

	public function getFeatureAction() {

		$this->initAction();
		
		$this->responseArray = $this->accessControlService->getAllFeatureList();
		// $this->responseArray = $this->screeningService->addScreeningQuestionFeedback();
		// print_r($this->responseArray); die;

		return new JsonResponse($this->responseArray);

	}  

  /**
   * @Route("/addgroup", name="vtech_solution_access_bundle_add_group")
   * @Method({"POST"})
   */

  public function addGroupAction() {

    $this->initAction();
    
    $this->responseArray = $this->accessControlService->addGroup();
    
    return new JsonResponse($this->responseArray);

  } 

  /**
   * @Route("/editgroup", name="vtech_solution_access_bundle_edit_group")
   * @Method({"POST"})
   */

  public function editGroupAction() {

    $this->initAction();
    
    $this->responseArray = $this->accessControlService->editGroup();
    
    return new JsonResponse($this->responseArray);

  } 

  /**
   * @Route("/add-user-to-group", name="vtech_solution_access_bundle_add_user_to_group")
   * @Method({"POST"})
   */

  public function addUserToGroupAction() {

    $this->initAction();
    
    $this->responseArray = $this->accessControlService->addUserToGroup();
    
    return new JsonResponse($this->responseArray);

  }

  /**
   * @Route("/get-access-group", name="vtech_solution_access_bundle_get_access_group")
   * @Method({"GET"})
   */

  public function getAllAccessFeatureListAction() {

    $this->initAction();
    
    $this->responseArray = $this->accessControlService->getAllAccessFeatureList();
    
    return new JsonResponse($this->responseArray);

  }

  /**
   * @Route("/getgroup", name="vtech_solution_access_bundle_get_group")
   * @Method({"GET"})
   */

  public function getATSGroupListAction() {

    $this->initAction();
    
    $this->responseArray = $this->accessControlService->getATSGroupList();
    
    return new JsonResponse($this->responseArray);

  }  

  /**
   * @Route("/get-group-permission", name="vtech_solution_access_bundle_get_group_permission")
   * @Method({"GET"})
   */

  public function getGroupPermissionAction() {

    $this->initAction();
    
    $this->responseArray = $this->accessControlService->getGroupPermission();
    
    return new JsonResponse($this->responseArray);

  }  

    /**
   * @Route("/get-all-group-permission",
   name="vtech_solution_access_bundle_get_all_group_permission")
   * @Method({"GET"})
   */

  public function getAllGroupPermissionAction() {

    $this->initAction();
    
    $this->responseArray = $this->accessControlService->getAllGroupPermission();
    
    return new JsonResponse($this->responseArray);

  }  

  /**
    * @Route("/delete-group", name="vtech_solution_access_bundle_delete_group")
    * @Method({"POST"} )
  */
    public function deleteGroupAction() {

      $this->initAction();

      $this->responseArray = $this->accessControlService->deleteGroup();

      return new JsonResponse($this->responseArray);
  }

  /**
    * @Route("/remove-group", name="vtech_solution_access_bundle_remove_group")
    * @Method({"POST"} )
  */
    public function removeAssignGroupAction() {

      $this->initAction();

      $this->responseArray = $this->accessControlService->removeAssignGroup();

      return new JsonResponse($this->responseArray);
  }


  /**
   * @Route("/get-default-group", name="vtech_solution_access_bundle_get_default_group")
   * @Method({"GET"})
   */

  public function getDefaultCatsGroupAction() {

    $this->initAction();
    
    $this->responseArray = $this->accessControlService->getDefaultCatsGroup();
    
    return new JsonResponse($this->responseArray);

  }


  /**
   * @Route("/get-group-feature-user", name="vtech_solution_access_bundle_get_group_feature_user")
   * @Method({"GET"})
   */

  public function getAllAccessFeatureListByUserAction() {

    $this->initAction();
    
    $this->responseArray = $this->accessControlService->getAllAccessFeatureListByUser();
    
    return new JsonResponse($this->responseArray);

  }

}
<?php

namespace vTechSolution\Bundle\AccessControlBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * featureList
 *
 * @ORM\Table(name="vtech_feature_list")
 * @ORM\Entity(repositoryClass="vTechSolution\Bundle\AccessControlBundle\Entity\featureListRepository")
 */
class featureList
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="feature_title", type="string", length=255)
     */
    private $featureTitle;

    /**
     * @var string
     *
     * @ORM\Column(name="portal_type", type="string", length=255)
     */
    private $portalType;

    /**
     * @var string
     *
     * @ORM\Column(name="feature_options", type="string", length=255)
     */
    private $featureOptions;

    /**
     * @var string
     *
     * @ORM\Column(name="feature_type", type="string", length=255)
     */
    private $featureType;

    /**
     * @var string
     *
     * @ORM\Column(name="created_by", type="string", length=255)
     */
    private $createdBy;

    /**
     * @var string
     *
     * @ORM\Column(name="created_at", type="string", length=255)
     */
    private $createdAt;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set featureTitle
     *
     * @param string $featureTitle
     *
     * @return featureList
     */
    public function setFeatureTitle($featureTitle)
    {
        $this->featureTitle = $featureTitle;

        return $this;
    }

    /**
     * Get featureTitle
     *
     * @return string
     */
    public function getFeatureTitle()
    {
        return $this->featureTitle;
    }

    /**
     * Set portalType
     *
     * @param string $portalType
     *
     * @return featureList
     */
    public function setPortalType($portalType)
    {
        $this->portalType = $portalType;

        return $this;
    }

    /**
     * Get portalType
     *
     * @return string
     */
    public function getPortalType()
    {
        return $this->portalType;
    }

    /**
     * Set featureOptions
     *
     * @param string $featureOptions
     *
     * @return featureList
     */
    public function setFeatureOptions($featureOptions)
    {
        $this->featureOptions = $featureOptions;

        return $this;
    }

    /**
     * Get featureOptions
     *
     * @return string
     */
    public function getFeatureOptions()
    {
        return $this->featureOptions;
    }

    /**
     * Set featureType
     *
     * @param string $featureType
     *
     * @return featureList
     */
    public function setFeatureType($featureType)
    {
        $this->featureType = $featureType;

        return $this;
    }

    /**
     * Get featureType
     *
     * @return string
     */
    public function getFeatureType()
    {
        return $this->featureType;
    }

    /**
     * Set createdBy
     *
     * @param string $createdBy
     *
     * @return featureList
     */
    public function setCreatedBy($createdBy)
    {
        $this->createdBy = $createdBy;

        return $this;
    }

    /**
     * Get createdBy
     *
     * @return string
     */
    public function getCreatedBy()
    {
        return $this->createdBy;
    }

    /**
     * Set createdAt
     *
     * @param string $createdAt
     *
     * @return featureList
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return string
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }
}


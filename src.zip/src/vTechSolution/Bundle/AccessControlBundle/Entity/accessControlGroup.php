<?php

namespace vTechSolution\Bundle\AccessControlBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * accessControlGroup
 *
 * @ORM\Table(name="vtech_access_control_group")
 * @ORM\Entity(repositoryClass="vTechSolution\Bundle\AccessControlBundle\Entity\accessControlGroupRepository")
 */
class accessControlGroup
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="group_title", type="string", length=255)
     */
    private $groupTitle;

    /**
     * @var string
     *
     * @ORM\Column(name="created_by", type="string", length=255)
     */
    private $createdBy;

    /**
     * @var string
     *
     * @ORM\Column(name="created_at", type="string", length=255)
     */
    private $createdAt;

    /**
     * @var int
     *
     * @ORM\Column(name="status", type="integer" )
     */
    private $status;

    /**
     * @var string
     *
     * @ORM\Column(name="deleted_at", type="string", nullable = true)
     */
    private $deletedAt;

    /**
     * @var string
     *
     * @ORM\Column(name="deleted_by", type="string", length=255, nullable = true)
     */
    private $deletedBy;

    /**
     * @var int
     *
     * @ORM\Column(name="is_default", type="integer", nullable = true)
     */
    private $isDefault;

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set groupTitle
     *
     * @param string $groupTitle
     *
     * @return accessControlGroup
     */
    public function setGroupTitle($groupTitle)
    {
        $this->groupTitle = $groupTitle;

        return $this;
    }

    /**
     * Get groupTitle
     *
     * @return string
     */
    public function getGroupTitle()
    {
        return $this->groupTitle;
    }

    /**
     * Set createdBy
     *
     * @param string $createdBy
     *
     * @return accessControlGroup
     */
    public function setCreatedBy($createdBy)
    {
        $this->createdBy = $createdBy;

        return $this;
    }

    /**
     * Get createdBy
     *
     * @return string
     */
    public function getCreatedBy()
    {
        return $this->createdBy;
    }

    /**
     * Set createdAt
     *
     * @param string $createdAt
     *
     * @return accessControlGroup
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return string
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set status
     *
     * @param integer $status
     *
     * @return accessControlGroup
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status
     *
     * @return int
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Set deletedAt
     *
     * @param string $deletedAt
     *
     * @return accessControlGroup
     */
    public function setDeletedAt($deletedAt)
    {
        $this->deletedAt = $deletedAt;

        return $this;
    }

    /**
     * Get deletedAt
     *
     * @return string
     */
    public function getDeletedAt()
    {
        return $this->deletedAt;
    }

    /**
     * Set isDefault
     *
     * @param integer $isDefault
     *
     * @return accessControlGroup
     */
    public function setIsDefault($isDefault)
    {
        $this->isDefault = $isDefault;

        return $this;
    }

    /**
     * Get isDefault
     *
     * @return int
     */
    public function getIsDefault()
    {
        return $this->isDefault;
    }

    /**
     * Set deletedBy
     *
     * @param string $deletedBy
     *
     * @return accessControlGroup
     */
    public function setDeletedBy($deletedBy)
    {
        $this->deletedBy = $deletedBy;

        return $this;
    }

    /**
     * Get deletedBy
     *
     * @return string
     */
    public function getDeletedBy()
    {
        return $this->deletedBy;
    }
}


<?php

namespace vTechSolution\Bundle\AccessControlBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * featureGroupMapping
 *
 * @ORM\Table(name="vtech_feature_group_mapping")
 * @ORM\Entity(repositoryClass="vTechSolution\Bundle\AccessControlBundle\Entity\featureGroupMappingRepository")
 */
class featureGroupMapping
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var int
     *
     * @ORM\Column(name="group_id", type="integer")
     */
    private $groupId;

    /**
     * @var int
     *
     * @ORM\Column(name="feature_id", type="integer")
     */
    private $featureId;

    /**
     * @var string
     *
     * @ORM\Column(name="feature_value", type="string", length=255)
     */
    private $featureValue;

    /**
     * @var string
     *
     * @ORM\Column(name="feature_key", type="string", length=255)
     */
    private $featureKey;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set groupId
     *
     * @param integer $groupId
     *
     * @return featureGroupMapping
     */
    public function setGroupId($groupId)
    {
        $this->groupId = $groupId;

        return $this;
    }

    /**
     * Get groupId
     *
     * @return int
     */
    public function getGroupId()
    {
        return $this->groupId;
    }

    /**
     * Set featureId
     *
     * @param integer $featureId
     *
     * @return featureGroupMapping
     */
    public function setFeatureId($featureId)
    {
        $this->featureId = $featureId;

        return $this;
    }

    /**
     * Get featureId
     *
     * @return int
     */
    public function getFeatureId()
    {
        return $this->featureId;
    }

    /**
     * Set featureValue
     *
     * @param string $featureValue
     *
     * @return featureGroupMapping
     */
    public function setFeatureValue($featureValue)
    {
        $this->featureValue = $featureValue;

        return $this;
    }

    /**
     * Get featureValue
     *
     * @return string
     */
    public function getFeatureValue()
    {
        return $this->featureValue;
    }

    /**
     * Set featureKey
     *
     * @param string $featureKey
     *
     * @return featureGroupMapping
     */
    public function setFeatureKey($featureKey)
    {
        $this->featureKey = $featureKey;

        return $this;
    }

    /**
     * Get featureKey
     *
     * @return string
     */
    public function getFeatureKey()
    {
        return $this->featureKey;
    }
}


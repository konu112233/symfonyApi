<?php

namespace vTechSolution\Bundle\AccessControlBundle\Manager;

use Symfony\Component\DependencyInjection\ContainerInterface as Container;

use vTechSolution\Bundle\AccessControlBundle\Entity\accessControlGroup;
use vTechSolution\Bundle\AccessControlBundle\Entity\featureAccessMapping;
use vTechSolution\Bundle\AccessControlBundle\Entity\featureGroupMapping;
use vTechSolution\Bundle\AccessControlBundle\Entity\featureList;
use Symfony\Component\HttpFoundation\Request;

class AccessControlService
{

    private $container;
    private $doctrine;
    private $request;
    private $responseArray;

    const HTTP_METHOD_GET = 'GET';
    const HTTP_METHOD_POST = 'POST';

	public function __construct(Container $container) {
        $this->container= $container;
        $this->request = $this->container->get('request');
        $this->responseArray = array();
        $this->doctrine = $this->container->get('doctrine');
        $this->accessControlGroupRepository = $this->doctrine->getRepository('vTechSolutionAccessControlBundle:accessControlGroup');
        $this->featureAccessMappingRepository = $this->doctrine->getRepository('vTechSolutionAccessControlBundle:featureAccessMapping');
		$this->featureGroupMappingRepository = $this->doctrine->getRepository('vTechSolutionAccessControlBundle:featureGroupMapping');
		$this->featureListRepository = $this->doctrine->getRepository('vTechSolutionAccessControlBundle:featureList');

    }

    public function __destructor()
    {
        unset($this->container);
        unset($this->request);
        unset($this->responseArray);
    }

	public function addGroup() {

		$groupName = $this->request->get('group_name');
		$loginUserId = $this->request->get('login_id');
		$featureGroup = $this->request->get('feature_group');

		$accessControlGroup = new accessControlGroup();
		$accessControlGroup->setGroupTitle($groupName);
		$accessControlGroup->setCreatedAt(date("Y-m-d H:i:s"));
		$accessControlGroup->setCreatedBy($loginUserId);
		$accessControlGroup->setStatus(1);

		$this->accessControlGroupRepository->commit($accessControlGroup);

			$groupId = $accessControlGroup->getId(); 

			foreach ($featureGroup as $featureKey => $featureValue) {
			
				 
				$featurekeys = isset($featureValue['visibility']) ? $featureValue['visibility'] : "" ;
				
				if(isset($featureValue['checkboxvisibility'])){
					$featurekeys = implode(",", $featureValue['checkboxvisibility']);
				}

				if( $featurekeys == 'hidden') {
					$featureValues = 0;
				}elseif( $featurekeys == NULL ){
					$featureValues = "";
				}else{
					$featureValues = 1;
				}

				if( $featurekeys == 'visible' || $featurekeys == 'hidden' ) {
					$featurekeys = $featureValue['feature_name'];
				}
				
				$featureGroupMapping = new featureGroupMapping();
    			$featureGroupMapping->setGroupId($groupId);
    			$featureGroupMapping->setFeatureId($featureValue['feature_id']);
    			$featureGroupMapping->setFeatureValue($featureValues);
    			$featureGroupMapping->setFeatureKey($featurekeys);

    	$this->featureGroupMappingRepository->commit($featureGroupMapping);
		
		}

	}

	public function editGroup() {

		$groupId = $this->request->get('gId');
		$accessControlGroup = $this->accessControlGroupRepository->findByGroupId($groupId);
		
		$groupName = $this->request->get('groups');
		$loginUserId = $this->request->get('login_id');
		$featureGroup = $this->request->get('feature_group');
		
		if ( count($accessControlGroup) > 0 ) {

			$accessControlGroup->setGroupTitle($groupName);
			$accessControlGroup->setCreatedAt(date("Y-m-d H:i:s"));
			$accessControlGroup->setCreatedBy($loginUserId);
			$accessControlGroup->setStatus(1);

			$this->accessControlGroupRepository->commit($accessControlGroup);
		

			foreach ($featureGroup as $featureValue) {
				

				$featurekeys = isset($featureValue['visibility']) ? $featureValue['visibility'] : "" ;
				
				if(isset($featureValue['checkboxvisibility'])){
					$featurekeys = implode(",", $featureValue['checkboxvisibility']);
				}

				if( $featurekeys == 'hidden') {
					$featureValues = 0;
				}elseif( $featurekeys == NULL ){
					$featureValues = "";
				}else{
					$featureValues = 1;
				}

				if( $featurekeys == 'visible' || $featurekeys == 'hidden' ) {
					$featurekeys = $featureValue['feature_name'];
				}

				$featureGroupMapping = $this->featureGroupMappingRepository->getGroupPermissionLists($groupId,$featureValue['feature_id']);
				if(!empty($featureGroupMapping)){
					$featureGroupMapping->setGroupId($groupId);
    				$featureGroupMapping->setFeatureId($featureValue['feature_id']);
    				$featureGroupMapping->setFeatureValue($featureValues);
    				$featureGroupMapping->setFeatureKey($featurekeys);
    			}else{
    				$featureGroupMapping = new featureGroupMapping();
    				$featureGroupMapping->setGroupId($groupId);
    				$featureGroupMapping->setFeatureId($featureValue['feature_id']);
    				$featureGroupMapping->setFeatureValue($featureValues);
    				$featureGroupMapping->setFeatureKey($featurekeys);
    			}

				$this->featureGroupMappingRepository->commit($featureGroupMapping);
			}
		}
	}

	public function addUserToGroup() {

		$userId = $this->request->get('userId');
		$groupId = $this->request->get('group_id');
		$loginUserId = $this->request->get('login_id');
		$null = '';


		$featureAccessMapping = new featureAccessMapping();
		$featureAccessMapping->setUserId($userId);
		$featureAccessMapping->setGroupId($groupId);
		$featureAccessMapping->setCreatedAt(date("Y-m-d H:i:s"));
		$featureAccessMapping->setCreatedBy($loginUserId);
		$featureAccessMapping->setDeletedBy($null);
		$featureAccessMapping->setDeletedAt($null);
		$featureAccessMapping->setStatus(1);


		$this->featureAccessMappingRepository->commit($featureAccessMapping);
		
	}

	

	public function getAllFeatureList() {

		return $this->featureListRepository->getFeatureList();				
		
	}

	public function getDefaultCatsGroup() {

		return $this->accessControlGroupRepository->getDefaultGroup();				
		
	}

	public function getAllAccessFeatureList() {

		$list = $this->featureAccessMappingRepository->getAllUserAccessPermissionList();
		
		foreach ($list as $key => $value) {
							
			$groupName =  $this->accessControlGroupRepository->findByGroupIds($value['groupId']);

			$finalList[] = array("userId" => $value['userId'] , "groupId" => $value['groupId'], "groupName" => $groupName[0]['groupTitle'] ); 
		}	

		return $finalList;			
		
	}

	public function getAllAccessFeatureListByUser() {

		$userId = $this->request->get('user_id');

		$groups = $this->featureAccessMappingRepository->getAllGroupListByUserId($userId);
		
		if(count($groups) > 0) {
		
			foreach ($groups as $key => $value) {
				
				if($value['status'] == 1) {
				
				$groupData[] = $this->featureGroupMappingRepository->getGroupPermissionList($value['groupId']);
				}
			}
		
		}

		return $groupData;
		
	}

	public function getATSGroupList() {

		return $this->accessControlGroupRepository->getATSGroup();				
		
	}

	public function addFeature($emailTemplate) {

		$emailTemplate->setCreatedAt(date("Y-m-d H:i:s"));
		$emailTemplate->setCreatedBy(1);

		$this->featureListRepository->commit($emailTemplate);

		return $emailTemplate;
	}

	public function editFeature($emailTemplate) {

		$emailTemplate->setCreatedAt(date("Y-m-d H:i:s"));
		$emailTemplate->setCreatedBy(1);

		$this->featureListRepository->commit($emailTemplate);

		return $emailTemplate;
	}

	public function getGroupPermission() {

		$groupId = $this->request->get('group_id');
		
		$groupData = $this->featureListRepository->getFeatureList();

		foreach($groupData as $groupKey => $groupValue) {

			$singleFeature = $this->featureGroupMappingRepository->getGroupPermissionListArray($groupId,$groupValue['id']); 
			if(empty($singleFeature)){
				$singleFeature[0]['featureValue'] = '';
				$singleFeature[0]['featureKey'] = '';
			}
			$featureArray[] = array("featureTitle" => $groupValue['featureTitle'] , "featureOptions" => $groupValue['featureOptions'] , "id" => $groupValue['id'] , "featureValue" => $singleFeature[0]['featureValue'] , "featureKey" => $singleFeature[0]['featureKey'] );
		}	

		return $featureArray;	

	}

	public function deleteGroup() {

        $groupId = $this->request->get('groupId');
        $loginId = $this->request->get('loginUser'); 
        $group = $this->accessControlGroupRepository->findByGroupId($groupId);
        $countUser = $this->featureAccessMappingRepository->countUserByGroup($groupId);
        
        if ( count($group) > 0 && $countUser == 0 ) {

            $group->setStatus(0);
            $group->setDeletedAt(date("Y-m-d H:i:s"));
            $group->setDeletedBy($loginId);

            $this->accessControlGroupRepository->commit($group);


            $this->responseArray = array("status" => "success", "message" => "Group successfully deleted");

    	
            // foreach ($allData as $key => $value) {
            	
            // 	$value->setStatus(0);

            // 	$this->featureAccessMappingRepository->commit($value);
            // }
            	
            
        }
        
        
        return $this->responseArray;

    }

    public function removeAssignGroup() {

        $userId = $this->request->get('userId');
        $loginId = $this->request->get('loginId'); 
        $userGroup = $this->featureAccessMappingRepository->getAllGroupByUserId($userId);
        
       	
       		
        if ( count($userGroup) > 0 ) {

        	foreach ($userGroup as $valueGroup) {
            	$valueGroup->setStatus(0);
            	$valueGroup->setDeletedAt(date("Y-m-d H:i:s"));
            	$valueGroup->setDeletedBy($loginId);

            	$this->featureAccessMappingRepository->commit($valueGroup);


            	$this->responseArray = array("status" => "success", "message" => "Group successfully deleted");

    	
            // foreach ($allData as $key => $value) {
            	
            // 	$value->setStatus(0);

            // 	$this->featureAccessMappingRepository->commit($value);
            // }
            	
            
        	}
        }
        
        return $this->responseArray;

    }

	public function getAllGroupPermission() {

		$groupData = $this->accessControlGroupRepository->getATSGroup();

		foreach($groupData as $groupKey => $groupValue) {
			
			$mappingData = $this->featureGroupMappingRepository->getGroupPermissionList($groupValue['id']);

			$countUserOfGroup = $this->featureAccessMappingRepository->countUserByGroup($groupValue['id']);
			
			foreach ($mappingData as $mapKey => $mapValue) {
				
				$groupArray[$groupValue['id']][] = array( "groupId" => $groupValue['id'] , "groupName" => $groupValue['groupTitle'] , "visibleFeature" => $mapValue['featureValue'] , "totalUser" => $countUserOfGroup );
			}
			
			
		}		
		return $groupArray;	

	}

}


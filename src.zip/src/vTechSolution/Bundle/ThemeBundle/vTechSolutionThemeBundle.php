<?php

namespace vTechSolution\Bundle\ThemeBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class vTechSolutionThemeBundle extends Bundle
{
}

<?php

namespace vTechSolution\Bundle\ThemeBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\JsonResponse;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;

class DefaultController extends Controller
{
    private $responseArray;
    private $request;

    private function initAction()
    {
      $this->responseArray = array();
      $this->request = $this->getRequest();

      $this->dashboardService = $this->get('v_tech_solution_theme.theme');
    }

    /**
     * @Route("/admin")
     */
    public function indexAction()
    {
        return $this->render('vTechSolutionThemeBundle:AdminTheme:base.html.twig');
    }

    /**
     * @Route("/email")
     */
    public function emailModule()
    {
        return $this->render('vTechSolutionThemeBundle:AdminTheme:emailtemplatelist.html.twig');
    }


    /**
     * @Route("/dashboard", name="vtech_solution_bundle_theme_dashboard")
     * @Method({"GET"} )
     * @Template("vTechSolutionThemeBundle:AdminTheme:dashboard.html.twig")
     */

    public function dashboardCount() {

      $this->initAction();

      $this->responseArray["count"] = $this->dashboardService->getCount();
      $this->responseArray["textCount"] = $this->dashboardService->getTextTemplateCount();
      $this->responseArray["userCount"] = $this->dashboardService->getHrmUserCount();
      $this->responseArray["resolutionCount"] = $this->dashboardService->getResolutionCount();
      $this->responseArray["accessCount"] = $this->dashboardService->getAccessControlFeatureCount();

      return $this->responseArray;

    }


}

<?php

namespace vTechSolution\Bundle\ThemeBundle\Manager;

use Symfony\Component\DependencyInjection\ContainerInterface as Container;
use vTechSolution\Bundle\EmailBundle\Entity\EmailTemplate;
use Symfony\Component\HttpFoundation\Request;


class DashboardService
{

  private $container;
  private $request;
  private $responseArray;
  private $provider;
  private $emailTemplateRepository;
  private $emailTrackDatabase;
  private $vtechhrminDatabase;

  const HTTP_METHOD_GET    = 'GET';
	const HTTP_METHOD_POST   = 'POST';

	public function __construct(Container $container) {
        $this->container = $container;
        $this->request = $this->container->get('request');
        $this->responseArray = array();
        $this->doctrine = $this->container->get('doctrine');
        $this->emailService = $this->container->get('v_tech_solution_email.email');
        $this->emailTemplateRepository = $this->doctrine->getRepository('vTechSolutionEmailBundle:EmailTemplate');
        $this->commonResolutionRepository = $this->doctrine->getRepository('vTechSolutionCommonBundle:CommonResolution');

        $this->featureListRepository = $this->doctrine->getRepository('vTechSolutionAccessControlBundle:featureList');
        
        $this->emailTrackDatabase = $this->container->get('v_tech_solution_ring_central.email_track')->getPDO();
        $this->vtechhrminDatabase = $this->container->get('v_tech_solution_user_management.vtechhrm_in')->getPDO();
    }


    public function __destructor()
    {
        unset($this->container);
        unset($this->request);
        unset($this->responseArray);
        unset($this->doctrine);
        unset($this->provider);
        unset($this->emailTemplateRepository);
        unset($this->emailService);
        unset($this->emailTrackDatabase);
        unset($this->vtechhrminDatabase);
    }


    public function getCount(){
      $result = $this->emailTemplateRepository->fetchAll();
      foreach($result as $value) {
        $id[] = $value->getId();
      }
      $count = count($id);
      return $count;
    }

    public function getTextTemplateCount() {
      $query = "SELECT count(id) FROM meta_data";
      $fetchedResult = $this->emailTrackDatabase->query($query)->fetchColumn();
      return $fetchedResult;
    }

    public function getHrmUserCount() {
      $userQuery = "SELECT count(id) FROM main_users WHERE isactive = '1'";
      $fetchedUserResult = $this->vtechhrminDatabase->query($userQuery)->fetchColumn();
      return $fetchedUserResult;
    }

    public function getResolutionCount() {
      $resolutionCount = $this->commonResolutionRepository->countData();
      return $resolutionCount;
    }

    public function getAccessControlFeatureCount() {
      $featureCount = $this->featureListRepository->countData();
      return $featureCount;
    }

}

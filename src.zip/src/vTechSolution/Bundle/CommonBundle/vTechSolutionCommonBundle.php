<?php

namespace vTechSolution\Bundle\CommonBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class vTechSolutionCommonBundle extends Bundle
{
}

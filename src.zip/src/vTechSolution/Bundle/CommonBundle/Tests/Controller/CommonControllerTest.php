<?php

namespace vTechSolution\Bundle\CommonBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class CommonControllerTest extends WebTestCase
{
}

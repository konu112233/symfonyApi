<?php

namespace vTechSolution\Bundle\CommonBundle\Document;

use Doctrine\ODM\MongoDB\Mapping\Annotations as MongoDB;

/**
 * @MongoDB\Document(repositoryClass="vTechSolution\Bundle\CommonBundle\Document\AtsDictionaryRepository")
 */
class AtsDictionary
{
    /**
     * @MongoDB\Id
     */
    protected $id;

    /**
     * @MongoDB\Field(type="string")
     */
    protected $type;

    /**
     * @MongoDB\Field(type="string")
     */
    protected $words;

    /**
     * @MongoDB\Field(type="string")
     */
    protected $replacingwordwith;

    /**
     * @MongoDB\Field(type="string")
     */
    protected $dictionaryusagetype;

    /**
     * @MongoDB\Date
     */
    protected $createdAt;

    /**
     * Get id
     *
     * @return id $id
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set type
     *
     * @param string $type
     * @return $this
     */
    public function settype($type)
    {
        $this->type = $type;
        return $this;
    }

    /**
     * Get type
     *
     * @return string $type
     */
    public function gettype()
    {
        return $this->type;
    }

    /**
     * Set words
     *
     * @param string $replacingwordwith
     * @return $this
     */
    public function setwords($words)
    {
        $this->words = $words;
        return $this;
    }

    /**
     * Get words
     *
     * @return string $replacingwordwith
     */
    public function getwords()
    {
        return $this->words;
    }

    /**
     * Set replacingwordwith
     *
     * @param string $replacingwordwith
     * @return $this
     */
    public function setreplacingwordwith($replacingwordwith)
    {
        $this->replacingwordwith = $replacingwordwith;
        return $this;
    }

    /**
     * Get replacingwordwith
     *
     * @return string $replacingwordwith
     */
    public function getreplacingwordwith()
    {
        return $this->replacingwordwith;
    }

    /**
     * Set dictionaryusagetype
     *
     * @param string $dictionaryusagetype
     * @return $this
     */
    public function setdictionaryusagetype($dictionaryusagetype)
    {
        $this->dictionaryusagetype = $dictionaryusagetype;
        return $this;
    }

    /**
     * Get dictionaryusagetype
     *
     * @return string $dictionaryusagetype
     */
    public function getdictionaryusagetype()
    {
        return $this->dictionaryusagetype;
    }

    /**
     * Set createdAt
     *
     * @param timestamp $createdAt
     * @return $this
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
        return $this;
    }

    /**
     * Get createdAt
     *
     * @return timestamp $createdAt
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * @MongoDB\PrePersist
     */
    public function onPrePersist()
    {
        $this->createdAt = new DateTime();
    }

}

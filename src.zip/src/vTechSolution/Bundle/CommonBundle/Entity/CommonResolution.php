<?php

namespace vTechSolution\Bundle\CommonBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * CommonResolution
 *
 * @ORM\Table(name="vtech_common_resolution")
 * @ORM\Entity(repositoryClass="vTechSolution\Bundle\CommonBundle\Entity\CommonResolutionRepository")
 */
class CommonResolution
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="DeparatmentName", type="string", length=255)
     */
    private $deparatmentName;

    /**
     * @var string
     *
     * @ORM\Column(name="Challenges", type="text")
     */
    private $challenges;

    /**
     * @var string
     *
     * @ORM\Column(name="Suggestions", type="text")
     */
    private $suggestions;

    /**
     * @var string
     *
     * @ORM\Column(name="Initiative", type="text")
     */
    private $initiative;

    /**
     * @var string
     *
     * @ORM\Column(name="BusinessImpact", type="string", length=255)
     */
    private $businessImpact;

    /**
     * @var string
     *
     * @ORM\Column(name="Type", type="string", length=255)
     */
    private $type;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set deparatmentName
     *
     * @param string $deparatmentName
     *
     * @return CommonResolution
     */
    public function setDeparatmentName($deparatmentName)
    {
        $this->deparatmentName = $deparatmentName;

        return $this;
    }

    /**
     * Get deparatmentName
     *
     * @return string
     */
    public function getDeparatmentName()
    {
        return $this->deparatmentName;
    }

    /**
     * Set challenges
     *
     * @param string $challenges
     *
     * @return CommonResolution
     */
    public function setChallenges($challenges)
    {
        $this->challenges = $challenges;

        return $this;
    }

    /**
     * Get challenges
     *
     * @return string
     */
    public function getChallenges()
    {
        return $this->challenges;
    }

    /**
     * Set suggestions
     *
     * @param string $suggestions
     *
     * @return CommonResolution
     */
    public function setSuggestions($suggestions)
    {
        $this->suggestions = $suggestions;

        return $this;
    }

    /**
     * Get suggestions
     *
     * @return string
     */
    public function getSuggestions()
    {
        return $this->suggestions;
    }

    /**
     * Set initiative
     *
     * @param string $initiative
     *
     * @return CommonResolution
     */
    public function setInitiative($initiative)
    {
        $this->initiative = $initiative;

        return $this;
    }

    /**
     * Get initiative
     *
     * @return string
     */
    public function getInitiative()
    {
        return $this->initiative;
    }

    /**
     * Set businessImpact
     *
     * @param string $businessImpact
     *
     * @return CommonResolution
     */
    public function setBusinessImpact($businessImpact)
    {
        $this->businessImpact = $businessImpact;

        return $this;
    }

    /**
     * Get businessImpact
     *
     * @return string
     */
    public function getBusinessImpact()
    {
        return $this->businessImpact;
    }

    /**
     * Set type
     *
     * @param string $type
     *
     * @return CommonResolution
     */
    public function setType($type)
    {
        $this->type = $type;

        return $this;
    }

    /**
     * Get type
     *
     * @return string
     */
    public function getType()
    {
        return $this->type;
    }
}


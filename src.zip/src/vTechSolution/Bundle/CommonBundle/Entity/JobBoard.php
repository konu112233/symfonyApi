<?php

namespace vTechSolution\Bundle\CommonBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * JobBoard
 *
 * @ORM\Table(name="job_board")
 * @ORM\Entity(repositoryClass="vTechSolution\Bundle\CommonBundle\Entity\JobBoardRepository")
 */
class JobBoard
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="JobBoardName", type="string", length=255, nullable=true, unique=true)
     */
    private $jobBoardName;

    /**
     * @var string
     *
     * @ORM\Column(name="URL", type="string", length=255, nullable=true)
     */
    private $uRL;

    /**
     * @var string
     *
     * @ORM\Column(name="Email", type="string", length=255, nullable=true)
     */
    private $email;

    /**
     * @var string
     *
     * @ORM\Column(name="Password", type="string", length=255, nullable=true)
     */
    private $password;

    /**
     * @var int
     *
     * @ORM\Column(name="CreatedBy", type="integer", nullable=true)
     */
    private $createdBy;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="CreatedAt", type="datetime", nullable=true)
     */
    private $createdAt;

    /**
     * @var int
     *
     * @ORM\Column(name="UpdatedBy", type="integer", nullable=true)
     */
    private $updatedBy;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="UpdatedAt", type="datetime", nullable=true)
     */
    private $updatedAt;

    /**
     * @var int
     *
     * @ORM\Column(name="status", type="integer", nullable=true)
     */
    private $status;

    /**
     * @var string
     *
     * @ORM\Column(name="ExtraField", type="string", length=255, nullable=true)
     */
    private $extraField;

    /**
     * @var string
     *
     * @ORM\Column(name="IsUsed", type="string", length=55, nullable=true)
     */
    private $isUsed;

    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set jobBoardName
     *
     * @param string $jobBoardName
     *
     * @return JobBoard
     */
    public function setJobBoardName($jobBoardName)
    {
        $this->jobBoardName = $jobBoardName;

        return $this;
    }

    /**
     * Get jobBoardName
     *
     * @return string
     */
    public function getJobBoardName()
    {
        return $this->jobBoardName;
    }

    /**
     * Set uRL
     *
     * @param string $uRL
     *
     * @return JobBoard
     */
    public function setURL($uRL)
    {
        $this->uRL = $uRL;

        return $this;
    }

    /**
     * Get uRL
     *
     * @return string
     */
    public function getURL()
    {
        return $this->uRL;
    }

    /**
     * Set email
     *
     * @param string $email
     *
     * @return JobBoard
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set password
     *
     * @param string $password
     *
     * @return JobBoard
     */
    public function setPassword($password)
    {
        $this->password = $password;

        return $this;
    }

    /**
     * Get password
     *
     * @return string
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * Set createdBy
     *
     * @param integer $createdBy
     *
     * @return JobBoard
     */
    public function setCreatedBy($createdBy)
    {
        $this->createdBy = $createdBy;

        return $this;
    }

    /**
     * Get createdBy
     *
     * @return int
     */
    public function getCreatedBy()
    {
        return $this->createdBy;
    }

    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     *
     * @return JobBoard
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set updatedBy
     *
     * @param integer $updatedBy
     *
     * @return JobBoard
     */
    public function setUpdatedBy($updatedBy)
    {
        $this->updatedBy = $updatedBy;

        return $this;
    }

    /**
     * Get updatedBy
     *
     * @return int
     */
    public function getUpdatedBy()
    {
        return $this->updatedBy;
    }

    /**
     * Set updatedAt
     *
     * @param \DateTime $updatedAt
     *
     * @return JobBoard
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return \DateTime
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    /**
     * Set status
     *
     * @param integer $status
     *
     * @return JobBoard
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status
     *
     * @return int
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Set extraField
     *
     * @param string $extraField
     *
     * @return JobBoard
     */
    public function setExtraField($extraField)
    {
        $this->extraField = $extraField;

        return $this;
    }

    /**
     * Get extraField
     *
     * @return string
     */
    public function getExtraField()
    {
        return $this->extraField;
    }

    /**
     * Set isUsed
     *
     * @param string $isUsed
     *
     * @return JobBoard
     */
    public function setIsUsed($isUsed)
    {
        $this->isUsed = $isUsed;

        return $this;
    }

    /**
     * Get isUsed
     *
     * @return string
     */
    public function getIsUsed()
    {
        return $this->isUsed;
    }
    
}


<?php

namespace vTechSolution\Bundle\CommonBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\JsonResponse;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;


/**
   * @Route("/address")
 */

class AtsCityParseController extends Controller
{
	  private $responseArray;
    private $request;

    private function initAction()
    {
      $this->responseArray = array();
      $this->request = $this->getRequest();
      $this->addressParseService = $this->get('v_tech_solution_common.addressparse');
    }


  /**
   * @Route("/city-parse", name="v_tech_solution_address_city_parse")
   * @Method({"POST"} )
   */

   	public function atsJobAddressParseAction() {

   	$this->initAction();

   	$this->responseArray = $this->addressParseService->atsAddressParse();

   	return new JsonResponse($this->responseArray);
   	}

}

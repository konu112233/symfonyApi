<?php

namespace vTechSolution\Bundle\CommonBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\JsonResponse;
use Nelmio\ApiDocBundle\Annotation\ApiDoc;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Knp\Bundle\SnappyBundle\Snappy\Response\PdfResponse;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Component\HttpFoundation\Request;
use Knp\Bundle\SnappyBundle\Snappy\Response\JpegResponse;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Translation\TranslatorInterface;

/**
 * @Route("/api/v1/jobboard")
 */

class JobBoardController extends Controller
{
	private $responseArray;
    private $request;
    private $jobBoardService;

    private function initAction()
    {

        $this->responseArray = array();
        $this->request = $this->getRequest();
        $this->jobBoardService = $this->get('v_tech_solution_common.jobboard');

    }
	/**
     * @Route("/add", name="v_tech_solution_common_jobboard_add")
     * @Method({"POST"} )
     */
    public function addJobOrderFormAction() {

            $this->initAction();
            $this->responseArray = $this->jobBoardService->submitForm();
            return new JsonResponse($this->responseArray);
    }

    /**
     * @Route("/edit", name="v_tech_solution_common_jobboard_edit")
     * @Method({"POST"} )
     */
    public function editJobOrderFormAction() {

            $this->initAction();
            $this->responseArray = $this->jobBoardService->editJobBoard();
            return new JsonResponse($this->responseArray);
    }

    /**
     * @Route("/delete", name="v_tech_solution_common_jobboard_delete")
     * @Method({"POST"} )
     */
    public function deleteJobOrderFormAction() {

            $this->initAction();
            $this->responseArray = $this->jobBoardService->deleteJobBoard();
            return new JsonResponse($this->responseArray);
    }

    /**
     * @Route("/list", name="v_tech_solution_common_jobboard_list")
     * @Method({"GET"} )
     */
    public function listJobOrderAction() {

            $this->initAction();
            $this->responseArray = $this->jobBoardService->listJobBoard();
            return new JsonResponse($this->responseArray);
    }

    /**
     * @Route("/single", name="v_tech_solution_common_jobboard_single")
     * @Method({"GET"} )
     */
    public function getJobBoardByIdAction() {

            $this->initAction();
            $this->responseArray = $this->jobBoardService->getJobBoardById();
            return new JsonResponse($this->responseArray);
    }

}

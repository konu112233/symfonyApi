<?php

namespace vTechSolution\Bundle\CommonBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\JsonResponse;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;


/**
   * @Route("/dictionary")
 */

class AtsDictionaryController extends Controller
{
	  private $responseArray;
    private $request;

    private function initAction()
    {
      $this->responseArray = array();
      $this->request = $this->getRequest();
      $this->dictionaryService = $this->get('v_tech_solution_common.dictionary');
    }


  /**
   * @Route("/add-dictionary", name="v_tech_solution_dictionary_add_dictionary")
   * @Method({"POST"} )
   */

  public function addDictionary() {

    $this->initAction();

    $this->responseArray = $this->dictionaryService->addDictionaryData();

    return new JsonResponse($this->responseArray);
  }

  /**
   * @Route("/list-dictionary", name="v_tech_solution_dictionary_list_dictionary")
   * @Method({"GET"} )
   */

  public function listDictionary() {

    $this->initAction();

    $this->responseArray = $this->dictionaryService->listDictionaryData();

    return new JsonResponse($this->responseArray);
  }

  /**
   * @Route("/delete-dictionary", name="v_tech_solution_dictionary_delete_dictionary")
   * @Method({"POST"} )
   */

  public function deleteDictionary() {

    $this->initAction();

    $this->responseArray = $this->dictionaryService->deleteDictionaryDataById();

    return new JsonResponse($this->responseArray);
  }

}

<?php

namespace vTechSolution\Bundle\CommonBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\JsonResponse;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;


/**
   * @Route("/common")
 */

class CommonController extends Controller
{
	private $responseArray;
    private $request;
    private $commonService;

    private function initAction()
    {
      $this->responseArray = array();
      $this->request = $this->getRequest();
	  $this->commonService = $this->get('v_tech_solution_common.common');
    }

    /**
   * @Route("/one-step-resolution", name="v_tech_solution_common_one_step_resolution")
   * @Method({"GET"} )
   * @Template("vTechSolutionCommonBundle:Default:form.html.twig")
   */

	public function submitFormAction() {

	$this->initAction();

	$this->responseArray = $this->commonService->departmentName();

	return array('dept' => $this->responseArray);

	}

	/**
   * @Route("/form", name="v_tech_solution_common_form")
   * @Method({"POST"} )
   */

	public function submitFormsAction() {

	$this->initAction();

	$this->responseArray = $this->commonService->submitForm();

	return new JsonResponse($this->responseArray);
	}
}

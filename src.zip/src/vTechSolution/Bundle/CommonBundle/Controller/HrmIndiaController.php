<?php

namespace vTechSolution\Bundle\CommonBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\JsonResponse;
use Nelmio\ApiDocBundle\Annotation\ApiDoc;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Knp\Bundle\SnappyBundle\Snappy\Response\PdfResponse;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;
use Symfony\Component\HttpFoundation\Request;
use Knp\Bundle\SnappyBundle\Snappy\Response\JpegResponse;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Translation\TranslatorInterface;

/**
 * @Route("/api/v1/hrmprocess")
 */

class HrmIndiaController extends Controller
{
	private $responseArray;
    private $request;
    private $hrmIndiaService;

    private function initAction()
    {

        $this->responseArray = array();
        $this->request = $this->getRequest();
        $this->hrmIndiaService = $this->get('v_tech_solution_common.probation');

    }
	/**
     * @Route("/probation", name="v_tech_solution_common_probation")
     * @Method({"GET"} )
     */
    public function createProbationConfirmationAction() {
            $this->initAction();
            $this->responseArray = $this->hrmIndiaService->createConfirmationHRMIndia();
            return new JsonResponse($this->responseArray);
        }
}

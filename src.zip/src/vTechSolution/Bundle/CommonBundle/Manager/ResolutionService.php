<?php
namespace vTechSolution\Bundle\CommonBundle\Manager;

use Symfony\Component\DependencyInjection\ContainerInterface as Container;
use vTechSolution\Bundle\CommonBundle\Entity\CommonResolution;
use Symfony\Component\HttpFoundation\Request;

class ResolutionService
{
    
    private $container;
    private $doctrine;
    private $request;
    private $responseArray;
    private $vtechhrmIndiadb;
    const HTTP_METHOD_GET = 'GET';
    const HTTP_METHOD_POST = 'POST';
    public function __construct(Container $container)
    {
        $this->container = $container;
        $this->request = $this->container->get('request');
        $this->responseArray = array();
        $this->doctrine = $this->container->get('doctrine');
        $this->commonResolutionRepository = $this->doctrine->getRepository('vTechSolutionCommonBundle:CommonResolution');
    }
    public function __destructor()
    {
        unset($this->container);
        unset($this->request);
        unset($this->responseArray);
    }
    
    public function submitForm() {

    		$departmentName = $this->request->get('department');
			$challenge = $this->request->get('challenge');
			$suggestion = $this->request->get('suggestion');
			$initiative = $this->request->get('initiative');
			$impact = $this->request->get('impact');
			$type = $this->request->get('type');

				$commonResolution = new CommonResolution();
				$commonResolution->setDeparatmentName($departmentName);
				$commonResolution->setChallenges($challenge);
				$commonResolution->setSuggestions($suggestion);
				$commonResolution->setInitiative($initiative);
				$commonResolution->setBusinessImpact($impact);
				$commonResolution->setType($type);

				$this->commonResolutionRepository->commit($commonResolution);

    }

    public function departmentName() {

    	$this->vtechhrmIndiadb = $this->container->get('v_tech_solution_common.vtechhrm_in')->getPDO();

    	$query = "SELECT id,deptname from main_departments order by deptname asc";

    	$department = $this->vtechhrmIndiadb->query($query)->fetchAll();

    	return $department;

    }
}

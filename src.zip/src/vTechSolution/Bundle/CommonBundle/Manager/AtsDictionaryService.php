<?php
namespace vTechSolution\Bundle\CommonBundle\Manager;

use Symfony\Component\DependencyInjection\ContainerInterface as Container;
use Symfony\Component\HttpFoundation\Request;
use vTechSolution\Bundle\CommonBundle\Document\AtsDictionary;

class AtsDictionaryService
{

    private $container;
    private $doctrine;
    private $request;
    private $responseArray;

    const HTTP_METHOD_GET = 'GET';
    const HTTP_METHOD_POST = 'POST';

    public function __construct(Container $container)
    {
        $this->container = $container;
        $this->request = $this->container->get('request');
        $this->responseArray = array();
        $this->doctrine = $this->container->get('doctrine');
        $this->dictionaryRepository = $this->container->get('doctrine_mongodb')->getRepository('vTechSolutionCommonBundle:AtsDictionary');
    }
    public function __destructor()
    {
        unset($this->container);
        unset($this->request);
        unset($this->responseArray);
    }

    // Add New Dictionary to Mongo-DB

    public function addDictionaryData()
    {

      $words = $this->request->get('words');
      $type = $this->request->get('type');
      $dictionaryUsageType = $this->request->get('dictionaryUsageType');
      $replacingWordWith = $this->request->get('replacingWordWith');

         $newDictionaryData = new AtsDictionary();
         $newDictionaryData->settype($type);
         $newDictionaryData->setwords($words);
         $newDictionaryData->setdictionaryusagetype($dictionaryUsageType);
         $newDictionaryData->setreplacingwordwith($replacingWordWith);
         $newDictionaryData->setCreatedAt(new \DateTime());
         $this->dictionaryRepository->commit($newDictionaryData);
    }

    // List All Dictionaries words

    public function listDictionaryData()
    {
        $result =  $this->dictionaryRepository->fetchAll();
        $response = [];
        
        foreach ($result as $key => $value) {
            $response[] = array("id" => $value->getid(), "words" => $value->getwords(), "dictionaryUsageType" => $value->getdictionaryusagetype(), "replacingWordWith" => $value->getreplacingwordwith());
        }

        return $response;
    }

    // Delete dictionary by id

    public function deleteDictionaryDataById()
    {
        $id = $this->request->get('id');

        $dictionaryObject = $this->dictionaryRepository->find($id);
        $this->dictionaryRepository->deleteByObject($dictionaryObject);

    }

}

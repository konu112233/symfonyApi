<?php

namespace vTechSolution\Bundle\CommonBundle\Manager;
use Symfony\Component\DependencyInjection\ContainerInterface as Container;
use Symfony\Component\HttpFoundation\Request;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Symfony\Component\HttpFoundation\JsonResponse;

class HrmIndiaService
{
    private $container;
    private $doctrine;
    private $request;
    private $responseArray;
    private $hrmindiaDatabase;
    const HTTP_METHOD_GET = 'GET';
    const HTTP_METHOD_POST = 'POST';

    public function __construct(Container $container)
    {
        $this->container = $container;
        $this->request = $this->container->get('request');
        $this->responseArray  = array();
        $this->doctrine = $this->container->get('doctrine');
        $this->emailService  = $this->container->get('v_tech_solution_email.email');
        $this->hrmindiaDatabase = $this->container->get('v_tech_solution_common.vtechhrm_in')->getPDO();
    }

    public function __destructor()
    {
        unset($this->container);
        unset($this->request);
        unset($this->responseArray);
        unset($this->emailService);
        unset($this->hrmindiaDatabase);
    }
    
    public function createConfirmationHRMIndia() {

        $query = "SELECT e.userfullname AS candidateName,e.date_of_joining AS joined_date,e.emailaddress AS email FROM main_employees_summary as e  WHERE e.isactive = 1 AND e.emailaddress != ''";
        $this->responseArray = $this->hrmindiaDatabase->query($query)->fetchAll();
        foreach ($this->responseArray as $key => $value) {
        $JoinedDate = date($value['joined_date']);
        $afterThreeMonths = strtotime(date("Y-m-d", strtotime($JoinedDate)) . " +3 month");
        $getAfterThreeMonths = date("Y-m-d",$afterThreeMonths);
        $priorfifteenDays = strtotime(date("Y-m-d", strtotime($getAfterThreeMonths)) . "-15 days");
        $getPriorfifteenDays = date("Y-m-d",$priorfifteenDays);
        $currentDate = date("Y-m-d");
        if ($currentDate == $getPriorfifteenDays) {
          $getDeatilsOfEmployee[] = array("candidateName" => $value['candidateName'], "joined_date" => $value['joined_date'],"confirm_date" => $getAfterThreeMonths);
          } 
        }
        if (!empty($getDeatilsOfEmployee)) {
         
        $sendEmailToHRtteam = $getDeatilsOfEmployee;
        $emailData = array(0 => array('reminderemail' => $currentDate, 'candidate_table' => ''));
        $candidateList = array();
        foreach($sendEmailToHRtteam as $key => $value) {
                $candidateList[] = array(
                    "candidate_name" => $value['candidateName'],
                    "joined_date" => $value['joined_date'],
                    "confirm_date" => $value['confirm_date']
                );
            }
        $emailData[0]['candidate_table'] = '<table style="width: 100%;border: 1px solid #ddd;">
                        <thead>
                          <tr style="background-color: #ccc;color: #000;font-size: 14px;">
                            <th style="text-align: center;vertical-align: middle;border-top: 1px solid #ddd;border-right: 1px solid #ddd;">Candidate Name</th>
                            <th style="text-align: center;vertical-align: middle;border-top: 1px solid #ddd;border-right: 1px solid #ddd;">Joined Date</th>
                            <th style="text-align: center;vertical-align: middle;border-top: 1px solid #ddd;">Expected Date of Confirmation</th>
                          </tr>
                        </thead>
                        <tbody id="myTable">';
        foreach ($candidateList as $value) {
                $emailData[0]['candidate_table'] .= '
                      <tr style="font-size: 15px;">
                        <td style="text-align: left;vertical-align: middle;border-top: 1px solid #ddd;border-right: 1px solid #ddd;">'.  $value['candidate_name'] .'</td>
                        <td style="text-align: center;vertical-align: middle;border-top: 1px solid #ddd;border-right: 1px solid #ddd;">'.  $value['joined_date'] .'</td>
                        <td style="text-align: center;vertical-align: middle;border-top: 1px solid #ddd;">'.  $value['confirm_date'] .'</td>
                      </tr>';
        }
        $emailData[0]['candidate_table'] .= '</tbody></table>';
        $this->emailService->sendEmailTemplate("probation", null, null, null, null, null, null, $emailData); 
        } else {
            $data[] = array(
                "candidate_table" => "<h1 style='color: red; text-align: center;''>No Record Found!</h1>"
            );
            $this->emailService->sendEmailTemplate("probation", null, null, null, null, null, null, $data); 
        }
    unset($query);
    unset($JoinedDate);
    unset($afterThreeMonths);
    unset($currentDate);
    unset($sendEmailToHRtteam);
    unset($getDeatilsOfEmployee);
    unset($getPriorfifteenDays);
    unset($getAfterThreeMonths);
    return $this->responseArray;
  }
}
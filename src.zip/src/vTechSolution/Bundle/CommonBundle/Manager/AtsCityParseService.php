<?php
namespace vTechSolution\Bundle\CommonBundle\Manager;

use Symfony\Component\DependencyInjection\ContainerInterface as Container;
use Symfony\Component\HttpFoundation\Request;

class AtsCityParseService
{

    private $container;
    private $doctrine;
    private $request;
    private $responseArray;

    const HTTP_METHOD_GET = 'GET';
    const HTTP_METHOD_POST = 'POST';

    public function __construct(Container $container)
    {
        $this->container = $container;
        $this->request = $this->container->get('request');
        $this->responseArray = array();
        $this->doctrine = $this->container->get('doctrine');
    }
    public function __destructor()
    {
        unset($this->container);
        unset($this->request);
        unset($this->responseArray);
    }

    public function atsAddressParse()
    {
      $address = $this->request->get('address');
      $atsJobAddressParseLocation = $this->container->getParameter('atsJobAddressParseLocation');
       ////////////////////  call python file  /////////////////////
      $parseFilter = shell_exec('python3.6 '.$atsJobAddressParseLocation .' "'.$address.'"');
      $result = str_replace(array( "(",")","[","]","'" ), '', $parseFilter);
      if ($result == null || $result == '') {
        return null;
      }
      $explodeAddressResult = explode(",",$result);
      $chunkAddressArray = array_chunk($explodeAddressResult, 2);

      foreach ($chunkAddressArray as $key => $value) {
        if (isset($value[0]) && isset($value[1])) {
          $customAddressArray[trim($value[0])] = $value[1];
        }
      }

      if (isset($customAddressArray['PlaceName'])) {
        return $customAddressArray['PlaceName'];
      } else {
        return null;
      }
    }
}

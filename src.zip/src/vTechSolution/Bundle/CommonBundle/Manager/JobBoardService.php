<?php
namespace vTechSolution\Bundle\CommonBundle\Manager;

use Symfony\Component\DependencyInjection\ContainerInterface as Container;
use vTechSolution\Bundle\CommonBundle\Entity\JobBoard;
use Symfony\Component\HttpFoundation\Request;

class JobBoardService
{
    
    private $container;
    private $doctrine;
    private $request;
    private $responseArray;
    private $vtechhrmIndiadb;
    const HTTP_METHOD_GET = 'GET';
    const HTTP_METHOD_POST = 'POST';
    public function __construct(Container $container)
    {
        $this->container = $container;
        $this->request = $this->container->get('request');
        $this->responseArray = array();
        $this->doctrine = $this->container->get('doctrine');
        $this->jobBoardRepository = $this->doctrine->getRepository('vTechSolutionCommonBundle:JobBoard');
    }
    public function __destructor()
    {
        unset($this->container);
        unset($this->request);
        unset($this->responseArray);
    }
    
    public function submitForm() {

    	$JobBoardName = $this->request->get('jobName');
		$password = $this->request->get('password');
		$email = $this->request->get('email');
		$url = $this->request->get('url');
		$loginId = $this->request->get('login_id');
        $orgKey = $this->request->get('orgKey');

		$jobBoard = new JobBoard();
		$jobBoard->setJobBoardName($JobBoardName);
		$jobBoard->setURL($url);
		$jobBoard->setEmail($email);
		$jobBoard->setPassword($password);
		$jobBoard->setCreatedBy($loginId);
        $jobBoard->setExtraField($orgKey);
		$jobBoard->setCreatedAt(new \DateTime());
        $jobBoard->setStatus(1);

		$this->jobBoardRepository->commit($jobBoard);

    }

    public function listJobBoard() {

    	return $this->jobBoardRepository->fetchallJobBoard();
    }

    public function getJobBoardById() {

        $jobBoardId = $this->request->get('jobboard_id');

        return $this->jobBoardRepository->findById($jobBoardId);
    }

    public function editJobBoard() {

        $jobId = $this->request->get('job_id');
        $jobBoard = $this->jobBoardRepository->findByJobId($jobId);
        
        $JobBoardName = $this->request->get('jobName');
        $password = $this->request->get('password');
        $email = $this->request->get('email');
        $url = $this->request->get('url');
        $loginId = $this->request->get('login_id');
        $orgKey = $this->request->get('orgKey');
        
        if ( count($jobBoard) > 0 ) {

            $jobBoard->setJobBoardName($JobBoardName);
            $jobBoard->setURL($url);
            $jobBoard->setEmail($email);
            $jobBoard->setPassword($password);
            $jobBoard->setUpdatedBy($loginId);
            $jobBoard->setExtraField($orgKey);
            $jobBoard->setUpdatedAt(new \DateTime());
            $jobBoard->setStatus(1);

            $this->jobBoardRepository->commit($jobBoard);
        }
    }

    public function deleteJobBoard() {

        $jobId = $this->request->get('jobId');
        $jobBoard = $this->jobBoardRepository->findByJobId($jobId);
        
        if ( count($jobBoard) > 0 ) {

            $jobBoard->setStatus(0);

            $this->jobBoardRepository->commit($jobBoard);
        }
    }

}

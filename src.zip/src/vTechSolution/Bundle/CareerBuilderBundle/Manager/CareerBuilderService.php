<?php
namespace vTechSolution\Bundle\CareerBuilderBundle\Manager;

use Symfony\Component\DependencyInjection\ContainerInterface as Container;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\DependencyInjection\SimpleXMLElement;


class CareerBuilderService
{
  private $container;
  private $request;
  private $responseArray;
  private $cbTokenDetail;
  private $cbResumeDetail;

  const HTTP_METHOD_GET    = 'GET';
  const HTTP_METHOD_POST   = 'POST';

  public function __construct(Container $container) {
        $this->container = $container;
        $this->request = $this->container->get('request');
        $this->responseArray = array();
        $this->doctrine = $this->container->get('doctrine');
        $this->candidatePayrateService = $this->container->get('v_tech_solution_screening.candidate_payrate');
  }

  public function __destructor() {
      unset($this->container);
      unset($this->request);
      unset($this->responseArray);
  }

  public function getUserDetails()
  {

    $email =  $this->container->getParameter('cb_user');
    $password = $this->container->getParameter('cb_password');

    $cbUrl = 'http://ws.careerbuilder.com/resumes/resumes.asmx/CB_BeginSession';

    $curl = curl_init();
        curl_setopt_array($curl, array(
        CURLOPT_URL => $cbUrl,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 300,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
                //CURLOPT_POSTFIELDS => "type=".$type."&message=".json_encode($data)."&to=".json_encode($to),
        CURLOPT_POSTFIELDS => "Email=".$email."&Password=".$password,
                ));
        $cb = curl_exec($curl);

      $xmlqbeResponse = simplexml_load_string($cb, "SimpleXMLElement", LIBXML_NOCDATA);
      $jsonqbeResponse = json_encode($xmlqbeResponse);
      $cbTokenResponse = json_decode($jsonqbeResponse,TRUE);

      $this->cbTokenDetail = $cbTokenResponse['SessionToken'];
      return $this->cbTokenDetail;
  }

  public function getUserDetail($searchKeywords = null, $searchZip = null, $page = null)
  {

    $this->getUserDetails();

    $this->responseArray = $cbResumeDetail = array();

    $searchString = $this->request->get('searchString');
    $searchJobTitle = $this->request->get('searchJobTitle');
    $country = $this->request->get('country');
    $city = $this->request->get('city');
    $state = $this->request->get('state');
    $zipCode = $this->request->get('zipCode');
    $searchmiles = $this->request->get('searchmiles');
    $searchMinSal = $this->request->get('searchMinSal');
    $searchMaxSal = $this->request->get('searchMaxSal');
    $minExperience = $this->request->get('minExperience');
    $maxExperience = $this->request->get('maxExperience');
    $selectWatc = $this->request->get('selectWatc');
    $selectEmpt = $this->request->get('selectEmpt');
    $searchRelocation = $this->request->get('searchRelocation');
    $searchResumeFreshness = $this->request->get('cbResumeFreshness');
    $searchResumeFreshnessRange = $this->request->get('cbResumeFreshnessRange');
    $cbCompany = $this->request->get('cb_company');
    $searchResumeMinimumDegree = $this->request->get('minimumDegree');
    $searchResumeMaximumDegree = $this->request->get('maximumDegree');
    $searchResumeMinimumTravel = $this->request->get('minimumTravel');
    $searchResumeMinimumExperience = $this->request->get('cb_min_exp');
    $searchResumeMaximumExperience = $this->request->get('cb_max_exp');
    $searchResumeCurrentlyEmployed = $this->request->get('currentlyEmployed');
    $searchResumeManagementExperience = $this->request->get('managementExperience');
    $searchResumeMinimumEmployeesManaged = $this->request->get('minimumEmployeesManaged');
    $searchResumeLanguageSpoken = $this->request->get('languageSpoken');
    $searchResumeCbWork = $this->request->get('cb_work');
    $searchResumeSecurityClearance = $this->request->get('securityClearance');
    $searchResumeMilitaryExperience = $this->request->get('military_experience');
    $searchResumePageNo = $this->request->get('pageNo');
    $searchResumeSortBy = $this->request->get('sortby');
    $rowsResult = '15';

    if ($searchKeywords != null) {
      $searchString = $searchKeywords;
    } else {
      $searchString = urlencode($this->candidatePayrateService->decryptionOfEmployeeId($searchString,'d'));
    }

    if ($searchZip != null) {
      $zipCode = $searchZip;
    }

    if ($page != null) {
      $searchResumePageNo = $page;
    }

    $cbToken = $this->cbTokenDetail;

    $cbResumeUrl = 'http://ws.careerbuilder.com/resumes/resumes.asmx/V2_AdvancedResumeSearch';

    //$pageCount = 0;

    $packet = "Packet=<Packet><SessionToken>".$cbToken."</SessionToken><Keywords>".$searchString."</Keywords><SearchPattern>ALL</SearchPattern><JobTitle >".$searchJobTitle."</JobTitle ><city>".$city."</city><state>".$state."</state><ZipCode>".$zipCode."</ZipCode ><country>".$country."</country><OrderBy>".$searchResumeSortBy."</OrderBy><SearchRadiusInMiles>".$searchmiles."</SearchRadiusInMiles><FreshnessInDays>".$searchResumeFreshnessRange."</FreshnessInDays><ApplyLastActivity>".$searchResumeFreshness."</ApplyLastActivity><Company>".$cbCompany."</Company><MinimumDegree>".$searchResumeMinimumDegree."</MinimumDegree><MaximumDegree>".$searchResumeMaximumDegree."</MaximumDegree><MinimumTravelRequirement>".$searchResumeMinimumTravel."</MinimumTravelRequirement><CBMinimumExperience>".$searchResumeMinimumExperience."</CBMinimumExperience><CBMaximumExperience>".$searchResumeMaximumExperience."</CBMaximumExperience><CurrentlyEmployed>".$searchResumeCurrentlyEmployed."</CurrentlyEmployed><ManagementExperience>".$searchResumeManagementExperience."</ManagementExperience><MinimumEmployeesManaged>".$searchResumeMinimumEmployeesManaged."</MinimumEmployeesManaged><LanguagesSpoken>".$searchResumeLanguageSpoken."</LanguagesSpoken><WorkStatus>".$searchResumeCbWork."</WorkStatus><SecurityClearance>".$searchResumeSecurityClearance."</SecurityClearance><MilitaryExperience>".$searchResumeMilitaryExperience."</MilitaryExperience><CompensationType>HOUR</CompensationType><MinimumSalary>".$searchMinSal."</MinimumSalary><MaximumSalary>".$searchMaxSal."</MaximumSalary><WorkStatus>".$selectWatc."</WorkStatus><EmploymentType>".$selectEmpt."</EmploymentType><RelocationFilter>".$searchRelocation."</RelocationFilter><RemoveDuplicates>True</RemoveDuplicates><PageNumber>".$searchResumePageNo."</PageNumber><RowsPerPage>".$rowsResult."</RowsPerPage><CBMinimumExperience>".$minExperience."</CBMinimumExperience><CBMaximumExperience>".$maxExperience."</CBMaximumExperience></Packet>";


    $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => $cbResumeUrl,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 300,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $packet ,
                ));
        $cbResume = curl_exec($curl);
        curl_close ($curl);


    $parser = xml_parser_create();
    xml_parse_into_struct($parser, $cbResume, $vals);
    xml_parser_free($parser);

    $xmlString = $vals[0]['value'];
    $xml = simplexml_load_string($xmlString);
    $json = json_encode($xml);
    $array = json_decode($json, TRUE);

    return $array;
  }

    public function getDatabyResumeId()
  {

    $this->getUserDetails();

    $this->responseArray = array();

    $resumeId = $this->request->get('resumeId');

    $cbToken = $this->cbTokenDetail;

    $cbResumeUrl = 'http://ws.careerbuilder.com/resumes/resumes.asmx/V2_GetResume';

    $packet = "Packet=<Packet><SessionToken>".$cbToken."</SessionToken><ResumeID>".$resumeId."</ResumeID><GetWordDocIfAvailable>True</GetWordDocIfAvailable></Packet>";

    $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => $cbResumeUrl,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 300,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $packet ,
                ));
        $cbResume = curl_exec($curl);
        curl_close ($curl);


    $parser = xml_parser_create();
    xml_parse_into_struct($parser, $cbResume, $vals);
    xml_parser_free($parser);

    $xmlString = $vals[0]['value'];
    $xml = simplexml_load_string($xmlString);
    $json = json_encode($xml);
    $array = json_decode($json, TRUE);
    $cbResumeDetail = $array;

    $this->cbResumeDetail = $cbResumeDetail;
    return $this->cbResumeDetail;
  }

}

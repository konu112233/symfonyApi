<?php

namespace vTechSolution\Bundle\CareerBuilderBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use AppBundle\Entity\ComplianceList;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Symfony\Component\Form\Extension\Core\Type\FileType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;


/**
 * @Route("/api/v1/cb")
 */
class CareerBuilderController extends Controller
{
    
	  private $responseArray;
    private $request;
    private $careerbuilderService;

    public function initAction()
    {
        $this->responseArray = array();
        $this->request = $this->getRequest();
        $this->careerbuilderService = $this->get('v_tech_solution_career_builder.cb');
    }

   /**
   * @Route("/get-user", name="v_tech_solution_carrer_builder_get_user")
   * @Method({"GET"})
   */
    public function startAction()
    {
	    
	    $this->initAction();

	    $this->responseArray = $this->careerbuilderService->getUserDetail();

      return new JsonResponse($this->responseArray);    
	  }

    /**
   * @Route("/get-resume", name="v_tech_solution_carrer_builder_get_resume")
   * @Method({"GET"})
   */
    public function getResumeAction()
    {
      
      $this->initAction();

      $this->responseArray = $this->careerbuilderService->getDatabyResumeId();

      return new JsonResponse($this->responseArray);    
    }
}

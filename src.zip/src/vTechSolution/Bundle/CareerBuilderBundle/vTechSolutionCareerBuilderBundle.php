<?php

namespace vTechSolution\Bundle\CareerBuilderBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class vTechSolutionCareerBuilderBundle extends Bundle
{
}

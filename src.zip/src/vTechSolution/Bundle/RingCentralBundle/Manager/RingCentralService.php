<?php
namespace vTechSolution\Bundle\RingCentralBundle\Manager;

use Symfony\Component\DependencyInjection\ContainerInterface as Container;


class RingCentralService
{
  private $container;
  private $request;
  private $responseArray;
  private $emailTrackDatabase;

  const HTTP_METHOD_GET    = 'GET';
  const HTTP_METHOD_POST   = 'POST';

  public function __construct(Container $container) {
        $this->container = $container;
        $this->request = $this->container->get('request');
        $this->responseArray = array();
    }

  public function __destructor() {
      unset($this->container);
      unset($this->request);
      unset($this->responseArray);
    }



 public function ringCentralPassword() {

        $ringCentralgrantType = $this->container->getParameter('ringCentralGrant_type');
      $ringCentralUserName = $this->container->getParameter('ringCentralUserName');
      $ringCentralPassword = $this->container->getParameter('ringCentralPassword');
      $ringCentralClient_id = $this->container->getParameter('ringCentralClient_id');
      $ringCentralClient_secret = $this->container->getParameter('ringCentralClient_secret');
      $ringCentralToken_url = $this->container->getParameter('ringCentralToken_url');
      $ringCentralExtension = $this->container->getParameter('ringCentralExtension');
      $encodedcId = base64_encode($ringCentralClient_id . ':' .$ringCentralClient_secret);
      $authorization = 'Basic ' . $encodedcId;

        $curl = curl_init();
        curl_setopt_array($curl, array(
        CURLOPT_URL => $ringCentralToken_url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => "grant_type=".$ringCentralgrantType."&username=".$ringCentralUserName."&password=".$ringCentralPassword."&extension=".$ringCentralExtension,
        CURLOPT_HTTPHEADER => array(
        "accept: application/json",
        "authorization:".$authorization,
        "cache-control: no-cache",
        "content-type: application/x-www-form-urlencoded"
          ),
        ));
      $response = curl_exec($curl);
      $this->responseArray = json_decode($response, true);

      curl_close($curl);


      unset($ringCentralgrantType);
      unset($ringCentralUserName);
      unset($ringCentralPassword);
      unset($ringCentralClient_id);
      unset($ringCentralClient_secret);
      unset($ringCentraToken_url);
      unset($encodedcId);
      unset($authorization);
      unset($curl);
	  $this->responseArray['access_token'];
	  $this->responseArray['token_type'];

      return $this->responseArray;
    }

 public function ringCentralSms() {
		$return = array();

			$ringCentralSms_url = $this->container->getParameter('ringCentralSms_url');
			$token = $this->ringCentralPassword();

			$accessToken = $token['access_token'];
			$tokenType = $token['token_type'];

			$atsFrom = $this->request->get('from');

			$atsTo = $this->request->get('to');
			$atsMessage = $this->request->get('msg');
			$atsJobId = $this->request->get('job_id');
			$atsUserId = $this->request->get('uid');

			$this->emailTrackDatabase = $this->container->get('v_tech_solution_ring_central.email_track')->getPDO();


			//$atsNo = implode(' ',$atsTo);
			$atsNumber = explode(' ',$atsTo);

			foreach($atsNumber as $number) {
			$data_array=array(
			 "from"=>array(
					"phoneNumber"=>$atsFrom
				),
				"to"=>[array(
					"phoneNumber"=>$number
					)],
				"text"=>$atsMessage
				);

			$data_json=json_encode($data_array);

			$curl = curl_init();
			curl_setopt_array($curl, array(
			CURLOPT_URL => $ringCentralSms_url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 30,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "POST",
			CURLOPT_POSTFIELDS => $data_json,
			CURLOPT_HTTPHEADER => array(
			"accept: application/json",
			"authorization:".$tokenType." ".$accessToken,
			"cache-control: no-cache",
			"content-type: application/json"
			  ),
			));
		  $response = curl_exec($curl);

		  $this->responseArray = json_decode($response, true);

		  $newToNumber = str_replace("+","",$number);

		  $querySelect = 'select count(*) FROM `sent_text` where user_id="'.$atsUserId.'" and text_to="'.$newToNumber.'"';
		   $sentSms = $this->emailTrackDatabase->query($querySelect)->fetchColumn();

		if($sentSms <= 0)
		{
		  $queryInsert="insert into sent_text(user_id, text_from, text_to, job_id) VALUES ('".$atsUserId."','".$atsFrom."','".$newToNumber."','".$atsJobId."')";

       $queryResult = $this->emailTrackDatabase->exec($queryInsert);
			}

      curl_close($curl);


			}

		}

 public function ringCentralReply() {

			$this->emailTrackDatabase = $this->container->get('v_tech_solution_ring_central.email_track')->getPDO();

			$logedinTo = $this->request->get('to');
			$logedinUserid = $this->request->get('uid');
			$logedinFrom = $this->request->get('from');



			$loginTo = explode(",",$logedinTo);

			$ringCentralReply_url = $this->container->getParameter('ringCentralReply_url');
			$token = $this->ringCentralPassword();

			$accessToken = $token['access_token'];
			$tokenType = $token['token_type'];
			foreach($loginTo as $key => $eachTo) {
			$curl = curl_init();
			curl_setopt_array($curl, array(
			CURLOPT_URL => $ringCentralReply_url."?dateFrom=2018-08-25T18:07:52.534Z&perPage=1000&phoneNumber=".$eachTo,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => "",
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 30,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => "GET",
			CURLOPT_HTTPHEADER => array(
			"accept: application/json",
			"authorization:".$tokenType." ".$accessToken,
			"cache-control: no-cache",
			"content-type: application/json"
			  ),
			));
		  $response = curl_exec($curl);
		  $this->responseArray['records'] = json_decode($response, true);
		  $newResponse[]=$this->responseArray['records'];
		  $fetchArray=$this->responseArray['records'];
		  $response=$fetchArray['paging']['totalElements'];


		$querySelect = 'select count(*) FROM `sent_text` where user_id="'.$logedinUserid.'" and text_to="'.$eachTo.'"';
		$sentSms = $this->emailTrackDatabase->query($querySelect)->fetchColumn();

		if($sentSms >= 1)
		{
		$queryUpdate='update sent_text set response="'.$response.'" where user_id="'.$logedinUserid.'" and text_to="'.$eachTo.'"';

       $quickbookEmployeeTimesheet = $this->emailTrackDatabase->exec($queryUpdate);
		}

			}
      curl_close($curl);

			//

			return $newResponse;

			//foreach ($this->responseArray['records'] as $value) {
			//$paging[]=$value['paging']['totalElements'];
			//}
			//print_r($fetchArray[0]['paging']);
		}


		public function ringCentralNotification() {

			$this->emailTrackDatabase = $this->container->get('v_tech_solution_ring_central.email_track')->getPDO();
			date_default_timezone_set('America/New_York');
			$logedinUserid = $this->request->get('uid');
			//$logedinUserid = '1435';


			$querySelect = 'select text_to,response FROM `sent_text` where user_id="'.$logedinUserid.'"';
			$sentSms = $this->emailTrackDatabase->query($querySelect)->fetchAll();


			$ringCentralReply_url = $this->container->getParameter('ringCentralReply_url');
			$token = $this->ringCentralPassword();

			$accessToken = $token['access_token'];
			$tokenType = $token['token_type'];
			$replyNumber = array();
			foreach($sentSms as $sentTo) {
				$getTo=$sentTo['text_to'];
				$getResponse=$sentTo['response'];

				$curl = curl_init();
				curl_setopt_array($curl, array(
				CURLOPT_URL => $ringCentralReply_url."?dateFrom=2018-08-25T18:07:52.534Z&perPage=1000&phoneNumber=".$getTo,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => "",
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 30,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "GET",
				CURLOPT_HTTPHEADER => array(
				"accept: application/json",
				"authorization:".$tokenType." ".$accessToken,
				"cache-control: no-cache",
				"content-type: application/json"
				  ),
				));
			  $response = curl_exec($curl);
			  $this->responseArray['records'] = json_decode($response, true);
			  $newResponse=$this->responseArray['records'];
			  $fetchArray=$this->responseArray['records'];
			  $response=$fetchArray['paging']['totalElements'];

			   $responseDifference=$response-$getResponse;

				  for($i=($responseDifference - 1);$i >=0 ;$i--) {
			if($newResponse['records'][$i]['from']["phoneNumber"] == $getTo && $newResponse['records'][$i]['to'][0]["phoneNumber"] == "+12026449774") {
			$replyNumber[$newResponse['records'][$i]['from']["phoneNumber"]][]=array("message"=>$newResponse['records'][$i]['subject'],"time"=>date("m-d-Y h:i:s A", strtotime($newResponse['records'][$i]['lastModifiedTime'])));
}
				  }


			}

      curl_close($curl);

			return $replyNumber;

		}
}

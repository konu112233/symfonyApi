<?php

namespace vTechSolution\Bundle\RingCentralBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\JsonResponse;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;

/**
   * @Route("/api/v1/ringcentral")
   */

class RingCentralController extends Controller
{
	private $responseArray;
    private $request;
    private $ringCentralService;

	private function initAction(){
      $this->responseArray = array();
      $this->request = $this->getRequest();

      $this->ringCentralService = $this->get('v_tech_solution_ring_central.ringcentral');
    }

	/**
   * @Route("/sms", name="v_tech_solution_bundle_sms")
   * @Method({"GET"})
   */

	 public function sms(){
      $this->initAction();

      $this->responseArray = $this->ringCentralService->ringCentralPassword();

      return new JsonResponse($this->responseArray);
  }

  /**
   * @Route("/generatetoken", name="vtech_solution_bundle_generatetoken")
   * @Method({"GET"} )
   */
  public function generatetoken(){
        $this->initAction();

        $this->responseArray = $this->ringCentralService->ringCentralPassword();

         return new JsonResponse($this->responseArray);
  }

   /**
   * @Route("/sendtext", name="vtech_solution_bundle_sendtext")
   * @Method({"POST"} )
   */
  public function sendtext(){
        $this->initAction();

        $this->responseArray = $this->ringCentralService->ringCentralSms();

         return new JsonResponse($this->responseArray);;
  }

   /**
   * @Route("/getreply", name="vtech_solution_bundle_getreply")
   * @Method({"POST"} )
   */
  public function getreply(){
        $this->initAction();

        $this->responseArray = $this->ringCentralService->ringCentralReply();

         return new JsonResponse($this->responseArray);;
  }

   /**
   * @Route("/getnotification", name="vtech_solution_bundle_getnotification")
   * @Method({"POST"} )
   * @Template("vTechSolutionRingCentralBundle:RingCentral:notification.html.twig")
   */
  public function getnotification(){
        $this->initAction();

        $this->responseArray["result"] = $this->ringCentralService->ringCentralNotification();

        return $this->responseArray;
  }


}

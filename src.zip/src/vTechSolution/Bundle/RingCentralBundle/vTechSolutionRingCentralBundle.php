<?php

namespace vTechSolution\Bundle\RingCentralBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class vTechSolutionRingCentralBundle extends Bundle
{
}

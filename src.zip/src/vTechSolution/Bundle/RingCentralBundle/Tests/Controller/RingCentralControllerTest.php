<?php

namespace vTechSolution\Bundle\RingCentralBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class RingCentralControllerTest extends WebTestCase
{
}

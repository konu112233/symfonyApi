<?php
namespace vTechSolution\Bundle\QuickBookBundle\Manager;
use Symfony\Component\DependencyInjection\ContainerInterface as Container;
use vTechSolution\Bundle\QuickBookBundle\Entity\Quickbook_Token;
use QuickBooksOnline\API\DataService\DataService;
use QuickBooksOnline\API\Core\Http\Serialization\XmlObjectSerializer;
use QuickBooksOnline\API\Facades\TimeActivity;
use QuickBooksOnline\API\Facades\Item;
use QuickBooksOnline\API\Facades\Customer;
use QuickBooksOnline\API\Facades\Vendor;
use QuickBooksOnline\API\Facades\Employee;
use QuickBooksOnline\API\Facades\Department;
use QuickBooksOnline\API\Facades\Invoice;
use QuickBooksOnline\API\Data\IPPInvoice;
use Symfony\Component\Validator\Constraints\DateTime;
class QuickBookService {
    private $container;
    private $doctrine;
    private $request;
    private $responseArray;
    private $icehrmdbDatabase;
    private $quickBookEmployeeDetail;
    private $quickBookNameDetail;
    private $quickbookCustomerDetail;
    private $quickbookServiceItemDetail;
    const HTTP_METHOD_GET = 'GET';
    const HTTP_METHOD_POST = 'POST';
    public function __construct(Container $container) {
        $this->container = $container;
        $this->request = $this->container->get('request');
        $this->doctrine = $this->container->get('doctrine');
        $this->responseArray = $this->quickBookEmployeeDetail = $this->quickbookCustomerDetail = $this->quickBookNameDetail = $this->quickbookServiceItemDetail = array();
        $this->mappingdbDatabase = $this->container->get('v_tech_solution_quick_book.mappingdb')->getPDO();
        $this->icehrmdbDatabase = null;
        $this->catsDatabase = null;
    }
    public function __destructor() {
        unset($this->container);
        unset($this->request);
        unset($this->doctrine);
        unset($this->responseArray);
        unset($this->icehrmdbDatabase);
        unset($this->catsDatabase);
        unset($this->mappingdbDatabase);
    }
    public function getAccessTokencode() {
        $this->responseArray = array('access_token' => $this->request->get('access_token'), 'refresh_token' => $this->request->get('refresh_token'));
        return $this->responseArray;
        /*$tokenEndPointUrl = $this->container->getParameter('oauthEndUrl');
        $grant_type = $this->container->getParameter('grantType_code');
        $grantType = $this->container->getParameter('grantType');
        $state = $this->container->getParameter('state');
        $authorizationRequestUrl = $this->container->getParameter('oauthUrl');
        $scope = $this->container->getParameter('scope');
        $redirect_uri = $this->container->getParameter('redirectUri');
        $response_type = $this->container->getParameter('responseType');
        
        $session_id = session_id();
        if (empty($session_id))
        {
            session_start();
        }
        
        if(isset($_SESSION['access_token']) && !empty($_SESSION['access_token'])){
        
          $refresh_token = $_SESSION['refresh_token'];
        
          $result = $this->refreshAccessToken($tokenEndPointUrl, $grantType, $refresh_token);
        
          $_SESSION['access_token'] = $result['access_token'];
          $_SESSION['refresh_token'] = $result['refresh_token'];
        
          $tokens = array('access_token' => $_SESSION['access_token'], 'refresh_token' => $_SESSION['refresh_token']);
        
          unset($grantType);
          unset($refresh_token);
        
          $this->responseArray = $tokens;
        
          return $this->responseArray;
        }else{
        
        $code = $this->request->get('code');
        
        if (!isset($code))
        {
          $authUrl = $this->getAuthorizationURL($authorizationRequestUrl, $scope, $redirect_uri, $response_type, $state);
        
          header("Access-Control-Allow-Origin: *");
          header('Access-Control-Allow-Credentials: true');
          header("Location: ".$authUrl);
          exit();
        }
        else{
        
          $responseState = $this->request->get('state');
        
          if(strcmp($state, $responseState) != 0){
            throw new Exception("The state is not correct from Intuit Server. Consider your app is hacked.");
          }
        
          $resulttoken = $this->getAccessToken($tokenEndPointUrl,  $code, $redirect_uri, $grant_type);
          $_SESSION['access_token'] = $resulttoken['access_token'];
          $_SESSION['refresh_token'] = $resulttoken['refresh_token'];
        
          unset($authUrl);
          unset($tokenEndPointUrl);
          unset($grant_type);
          unset($state);
          unset($authorizationRequestUrl);
          unset($scope);
          unset($redirect_uri);
          unset($response_type);
          unset($code);
          unset($responseState);
          $result = json_encode($resulttoken, true);
        
          $this->responseArray = $result;
          return $this->responseArray;
        }
        }*/
    }
    public function getAuthorizationURL($authorizationRequestUrl, $scope, $redirect_uri, $response_type, $state) {
        $client_id = $this->container->getParameter('clientId');
        $scope = $this->container->getParameter('scope');
        $redirect_uri = $this->container->getParameter('redirectUri');
        $response_type = $this->container->getParameter('responseType');
        $state = $this->container->getParameter('state');
        $parameters = array('client_id' => $client_id, 'scope' => $scope, 'redirect_uri' => $redirect_uri, 'response_type' => $response_type, 'state' => $state);
        $authorizationRequestUrl.= '?' . http_build_query($parameters, null, '&', PHP_QUERY_RFC1738);
        unset($client_id);
        unset($scope);
        unset($redirect_uri);
        unset($response_type);
        unset($state);
        unset($parameters);
        return $authorizationRequestUrl;
    }
    private function generateAuthorizationHeader() {
        $encodedClientIDClientSecrets = base64_encode($this->container->getParameter('clientId') . ':' . $client_secret = $this->container->getParameter('clientSecret'));
        $authorizationheader = 'Basic ' . $encodedClientIDClientSecrets;
        unset($encodedClientIDClientSecrets);
        return $authorizationheader;
    }
    public function getAccessToken($tokenEndPointUrl, $code, $redirect_uri, $grantType) {
        if (!isset($grantType)) {
            throw new InvalidArgumentException('The grantType is mandatory.', InvalidArgumentException::INVALID_GRANT_TYPE);
        }
        $parameters = array('grant_type' => $grantType, 'code' => $code, 'redirect_uri' => $redirect_uri);
        $authorizationHeaderInfo = $this->generateAuthorizationHeader();
        $http_header = array('Accept' => 'application/json', 'Authorization' => $authorizationHeaderInfo, 'Content-Type' => 'application/x-www-form-urlencoded');
        //Try catch???
        $result = $this->executeRequest($tokenEndPointUrl, $parameters, $http_header, self::HTTP_METHOD_POST);
        unset($parameters);
        unset($authorizationHeaderInfo);
        unset($http_header);
        return $result;
    }
    public function refreshAccessToken($tokenEndPointUrl, $grant_type, $refresh_token) {
        $parameters = array('grant_type' => $grant_type, 'refresh_token' => $refresh_token);
        $authorizationHeaderInfo = $this->generateAuthorizationHeader();
        $http_header = array('Accept' => 'application/json', 'Authorization' => $authorizationHeaderInfo, 'Content-Type' => 'application/x-www-form-urlencoded');
        $result = $this->executeRequest($tokenEndPointUrl, $parameters, $http_header, self::HTTP_METHOD_POST);
        unset($parameters);
        unset($authorizationHeaderInfo);
        unset($http_header);
        return $result;
    }
    public function executeRequest($url, $parameters = array(), $http_header, $http_method) {
        $curl_options = array();
        switch ($http_method) {
            case self::HTTP_METHOD_GET:
                $curl_options[CURLOPT_HTTPGET] = 'true';
                if (is_array($parameters) && count($parameters) > 0) {
                    $url.= '?' . http_build_query($parameters);
                } elseif ($parameters) {
                    $url.= '?' . $parameters;
                }
            break;
            case self::HTTP_METHOD_POST:
                $curl_options[CURLOPT_POST] = '1';
                if (is_array($parameters) && count($parameters) > 0) {
                    $body = http_build_query($parameters);
                    $curl_options[CURLOPT_POSTFIELDS] = $body;
                }
            break;
            default:
            break;
        }
        if (is_array($http_header)) {
            $header = array();
            foreach ($http_header as $key => $value) {
                $header[] = "$key: $value";
            }
            $curl_options[CURLOPT_HTTPHEADER] = $header;
        }
        $curl_options[CURLOPT_URL] = $url;
        $ch = curl_init();
        curl_setopt_array($ch, $curl_options);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($ch);
        $json_decode = json_decode($result, true);
        curl_close($ch);
        //var_dump($json_decode);
        unset($curl_options);
        unset($http_method);
        unset($parameters);
        unset($ch);
        return $json_decode;
    }
    public function timesheetProcess() {
        $tokens = $this->getAccessTokencode();
        $accessToken = $tokens['access_token'];
        $refreshToken = $tokens['refresh_token'];
        //print_r($accessToken);
        //exit();
        $realmId = $this->container->getParameter('realmId');
        $baseUrl = $this->container->getParameter('baseUrl');
        $clientId = $this->container->getParameter('clientId');
        $clientSecret = $this->container->getParameter('clientSecret');
        $this->icehrmdbDatabase = $this->container->get('v_tech_solution_quick_book.icehrmdb')->getPDO();
        $this->mappingdbDatabase = $this->container->get('v_tech_solution_quick_book.mappingdb')->getPDO();
        $timesheetId = $this->request->get('timesheet_id');
        $query = 'SELECT employee FROM `employeetimesheets` WHERE id=' . $timesheetId;
        $employeeId = $this->icehrmdbDatabase->query($query)->fetchColumn(0);
        if ($employeeId != '') {
            $quickbookEmployeeId = $this->getQuickbookIdbyHrm($employeeId);
            $timesheets = $this->getEmployeeTimesheetbyHrm($employeeId, $timesheetId);
            if (count($this->quickbookServiceItemDetail) == 0) {
                $this->getEmployeeServiceItembyQuickbook($employeeId);
            }
            $quickbookServiceItemId = $this->quickbookServiceItemDetail['Id'];
            $quickbookServiceItemDescription = $this->quickbookServiceItemDetail['Description'];
            /*        if (count($this->quickBookEmployeeDetail) == 0) {
            $this->getVendorIdbyQuickbook($employeeId);
            }
            
            if (count($this->quickBookNameDetail) == 0) {
            $this->getEmployeeIdbyQuickbook($employeeId);
            }*/
            if (count($this->quickbookCustomerDetail) == 0) {
                $this->getEmployeeMSPNamebyQuickbook($employeeId);
            }
            $quickbookCustomerId = $this->quickbookCustomerDetail['Id'];
            $quickbookCustomerTaxtable = $this->quickbookCustomerDetail['Taxable'];
            $timesheetId = $this->request->get('timesheet_id');
            $BillRate = $this->getBillRatebyHrm($employeeId);
            $query = 'SELECT hrm_timesheet_id FROM `quickbook_employee_timesheet` WHERE hrm_timesheet_id=' . $timesheetId;
            $hrmtimesheetid = $this->mappingdbDatabase->query($query)->fetchColumn(0);
            if ($hrmtimesheetid <= 1) {
                $dataService = DataService::Configure(array('auth_mode' => 'oauth2', 'ClientID' => $clientId, 'ClientSecret' => $clientSecret, 'accessTokenKey' => $accessToken, 'refreshTokenKey' => $refreshToken, 'QBORealmID' => $realmId, 'baseUrl' => $baseUrl));
                foreach ($timesheets as $timeSheet) {
                    $splitstarTime = explode(" ", $timeSheet[0]);
                    $date = $splitstarTime[0];
                    $startTime = $splitstarTime[1];
                    $splitendTime = explode(" ", $timeSheet[1]);
                    $endTime = $splitendTime[1];
                    $theResourceObj = TimeActivity::create(["TxnDate" => $date, "NameOf" => "Employee", "EmployeeRef" => ["value" => $quickbookEmployeeId], "CustomerRef" => ["value" => $quickbookCustomerId], "ItemRef" => ["value" => $quickbookServiceItemId], "StartTime" => $startTime, "EndTime" => $endTime, "BillableStatus" => "Billable", "Taxable" => $quickbookCustomerTaxtable, "HourlyRate" => $BillRate, "Description" => $quickbookServiceItemDescription]);
                    $resultingObj = $dataService->Add($theResourceObj);
                    $error = $dataService->getLastError();
                    if ($error) {
                        echo "The Status code is: " . $error->getHttpStatusCode() . "\n";
                        echo "The Helper message is: " . $error->getOAuthHelperError() . "\n";
                        echo "The Response message is: " . $error->getResponseBody() . "\n";
                    } else {
                        $quickbookTimesheetId = "{$resultingObj->Id}";
                        if ($quickbookTimesheetId != ' ') {
                            $status = "Timesheet Imported";
                            $currentDateTime = date('Y-m-d h:i:s a', time());
                            $query = "INSERT INTO `quickbook_employee_timesheet`(`hrm_emp_id`, `quick_emp_id`, `hrm_timesheet_id`, `quick_timesheet_id`, `status`,`date_hrm`, `created_at`, `updated_at`) VALUES ('$employeeId','$quickbookEmployeeId','$timesheetId','$quickbookTimesheetId','$status','$date', '$currentDateTime','$currentDateTime')";
                            $quickbookEmployeeTimesheet = $this->mappingdbDatabase->exec($query);
                            $response = 1; // Timesheet has been inserted In Quickbook
                            $this->responseArray = $response;
                        } else {
                            $response = 2; //Something wrong in Quickbook
                            $this->responseArray = $response;
                        }
                    }
                }
            } else {
                $response = 3; //Timesheet has been inserted Already In Quickbook.
                $this->responseArray = $response;
            }
        }
        unset($employeeId);
        unset($timesheetId);
        unset($quickbookEmployeeId);
        unset($quickbookTimesheetId);
        unset($status);
        unset($currentDateTime);
        unset($query);
        unset($quickbookEmployeeTimesheet);
        unset($quickbookBillRate);
        unset($quickbookEmployeeBillRate);
        unset($quickbookCustomerTaxtable);
        unset($quickbookServiceItemDescription);
        unset($response);
        return $this->responseArray;
    }
    private function getQuickbookIdbyHrm($employeeId) {
        $query = 'SELECT quick_emp_id FROM `quickbook_user_mapping` WHERE hrm_emp_id=' . $employeeId;
        $quickbookEmployeeId = $this->mappingdbDatabase->query($query)->fetchColumn(0);
        if ($quickbookEmployeeId == '') {
            $quickbookEmployeeId = $this->getQuickbookIdbyMappingtable($employeeId);
        }
        unset($query);
        return $quickbookEmployeeId;
    }
    private function getHrmEmployeedetail($employeeId) {
        $query = 'SELECT private_email FROM `employees` WHERE id=' . $employeeId;
        $isGivenName = $this->icehrmdbDatabase->query($query)->fetchColumn(0);
        unset($query);
        return $isGivenName;
    }
    private function getHrmEmployeeName($employeeId) {
        $query = 'SELECT first_name FROM `employees` WHERE id=' . $employeeId;
        $isEmployeeEmail = $this->icehrmdbDatabase->query($query)->fetchColumn(0);
        unset($query);
        return $isEmployeeEmail;
    }
    private function getVendordetailsbyHrm($employeeId) {
        $query = "SELECT mpd.v_name FROM `vendor_details` as mpd join `system_integration` `mspd` on `mpd`.`map_data_id` = `mspd`.`id` WHERE mspd.h_employee_id=" . $employeeId;
        $isVendorName = $this->mappingdbDatabase->query($query)->fetchColumn(0);
        // print_r($isVendorName);
        unset($query);
        return $isVendorName;
    }
    private function getEmployeeIdbyQuickbook($employeeId) {
        $tokens = $this->getAccessTokencode();
        $accessToken = $tokens['access_token'];
        //$refreshToken = $tokens['refresh_token'];
        $employeeEmail = $this->getHrmEmployeedetail($employeeId);
        $quickbookUrl = $this->container->getParameter('quickbookUrl');
        $realmId = $this->container->getParameter('realmId');
        $query = "select%20*%20from%20Employee%20where%20PrimaryEmailAddr%3D'" . $employeeEmail . "'";
        $curl = curl_init();
        curl_setopt_array($curl, array(CURLOPT_URL => $quickbookUrl . "/v3/company/" . $realmId . "/query?query=" . $query . "&minorversion=4", CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 30, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "GET", CURLOPT_HTTPHEADER => array("authorization: Bearer " . $accessToken, "content-type: application/json"),));
        $qbeResponse = curl_exec($curl);
        curl_close($curl);
        $xmlqbeResponse = simplexml_load_string($qbeResponse, "SimpleXMLElement", LIBXML_NOCDATA);
        $jsonqbeResponse = json_encode($xmlqbeResponse);
        $quickbookEmployeeResponse = json_decode($jsonqbeResponse, TRUE);
        unset($accessToken);
        unset($quickbookUrl);
        unset($realmId);
        unset($query);
        unset($curl);
        unset($qbeResponse);
        unset($xml);
        unset($json);
        $this->quickBookEmployeeDetail = $quickbookEmployeeResponse['QueryResponse']['Employee'];
        return $this->quickBookEmployeeDetail;
    }
    private function getVendorIdbyQuickbook($employeeId) {
        $tokens = $this->getAccessTokencode();
        $accessToken = $tokens['access_token'];
        $query = "SELECT mpd.v_name FROM `vendor_details` as mpd join `system_integration` `mspd` on `mpd`.`map_data_id` = `mspd`.`id` WHERE mspd.h_employee_id=" . $employeeId;
        $isVendorName = $this->mappingdbDatabase->query($query)->fetchColumn(0);
        $isVendorName = str_replace(' ', '%20', $isVendorName);
        $quickbookUrl = $this->container->getParameter('quickbookUrl');
        $realmId = $this->container->getParameter('realmId');
        $query = "select%20*%20from%20Vendor%20where%20CompanyName%20%3d%20%27" . $isVendorName . "%27";
        // print_r($query);
        //exit();
        $curl = curl_init();
        curl_setopt_array($curl, array(CURLOPT_URL => $quickbookUrl . "/v3/company/" . $realmId . "/query?query=" . $query . "&minorversion=4", CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 30, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "GET", CURLOPT_HTTPHEADER => array("authorization: Bearer " . $accessToken, "content-type: application/json"),));
        $qbeResponse = curl_exec($curl);
        curl_close($curl);
        $xmlqbeResponse = simplexml_load_string($qbeResponse, "SimpleXMLElement", LIBXML_NOCDATA);
        $jsonqbeResponse = json_encode($xmlqbeResponse);
        $quickbookEmployeeResponse = json_decode($jsonqbeResponse, TRUE);
        //print_r($quickbookEmployeeResponse);
        //exit();
        unset($accessToken);
        unset($quickbookUrl);
        unset($realmId);
        unset($query);
        unset($curl);
        unset($qbeResponse);
        unset($xml);
        unset($json);
        $this->quickBookNameDetail = $quickbookEmployeeResponse['QueryResponse']['Vendor'];
        //print_r($this->quickBookEmployeeDetail);
        //exit();
        return $this->quickBookNameDetail;
    }
    ///
    private function getQuickbookIdbyMappingtable($employeeId) {
        $isVendorName = $this->getVendordetailsbyHrm($employeeId);
        //print_r($isVendorName);
        if ($isVendorName == '') {
            $quickbookvendorId = $this->getEmployeeIdbyQuickbook($employeeId);
            $qbId = $quickbookvendorId['Id'];
        } else {
            $quickbookvendorId = $this->getVendorIdbyQuickbook($employeeId);
            $qbId = $quickbookvendorId['Id'];
        }
        $currentDate = date('Y-m-d h:i:s a', time());
        $this->mappingdbDatabase->exec("INSERT INTO `quickbook_user_mapping` (`hrm_emp_id`, `quick_emp_id`, `sync_date`, `created_date`, `updated_date`) VALUES ('" . $employeeId . "','" . $qbId . "','" . $currentDate . "','" . $currentDate . "','" . $currentDate . "')");
        $query = 'SELECT quick_emp_id FROM `quickbook_user_mapping` WHERE hrm_emp_id=' . $employeeId;
        $mappingData = $this->mappingdbDatabase->query($query)->fetchColumn(0);
        unset($qbid);
        unset($currentDate);
        return $mappingData;
    }
    private function getEmployeeMSPdetailbyHrm($employeeId) {
        $query = "SELECT mspd.msp_email FROM `system_integration` as mpd left join `msp_details` `mspd` on `mpd`.`id` = `mspd`.`map_data_id` WHERE mpd.h_employee_id=" . $employeeId;
        $isMspEmail = $this->mappingdbDatabase->query($query)->fetchAll();
        //print_r($isMspEmail);
        unset($query);
        return $isMspEmail;
    }
    private function getEmployeeMSPNamebyQuickbook($employeeId) {
        $tokens = $this->getAccessTokencode();
        $accessToken = $tokens['access_token'];
        $mspDetails = $this->getEmployeeMSPdetailbyHrm($employeeId);
        $mspEmail = $mspDetails[0]['msp_email'];
        //print_r($mspEmail);
        $quickbookUrl = $this->container->getParameter('quickbookUrl');
        $realmId = $this->container->getParameter('realmId');
        $query = "select%20id,Taxable%20from%20customer%20where%20PrimaryEmailAddr%3d'" . $mspEmail . "'";
        $curl = curl_init();
        curl_setopt_array($curl, array(CURLOPT_URL => $quickbookUrl . "/v3/company/" . $realmId . "/query?query=" . $query . "&minorversion=4", CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 30, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "GET", CURLOPT_HTTPHEADER => array("authorization: Bearer " . $accessToken, "content-type: application/json"),));
        $qbeResponse = curl_exec($curl);
        curl_close($curl);
        $xmlqbeResponse = simplexml_load_string($qbeResponse, "SimpleXMLElement", LIBXML_NOCDATA);
        $jsonqbeResponse = json_encode($xmlqbeResponse);
        $quickbookCustomerResponse = json_decode($jsonqbeResponse, TRUE);
        unset($mspDetails);
        unset($mspEmail);
        unset($accessToken);
        unset($quickbookUrl);
        unset($realmId);
        unset($query);
        unset($curl);
        unset($qbeResponse);
        unset($xml);
        unset($json);
        $this->quickbookCustomerDetail = $quickbookCustomerResponse['QueryResponse']['Customer'];
        return $this->quickbookCustomerDetail;
    }
    private function getEmployeeServiceItemdetailbyHrm($employeeId) {
        /* $query = "SELECT empj.name FROM `employees` as emp left join `jobtitles` `empj` on `emp`.`job_title` = `empj`.`id` WHERE emp.id=".$employeeId;
         $isJobTitle = $this->icehrmdbDatabase->query($query)->fetchAll();*/
        $query = "SELECT jobtitles.name , employees.first_name, employees.middle_name, employees.last_name FROM employees INNER JOIN jobtitles ON employees.job_title=jobtitles.id where employees.id=" . $employeeId;
        $isJobTitle = $this->icehrmdbDatabase->query($query)->fetchAll();
        $isJobTitle = $isJobTitle[0]['name'] . "_" . $isJobTitle[0]['first_name'] . " " . $isJobTitle[0]['last_name'];
        //print_r($isJobTitle);
        //exit();
        return $isJobTitle;
    }
    private function insertserviceitemdetailsinQuickbook($employeeId) {
        $tokens = $this->getAccessTokencode();
        $realmId = $this->container->getParameter('realmId');
        $baseUrl = $this->container->getParameter('baseUrl');
        $clientId = $this->container->getParameter('clientId');
        $clientSecret = $this->container->getParameter('clientSecret');
        $tokens = $this->getAccessTokencode();
        $accessToken = $tokens['access_token'];
        $refreshToken = $tokens['refresh_token'];
        $isVendorName = $this->getVendordetailsbyHrm($employeeId);
        //print_r($isVendorName);
        if ($isVendorName == '') {
            $quickbookvendorId = $this->getEmployeeIdbyQuickbook($employeeId);
            $qbId = $quickbookvendorId['Id'];
        } else {
            $quickbookvendorId = $this->getVendorIdbyQuickbook($employeeId);
            $qbId = $quickbookvendorId['Id'];
        }
        //print_r($qbId);
        //exit();
        $serviceItemDetails = $this->getEmployeeServiceItemdetailbyHrm($employeeId);
        $query = 'SELECT quick_emp_id FROM `quickbook_jobtitle` WHERE quick_emp_id=' . $qbId;
        //print_r($query);
        $quickbookEmployeeId = $this->mappingdbDatabase->query($query)->fetchColumn(0);
        $query = 'SELECT custom3 FROM `employees` WHERE id=' . $employeeId;
        $BillRate = $this->icehrmdbDatabase->query($query)->fetchColumn(0);
        if ($quickbookEmployeeId <= 1) {
            $dataService = DataService::Configure(array('auth_mode' => 'oauth2', 'ClientID' => $clientId, 'ClientSecret' => $clientSecret, 'accessTokenKey' => $accessToken, 'refreshTokenKey' => $refreshToken, 'QBORealmID' => $realmId, 'baseUrl' => $baseUrl));
            $dataService->setLogLocation("/Users/hlu2/Desktop/newFolderForLog");
            $dataService->throwExceptionOnError(true);
            $theResourceObj = Item::create(["Name" => $serviceItemDetails, "UnitPrice" => $BillRate, "IncomeAccountRef" => ["value" => "79", "name" => "Sales of Product Income"], "ExpenseAccountRef" => ["value" => "80", "name" => "Cost of Goods Sold"], "AssetAccountRef" => ["value" => "81", "name" => "Inventory Asset"], "Type" => "Service", "Description" => $serviceItemDetails, ]);
            $resultingObj = $dataService->Add($theResourceObj);
            $this->mappingdbDatabase->exec("INSERT INTO `quickbook_jobtitle` (`quick_emp_id`, `jobtitle`) VALUES ('" . $qbId . "','" . $serviceItemDetails . "')");
        }
    }
    private function getEmployeeServiceItembyQuickbook($employeeId) {
        $test = $this->insertserviceitemdetailsinQuickbook($employeeId);
        $tokens = $this->getAccessTokencode();
        $accessToken = $tokens['access_token'];
        $refreshToken = $tokens['refresh_token'];
        $serviceItemDetails = $this->getEmployeeServiceItemdetailbyHrm($employeeId);
        $serviceItemName = str_replace(' ', '%20', $serviceItemDetails);
        $quickbookUrl = $this->container->getParameter('quickbookUrl');
        $realmId = $this->container->getParameter('realmId');
        $query = "select%20id%2cDescription%20from%20Item%20where%20FullyQualifiedName%3d%27" . $serviceItemName . "%27&minorversion=4";
        $curl = curl_init();
        curl_setopt_array($curl, array(CURLOPT_URL => $quickbookUrl . "/v3/company/" . $realmId . "/query?query=" . $query . "&minorversion=4", CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 30, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "GET", CURLOPT_HTTPHEADER => array("authorization: Bearer " . $accessToken, "content-type: application/json"),));
        $qbeResponse = curl_exec($curl);
        curl_close($curl);
        $xmlqbeResponse = simplexml_load_string($qbeResponse, "SimpleXMLElement", LIBXML_NOCDATA);
        $jsonqbeResponse = json_encode($xmlqbeResponse);
        $quickbookJobResponse = json_decode($jsonqbeResponse, TRUE);
        unset($serviceItemDetails);
        unset($serviceItemName);
        unset($accessToken);
        unset($quickbookUrl);
        unset($realmId);
        unset($query);
        unset($curl);
        unset($qbeResponse);
        unset($xml);
        unset($json);
        $this->quickbookServiceItemDetail = $quickbookJobResponse['QueryResponse']['Item'];
        return $this->quickbookServiceItemDetail;
    }
    private function getEmployeeTimesheetbyHrm($employeeId, $timesheetId) {
        if ($this->icehrmdbDatabase == null) {
            $this->icehrmdbDatabase = $this->container->get('v_tech_solution_quick_book.icehrmdb')->getPDO();
        }
        $query = 'SELECT * FROM `employeetimesheets` WHERE id=' . $timesheetId;
        $employeetimesheetDates = $this->icehrmdbDatabase->query($query)->fetchAll();
        $startDate = $employeetimesheetDates[0]['date_start'];
        $endDate = $employeetimesheetDates[0]['date_end'];
        $query = "SELECT date_start,date_end FROM `employeetimeentry` WHERE employee='" . $employeeId . "' AND date_format(date_start, '%Y-%m-%d') BETWEEN '" . $startDate . "' AND '" . $endDate . "'";
        $employeeTimeentry = $this->icehrmdbDatabase->query($query)->fetchAll();
        unset($employeetimesheetDates);
        return $employeeTimeentry;
    }
    private function getBillRatebyHrm($employeeId) {
        $query = 'SELECT custom3 FROM `employees` WHERE id=' . $employeeId;
        $BillRate = $this->icehrmdbDatabase->query($query)->fetchColumn(0);
        return $BillRate;
    }
    //My Code (Ravi)
    public function getEmployeeDetailFromHrm() {
        $this->icehrmdbDatabase = $this->container->get('v_tech_solution_quick_book.icehrmdb')->getPDO();
        $employeeId = $this->request->get('id');
        $query = "SELECT
            id,
            first_name,
            middle_name,
            last_name,
            concat(first_name,' ',last_name) AS full_name,
            gender,
            date_format(birthday, '%Y-%m-%d') AS birthDate,
            date_format(custom7, '%Y-%m-%d') AS hiredDate,
            date_format(confirmation_date, '%Y-%m-%d') AS releaseDate,
            CAST(replace(custom4,'$','') AS DECIMAL (10,2)) AS payRate,
            mobile_phone,
            private_email,
            address1,
            city,
            (SELECT name FROM province WHERE id = province AND country = country) AS state,
            (SELECT name FROM country WHERE code = country) AS country,
            postal_code
        FROM
            employees
        WHERE
            id=" . $employeeId;
        $empDetail = $this->icehrmdbDatabase->query($query)->fetchAll();
        $this->responseArray = $empDetail[0];
        return $this->responseArray;
    }
    public function getVendorDetailFromHrm() {
        $this->icehrmdbDatabase = $this->container->get('v_tech_solution_quick_book.icehrmdb')->getPDO();
        $employeeId = $this->request->get('id');
        $query = "SELECT
            id,
            first_name,
            middle_name,
            last_name,
            concat(first_name,' ',last_name) AS full_name,
            mobile_phone,
            private_email,
            address1,
            city,
            (SELECT name FROM province WHERE id = province AND country = country) AS state,
            (SELECT name FROM country WHERE code = country) AS country,
            postal_code
        FROM
            employees
        WHERE
            id=" . $employeeId;
        $vendorDetail = $this->icehrmdbDatabase->query($query)->fetchAll();
        $this->responseArray = $vendorDetail[0];
        return $this->responseArray;
    }
    public function getCustomerDetailFromHrm() {
        $this->catsDatabase = $this->container->get('v_tech_solution_quick_book.catsdb')->getPDO();
        $clientId = $this->request->get('id');
        $query = "SELECT
            company_id AS ids,
            name,
            address,
            city,
            state,
            zip,
            phone1,
            phone2,
            url,
            fax_number,
            notes
        FROM
            company
        WHERE
            company_id=" . $clientId;
        $customerDetail = $this->catsDatabase->query($query)->fetchAll();
        $this->responseArray = $customerDetail[0];
        return $this->responseArray;
    }
    public function employeeProcess() {
        $tokens = $this->getAccessTokencode();
        $accessToken = $tokens['access_token'];
        $refreshToken = $tokens['refresh_token'];
        $realmId = $this->container->getParameter('realmId');
        $baseUrl = $this->container->getParameter('baseUrl');
        $clientId = $this->container->getParameter('clientId');
        $clientSecret = $this->container->getParameter('clientSecret');
        $this->mappingdbDatabase = $this->container->get('v_tech_solution_quick_book.mappingdb')->getPDO();
        $employee_id = $this->request->get('id');
        $first_name = $this->request->get('first_name');
        $middle_name = $this->request->get('middle_name');
        $last_name = $this->request->get('last_name');
        $full_name = $first_name . ' ' . $last_name;
        $gender = $this->request->get('gender');
        $payRate = floatval($this->request->get('payRate'));
        $birthDate = $this->request->get('birthDate');
        $hiredDate = $this->request->get('hiredDate');
        $releaseDate = $this->request->get('releaseDate');
        $address1 = $this->request->get('address1');
        $city = $this->request->get('city');
        $state = $this->request->get('state');
        $postal_code = $this->request->get('postal_code');
        $country = $this->request->get('country');
        $mobile_phone = $this->request->get('mobile_phone');
        $private_email = $this->request->get('private_email');
        //Prepare DataService
        $dataService = DataService::Configure(array('auth_mode' => 'oauth2', 'ClientID' => $clientId, 'ClientSecret' => $clientSecret, 'accessTokenKey' => $accessToken, 'refreshTokenKey' => $refreshToken, 'QBORealmID' => $realmId, 'baseUrl' => $baseUrl));
        //Add a new Employee
        $theResourceObj = Employee::create(["PrimaryAddr" => ["Line1" => $address1, "City" => $city, "Country" => $country, "CountrySubDivisionCode" => $state, "PostalCode" => $postal_code], "Active" => true, "EmployeeNumber" => $employee_id, "BillableTime" => false, "BillRate" => $payRate, "BirthDate" => $birthDate, "Gender" => $gender, "HiredDate" => $hiredDate, "ReleasedDate" => $releaseDate, "GivenName" => $first_name, "MiddleName" => $middle_name, "FamilyName" => $last_name, "Mobile" => ["FreeFormNumber" => $mobile_phone], "PrimaryEmailAddr" => ["Address" => $private_email]]);
        $resultingObj = $dataService->Add($theResourceObj);
        $error = $dataService->getLastError();
        if ($error) {
            $response = 2; // Error in adding Employee to Quickbook
            $this->responseArray = $response;
        } else {
            $QB_Id = $resultingObj->Id;
            $query = "SELECT mapping_id FROM quickbook_mapping WHERE mapping_type='Employee' AND  reference_id='$QB_Id'";
            $mappingId = $this->mappingdbDatabase->query($query)->fetchColumn(0);
            if ($mappingId < 1) {
                $this->mappingdbDatabase->exec("INSERT INTO quickbook_mapping(reference_id,reference_type,mapping_id,mapping_name,mapping_type) VALUES('$employee_id','Employee','$QB_Id','$full_name','Employee')");
            } else {
                $this->mappingdbDatabase->exec("UPDATE quickbook_mapping SET mapping_id = '$QB_Id', mapping_name = '$full_name' WHERE reference_id = '$employee_id' AND mapping_type = 'Employee'");
            }
            $response = 1; //  Employee Successfully Created to Quickbook
            $this->responseArray = $response;
        }
        unset($QB_Id);
        unset($query);
        unset($mappingId);
        unset($employee_id);
        unset($first_name);
        unset($middle_name);
        unset($last_name);
        unset($full_name);
        unset($gender);
        unset($payRate);
        unset($birthDate);
        unset($hiredDate);
        unset($releaseDate);
        unset($address1);
        unset($city);
        unset($state);
        unset($postal_code);
        unset($country);
        unset($mobile_phone);
        unset($private_email);
        unset($QB_Id);
        return $this->responseArray;
    }
    public function vendorProcess() {
        $tokens = $this->getAccessTokencode();
        $accessToken = $tokens['access_token'];
        $refreshToken = $tokens['refresh_token'];
        $realmId = $this->container->getParameter('realmId');
        $baseUrl = $this->container->getParameter('baseUrl');
        $clientId = $this->container->getParameter('clientId');
        $clientSecret = $this->container->getParameter('clientSecret');
        $this->mappingdbDatabase = $this->container->get('v_tech_solution_quick_book.mappingdb')->getPDO();
        $hrmId = $this->request->get('id');
        $first_name = $this->request->get('first_name');
        $middle_name = $this->request->get('middle_name');
        $last_name = $this->request->get('last_name');
        $full_name = $first_name . ' ' . $last_name;
        $company = $this->request->get('company');
        $website = $this->request->get('website');
        $address1 = $this->request->get('address1');
        $city = $this->request->get('city');
        $state = $this->request->get('state');
        $postal_code = $this->request->get('postal_code');
        $country = $this->request->get('country');
        $mobile_phone = $this->request->get('mobile_phone');
        $private_email = $this->request->get('private_email');
        //Prepare DataService
        $dataService = DataService::Configure(array('auth_mode' => 'oauth2', 'ClientID' => $clientId, 'ClientSecret' => $clientSecret, 'accessTokenKey' => $accessToken, 'refreshTokenKey' => $refreshToken, 'QBORealmID' => $realmId, 'baseUrl' => $baseUrl));
        //Add a new Vendor
        $theResourceObj = Vendor::create(["BillAddr" => ["Line1" => $address1, "City" => $city, "Country" => $country, "CountrySubDivisionCode" => $state, "PostalCode" => $postal_code], "CompanyName" => $company, "GivenName" => $first_name, "MiddleName" => $middle_name, "FamilyName" => $last_name, "Active" => true, "Mobile" => ["FreeFormNumber" => $mobile_phone], "PrimaryEmailAddr" => ["Address" => $private_email], "WebAddr" => ["URI" => $website]]);
        $resultingObj = $dataService->Add($theResourceObj);
        $error = $dataService->getLastError();
        if ($error) {
            $response = 2; // Error in adding Vendor to Quickbook
            $this->responseArray = $response;
        } else {
            $QB_Id = $resultingObj->Id;
            $query = "SELECT mapping_id FROM quickbook_mapping WHERE mapping_type='Vendor' AND  reference_id='$QB_Id'";
            $mappingId = $this->mappingdbDatabase->query($query)->fetchColumn(0);
            if ($mappingId < 1) {
                $this->mappingdbDatabase->exec("INSERT INTO quickbook_mapping(reference_id,reference_type,mapping_id,mapping_name,mapping_type) VALUES('$hrmId','Employee','$QB_Id','$full_name','Vendor')");
            } else {
                $this->mappingdbDatabase->exec("UPDATE quickbook_mapping SET mapping_id = '$QB_Id', mapping_name = '$full_name' WHERE reference_id = '$hrmId' AND mapping_type = 'Vendor'");
            }
            $response = 1; //  Vendor Successfully Created to Quickbook
            $this->responseArray = $response;
        }
        unset($QB_Id);
        unset($query);
        unset($mappingId);
        unset($hrmId);
        unset($first_name);
        unset($middle_name);
        unset($last_name);
        unset($full_name);
        unset($company);
        unset($website);
        unset($address1);
        unset($city);
        unset($state);
        unset($postal_code);
        unset($country);
        unset($mobile_phone);
        unset($private_email);
        return $this->responseArray;
    }
    public function customerProcess() {
        $tokens = $this->getAccessTokencode();
        $accessToken = $tokens['access_token'];
        $refreshToken = $tokens['refresh_token'];
        $realmId = $this->container->getParameter('realmId');
        $baseUrl = $this->container->getParameter('baseUrl');
        $clientId = $this->container->getParameter('clientId');
        $clientSecret = $this->container->getParameter('clientSecret');
        $this->mappingdbDatabase = $this->container->get('v_tech_solution_quick_book.mappingdb')->getPDO();
        $hrmId = $this->request->get('idNum');
        $name = $this->request->get('name');
        $url = $this->request->get('url');
        $address = $this->request->get('address');
        $notes = $this->request->get('notes');
        $city = $this->request->get('city');
        $state = $this->request->get('state');
        $zip = $this->request->get('zip');
        $country = $this->request->get('country');
        $phone1 = $this->request->get('phone1');
        $phone2 = $this->request->get('phone2');
        $fax_number = $this->request->get('fax_number');
        $email = $this->request->get('email');
        //Prepare DataService
        $dataService = DataService::Configure(array('auth_mode' => 'oauth2', 'ClientID' => $clientId, 'ClientSecret' => $clientSecret, 'accessTokenKey' => $accessToken, 'refreshTokenKey' => $refreshToken, 'QBORealmID' => $realmId, 'baseUrl' => $baseUrl));
        //Add a new Customer
        $theResourceObj = Customer::create(["BillAddr" => ["Line1" => $address, "City" => $city, "Country" => $country, "CountrySubDivisionCode" => $state, "PostalCode" => $zip], "Notes" => $notes, "CompanyName" => $name, "DisplayName" => $name, "PrimaryPhone" => ["FreeFormNumber" => $phone1], "Mobile" => ["FreeFormNumber" => $phone2], "Fax" => ["FreeFormNumber" => $fax_number], "PrimaryEmailAddr" => ["Address" => $email], "WebAddr" => ["URI" => $url]]);
        $resultingObj = $dataService->Add($theResourceObj);
        $error = $dataService->getLastError();
        if ($error) {
            $response = 2; // Error in adding Customer to Quickbook
            $this->responseArray = $response;
        } else {
            $QB_Id = $resultingObj->Id;
            $query = "SELECT mapping_id FROM quickbook_mapping WHERE mapping_type='Customer' AND  reference_id='$QB_Id'";
            $mappingId = $this->mappingdbDatabase->query($query)->fetchColumn(0);
            if ($mappingId < 1) {
                $this->mappingdbDatabase->exec("INSERT INTO quickbook_mapping(reference_id,reference_type,mapping_id,mapping_name,mapping_type) VALUES('$hrmId','Employee','$QB_Id','$name','Customer')");
            } else {
                $this->mappingdbDatabase->exec("UPDATE quickbook_mapping SET mapping_id = '$QB_Id', mapping_name = '$name' WHERE reference_id = '$hrmId' AND mapping_type = 'Customer'");
            }
            $response = 1; //  Customer Successfully Created to Quickbook
            $this->responseArray = $response;
        }
        unset($hrmId);
        unset($name);
        unset($url);
        unset($address);
        unset($notes);
        unset($city);
        unset($state);
        unset($zip);
        unset($country);
        unset($phone1);
        unset($phone2);
        unset($fax_number);
        unset($email);
        unset($QB_Id);
        unset($query);
        unset($mappingId);
        return $this->responseArray;
    }
    public function serviceProcess() {
        $tokens = $this->getAccessTokencode();
        $accessToken = $tokens['access_token'];
        $refreshToken = $tokens['refresh_token'];
        $realmId = $this->container->getParameter('realmId');
        $baseUrl = $this->container->getParameter('baseUrl');
        $clientId = $this->container->getParameter('clientId');
        $clientSecret = $this->container->getParameter('clientSecret');
        $HRM_id = $this->request->get('HRM_id');
        $mapType = $this->request->get('mapType');
        $QB_name = $this->request->get('QB_name');
        $QB_description = $this->request->get('QB_description');
        $this->mappingdbDatabase = $this->container->get('v_tech_solution_quick_book.mappingdb')->getPDO();
        //Prepare DataService
        $dataService = DataService::Configure(array('auth_mode' => 'oauth2', 'ClientID' => $clientId, 'ClientSecret' => $clientSecret, 'accessTokenKey' => $accessToken, 'refreshTokenKey' => $refreshToken, 'QBORealmID' => $realmId, 'baseUrl' => $baseUrl));
        //Add a new Service
        $theResourceObj = Item::create(["Name" => $QB_name, "Type" => "Service", "Description" => $QB_description, "IncomeAccountRef" => ["value" => "1", "name" => "Services"]]);
        $resultingObj = $dataService->Add($theResourceObj);
        $error = $dataService->getLastError();
        if ($error) {
            $response = 2; // Error in adding Service to Quickbook
            $this->responseArray = $response;
        } else {
            $QB_Id = $resultingObj->Id;
            $query = "SELECT mapping_id FROM quickbook_mapping WHERE mapping_type='Service' AND  reference_id='$QB_Id'";
            $mappingId = $this->mappingdbDatabase->query($query)->fetchColumn(0);
            if ($mappingId < 1) {
                $this->mappingdbDatabase->exec("INSERT INTO quickbook_mapping(reference_id,reference_type,mapping_id,mapping_name,mapping_type) VALUES('$HRM_id','Employee','$QB_Id','$QB_name','Service')");
            } else {
                $this->mappingdbDatabase->exec("UPDATE quickbook_mapping SET mapping_id = '$QB_Id', mapping_name = '$QB_name' WHERE reference_id = '$HRM_id' AND mapping_type = 'Service'");
            }
            $response = 1; //  Service Successfully Created to Quickbook
            $this->responseArray = $response;
        }
        unset($HRM_id);
        unset($mappingId);
        unset($QB_Id);
        unset($QB_name);
        unset($QB_description);
        return $this->responseArray;
    }
    public function servicelistProcess() {
        $tokens = $this->getAccessTokencode();
        $accessToken = $tokens['access_token'];
        $quickbookUrl = $this->container->getParameter('quickbookUrl');
        $realmId = $this->container->getParameter('realmId');
        $serviceQuery = "select%20Id%2cName%20from%20Item%20where%20Active%20%3d%20true%20maxresults%201000";
        $curl = curl_init();
        curl_setopt_array($curl, array(CURLOPT_URL => $quickbookUrl . "/v3/company/" . $realmId . "/query?query=" . $serviceQuery . "&minorversion=4", CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 30, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "GET", CURLOPT_HTTPHEADER => array("authorization: Bearer " . $accessToken, "content-type: application/json"),));
        $qbServiceResponse = curl_exec($curl);
        curl_close($curl);
        $xmlqbServiceResponse = simplexml_load_string($qbServiceResponse, "SimpleXMLElement", LIBXML_NOCDATA);
        $jsonqbServiceResponse = json_encode($xmlqbServiceResponse);
        $quickbookServiceResponse = json_decode($jsonqbServiceResponse, TRUE);
        $quickBookServiceDetail = $quickbookServiceResponse['QueryResponse']['Item'];
        $this->responseArray = $quickBookServiceDetail;
        unset($tokens);
        unset($accessToken);
        unset($quickbookUrl);
        unset($realmId);
        unset($serviceQuery);
        unset($qbServiceResponse);
        unset($xmlqbServiceResponse);
        unset($jsonqbServiceResponse);
        unset($quickbookServiceResponse);
        unset($quickBookServiceDetail);
        return $this->responseArray;
    }
    public function employeelistProcess() {
        $tokens = $this->getAccessTokencode();
        $accessToken = $tokens['access_token'];
        $quickbookUrl = $this->container->getParameter('quickbookUrl');
        $realmId = $this->container->getParameter('realmId');
        $employeeQuery = "select%20Id%2cDisplayName%20from%20Employee%20where%20Active%3dtrue%20maxresults%201000";
        $curl = curl_init();
        curl_setopt_array($curl, array(CURLOPT_URL => $quickbookUrl . "/v3/company/" . $realmId . "/query?query=" . $employeeQuery . "&minorversion=4", CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 30, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "GET", CURLOPT_HTTPHEADER => array("authorization: Bearer " . $accessToken, "content-type: application/json"),));
        $qbEmployeeResponse = curl_exec($curl);
        curl_close($curl);
        $xmlqbEmployeeResponse = simplexml_load_string($qbEmployeeResponse, "SimpleXMLElement", LIBXML_NOCDATA);
        $jsonqbEmployeeResponse = json_encode($xmlqbEmployeeResponse);
        $quickbookEmployeeResponse = json_decode($jsonqbEmployeeResponse, TRUE);
        $quickBookEmployeeDetail = $quickbookEmployeeResponse['QueryResponse']['Employee'];
        $this->responseArray = $quickBookEmployeeDetail;
        unset($tokens);
        unset($accessToken);
        unset($quickbookUrl);
        unset($realmId);
        unset($employeeQuery);
        unset($qbEmployeeResponse);
        unset($xmlqbEmployeeResponse);
        unset($jsonqbEmployeeResponse);
        unset($quickbookEmployeeResponse);
        unset($quickBookEmployeeDetail);
        return $this->responseArray;
    }
    public function vendorlistProcess() {
        $tokens = $this->getAccessTokencode();
        $accessToken = $tokens['access_token'];
        $quickbookUrl = $this->container->getParameter('quickbookUrl');
        $realmId = $this->container->getParameter('realmId');
        $vendorQuery = "select%20Id%2cDisplayName%20from%20Vendor%20where%20Active%3dtrue%20maxresults%201000";
        $curl = curl_init();
        curl_setopt_array($curl, array(CURLOPT_URL => $quickbookUrl . "/v3/company/" . $realmId . "/query?query=" . $vendorQuery . "&minorversion=4", CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 30, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "GET", CURLOPT_HTTPHEADER => array("authorization: Bearer " . $accessToken, "content-type: application/json"),));
        $qbVendorResponse = curl_exec($curl);
        curl_close($curl);
        $xmlqbVendorResponse = simplexml_load_string($qbVendorResponse, "SimpleXMLElement", LIBXML_NOCDATA);
        $jsonqbVendorResponse = json_encode($xmlqbVendorResponse);
        $quickbookVendorResponse = json_decode($jsonqbVendorResponse, TRUE);
        $quickBookVendorDetail = $quickbookVendorResponse['QueryResponse']['Vendor'];
        $this->responseArray = $quickBookVendorDetail;
        unset($tokens);
        unset($accessToken);
        unset($quickbookUrl);
        unset($realmId);
        unset($vendorQuery);
        unset($qbVendorResponse);
        unset($xmlqbVendorResponse);
        unset($jsonqbVendorResponse);
        unset($quickbookVendorResponse);
        unset($quickBookVendorDetail);
        return $this->responseArray;
    }
    public function customerlistProcess() {
        $tokens = $this->getAccessTokencode();
        $accessToken = $tokens['access_token'];
        $quickbookUrl = $this->container->getParameter('quickbookUrl');
        $realmId = $this->container->getParameter('realmId');
        $customerQuery = "select%20Id%2cDisplayName%20from%20Customer%20where%20Active%20%3d%20true%20maxresults%201000";
        $curl = curl_init();
        curl_setopt_array($curl, array(CURLOPT_URL => $quickbookUrl . "/v3/company/" . $realmId . "/query?query=" . $customerQuery . "&minorversion=4", CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 30, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "GET", CURLOPT_HTTPHEADER => array("authorization: Bearer " . $accessToken, "content-type: application/json"),));
        $qbCustomerResponse = curl_exec($curl);
        curl_close($curl);
        $xmlqbCustomerResponse = simplexml_load_string($qbCustomerResponse, "SimpleXMLElement", LIBXML_NOCDATA);
        $jsonqbCustomerResponse = json_encode($xmlqbCustomerResponse);
        $quickbookCustomerResponse = json_decode($jsonqbCustomerResponse, TRUE);
        $quickBookCustomerDetail = $quickbookCustomerResponse['QueryResponse']['Customer'];
        $this->responseArray = $quickBookCustomerDetail;
        unset($tokens);
        unset($accessToken);
        unset($quickbookUrl);
        unset($realmId);
        unset($customerQuery);
        unset($qbCustomerResponse);
        unset($xmlqbCustomerResponse);
        unset($jsonqbCustomerResponse);
        unset($quickbookCustomerResponse);
        unset($quickBookCustomerDetail);
        return $this->responseArray;
    }
    public function divisionlistProcess() {
        $tokens = $this->getAccessTokencode();
        $accessToken = $tokens['access_token'];
        $quickbookUrl = $this->container->getParameter('quickbookUrl');
        $realmId = $this->container->getParameter('realmId');
        $divisionQuery = "select%20Id%2cName%20from%20Department%20where%20Active%3dtrue%20maxresults%201000";
        $curl = curl_init();
        curl_setopt_array($curl, array(CURLOPT_URL => $quickbookUrl . "/v3/company/" . $realmId . "/query?query=" . $divisionQuery . "&minorversion=4", CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 30, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "GET", CURLOPT_HTTPHEADER => array("authorization: Bearer " . $accessToken, "content-type: application/json"),));
        $qbDivisionResponse = curl_exec($curl);
        curl_close($curl);
        $xmlqbDivisionResponse = simplexml_load_string($qbDivisionResponse, "SimpleXMLElement", LIBXML_NOCDATA);
        $jsonqbDivisionResponse = json_encode($xmlqbDivisionResponse);
        $quickbookDivisionResponse = json_decode($jsonqbDivisionResponse, TRUE);
        //$quickBookDivisionDetail = $quickbookDivisionResponse['QueryResponse'];
        $quickBookDivisionDetail = $quickbookDivisionResponse['QueryResponse']['Department'];
        $this->responseArray = $quickBookDivisionDetail;
        unset($tokens);
        unset($accessToken);
        unset($quickbookUrl);
        unset($realmId);
        unset($divisionQuery);
        unset($qbDivisionResponse);
        unset($xmlqbDivisionResponse);
        unset($jsonqbDivisionResponse);
        unset($quickbookDivisionResponse);
        unset($quickBookDivisionDetail);
        return $this->responseArray;
    }
    private function decimalHours($time) {
        $tms = explode(":", $time);
        return ($tms[0] + ($tms[1] / 60) + ($tms[2] / 3600));
    }
    private function hourMinutes($t) {
        return (($t < 0) ? "-" : "") . date((abs($t) > 24) ? floor(abs($t) / 24) . ":H:i" : "G:i", mktime(0, abs($t) * 60));
    }
    private function addTotalTime($times) {
        $minutes = 0;
        foreach ($times as $time) {
            list($hour, $minute) = explode(':', $time);
            $minutes+= $hour * 60;
            $minutes+= $minute;
        }
        $hours = floor($minutes / 60);
        $minutes-= $hours * 60;
        return sprintf('%02d:%02d', $hours, $minutes);
    }

    public function billRateMinusMsp($employeeId, $billRate) {
        
        $query = "SELECT
            cf.mspChrg_pct,
            cf.mspChrg_dlr
        FROM
            vtech_mappingdb.system_integration AS si
            JOIN vtech_mappingdb.client_fees AS cf ON cf.client_id = si.c_company_id
        WHERE
            si.h_employee_id = '$employeeId'
        GROUP BY si.h_employee_id";

        $mspFees = $this->mappingdbDatabase->query($query)->fetchAll();
        $mspFeesPct = $mspFees[0]['mspChrg_pct'];
        $mspFeesDlr = $mspFees[0]['mspChrg_dlr'];

        if($mspFeesPct > 0) {
            $finalRate = ($billRate * $mspFeesPct )/ 100 ;
            $finalBillRate = $billRate - $finalRate;
        } elseif ($mspFeesDlr > 0) {
            $finalBillRate = $billRate - $mspFeesDlr;
        } else {
            $finalBillRate = $billRate;
        }
        unset($query, $mspFees, $mspFeesPct, $mspFeesDlr);
       
        return number_format((float)$finalBillRate, 2, '.', '');
    }

    private function getEmployeeTimeEntry($employeeId, $fromDate, $toDate) {
        $timingsArray = array();
        $this->icehrmdbDatabase = $this->container->get('v_tech_solution_quick_book.icehrmdb')->getPDO();
        $query = "SELECT
            date_format(ete.date_start, '%Y-%m-%d') AS given_date,
            CAST(replace(e.custom3,'$','') AS DECIMAL (10,2)) AS bill_rate,
            CAST(replace(e.custom5,'$','') AS DECIMAL (10,2)) AS ot_rate,
            ete.time_start,
            ete.time_end,
            ete.details AS time_details,
            vts.overtime AS over_time
        FROM
            vtechhrm.employees AS e
            LEFT JOIN vtechhrm.employeetimeentry AS ete ON ete.employee = e.id
            LEFT JOIN vtechhrm.vtech_timesheet AS vts ON vts.employee = ete.employee AND vts.timesheet = ete.timesheet AND vts.date_start = ete.date_start
        WHERE
            ete.employee = '$employeeId'
        AND
            date_format(ete.date_start, '%Y-%m-%d') BETWEEN '$fromDate' AND '$toDate'
        GROUP BY e.id,given_date";
        $employeeTimeROW = $this->icehrmdbDatabase->query($query)->fetchAll();
        foreach ($employeeTimeROW as $employeeTimeEntry) {
            $regularTimings = $breakTimings = $overTimeTimings = $finalRegularHours = $finalRegularMinutes = $finalOverTimeHours = $finalOverTimeMinutes = $finalHours = $finalMinutes = $billRate = $otRate = "";
            $breakDetails = $explodeBreakHours = $finalRegularTimings = $finalOverTimeTimings = $finalTimings = array();
            $regularTimings = $this->decimalHours($employeeTimeEntry["time_end"]) - $this->decimalHours($employeeTimeEntry["time_start"]);
            $breakDetails = explode(",", $employeeTimeEntry['time_details']);
            $explodeBreakHours = explode("BreakHours :", $breakDetails[3]);
            $breakTimings = $this->decimalHours($explodeBreakHours[1]);
            $overTimeTimings = $employeeTimeEntry['over_time'];
            $finalRegularTimings = explode(":", $this->hourMinutes(($regularTimings - $breakTimings)));
            $finalRegularHours = $finalRegularTimings[0];
            $finalRegularMinutes = $finalRegularTimings[1];
            $finalOverTimeTimings = explode(":", $this->hourMinutes($overTimeTimings));
            $finalOverTimeHours = $finalOverTimeTimings[0];
            $finalOverTimeMinutes = $finalOverTimeTimings[1];
            $finalTimings = explode(":", $this->hourMinutes(($regularTimings - $breakTimings + $overTimeTimings)));
            $finalHours = $finalTimings[0];
            $finalMinutes = $finalTimings[1];
            $billRate = $employeeTimeEntry["bill_rate"];
            $otRate = $employeeTimeEntry["ot_rate"];
            if($billRate > 0) {
                $billRate = $this->billRateMinusMsp($employeeId,$billRate);
            }
            if ($finalHours != "00" || $finalMinutes != "00") {
                if (($finalOverTimeHours != "00" || $finalOverTimeMinutes != "00") && $otRate != "0.00") {
                    $timingsArray[] = array("txn_date" => $employeeTimeEntry["given_date"], "hours" => $finalRegularHours, "minutes" => $finalRegularMinutes, "time_rate" => $billRate);
                    $timingsArray[] = array("txn_date" => $employeeTimeEntry["given_date"], "hours" => $finalOverTimeHours, "minutes" => $finalOverTimeMinutes, "time_rate" => $otRate);
                } else {
                    $timingsArray[] = array("txn_date" => $employeeTimeEntry["given_date"], "hours" => $finalHours, "minutes" => $finalMinutes, "time_rate" => $billRate);
                }
            }
            unset($regularTimings, $breakTimings, $overTimeTimings, $finalRegularHours, $finalRegularMinutes, $finalOverTimeHours, $finalOverTimeMinutes, $finalHours, $finalMinutes, $billRate, $otRate, $breakDetails, $explodeBreakHours, $finalRegularTimings, $finalOverTimeTimings, $finalTimings);
        }
        return $timingsArray;
    }
    private function getEmployeeTotalTime($employeeId, $fromDate, $toDate, $syncDate) {
        $timingsArray = array();
        $this->icehrmdbDatabase = $this->container->get('v_tech_solution_quick_book.icehrmdb')->getPDO();
        $query = "SELECT
            date_format(ete.date_start, '%Y-%m-%d') AS given_date,
            CAST(replace(e.custom3,'$','') AS DECIMAL (10,2)) AS bill_rate,
            CAST(replace(e.custom5,'$','') AS DECIMAL (10,2)) AS ot_rate,
            ete.time_start,
            ete.time_end,
            ete.details AS time_details,
            vts.overtime AS over_time
        FROM
            vtechhrm.employees AS e
            LEFT JOIN vtechhrm.employeetimeentry AS ete ON ete.employee = e.id
            LEFT JOIN vtechhrm.vtech_timesheet AS vts ON vts.employee = ete.employee AND vts.timesheet = ete.timesheet AND vts.date_start = ete.date_start
        WHERE
            ete.employee = '$employeeId'
        AND
            date_format(ete.date_start, '%Y-%m-%d') BETWEEN '$fromDate' AND '$toDate'
        GROUP BY e.id,given_date";
        $finalRegularTimingsArray = $finalOverTimeTimingsArray = $finalTimingsArray = $finalRegularTimings = $finalOverTimeTimings = $finalTimings = array();
        $billRate = $otRate = $finalRegularHours = $finalRegularMinutes = $finalOverTimeHours = $finalOverTimeMinutes = $finalHours = $finalMinutes = "";
        $employeeTimeROW = $this->icehrmdbDatabase->query($query)->fetchAll();
        foreach ($employeeTimeROW as $employeeTimeEntry) {
            $regularTimings = $breakTimings = $overTimeTimings = "";
            $breakDetails = $explodeBreakHours = array();
            $regularTimings = $this->decimalHours($employeeTimeEntry["time_end"]) - $this->decimalHours($employeeTimeEntry["time_start"]);
            $breakDetails = explode(",", $employeeTimeEntry['time_details']);
            $explodeBreakHours = explode("BreakHours :", $breakDetails[3]);
            $breakTimings = $this->decimalHours($explodeBreakHours[1]);
            $overTimeTimings = $employeeTimeEntry['over_time'];
            $finalRegularTimingsArray[] = $this->hourMinutes(($regularTimings - $breakTimings));
            $finalOverTimeTimingsArray[] = $this->hourMinutes($overTimeTimings);
            $finalTimingsArray[] = $this->hourMinutes(($regularTimings - $breakTimings + $overTimeTimings));
            $billRate = $employeeTimeEntry["bill_rate"];
            $otRate = $employeeTimeEntry["ot_rate"];
            if($billRate > 0) {
                $billRate = $this->billRateMinusMsp($employeeId,$billRate);
            }
            unset($regularTimings, $breakTimings, $overTimeTimings, $breakDetails, $explodeBreakHours);
        }
        $finalRegularTimings = explode(":", $this->addTotalTime($finalRegularTimingsArray));
        $finalRegularHours = $finalRegularTimings[0];
        $finalRegularMinutes = $finalRegularTimings[1];
        $finalOverTimeTimings = explode(":", $this->addTotalTime($finalOverTimeTimingsArray));
        $finalOverTimeHours = $finalOverTimeTimings[0];
        $finalOverTimeMinutes = $finalOverTimeTimings[1];
        $finalTimings = explode(":", $this->addTotalTime($finalTimingsArray));
        $finalHours = $finalTimings[0];
        $finalMinutes = $finalTimings[1];
        if ($finalHours != 00 || $finalMinutes != 00) {
            if (($finalOverTimeHours != '00' || $finalOverTimeMinutes != '00') && $otRate != '0.00') {
                $timingsArray[] = array("txn_date" => $syncDate, "hours" => $finalRegularHours, "minutes" => $finalRegularMinutes, "time_rate" => $billRate);
                $timingsArray[] = array("txn_date" => $syncDate, "hours" => $finalOverTimeHours, "minutes" => $finalOverTimeMinutes, "time_rate" => $otRate);
            } else {
                $timingsArray[] = array("txn_date" => $syncDate, "hours" => $finalHours, "minutes" => $finalMinutes, "time_rate" => $billRate);
            }
        }
        unset($finalRegularTimingsArray, $finalOverTimeTimingsArray, $finalTimingsArray, $finalRegularTimings, $finalOverTimeTimings, $finalTimings, $billRate, $otRate, $finalRegularHours, $finalRegularMinutes, $finalOverTimeHours, $finalOverTimeMinutes, $finalHours, $finalMinutes);
        return $timingsArray;
    }
    public function timesheetsProcess() {
        $return = array();
        $tokens = $this->getAccessTokencode();
        $accessToken = $tokens['access_token'];
        $refreshToken = $tokens['refresh_token'];
        $realmId = $this->container->getParameter('realmId');
        $baseUrl = $this->container->getParameter('baseUrl');
        $clientId = $this->container->getParameter('clientId');
        $clientSecret = $this->container->getParameter('clientSecret');
        $this->mappingdbDatabase = $this->container->get('v_tech_solution_quick_book.mappingdb')->getPDO();
        //Prepare DataService
        $dataService = DataService::Configure(array('auth_mode' => 'oauth2', 'ClientID' => $clientId, 'ClientSecret' => $clientSecret, 'accessTokenKey' => $accessToken, 'refreshTokenKey' => $refreshToken, 'QBORealmID' => $realmId, 'baseUrl' => $baseUrl));
        $employeeId = $this->request->get('employeeId');
        $timsheetId = $this->request->get('timsheetId');
        $payRate = $this->request->get('payRate');
        $candidateId = $this->request->get('candidateId');
        $candidateName = $this->request->get('candidateName');
        $candidateType = $this->request->get('candidateType');
        $serviceId = $this->request->get('serviceId');
        $serviceName = $this->request->get('serviceName');
        $customerId = $this->request->get('customerId');
        $customerName = $this->request->get('customerName');
        $divisionId = $this->request->get('divisionId');
        $divisionName = $this->request->get('divisionName');
        $fromDate = $this->request->get('fromDate');
        $toDate = $this->request->get('toDate');
        $syncWith = $this->request->get('syncWith');
        $syncDate = $this->request->get('syncDate');
        if ($syncWith == "selecteddate") {
            $timeEntriesGroup = $this->getEmployeeTotalTime($employeeId, $fromDate, $toDate, $syncDate);
        } else {
            $timeEntriesGroup = $this->getEmployeeTimeEntry($employeeId, $fromDate, $toDate);
        }
        foreach ($timeEntriesGroup as $timeEntries) {
            $txnDate = $timeEntries['txn_date'];
            $hours = $timeEntries['hours'];
            $minutes = $timeEntries['minutes'];
            $timeRate = $timeEntries['time_rate'];
            $theResourceObj = TimeActivity::create(["TxnDate" => $txnDate, "NameOf" => $candidateType, $candidateType . "Ref" => ["value" => $candidateId, "name" => $candidateName], "CustomerRef" => ["value" => $customerId, "name" => $customerName], "DepartmentRef" => ["value" => $divisionId, "name" => $divisionName], "ItemRef" => ["value" => $serviceId, "name" => $serviceName], "Hours" => $hours, "Minutes" => $minutes, "BillableStatus" => "Billable", "Taxable" => false, "HourlyRate" => $timeRate, "Description" => $serviceName]);
            $resultingObj = $dataService->Add($theResourceObj);
            $error = $dataService->getLastError();
            if ($error) {
            } else {
                $quickbookTimesheetId = "{$resultingObj->Id}";
                $this->mappingdbDatabase->exec("INSERT INTO quickbook_timeentry(hrm_emp_id,qb_emp_id,hrm_timesheet_id,qb_timesheet_id,qb_timeentry_date,qb_time_start,qb_end_time,qb_hourly_rate) VALUES('$employeeId','$candidateId','$timesheetId','$quickbookTimesheetId','$txnDate','$hours','$minutes','$timeRate')");
            }
            unset($txnDate, $hours, $minutes, $timeRate, $quickbookTimesheetId);
        }
        unset($employeeId, $timesheetId, $payRate, $candidateId, $candidateName, $candidateType, $serviceId, $serviceName, $customerId, $customerName, $divisionId, $divisionName, $fromDate, $toDate, $syncWith, $syncDate);
        $return["message"] = "Timesheet is added in quickbook";
        return $return;
    }
    public function hrmEmployeeListProcess() {
        $this->icehrmdbDatabase = $this->container->get('v_tech_solution_quick_book.icehrmdb')->getPDO();
        $query = "SELECT
            e.id AS empId,
            concat(e.first_name,' ',e.last_name) AS empName,
            e.status,
            job.name AS jobTitle,
            comp.company_id AS id,
            comp.name AS cname,
            (SELECT qbm.mapping_id FROM vtech_mappingdb.quickbook_mapping AS qbm WHERE qbm.reference_type = 'Employee' AND qbm.mapping_type = 'Employee' AND qbm.reference_id = e.id) AS employeeMapId,
            (SELECT qbm.mapping_name FROM vtech_mappingdb.quickbook_mapping AS qbm WHERE qbm.reference_type = 'Employee' AND qbm.mapping_type = 'Employee' AND qbm.reference_id = e.id) AS employeeMapName,
            (SELECT qbm.mapping_id FROM vtech_mappingdb.quickbook_mapping AS qbm WHERE qbm.reference_type = 'Employee' AND qbm.mapping_type = 'Service' AND qbm.reference_id = e.id) AS serviceMapId,
            (SELECT qbm.mapping_name FROM vtech_mappingdb.quickbook_mapping AS qbm WHERE qbm.reference_type = 'Employee' AND qbm.mapping_type = 'Service' AND qbm.reference_id = e.id) AS serviceMapName,
            (SELECT qbm.mapping_id FROM vtech_mappingdb.quickbook_mapping AS qbm WHERE qbm.reference_type = 'Employee' AND qbm.mapping_type = 'Customer' AND qbm.reference_id = e.id) AS customerMapId,
            (SELECT qbm.mapping_name FROM vtech_mappingdb.quickbook_mapping AS qbm WHERE qbm.reference_type = 'Employee' AND qbm.mapping_type = 'Customer' AND qbm.reference_id = e.id) AS customerMapName,
            (SELECT qbm.mapping_id FROM vtech_mappingdb.quickbook_mapping AS qbm WHERE qbm.reference_type = 'Employee' AND qbm.mapping_type = 'Division' AND qbm.reference_id = e.id) AS divisionMapId,
            (SELECT qbm.mapping_name FROM vtech_mappingdb.quickbook_mapping AS qbm WHERE qbm.reference_type = 'Employee' AND qbm.mapping_type = 'Division' AND qbm.reference_id = e.id) AS divisionMapName
        FROM
            employees AS e
            JOIN employmentstatus AS es ON e.employment_status = es.id
            JOIN jobtitles AS job ON e.job_title = job.id
            JOIN vtech_mappingdb.system_integration AS mp ON e.id = mp.h_employee_id
            JOIN cats.company AS comp ON comp.company_id = mp.c_company_id
        WHERE
            e.status != 'Internal Employee'
        AND
            e.status != 'OnBoarding'
        AND
            e.status != 'External Client manager'
        AND
            (es.name = 'Full Time - W2' OR es.name = 'Project Based - W2')";
        $hrmEmployeeList = $this->icehrmdbDatabase->query($query)->fetchAll();
        $this->responseArray = $hrmEmployeeList;
        return $this->responseArray;
    }
    public function hrmVendorListProcess() {
        $this->icehrmdbDatabase = $this->container->get('v_tech_solution_quick_book.icehrmdb')->getPDO();
        $query = "SELECT
            e.id AS empId,
            concat(e.first_name,' ',e.last_name) AS empName,
            e.status,
            job.name AS jobTitle,
            comp.company_id AS id,
            comp.name AS cname,
            IF(es.id IN (3,6),'C2C',IF(es.id IN (2,5),'1099','')) AS statusName,
            (SELECT qbm.mapping_id FROM vtech_mappingdb.quickbook_mapping AS qbm WHERE qbm.reference_type = 'Employee' AND qbm.mapping_type = 'Vendor' AND qbm.reference_id = e.id) AS vendorMapId,
            (SELECT qbm.mapping_name FROM vtech_mappingdb.quickbook_mapping AS qbm WHERE qbm.reference_type = 'Employee' AND qbm.mapping_type = 'Vendor' AND qbm.reference_id = e.id) AS vendorMapName,
            (SELECT qbm.mapping_id FROM vtech_mappingdb.quickbook_mapping AS qbm WHERE qbm.reference_type = 'Employee' AND qbm.mapping_type = 'Service' AND qbm.reference_id = e.id) AS serviceMapId,
            (SELECT qbm.mapping_name FROM vtech_mappingdb.quickbook_mapping AS qbm WHERE qbm.reference_type = 'Employee' AND qbm.mapping_type = 'Service' AND qbm.reference_id = e.id) AS serviceMapName,
            (SELECT qbm.mapping_id FROM vtech_mappingdb.quickbook_mapping AS qbm WHERE qbm.reference_type = 'Employee' AND qbm.mapping_type = 'Customer' AND qbm.reference_id = e.id) AS customerMapId,
            (SELECT qbm.mapping_name FROM vtech_mappingdb.quickbook_mapping AS qbm WHERE qbm.reference_type = 'Employee' AND qbm.mapping_type = 'Customer' AND qbm.reference_id = e.id) AS customerMapName,
            (SELECT qbm.mapping_id FROM vtech_mappingdb.quickbook_mapping AS qbm WHERE qbm.reference_type = 'Employee' AND qbm.mapping_type = 'Division' AND qbm.reference_id = e.id) AS divisionMapId,
            (SELECT qbm.mapping_name FROM vtech_mappingdb.quickbook_mapping AS qbm WHERE qbm.reference_type = 'Employee' AND qbm.mapping_type = 'Division' AND qbm.reference_id = e.id) AS divisionMapName
        FROM
            employees AS e
            JOIN employmentstatus AS es ON e.employment_status = es.id
            JOIN jobtitles AS job ON e.job_title = job.id
            JOIN vtech_mappingdb.system_integration AS mp ON e.id = mp.h_employee_id
            JOIN cats.company AS comp ON comp.company_id = mp.c_company_id
        WHERE
            e.status != 'Internal Employee'
        AND
            e.status != 'OnBoarding'
        AND
            e.status != 'External Client manager'
        AND
            es.id IN (2,3,5,6)";
        $hrmVendorList = $this->icehrmdbDatabase->query($query)->fetchAll();
        $this->responseArray = $hrmVendorList;
        return $this->responseArray;
    }
    Public function getAllCustomerFromQuickbook() {
        $tokens = $this->getAccessTokencode();
        $accessToken = $tokens['access_token'];
        $quickbookUrl = $this->container->getParameter('quickbookUrl');
        $realmId = $this->container->getParameter('realmId');
        $query = "select%20%2a%20FROM%20Customer";
        $curl = curl_init();
        curl_setopt_array($curl, array(CURLOPT_URL => $quickbookUrl . "/v3/company/" . $realmId . "/query?query=" . $query . "&minorversion=4", CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 30, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "GET", CURLOPT_HTTPHEADER => array("authorization: Bearer " . $accessToken, "content-type: application/json"),));
        $qbeResponse = curl_exec($curl);
        curl_close($curl);
        $xmlqbeResponse = simplexml_load_string($qbeResponse, "SimpleXMLElement", LIBXML_NOCDATA);
        $jsonqbeResponse = json_encode($xmlqbeResponse);
        $quickbookCustomerResponse = json_decode($jsonqbeResponse, TRUE);
        unset($accessToken);
        unset($quickbookUrl);
        unset($realmId);
        unset($query);
        unset($curl);
        unset($qbeResponse);
        unset($xml);
        unset($json);
        $this->quickbookCustomerDetail = $quickbookCustomerResponse['QueryResponse']['Customer'];
        return $this->quickbookCustomerDetail;
    }
    public function getInvoiceDetailFromHrm($employee, $startDate, $endDate) {
        $employee = $employee;
        $startDate = $startDate;
        $endDate = $endDate;
        $completeStartDate = $startDate . " " . "00:00:00.00";
        $completeEndDate = $endDate . " " . "23:59:59.999";
        $this->icehrmdbDatabase = $this->container->get('v_tech_solution_quick_book.icehrmdb')->getPDO();
        $this->mappingdbDatabase = $this->container->get('v_tech_solution_quick_book.mappingdb')->getPDO();
        $query = "SELECT `reference_id` FROM `quickbook_mapping` WHERE mapping_id = '$employee' AND mapping_type In ('Employee','Vendor')";
        $hrmEmployeeId = $this->mappingdbDatabase->query($query)->fetchColumn(0);
        $query = "SELECT custom3 as payrate FROM `employees` WHERE id = '$hrmEmployeeId'";
        $payRate = $this->icehrmdbDatabase->query($query)->fetchColumn(0);
        $queryOverTime = "SELECT custom5 as payrate FROM `employees` WHERE id = '$hrmEmployeeId'";
        $overTimeRate = $this->icehrmdbDatabase->query($queryOverTime)->fetchColumn(0);
        if ($overTimeRate == null) {
            $overTimeRate = $payRate;
        } else {
            $overTimeRate;
        }
        $query = "SELECT * from employeetimeentry WHERE date_start BETWEEN '$completeStartDate' AND '$completeEndDate' AND employee = '$hrmEmployeeId'";
        $this->responseArray = $this->icehrmdbDatabase->query($query)->fetchAll();
        $count = sizeof($this->responseArray);
        $weekTotalHours = 0;
        $weekTotalOverHours = 0;
        $totalHours = 0;
        for ($i = 0;$i < $count;$i++) {
            $totalHoursDate = $this->responseArray[$i]['details'];
            $explodeDate = explode(',', $totalHoursDate);
            $explodeHours = explode(':', $explodeDate['2']);
            $explodeOverTimeHours = explode(':', $explodeDate['1']);
            $totalByHours = ($explodeHours['1'] * 60 * 60);
            $totalByMinutes = ($explodeHours['2'] * 60);
            $totalBySeconds = ($explodeHours['3']);
            $totalByOverHours = ($explodeOverTimeHours['1'] * 60 * 60);
            $totalByOverMinutes = ($explodeOverTimeHours['2'] * 60);
            $totalByOverSeconds = ($explodeOverTimeHours['3']);
            $weekTotalHours = ($totalByHours + $totalByMinutes + $totalBySeconds) + $weekTotalHours;
            $weekTotalOverHours = ($totalByOverHours + $totalByOverMinutes + $totalByOverSeconds) + $weekTotalOverHours;
        }
        $totalHoursCalculated = $weekTotalHours / 60;
        $weekTotalHoursCalculated = $totalHoursCalculated / 60;
        $weekTotalHoursCalculatedByRoundUp = number_format((float)$weekTotalHoursCalculated, 2, '.', '');
        $totalRegularHoursAmount = $weekTotalHoursCalculatedByRoundUp * $payRate;
        $totalOverHoursCalculated = $weekTotalOverHours / 60;
        $weekOverTotalHoursCalculated = $totalOverHoursCalculated / 60;
        $weekOverTotalHoursCalculatedByRoundUp = number_format((float)$weekOverTotalHoursCalculated, 2, '.', '');
        $totalOverHoursAmount = $weekOverTotalHoursCalculatedByRoundUp * $overTimeRate;
        $totalAmount = $totalRegularHoursAmount + $totalOverHoursAmount;
        return $totalAmount;
    }
    public function createInvoiceFromHrm() {
        $accessToken = $this->request->get('accessToken');
        $refreshToken = $this->request->get('refreshToken');
        $invoiceDate = $this->request->get('invoicedate');
        $startDate = $this->request->get('startDate');
        $endDate = $this->request->get('endDate');
        $customer = $this->request->get('clientId');
        $employeeId = $this->request->get('employeeId');
        $employee = implode(", ", $employeeId);
        $invoicePdfUrl = $this->container->getParameter('invoicePdfUrl');
        $curl = curl_init();
        curl_setopt_array($curl, array(CURLOPT_URL => $invoicePdfUrl, CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 300, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "POST", CURLOPT_POSTFIELDS => "accessToken=" . $accessToken . "&refreshToken=" . $refreshToken . "&invoiceDate=" . $invoiceDate . "&startDate=" . $startDate . "&endDate=" . $endDate . "&customer=" . $customer . "&employee=" . $employee,));
        $this->responseArray = curl_exec($curl);
        unset($accessToken, $refreshToken, $invoiceDate, $startDate, $endDate, $customer, $employee, $invoicePdfUrl);
        return $this->responseArray;
    }
    public function getTimeActivity($startDate, $endDate, $customer, $realmId, $quickbookUrl, $accessToken, $employee) {
        $query = "select%20%2a%20from%20TimeActivity%20where%20CustomerRef%20%3d%20%27" . $customer . "%27%20AND%20TxnDate%20%3e%3d%20%27" . $startDate . "%27%20%20AND%20TxnDate%20%3c%3d%20%27" . $endDate . "%27";
        $curl = curl_init();
        curl_setopt_array($curl, array(CURLOPT_URL => $quickbookUrl . "/v3/company/" . $realmId . "/query?query=" . $query . "&minorversion=4", CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 30, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "GET", CURLOPT_HTTPHEADER => array("authorization: Bearer " . $accessToken, "content-type: application/json"),));
        $qbeResponse = curl_exec($curl);
        curl_close($curl);
        $xmlqbeResponse = simplexml_load_string($qbeResponse, "SimpleXMLElement", LIBXML_NOCDATA);
        $jsonqbeResponse = json_encode($xmlqbeResponse);
        $quickbookCustomerResponse = json_decode($jsonqbeResponse, TRUE);
        if (isset($quickbookCustomerResponse['QueryResponse']['TimeActivity'])) {
            $this->getQuickbookCustomerDetail = $quickbookCustomerResponse['QueryResponse']['TimeActivity'];
            if (array_key_exists("0", $this->getQuickbookCustomerDetail)) {
                $this->quickbookCustomerDetail = $this->getQuickbookCustomerDetail;
            } else {
                $this->quickbookCustomerDetail[] = $this->getQuickbookCustomerDetail;
            }
        } else {
            $this->responseArray = "TimeActivity Not Found";
        }
        return $this->responseArray;
    }
    public function invoiceCreate() {
        $this->icehrmdbDatabase = $this->container->get('v_tech_solution_quick_book.icehrmdb')->getPDO();
        $this->mappingdbDatabase = $this->container->get('v_tech_solution_quick_book.mappingdb')->getPDO();
        $accessToken = $this->request->get('accessToken');
        $refreshToken = $this->request->get('refreshToken');
        $realmId = $this->container->getParameter('realmId');
        $quickbookUrl = $this->container->getParameter('quickbookUrl');
        $clientId = $this->container->getParameter('clientId');
        $clientSecret = $this->container->getParameter('clientSecret');
        $baseUrl = $this->container->getParameter('baseUrl');
        $invoiceDate = $this->request->get('invoiceDate');
        $startDate = $this->request->get('startDate');
        $endDate = $this->request->get('endDate');
        $customer = $this->request->get('customer');
        $employeeId = $this->request->get('employee');
        $employee = explode(",", $employeeId);
        $date = $invoiceDate;
        $month = date('m', strtotime($date));
        $year = date('Y', strtotime($date));
        $monthNum = $month;
        $dateObj = \DateTime::createFromFormat('!m', $monthNum);
        $monthName = $dateObj->format('F'); // March
        $formattedDate = $monthName . " " . $year;
        $currentDate = date("Y-m-d");
        $timestamp = strtotime($endDate);
        $timestampForEndDate = strtotime($endDate);
        $invoicePdfDate = date('F Y', $timestamp);
        $invoiceNumberDate = date('m/d', $timestampForEndDate);
        $query = "SELECT term_id,timesheet_type FROM `quickbook_invoice_terms_mapping` WHERE customer_id = '$customer'";
        $getTermsAndType = $this->mappingdbDatabase->query($query)->fetchAll();
        $getTerms = $getTermsAndType[0]['term_id'];
        $getType = $getTermsAndType[0]['timesheet_type'];
        $emailQuery = "select%20PrimaryEmailAddr%20from%20Customer%20where%20Id%20%3d%20%27" . $customer . "%27";
        $curl = curl_init();
        curl_setopt_array($curl, array(CURLOPT_URL => $quickbookUrl . "/v3/company/" . $realmId . "/query?query=" . $emailQuery . "&minorversion=4", CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 30, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "GET", CURLOPT_HTTPHEADER => array("authorization: Bearer " . $accessToken, "content-type: application/json"),));
        $qbeResponse = curl_exec($curl);
        curl_close($curl);
        $xmlqbeResponse = simplexml_load_string($qbeResponse, "SimpleXMLElement", LIBXML_NOCDATA);
        $jsonqbeResponse = json_encode($xmlqbeResponse);
        $quickbookCustomerEmail = json_decode($jsonqbeResponse, TRUE);
        if (isset($quickbookCustomerEmail['QueryResponse']['Customer'])) {
            $this->quickbookCustomerEmail = $quickbookCustomerEmail['QueryResponse']['Customer'];
            $customerEmail = $this->quickbookCustomerEmail['PrimaryEmailAddr']['Address'];
            /*$this->getTimeActivity($startDate,$endDate,$customer,$realmId,$quickbookUrl,$accessToken,$employee);  */
        } else {
            $this->responseArray = "Customer Email Not Found";
        }
        if (!empty($customerEmail)) {
            $this->getTimeActivity($startDate, $endDate, $customer, $realmId, $quickbookUrl, $accessToken, $employee);
            if (!empty($this->quickbookCustomerDetail)) {
                $employeeLine = array();
                $TaxLine = array();
                $total = 0;
                $dataService = DataService::Configure(array('auth_mode' => 'oauth2', 'ClientID' => $clientId, 'ClientSecret' => $clientSecret, 'accessTokenKey' => $accessToken, 'refreshTokenKey' => $refreshToken, 'QBORealmID' => $realmId, 'baseUrl' => $baseUrl));
                $totalHoursOfEmployee = 0;
                $i = 0;
                foreach ($this->quickbookCustomerDetail as $timeActivity) {
                    foreach ($employee as $key => $valueEmployee) {
                        $nameOf = $timeActivity['NameOf'];
                        if ($nameOf == 'Employee' && $timeActivity['EmployeeRef'] == $valueEmployee) {
                            $totalHoursOfEmployeeData[$valueEmployee][] = ($totalHoursOfEmployee + $timeActivity['Hours']);
                        } elseif ($nameOf == 'Vendor' && $timeActivity['VendorRef'] == $valueEmployee) {
                            $totalHoursOfEmployeeData[$valueEmployee][] = ($totalHoursOfEmployee + $timeActivity['Hours']);
                        }
                    }
                }
                foreach ($this->quickbookCustomerDetail as $timeActivity) {
                    foreach ($employee as $key => $valueEmployee) {
                        $nameOf = $timeActivity['NameOf'];
                        if ($nameOf == 'Employee' && $timeActivity['EmployeeRef'] == $valueEmployee) {
                            $totalHoursOfEmployee = ($totalHoursOfEmployee + $timeActivity['Hours']);
                            $HourlyRate = $timeActivity['HourlyRate'];
                            $employeeName = $timeActivity['EmployeeRef'];
                            $query = "SELECT reference_id FROM `quickbook_mapping` WHERE `mapping_id` = '$employeeName' AND `mapping_type` in ('Employee')";
                            $employeeName = $this->mappingdbDatabase->query($query)->fetchColumn(0);
                            $query = "SELECT CONCAT(first_name,' ',last_name) as name FROM `employees` WHERE id = '$employeeName'";
                            $employeeName = $this->icehrmdbDatabase->query($query)->fetchColumn(0);
                            $amount = ($timeActivity['HourlyRate'] * $timeActivity['Hours']);
                            $employeeLineArray = array("LineNum" => ++$i, "Description" => $timeActivity['Description'] . "_" . $employeeName . "(" . $timeActivity['Hours'] . "hrs @ $" . $timeActivity['HourlyRate'] . " for " . $formattedDate . ")", "Amount" => $amount, "DetailType" => "SalesItemLineDetail", "SalesItemLineDetail" => ["Qty" => $timeActivity['Hours'], "UnitPrice" => $timeActivity['HourlyRate'], "ServiceDate" => $timeActivity['TxnDate'], "ItemRef" => ["value" => $timeActivity['ItemRef'], "name" => "Services"]]);
                            $TaxLineArray = ["TxnLineId" => ++$i, "TxnId" => $timeActivity['Id'], "TxnType" => "TimeActivity"];
                            if ($getType == 4) {
                                $employeeLine[] = $employeeLineArray;
                                $TaxLine[] = $TaxLineArray;
                            } else {
                                $employeeLine[$valueEmployee][] = $employeeLineArray;
                                $TaxLine[$valueEmployee][] = $TaxLineArray;
                            }
                        }
                    }
                }
                foreach ($this->quickbookCustomerDetail as $timeActivity) {
                    foreach ($employee as $key => $valueEmployee) {
                        $nameOf = $timeActivity['NameOf'];
                        if ($nameOf == 'Vendor' && $timeActivity['VendorRef'] == $valueEmployee) {
                            $HourlyRate = $timeActivity['HourlyRate'];
                            $totalHoursOfEmployee = ($totalHoursOfEmployee + $timeActivity['Hours']);
                            $employeeName = $timeActivity['VendorRef'];
                            $query = "SELECT reference_id FROM `quickbook_mapping` WHERE `mapping_id` = '$employeeName' AND `mapping_type` in ('Vendor')";
                            $employeeName = $this->mappingdbDatabase->query($query)->fetchColumn(0);
                            $query = "SELECT CONCAT(first_name,' ',last_name) as name FROM `employees` WHERE id = '$employeeName'";
                            $employeeName = $this->icehrmdbDatabase->query($query)->fetchColumn(0);
                            $amount = ($timeActivity['HourlyRate'] * $timeActivity['Hours']);
                            $employeeLineArray = array("LineNum" => ++$i, "Description" => $timeActivity['Description'] . "_" . $employeeName . "(" . $timeActivity['Hours'] . "hrs @ $" . $timeActivity['HourlyRate'] . " for " . $formattedDate . ")", "Amount" => $amount, "DetailType" => "SalesItemLineDetail", "SalesItemLineDetail" => ["Qty" => $timeActivity['Hours'], "UnitPrice" => $timeActivity['HourlyRate'], "ServiceDate" => $timeActivity['TxnDate'], "ItemRef" => ["value" => $timeActivity['ItemRef'], "name" => "Services"]]);
                            $TaxLineArray = ["TxnLineId" => ++$i, "TxnId" => $timeActivity['Id'], "TxnType" => "TimeActivity"];
                            if ($getType == 4) {
                                $employeeLine[] = $employeeLineArray;
                                $TaxLine[] = $TaxLineArray;
                            } else {
                                $employeeLine[$valueEmployee][] = $employeeLineArray;
                                $TaxLine[$valueEmployee][] = $TaxLineArray;
                            }
                        }
                    }
                }
                if ($getType == 4) {
                    $theResourceObj = Invoice::create(["Line" => $employeeLine, "TxnDate" => $invoiceDate, "CustomerRef" => ["value" => $customer], "SalesTermRef" => ["value" => $getTerms], "BillEmail" => ["Address" => $customerEmail], "LinkedTxn" => $TaxLine]);
                    $resultingObj = $dataService->Add($theResourceObj);
                    $error = $dataService->getLastError();
                    if ($error) {
                        $this->responseArray = "Invoice is Already created";
                    } else {
                        $invoiceId = $resultingObj->Id;
                        $docNumber = $this->getDocNumberOfInvoice($invoiceId);
                        $invoice = $dataService->FindbyId('invoice', $invoiceId);
                        $theResourceObj = Invoice::update($invoice, ["CustomField" => ["DefinitionId" => "1", "Type" => "StringType", "Name" => "Invoice no", "StringValue" => $docNumber]]);
                        $resultingObj = $dataService->Update($theResourceObj);
                        $this->getInvoiceInPdfByCustomer($invoiceId, $invoicePdfDate, $customer, $totalHoursOfEmployee);
                        $error = $dataService->getLastError();
                        if ($error) {
                            echo "The Status code is: " . $error->getHttpStatusCode() . "\n";
                            echo "The Helper message is: " . $error->getOAuthHelperError() . "\n";
                            echo "The Response message is: " . $error->getResponseBody() . "\n";
                        } else {
                            $quickbookAmount = $totalHoursOfEmployee * $HourlyRate;
                            $this->mappingdbDatabase->exec("INSERT INTO `quickbook_invoice`(`id`, `client_id`, `consultant_id`, `start_date`, `end_date`, `quickbook_amount`, `created_at`) VALUES ('','$customer','-','$startDate','$endDate','$quickbookAmount')");
                            $response = 2;
                            $this->responseArray = $response;
                        }
                    }
                } else {
                    foreach ($employee as $key => $valueEmployeeList) {
                        $totalHoursOfCandidate = array_sum($totalHoursOfEmployeeData[$valueEmployeeList]);
                        $quickbookAmount = $totalHoursOfCandidate * $HourlyRate;
                        $theResourceObj = Invoice::create(["Line" => $employeeLine[$valueEmployeeList], "TxnDate" => $invoiceDate, "CustomerRef" => ["value" => $customer], "SalesTermRef" => ["value" => $getTerms], "BillEmail" => ["Address" => $customerEmail], "LinkedTxn" => $TaxLine[$valueEmployeeList]]);
                        $resultingObj = $dataService->Add($theResourceObj);
                        $error = $dataService->getLastError();
                        if ($error) {
                            $this->responseArray = "Invoice is Already created";
                        } else {
                            $invoiceId = $resultingObj->Id;
                            if ($getType == 2) {
                                $docNumber = $this->getDocNumberOfInvoice($invoiceId);
                                $docNumber = $docNumber.'-'.$invoiceNumberDate.$this->getEmployeeName($valueEmployeeList);
                            } else {
                                $docNumber = $this->getDocNumberOfInvoice($invoiceId);
                                $docNumber = $docNumber.'-'.$invoiceNumberDate.$this->getEmployeeName($valueEmployeeList);
                            }
                            $invoice = $dataService->FindbyId('invoice', $invoiceId);
                            $theResourceObj = Invoice::update($invoice, ["CustomField" => ["DefinitionId" => "1", "Type" => "StringType", "Name" => "Invoice no", "StringValue" => $docNumber]]);
                            $resultingObj = $dataService->Update($theResourceObj);
                            $employeeId = $valueEmployeeList;
                            $this->getInvoiceInPdfByEmployee($invoiceId, $invoicePdfDate, $employeeId, $totalHoursOfEmployeeData);
                            $error = $dataService->getLastError();
                            if ($error) {
                                echo "The Status code is: " . $error->getHttpStatusCode() . "\n";
                                echo "The Helper message is: " . $error->getOAuthHelperError() . "\n";
                                echo "The Response message is: " . $error->getResponseBody() . "\n";
                            } else {
                                $this->mappingdbDatabase->exec("INSERT INTO `quickbook_invoice`(`id`, `client_id`, `consultant_id`, `start_date`, `end_date`, `quickbook_amount`, `created_at`) VALUES ('','$customer','$valueEmployeeList','$startDate','$endDate','$quickbookAmount','$currentDate')");
                                $response = 2;
                                $this->responseArray = $response;
                            }
                        }
                    }
                }
            }
        }
        unset($accessToken);
        unset($refreshToken);
        unset($realmId);
        unset($quickbookUrl);
        unset($clientId);
        unset($clientSecret);
        unset($invoiceDate);
        unset($startDate);
        unset($endDate);
        unset($customer);
        unset($employee);
        unset($date);
        unset($month);
        unset($year);
        unset($monthNum);
        unset($dateObj);
        unset($monthName);
        unset($formattedDate);
        unset($currentDate);
        unset($timestamp);
        unset($invoicePdfDate);
        unset($query);
        return $this->responseArray;
    }
    public function getInvoiceInPdfByEmployee($invoiceId, $invoicePdfDate, $employeeId, $totalHoursOfEmployeeData) {
        $quickbookUrl = $this->container->getParameter('quickbookUrl');
        $accessToken = $this->request->get('accessToken');
        $realmId = $this->container->getParameter('realmId');
        $quickbookPdfLocation = $this->container->getParameter('invoiceLocation');
        $query = "select%20%2a%20from%20Invoice%20where%20id%20%3d%20%27" . $invoiceId . "%27";
        $curl = curl_init();
        curl_setopt_array($curl, array(CURLOPT_URL => $quickbookUrl . "/v3/company/" . $realmId . "/query?query=" . $query . "&minorversion=4", CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 30, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "GET", CURLOPT_HTTPHEADER => array("authorization: Bearer " . $accessToken, "content-type: application/json"),));
        $qbeResponse = curl_exec($curl);
        curl_close($curl);
        $xmlqbeResponse = simplexml_load_string($qbeResponse, "SimpleXMLElement", LIBXML_NOCDATA);
        $jsonqbeResponse = json_encode($xmlqbeResponse);
        $quickbookInvoiceResponse = json_decode($jsonqbeResponse, TRUE);
        $quickbookInvoiceResponse = $quickbookInvoiceResponse['QueryResponse']['Invoice'];
        $docNumber = $quickbookInvoiceResponse['DocNumber'];
        $query = "SELECT reference_id FROM `quickbook_mapping` WHERE `mapping_id` = '$employeeId' AND `mapping_type` in ('Vendor','Employee')";
        $getEmployeeName = $this->mappingdbDatabase->query($query)->fetchColumn(0);
        $query = "SELECT CONCAT(first_name,' ',last_name) as name FROM `employees` WHERE id = '$getEmployeeName'";
        $employeeName = $this->icehrmdbDatabase->query($query)->fetchColumn(0);
        $totalHoursOfCandidate = array_sum($totalHoursOfEmployeeData[$employeeId]);
        foreach ($quickbookInvoiceResponse as $key => $value) {
            $curl = curl_init();
            curl_setopt_array($curl, array(CURLOPT_URL => $quickbookUrl . "/v3/company/" . $realmId . "/invoice/" . $invoiceId . "/pdf", CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 30, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "GET", CURLOPT_POSTFIELDS => "", CURLOPT_HTTPHEADER => array("authorization: Bearer " . $accessToken, "content-type: application/pdf"),));
            $response = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);
            if ($err) {
                $this->responseArray = "cURL Error #:" . $err;
            } else {
                $employeeFileLocation = "Invoice" . ' ' . $invoicePdfDate;
                $directoryName = $quickbookPdfLocation . ' ' . $employeeFileLocation;
                if (!is_dir($directoryName)) {
                    mkdir($directoryName, 0755);
                }
                $location = $directoryName . '/' . 'Invoice' . ' ' . $docNumber . ' ' . $employeeName . ' ' . '(' . $totalHoursOfCandidate . 'hrs' . ')' . ' ' . $invoicePdfDate . '.pdf';
                if (!file_exists($location)) {
                    $fp = fopen($location, 'w');
                    fwrite($fp, $response);
                    fclose($fp);
                }
            }
        }
        unset($query);
        unset($quickbookPdfLocation);
        unset($directoryName);
        unset($location);
        unset($response);
        unset($err);
        unset($curl);
        unset($qbeResponse);
        unset($xmlqbeResponse);
        unset($jsonqbeResponse);
        unset($quickbookInvoiceResponse);
        unset($docNumber);
        unset($getEmployeeName);
        unset($quickbookInvoiceResponse);
        return $this->responseArray;
    }
    public function getInvoiceInPdfByCustomer($invoiceId, $invoicePdfDate, $customer, $totalHoursOfEmployee) {
        $quickbookUrl = $this->container->getParameter('quickbookUrl');
        $accessToken = $this->request->get('accessToken');
        $realmId = $this->container->getParameter('realmId');
        $query = "select%20%2a%20from%20Invoice%20where%20id%20%3d%20%27" . $invoiceId . "%27";
        $quickbookPdfLocation = $this->container->getParameter('invoiceLocation');
        $curl = curl_init();
        curl_setopt_array($curl, array(CURLOPT_URL => $quickbookUrl . "/v3/company/" . $realmId . "/query?query=" . $query . "&minorversion=4", CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 30, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "GET", CURLOPT_HTTPHEADER => array("authorization: Bearer " . $accessToken, "content-type: application/json"),));
        $qbeResponse = curl_exec($curl);
        curl_close($curl);
        $xmlqbeResponse = simplexml_load_string($qbeResponse, "SimpleXMLElement", LIBXML_NOCDATA);
        $jsonqbeResponse = json_encode($xmlqbeResponse);
        $quickbookInvoiceResponse = json_decode($jsonqbeResponse, TRUE);
        $quickbookInvoiceResponse = $quickbookInvoiceResponse['QueryResponse']['Invoice'];
        $docNumber = $quickbookInvoiceResponse['DocNumber'];
        $query = "SELECT mapping_name FROM `quickbook_mapping` WHERE `mapping_id` = '$customer' AND mapping_type = 'Customer'";
        $getCustomerName = $this->mappingdbDatabase->query($query)->fetchColumn(0);
        foreach ($quickbookInvoiceResponse as $key => $value) {
            $curl = curl_init();
            curl_setopt_array($curl, array(CURLOPT_URL => $quickbookUrl . "/v3/company/" . $realmId . "/invoice/" . $invoiceId . "/pdf", CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 30, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "GET", CURLOPT_POSTFIELDS => "", CURLOPT_HTTPHEADER => array("authorization: Bearer " . $accessToken, "content-type: application/pdf"),));
            $response = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);
            if ($err) {
                $this->responseArray = "cURL Error #:" . $err;
            } else {
                $customerFileLocation = "Invoice" . ' ' . $invoicePdfDate;
                $directoryName = $quickbookPdfLocation . ' ' . $customerFileLocation;
                if (!is_dir($directoryName)) {
                    mkdir($directoryName, 0755);
                }
                $location = $directoryName . '/' . 'Invoice' . ' ' . $docNumber . ' ' . $getCustomerName . ' ' . '(' . $totalHoursOfEmployee . 'hrs' . ')' . ' ' . $invoicePdfDate . '.pdf';
                if (!file_exists($location)) {
                    $fp = fopen($location, 'w');
                    fwrite($fp, $response);
                    fclose($fp);
                }
            }
        }
        unset($query);
        unset($quickbookPdfLocation);
        unset($directoryName);
        unset($location);
        unset($response);
        unset($err);
        unset($curl);
        unset($qbeResponse);
        unset($xmlqbeResponse);
        unset($jsonqbeResponse);
        unset($quickbookInvoiceResponse);
        unset($docNumber);
        unset($getCustomerName);
        unset($quickbookInvoiceResponse);
        return $this->responseArray;
    }
    public function getDocNumberOfInvoice($invoiceId) {
        $quickbookUrl = $this->container->getParameter('quickbookUrl');
        $accessToken = $this->request->get('accessToken');
        $realmId = $this->container->getParameter('realmId');
        $query = "select%20%2a%20from%20Invoice%20where%20id%20%3d%20%27" . $invoiceId . "%27";
        $curl = curl_init();
        curl_setopt_array($curl, array(CURLOPT_URL => $quickbookUrl . "/v3/company/" . $realmId . "/query?query=" . $query . "&minorversion=4", CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 30, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "GET", CURLOPT_HTTPHEADER => array("authorization: Bearer " . $accessToken, "content-type: application/json"),));
        $qbeResponse = curl_exec($curl);
        curl_close($curl);
        $xmlqbeResponse = simplexml_load_string($qbeResponse, "SimpleXMLElement", LIBXML_NOCDATA);
        $jsonqbeResponse = json_encode($xmlqbeResponse);
        $quickbookInvoiceResponse = json_decode($jsonqbeResponse, TRUE);
        $quickbookInvoiceResponse = $quickbookInvoiceResponse['QueryResponse']['Invoice'];
        $docNumber = $quickbookInvoiceResponse['DocNumber'];
        unset($query);
        unset($quickbookUrl);
        unset($accessToken);
        unset($realmId);
        unset($curl);
        unset($xmlqbeResponse);
        unset($jsonqbeResponse);
        unset($quickbookInvoiceResponse);
        return $docNumber;
    }
    public function getEmployeeName($employeeId) {
        $this->icehrmdbDatabase = $this->container->get('v_tech_solution_quick_book.icehrmdb')->getPDO();
        $this->mappingdbDatabase = $this->container->get('v_tech_solution_quick_book.mappingdb')->getPDO();
        $query = "SELECT reference_id FROM `quickbook_mapping` WHERE `mapping_id` = '$employeeId' AND `mapping_type` in ('Vendor','Employee')";
        $getEmployeeName = $this->mappingdbDatabase->query($query)->fetchColumn(0);
        $query = "SELECT CONCAT(first_name,' ',last_name) as name FROM `employees` WHERE id = '$getEmployeeName'";
        $employeeName = $this->icehrmdbDatabase->query($query)->fetchColumn(0);
        unset($query);
        return $employeeName;
    }
    public function getCustomerDetailFromMapping() {
        $this->mappingdbDatabase = $this->container->get('v_tech_solution_quick_book.mappingdb')->getPDO();
        $query = "SELECT DISTINCT mapping_id, mapping_name FROM `quickbook_mapping` WHERE mapping_type = 'Customer' ORDER BY `mapping_type` ASC";
        $this->responseArray = $this->mappingdbDatabase->query($query)->fetchAll();
        unset($query);
        return $this->responseArray;
    }
    public function getTermsFromQuickBook() {
        $tokens = $this->getAccessTokencode();
        $accessToken = $tokens['access_token'];
        $quickbookUrl = $this->container->getParameter('quickbookUrl');
        $realmId = $this->container->getParameter('realmId');
        $query = "select%20%2a%20FROM%20Term";
        $curl = curl_init();
        curl_setopt_array($curl, array(CURLOPT_URL => $quickbookUrl . "/v3/company/" . $realmId . "/query?query=" . $query . "&minorversion=4", CURLOPT_RETURNTRANSFER => true, CURLOPT_ENCODING => "", CURLOPT_MAXREDIRS => 10, CURLOPT_TIMEOUT => 30, CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1, CURLOPT_CUSTOMREQUEST => "GET", CURLOPT_HTTPHEADER => array("authorization: Bearer " . $accessToken, "content-type: application/json"),));
        $qbeResponse = curl_exec($curl);
        curl_close($curl);
        $xmlqbeResponse = simplexml_load_string($qbeResponse, "SimpleXMLElement", LIBXML_NOCDATA);
        $jsonqbeResponse = json_encode($xmlqbeResponse);
        $quickbookCustomerResponse = json_decode($jsonqbeResponse, TRUE);
        unset($accessToken);
        unset($quickbookUrl);
        unset($realmId);
        unset($query);
        unset($curl);
        unset($qbeResponse);
        unset($xml);
        unset($json);
        $this->quickbookTermsDetail = $quickbookCustomerResponse['QueryResponse']['Term'];
        return $this->quickbookTermsDetail;
    }
}

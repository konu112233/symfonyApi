<?php

namespace vTechSolution\Bundle\QuickBookBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class vTechSolutionQuickBookBundle extends Bundle
{
}

<?php

namespace vTechSolution\Bundle\SearchBundle\Document;

use Doctrine\ODM\MongoDB\Mapping\Annotations as MongoDB;

/**
 * @MongoDB\Document(repositoryClass="vTechSolution\Bundle\SearchBundle\Document\SuggestedKeyStringsRepository")
 */
class SuggestedKeyStrings
{
    /**
    * @MongoDB\Id
    */
    protected $id;

    /**
    * @MongoDB\Field(type="integer")
    */
    protected $joborderId;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $resouce;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $keyString;

    /**
     * @MongoDB\Date
     */
    protected $createdAt;

    /**
     * Get id
     *
     * @return id $id
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set joborderId
     *
     * @param integer $joborderId
     * @return $this
     */
    public function setJoborderId($joborderId)
    {
        $this->joborderId = $joborderId;
        return $this;
    }

    /**
     * Get joborderId
     *
     * @return integer $joborderId
     */
    public function getJoborderId()
    {
        return $this->joborderId;
    }

    /**
     * Set resouce
     *
     * @param string $resouce
     * @return $this
     */
    public function setResouce($resouce)
    {
        $this->resouce = $resouce;
        return $this;
    }

    /**
     * Get resouce
     *
     * @return string $resouce
     */
    public function getResouce()
    {
        return $this->resouce;
    }

    /**
     * Set keyString
     *
     * @param string $keyString
     * @return $this
     */
    public function setkeyString($keyString)
    {
        $this->keyString = $keyString;
        return $this;
    }

    /**
     * Get keyString
     *
     * @return string $keyString
     */
    public function getkeyString()
    {
        return $this->keyString;
    }

    /**
     * Set createdAt
     *
     * @param timestamp $createdAt
     * @return $this
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
        return $this;
    }

    /**
     * Get createdAt
     *
     * @return timestamp $createdAt
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

}

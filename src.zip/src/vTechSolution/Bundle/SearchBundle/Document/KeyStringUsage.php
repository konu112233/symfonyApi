<?php

namespace vTechSolution\Bundle\SearchBundle\Document;

use Doctrine\ODM\MongoDB\Mapping\Annotations as MongoDB;

/**
 * @MongoDB\Document(repositoryClass="vTechSolution\Bundle\SearchBundle\Document\KeyStringUsageRepository")
 */
class KeyStringUsage
{
    /**
    * @MongoDB\Id
    */
    protected $id;

    /**
    * @MongoDB\Field(type="integer")
    */
    protected $userId;

    /**
    * @MongoDB\Field(type="integer")
    */
    protected $joborderId;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $keyString;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $source;

    /**
     * @MongoDB\Date
     */
    protected $createdAt;

    /**
     * Get id
     *
     * @return id $id
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set userId
     *
     * @param integer $userId
     * @return $this
     */
    public function setUserId($userId)
    {
        $this->userId = $userId;
        return $this;
    }

    /**
     * Get userId
     *
     * @return integer $userId
     */
    public function getUserId()
    {
        return $this->userId;
    }

    /**
     * Set joborderId
     *
     * @param integer $joborderId
     * @return $this
     */
    public function setJoborderId($joborderId)
    {
        $this->joborderId = $joborderId;
        return $this;
    }

    /**
     * Get joborderId
     *
     * @return integer $joborderId
     */
    public function getJoborderId()
    {
        return $this->joborderId;
    }

    /**
     * Set keyString
     *
     * @param string $keyString
     * @return $this
     */
    public function setkeyString($keyString)
    {
        $this->keyString = $keyString;
        return $this;
    }

    /**
     * Get keyString
     *
     * @return string $keyString
     */
    public function getkeyString()
    {
        return $this->keyString;
    }

    /**
     * Set source
     *
     * @param string $source
     * @return $this
     */
    public function setSource($source)
    {
        $this->source = $source;
        return $this;
    }

    /**
     * Get source
     *
     * @return string $source
     */
    public function getSource()
    {
        return $this->source;
    }

    /**
     * Set createdAt
     *
     * @param timestamp $createdAt
     * @return $this
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
        return $this;
    }

    /**
     * Get createdAt
     *
     * @return timestamp $createdAt
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

}

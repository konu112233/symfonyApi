<?php

namespace vTechSolution\Bundle\SearchBundle\Document;

use Doctrine\ODM\MongoDB\Mapping\Annotations as MongoDB;

/**
 * @MongoDB\Document(repositoryClass="vTechSolution\Bundle\SearchBundle\Document\SaveSearchRepository")
 */
class HotList
{
    /**
    * @MongoDB\Id
    */
    protected $id;

    /**
    * @MongoDB\Field(type="integer")
    */
    protected $date;

    /**
     * @MongoDB\Date
     */
    protected $recruiterId;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $data;

    /**
    * @MongoDB\Field(type="string")
    */

    protected $updatedAt;

    /**
     * Get id
     *
     * @return id $id
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set userId
     *
     * @param string $userId
     * @return $this
     */
    public function setRecruiterId($recruiterId)
    {
        $this->recruiterId = $recruiterId;
        return $this;
    }

    /**
     * Get userId
     *
     * @return string $userId
     */
    public function getRecruiterId()
    {
        return $this->recruiterId;
    }

    /**
     * Set date
     *
     * @param timestamp $date
     * @return $this
     */
    public function setDate($date)
    {
        $this->date = $date;
        return $this;
    }

    /**
     * Get date
     *
     * @return timestamp $date
     */
    public function getDate()
    {
        return $this->date;
    }

    /**
     * Set data
     *
     * @param string $data
     * @return $this
     */
    public function setData($data)
    {
        $this->Data = $data;
        return $this;
    }

    /**
     * Get data
     *
     * @return string $data
     */
    public function getData()
    {
        return $this->Data;
    }
}

<?php

namespace vTechSolution\Bundle\SearchBundle\Document;

use Doctrine\ODM\MongoDB\Mapping\Annotations as MongoDB;

/**
 * @MongoDB\Document(repositoryClass="vTechSolution\Bundle\SearchBundle\Document\RelevanceCandidateRepository")
 */
class RelevanceCandidate
{
    /**
    * @MongoDB\Id
    */
    protected $id;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $joborderId;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $records;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $skill;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $city;


    /**
    * @MongoDB\Field(type="string")
    */
    protected $candidates;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $createdAt;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $updatedAt;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $createdTime;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $updatedTime;

    /**
     * Get id
     *
     * @return id $id
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set joborderId
     *
     * @param string $joborderId
     * @return $this
     */
    public function setJoborderId($joborderId)
    {
        $this->joborderId = $joborderId;
        return $this;
    }

    /**
     * Get joborderId
     *
     * @return string $joborderId
     */
    public function getJoborderId()
    {
        return $this->joborderId;
    }

    /**
     * Set records
     *
     * @param string $records
     * @return $this
     */
    public function setRecords($records)
    {
        $this->records = $records;
        return $this;
    }

    /**
     * Get records
     *
     * @return string $records
     */
    public function getRecords()
    {
        return $this->records;
    }

    /**
     * Set skill
     *
     * @param string $skill
     * @return $this
     */

    public function setSkill($skill)
    {
        $this->skill = $skill;
        return $this;
    }

    /**
     * Get skill
     *
     * @return string $skill
     */
    public function getSkill()
    {
        return $this->skill;
    }

    /**
     * Set city
     *
     * @param string $city
     * @return $this
     */

    public function setCity($city)
    {
        $this->city = $city;
        return $this;
    }

    /**
     * Get city
     *
     * @return string $city
     */
    public function getCity()
    {
        return $this->city;
    }

    /**
     * Set candidates
     *
     * @param string $candidates
     * @return $this
     */
    public function setCandidates($candidates)
    {
        $this->candidates = $candidates;
        return $this;
    }

    /**
     * Get candidates
     *
     * @return string $candidates
     */
    public function getCandidates()
    {
        return $this->candidates;
    }

    /**
     * Set createdAt
     *
     * @param string $createdAt
     * @return $this
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
        return $this;
    }

    /**
     * Get createdAt
     *
     * @return string $createdAt
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set updatedAt
     *
     * @param string $updatedAt
     * @return $this
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;
        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return string $updatedAt
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    /**
     * Set createdTime
     *
     * @param string $createdTime
     * @return $this
     */
    public function setCreatedTime($createdTime)
    {
        $this->createdTime = $createdTime;
        return $this;
    }

    /**
     * Get createdTime
     *
     * @return string $createdTime
     */
    public function getCreatedTime()
    {
        return $this->createdTime;
    }

    /**
     * Set updatedTime
     *
     * @param string $updatedTime
     * @return $this
     */
    public function setUpdatedTime($updatedTime)
    {
        $this->updatedTime = $updatedTime;
        return $this;
    }

    /**
     * Get updatedTime
     *
     * @return string $updatedTime
     */
    public function getUpdatedTime()
    {
        return $this->updatedTime;
    }


}

<?php

namespace vTechSolution\Bundle\SearchBundle\Document;

use Doctrine\ODM\MongoDB\Mapping\Annotations as MongoDB;

/**
 * @MongoDB\Document(repositoryClass="vTechSolution\Bundle\SearchBundle\Document\SaveSearchRepository")
 */
class SaveSearch
{
    /**
    * @MongoDB\Id
    */
    protected $id;

    /**
    * @MongoDB\Field(type="integer")
    */
    protected $userId;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $resouce;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $keyString;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $searchResult;

    /**
    * @MongoDB\Field(type="integer")
    */
    protected $totalCount;

    /**
     * @MongoDB\Date
     */
    protected $createdAt;

    /**
     * @MongoDB\Date
     */
    protected $updatedAt;

    /**
     * Get id
     *
     * @return id $id
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set userId
     *
     * @param integer $userId
     * @return $this
     */
    public function setUserId($userId)
    {
        $this->userId = $userId;
        return $this;
    }

    /**
     * Get userId
     *
     * @return integer $userId
     */
    public function getUserId()
    {
        return $this->userId;
    }

    /**
     * Set resouce
     *
     * @param string $resouce
     * @return $this
     */
    public function setResouce($resouce)
    {
        $this->resouce = $resouce;
        return $this;
    }

    /**
     * Get resouce
     *
     * @return string $resouce
     */
    public function getResouce()
    {
        return $this->resouce;
    }

    /**
     * Set keyString
     *
     * @param string $keyString
     * @return $this
     */
    public function setkeyString($keyString)
    {
        $this->keyString = $keyString;
        return $this;
    }

    /**
     * Get keyString
     *
     * @return string $keyString
     */
    public function getkeyString()
    {
        return $this->keyString;
    }

    /**
     * Set searchResult
     *
     * @param string $searchResult
     * @return $this
     */
    public function setSearchResult($searchResult)
    {
        $this->searchResult = $searchResult;
        return $this;
    }

    /**
     * Get searchResult
     *
     * @return string $searchResult
     */
    public function getSearchResult()
    {
        return $this->searchResult;
    }

    /**
     * Set totalCount
     *
     * @param integer $totalCount
     * @return $this
     */
    public function setTotalCount($totalCount)
    {
        $this->totalCount = $totalCount;
        return $this;
    }

    /**
     * Get totalCount
     *
     * @return integer $totalCount
     */
    public function getTotalCount()
    {
        return $this->totalCount;
    }

    /**
     * Set createdAt
     *
     * @param timestamp $createdAt
     * @return $this
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
        return $this;
    }

    /**
     * Get createdAt
     *
     * @return timestamp $createdAt
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set updatedAt
     *
     * @param timestamp $updatedAt
     * @return $this
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;
        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return timestamp $updatedAt
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    
    /**
     * @MongoDB\PrePersist
     */
    public function onPrePersist()
    {
        $this->createdAt = new DateTime();
    }

    /**
     * @MongoDB\PreUpdate
     */
    public function onPreUpdate()
    {
        $this->updatedAt = new DateTime();
    }
}

<?php

namespace vTechSolution\Bundle\SearchBundle\Document;

use Doctrine\ODM\MongoDB\Mapping\Annotations as MongoDB;

/**
 * @MongoDB\Document(repositoryClass="vTechSolution\Bundle\SearchBundle\Document\MatchedJobOrdersRepository")
 */
class MatchedJobOrders
{
    /**
    * @MongoDB\Id
    */
    protected $id;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $joborderId;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $matchedJobOrderList;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $totalWords;

    /**
    * @MongoDB\Date
    */
    protected $createdAt;

    /**
     * Get id
     *
     * @return id $id
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set joborderId
     *
     * @param string $joborderId
     * @return $this
     */
    public function setJoborderId($joborderId)
    {
        $this->joborderId = $joborderId;
        return $this;
    }

    /**
     * Get joborderId
     *
     * @return string $joborderId
     */
    public function getJoborderId()
    {
        return $this->joborderId;
    }

    /**
     * Set matchedJobOrderList
     *
     * @param string $matchedJobOrderList
     * @return $this
     */
    public function setMatchedJobOrderList($matchedJobOrderList)
    {
        $this->matchedJobOrderList = $matchedJobOrderList;
        return $this;
    }

    /**
     * Get matchedJobOrderList
     *
     * @return string $matchedJobOrderList
     */
    public function getMatchedJobOrderList()
    {
        return $this->matchedJobOrderList;
    }

    /**
     * Set totalWords
     *
     * @param string $totalWords
     * @return $this
     */
    public function setTotalWords($totalWords)
    {
        $this->totalWords = $totalWords;
        return $this;
    }

    /**
     * Get totalWords
     *
     * @return string $totalWords
     */
    public function getTotalWords()
    {
        return $this->totalWords;
    }

    /**
     * Set createdAt
     *
     * @param timestamp $createdAt
     * @return $this
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
        return $this;
    }

    /**
     * Get createdAt
     *
     * @return timestamp $createdAt
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

}

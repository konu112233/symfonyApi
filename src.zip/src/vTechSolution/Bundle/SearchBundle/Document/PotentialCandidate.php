<?php

namespace vTechSolution\Bundle\SearchBundle\Document;

use Doctrine\ODM\MongoDB\Mapping\Annotations as MongoDB;

/**
 * @MongoDB\Document(repositoryClass="vTechSolution\Bundle\SearchBundle\Document\PotentialCandidateRepository")
 */
class PotentialCandidate
{
    /**
    * @MongoDB\Id
    */
    protected $id;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $joborderId;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $title;


    /**
    * @MongoDB\Field(type="string")
    */
    protected $candidates;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $monster;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $nexxt;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $candidateList;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $createdAt;

    /**
     * Get id
     *
     * @return id $id
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set joborderId
     *
     * @param string $joborderId
     * @return $this
     */
    public function setJoborderId($joborderId)
    {
        $this->joborderId = $joborderId;
        return $this;
    }

    /**
     * Get joborderId
     *
     * @return string $joborderId
     */
    public function getJoborderId()
    {
        return $this->joborderId;
    }

    /**
     * Set title
     *
     * @param string $title
     * @return $this
     */
    public function setTitle($title)
    {
        $this->title = $title;
        return $this;
    }

    /**
     * Get title
     *
     * @return string $title
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set nexxt
     *
     * @param string $nexxt
     * @return $this
     */

    public function setNexxt($nexxt)
    {
        $this->nexxt = $nexxt;
        return $this;
    }

    /**
     * Get nexxt
     *
     * @return string $nexxt
     */
    public function getNexxt()
    {
        return $this->nexxt;
    }

    /**
     * Set monster
     *
     * @param string $monster
     * @return $this
     */
    public function setMonster($monster)
    {
        $this->monster = $monster;
        return $this;
    }

    /**
     * Get monster
     *
     * @return string $monster
     */
    public function getMonster()
    {
        return $this->monster;
    }

    /**
     * Set candidateList
     *
     * @param string $candidateList
     * @return $this
     */
    public function setCandidateList($candidateList)
    {
        $this->candidateList = $candidateList;
        return $this;
    }

    /**
     * Get candidateList
     *
     * @return string $candidateList
     */
    public function getCandidateList()
    {
        return $this->candidateList;
    }

    /**
     * Set createdAt
     *
     * @param string $createdAt
     * @return $this
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
        return $this;
    }

    /**
     * Get createdAt
     *
     * @return string $createdAt
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set candidates
     *
     * @param string $candidates
     * @return $this
     */
    public function setCandidates($candidates)
    {
        $this->candidates = $candidates;
        return $this;
    }

    /**
     * Get candidates
     *
     * @return string $candidates
     */
    public function getCandidates()
    {
        return $this->candidates;
    }

}

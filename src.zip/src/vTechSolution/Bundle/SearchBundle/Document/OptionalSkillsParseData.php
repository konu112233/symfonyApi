<?php

namespace vTechSolution\Bundle\SearchBundle\Document;

use Doctrine\ODM\MongoDB\Mapping\Annotations as MongoDB;

/**
 * @MongoDB\Document(repositoryClass="vTechSolution\Bundle\SearchBundle\Document\OptionalSkillsParseDataRepository")
 */
class OptionalSkillsParseData
{
    /**
    * @MongoDB\Id
    */
    protected $id;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $joborderId;

    /**
    * @MongoDB\Field(type="string")
    */
    protected $optionalSkills;

    /**
    * @MongoDB\Date
    */
    protected $createdAt;

    /**
     * Get id
     *
     * @return id $id
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set joborderId
     *
     * @param string $joborderId
     * @return $this
     */
    public function setJoborderId($joborderId)
    {
        $this->joborderId = $joborderId;
        return $this;
    }

    /**
     * Get joborderId
     *
     * @return string $joborderId
     */
    public function getJoborderId()
    {
        return $this->joborderId;
    }

    /**
     * Set optionalSkills
     *
     * @param string $optionalSkills
     * @return $this
     */
    public function setOptionalSkills($optionalSkills)
    {
        $this->optionalSkills = $optionalSkills;
        return $this;
    }

    /**
     * Get optionalSkills
     *
     * @return string $optionalSkills
     */
    public function getOptionalSkills()
    {
        return $this->optionalSkills;
    }

    /**
     * Set createdAt
     *
     * @param timestamp $createdAt
     * @return $this
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;
        return $this;
    }

    /**
     * Get createdAt
     *
     * @return timestamp $createdAt
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

}

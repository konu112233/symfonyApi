<?php

namespace vTechSolution\Bundle\SearchBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class vTechSolutionSearchBundle extends Bundle
{
}

<?php

namespace vTechSolution\Bundle\SearchBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class SearchBundleControllerTest extends WebTestCase
{
    public function testCandidate()
    {
        $client = static::createClient();

        $crawler = $client->request('GET', '/candidate');
    }

}

<?php

namespace vTechSolution\Bundle\SearchBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;


/**
 * @Route("/search")
 */
class SearchBundleController extends Controller
{
    private $responseArray;
    private $request;
    private $candidateService;

    private function initAction()
    {
    $this->responseArray = array();
    $this->request = $this->getRequest();

    $this->candidateService = $this->get('v_tech_solution_search.candidate');
    }

    /**
     * @Route("/candidate", name="vtech_solution_bundle_search_candidate")
     * @Method({"GET"})
     */
    public function candidateAction()
    {
        $candidateService = $this->get('v_tech_solution_search.candidate');

        $candidateService->searchCandidate();

        return $this->render('vTechSolutionSearchBundle:SearchBundle:candidate.html.twig', array(
        ));
    }

    /**
     * @Route("/candidate/add", name="vtech_solution_bundle_search_candidate_add")
     * @Method({"GET"})
     */
    public function candidateAddAction()
    {
        $candidateService = $this->get('v_tech_solution_search.candidate');

        $result1=$candidateService->atsToSolrMigrate();

        return $this->render('vTechSolutionSearchBundle:SearchBundle:candidate.html.twig', array(
        ));
    }

      /**
     * @Route("/candidate/search", name="vtech_solution_bundle_search_solr_candidate")
     * @Method({"GET"})
     */
    public function atssearchAction(Request $request)
    {
       $candidateService = $this->get('v_tech_solution_search.candidate');

       $this->responseArray = $candidateService->searchsolrCandidate();

       return new JsonResponse($this->responseArray);

    }

    /**
     * @Route("/save-data", name="vtech_solution_bundle_search_save_data")
     * @Method({"POST"})
     */
    public function saveDataAction()
    {
        $this->initAction();

        $this->responseArray = $this->candidateService->saveSearchData();

        return new JsonResponse($this->responseArray);
    }

    /**
     * @Route("/recent-search", name="vtech_solution_bundle_search_recent_searcg")
     * @Method({"GET"})
     */
    public function recentSearchAction()
    {
        $this->initAction();

        $this->responseArray = $this->candidateService->recentSearch();

        return new JsonResponse($this->responseArray);
    }

 /**
     * @Route("/candidate/joborderparse/{id}/{start}/{end}/{skill}/{city}", name="vtech_solution_bundle_joborderparse")
     * @Method({"GET"})
     */
    public function joborderparseAction(Request $request)
    {

        $this->initAction();

        $this->responseArray['parseresult'] = $this->candidateService->jobOrderParse();

        return new JsonResponse($this->responseArray);
     }

     /**
      * @Route("/candidate/jobparse", name="vtech_solution_bundle_search_job_parse")
      * @Method({"GET"})
      */
     public function jobParseData()
     {
         $this->initAction();

         $this->responseArray = $this->candidateService->jobDescriptionParse();

         return new JsonResponse($this->responseArray);
     }

     /**
      * @Route("/candidate/jobmatch", name="vtech_solution_bundle_search_job_match")
      * @Method({"GET"})
      */
     public function jobParseMatch()
     {
         $this->initAction();

         $this->responseArray = $this->candidateService->jobParseDataMatch();

         return new JsonResponse($this->responseArray);
     }

     /**
      * @Route("/candidate/find-candidate", name="vtech_solution_bundle_search_find_candidate")
      * @Method({"GET"})
      */
     public function findCandidateFromJob()
     {
         $this->initAction();

         $this->responseArray = $this->candidateService->findCandidateFromMatchedJoborders();

         return new JsonResponse($this->responseArray);
     }

     /**
      * @Route("/candidate/suggested-keystrings", name="vtech_solution_bundle_search_suggested_keystrings")
      * @Method({"GET"})
      */
     public function keyStringSuggestions()
     {
         $this->initAction();

         $this->responseArray = $this->candidateService->findSuggestedKeyStrings();

         return new JsonResponse($this->responseArray);
     }

     /**
      * @Route("/candidate/keystring-usage", name="vtech_solution_bundle_search_keystring_usage")
      * @Method({"GET"})
      */
     public function keyStringUsageReport()
     {
         $this->initAction();

         $this->responseArray = $this->candidateService->keyStringUsage();

         return new JsonResponse($this->responseArray);
     }

     /**
      * @Route("/candidate/keystring-for-single-job", name="vtech_solution_bundle_search_keystring_for_single_job")
      * @Method({"POST"})
      */
     public function findKeyStringForSingleJobAction()
     {
         $this->initAction();

         $this->responseArray = $this->candidateService->findKeyStringForSingleJob();

         return new JsonResponse($this->responseArray);
     }

     /**
      * @Route("/candidate/candidate-search", name="vtech_solution_bundle_search_candidate_search")
      * @Method({"GET"})
      */
     public function findCandidateFromKeystringAction()
     {
         $this->initAction();

         $this->responseArray = $this->candidateService->findCandidateFromKeystring();

         return new JsonResponse($this->responseArray);
     }

     /**
      * @Route("/candidate/candidate-list", name="vtech_solution_bundle_search_candidate_list")
      * @Method({"GET"})
      */
     public function potentialCandidatesListAction()
     {
         $this->initAction();

         $this->responseArray = $this->candidateService->candidatesList();

         return new JsonResponse($this->responseArray);
     }

     /**
     * @Route("/candidate/potential/{id}", name="vtech_solution_bundle_potential_candidate")
     * @Method({"GET"})
     */
    public function potentialAction(Request $request)
    {

        $this->initAction();

        $this->responseArray['parseresult'] = $this->candidateService->potentialCandidate();

        return new JsonResponse($this->responseArray);
     }

/**
     * @Route("/candidate/keystringsearch/{id}", name="vtech_solution_bundle_keystringsearch")
     * @Method({"GET"})

     */
    public function keystringsearchAction(Request $request)
    {

        $this->initAction();

        $this->responseArray['parseresult'] = $this->candidateService->keyStringSearch();

        return new JsonResponse($this->responseArray);
    }
 /**
     * @Route("/candidate/textrazor", name="vtech_solution_bundle_textrazor")
     * @Method({"POST"})

     */
    public function textrazorAction(Request $request)
    {
    $this->initAction();
    $this->responseArray['parseresult'] = $this->candidateService->textRazorParse();
    return new JsonResponse($this->responseArray);
    }

 /**
     * @Route("/candidate/relevancecandidateinsert", name="vtech_solution_bundle_relevancecandidate")
     * @Method({"GET"})

     */
    public function relevancecandidateAction(Request $request)
    {
    $this->initAction();
    $this->responseArray = $this->candidateService->relevantCandidate();
    return new JsonResponse($this->responseArray);
    }

 /**
     * @Route("/candidate/relevancecandidatecount", name="vtech_solution_bundle_relevancecandidatecount")
     * @Method({"GET"})

     */
    public function relevancecandidatecountsAction(Request $request)
    {
    $this->initAction();
    $this->responseArray = $this->candidateService->relevantCandidateCount();
    return new JsonResponse($this->responseArray);
    }

 /**
     * @Route("/candidate/relevancefetch/{id}", name="vtech_solution_bundle_relevancecandidatelist")
     * @Method({"GET"})

     */
    public function relevancecandidatefetchAction(Request $request)
    {
    $this->initAction();
    $this->responseArray['parseresult'] = $this->candidateService->relevantCandidateList();
    return new JsonResponse($this->responseArray);
    }

 /**
     * @Route("/candidate/potentiallist/{id}", name="vtech_solution_bundle_potentialcandidatelist")
     * @Method({"GET"})

     */
    public function potentialcandidatelistAction(Request $request)
    {
    $this->initAction();
    $this->responseArray['parseresult'] = $this->candidateService->potentialCandidateList();
    return new JsonResponse($this->responseArray);
    }

}

<?php
namespace vTechSolution\Bundle\SearchBundle\Manager;

class ClassifierManager extends TextRazorConnection {
    public function __construct($apiKey = NULL) {
        parent::__construct($apiKey);
    }
    public function createClassifier($classifierID, $categories) {
        $request = array();
        if(!is_string($classifierID)) {
            throw new Exception('TextRazor Error: Classifiers must have an ID.');
        }
        if(!is_array($categories)) {
            throw new Exception('TextRazor Error: $categories must be a List of dicts corresponding to properties of the new Category objects.');
        }
        if (empty($categories)) {
            throw new Exception('TextRazor Error: Array of new categories cannot be empty.');
        }
        return $this->sendRequest(json_encode($categories), "/categories/" . $classifierID, "PUT", "application/json");
    }
    public function createClassifierWithCSV($classifierID, $categoriesCSV) {
        $request = array();
        if(!is_string($classifierID)) {
            throw new Exception('TextRazor Error: Classifiers must have an ID.');
        }
        if(!is_string($categoriesCSV)) {
            throw new Exception('TextRazor Error: $categoriesCSV must be a String containing the contents of a csv file that defines a new classifier.');
        }
        return $this->sendRequest($categoriesCSV, "/categories/" . $classifierID, "PUT", "application/csv");
    }
    public function deleteClassifier($classifierID) {
        return $this->sendRequest("", "/categories/" . $classifierID, "DELETE");
    }
    public function allCategories($classifierID, $limit = NULL, $offset = NULL) {
        if(!is_string($classifierID)) {
            throw new Exception('TextRazor Error: Classifiers must have an ID.');
        }
        $url_params = array();
        if (isset($limit)) {
            $url_params["limit"] = $limit;
        }
        if (isset($offset)) {
            $url_params["offset"] = $offset;
        }
        return $this->sendRequest("", "/categories/" . $classifierID . "/_all?" . http_build_query($url_params), "GET");
    }
    public function deleteCategory($classifierID, $categoryID) {
        return $this->sendRequest("", "/categories/" . $classifierID . "/" . $categoryID, "DELETE");
    }
    public function getCategory($classifierID, $categoryID) {
        return $this->sendRequest("", "/categories/" . $classifierID . "/" . $categoryID, "GET");
    }
}
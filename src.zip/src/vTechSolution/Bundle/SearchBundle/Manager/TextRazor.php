<?php
namespace vTechSolution\Bundle\SearchBundle\Manager;

class TextRazor extends TextRazorConnection {
    private $extractors = array();
    private $rules = NULL;
    private $cleanupHTML = false;
    private $languageOverride = NULL;
    private $dbpediaTypeFilters = array();
    private $freebaseTypeFilters = array();
    private $enrichmentQueries = array();
    private $allowOverlap = true;
    private $entityDictionaries = array();
    private $cleanupMode = NULL;
    private $cleanupReturnCleaned = false;
    private $cleanupReturnRaw = false;
    private $cleanupUseMetadata = false;
    private $downloadUserAgent = NULL;
    private $classifiers = array();
    public function __construct($apiKey = NULL) {
        parent::__construct($apiKey);
    }
    public function setExtractors($extractors) {
        if(!is_array($extractors)) {
            throw new Exception('TextRazor Error: extractors must be an array of strings');
        }
        $this->extractors = $extractors;
    }
    public function addExtractor($extractor) {
        if(!is_string($extractor)) {
            throw new Exception('TextRazor Error: extractor must be a string');
        }
        array_push($this->extractors, $extractor);
    }
    public function setClassifiers($classifiers) {
        if(!is_array($classifiers)) {
            throw new Exception('TextRazor Error: $classifiers must be an array of strings');
        }
        $this->classifiers = $classifiers;
    }
    public function addClassifier($classifier) {
        if(!is_string($classifier)) {
            throw new Exception('TextRazor Error: $classifier must be a string');
        }
        array_push($this->classifiers, $classifier);
    }
    public function setRules($rules) {
        if(!is_string($rules)) {
            throw new Exception('TextRazor Error: rules must be a string');
        }
        $this->rules = $rules;
    }
    public function setCleanupHTML($cleanupHTML) {
        if(!is_bool($cleanupHTML)) {
            throw new Exception('TextRazor Error: cleanupHTML must be a bool');
        }
        $this->cleanupHTML = $cleanupHTML;
    }
    public function setLanguageOverride($languageOverride) {
        if(!is_string($languageOverride)) {
            throw new Exception('TextRazor Error: languageOverride must be a string');
        }
        $this->languageOverride = $languageOverride;
    }
    public function setAllowOverlap($allowOverlap) {
        if (!is_bool($allowOverlap)) {
            throw new Exception('TextRazor Error: allowOverlap must be a bool');
        }
        $this->allowOverlap = $allowOverlap;
    }
    public function addEntityDictionary($dictionaryId) {
        if(!is_string($dictionaryId)) {
            throw new Exception('TextRazor Error: dictionaryId must be a string');
        }
        array_push($this->entityDictionaries, $dictionaryId);
    }
    public function addDbpediaTypeFilter($filter) {
        if(!is_string($filter)) {
            throw new Exception('TextRazor Error: filter must be a string');
        }
        array_push($this->dbpediaTypeFilters, $filter);
    }
    public function addFreebaseTypeFilter($filter) {
        if(!is_string($filter)) {
            throw new Exception('TextRazor Error: filter must be a string');
        }
        array_push($this->freebaseTypeFilters, $filter);
    }
    public function addEnrichmentQuery($query) {
        if(!is_string($query)) {
            throw new Exception('TextRazor Error: query must be a string');
        }
        array_push($this->enrichmentQueries, $query);
    }
    public function setCleanupMode($cleanupMode) {
        if(!is_string($cleanupMode)) {
            throw new Exception('TextRazor Error: Invalid Cleanup Mode');
        }
        $this->cleanupMode = $cleanupMode;
    }
    public function setCleanupReturnCleaned($cleanupReturnCleaned) {
        if(!is_bool($cleanupReturnCleaned)) {
            throw new Exception('TextRazor Error: cleanupReturnCleaned must be a bool');
        }
        $this->cleanupReturnCleaned = $cleanupReturnCleaned;
    }
    public function setCleanupReturnRaw($cleanupReturnRaw) {
        if(!is_bool($cleanupReturnRaw)) {
            throw new Exception('TextRazor Error: cleanupReturnRaw must be a bool');
        }
        $this->cleanupReturnRaw = $cleanupReturnRaw;
    }
    public function setCleanupUseMetadata($cleanupUseMetadata) {
        if(!is_bool($cleanupUseMetadata)) {
            throw new Exception('TextRazor Error: cleanupUseMetadata must be a bool');
        }
        $this->cleanupUseMetadata = $cleanupUseMetadata;
    }
    public function setDownloadUserAgent($downloadUserAgent) {
        if(!is_string($downloadUserAgent)) {
            throw new Exception('TextRazor Error: Invalid downloadUserAgent');
        }
        $this->downloadUserAgent = $downloadUserAgent;
    }
    private function buildRequest() {
        $builder = new TextRazorQueryBuilder();
        $builder->add('extractors', $this->extractors);
        $builder->add('cleanupHTML', $this->cleanupHTML);
        $builder->add('extractors', $this->extractors);
        $builder->add('rules', $this->rules);
        $builder->add('languageOverride', $this->languageOverride);
        $builder->add('entities.allowOverlap', $this->allowOverlap);
        $builder->add('entities.filterDbpediaTypes', $this->dbpediaTypeFilters);
        $builder->add('entities.filterFreebaseTypes', $this->freebaseTypeFilters);
        $builder->add('entities.enrichmentQueries', $this->enrichmentQueries);
        $builder->add('entities.dictionaries', $this->entityDictionaries);
        $builder->add('classifiers', $this->classifiers);
        $builder->add('cleanup.mode', $this->cleanupMode);
        $builder->add('cleanup.returnCleaned', $this->cleanupReturnCleaned);
        $builder->add('cleanup.returnRaw', $this->cleanupReturnRaw);
        $builder->add('cleanup.useMetadata', $this->cleanupUseMetadata);
        $builder->add('download.userAgent', $this->downloadUserAgent);
        return $builder;
    }
    public function analyzeUrl($url) {
        if(!is_string($url)) {
            throw new Exception('TextRazor Error: url must be a UTF8 encoded string');
        }
        $builder = $this->buildRequest();
        $builder->add('url', $url);
        return $this->sendRequest($builder->build());
    }
    public function analyze($text) {
        if(!is_string($text)) {
            throw new Exception('TextRazor Error: text must be a UTF8 encoded string');
        }
        $builder = $this->buildRequest();
        $builder->add('text', $text);
        return $this->sendRequest($builder->build());
    }
}
class DictionaryManager extends TextRazorConnection {
    public function __construct($apiKey = NULL) {
        parent::__construct($apiKey);
    }
    /**
    * Creates a new dictionary using properties provided in the dict $dictionaryProperties.
    * See the properties of class Dictionary for valid options.
    */
    public function createDictionary($id, $matchType=NULL, $caseInsensitive=NULL, $language=NULL) {
        $request = array();
        if(!is_string($id)) {
            throw new Exception('TextRazor Error: Custom Entity Dictionaries must have an ID.');
        }
        if (isset($matchType)) { $request["matchType"] = $matchType; }
        if (isset($caseInsensitive)) { $request["caseInsensitive"] = $caseInsensitive; }
        if (isset($language)) { $request["language"] = $language; }
        $encodedRequest = empty($request) ? "{}" : json_encode($request);
        return $this->sendRequest($encodedRequest, "/entities/" . $id, "PUT");
    }
    public function allDictionaries() {
        return $this->sendRequest("", "/entities/", "GET");
    }
    public function deleteDictionary($id) {
        if(!is_string($id)) {
            throw new Exception('TextRazor Error: Custom Entity Dictionaries must have an ID.');
        }
        return $this->sendRequest("", "/entities/" . $id, "DELETE");
    }
    public function getDictionary($id) {
        if(!is_string($id)) {
            throw new Exception('TextRazor Error: Custom Entity Dictionaries must have an ID.');
        }
        return $this->sendRequest("", "/entities/" . $id, "GET");
    }
    public function allEntries($id, $limit = NULL, $offset = NULL) {
        if(!is_string($id)) {
            throw new Exception('TextRazor Error: Custom Entity Dictionaries must have an ID.');
        }
        $url_params = array();
        if (isset($limit)) {
            $url_params["limit"] = $limit;
        }
        if (isset($offset)) {
            $url_params["offset"] = $offset;
        }
        return $this->sendRequest("", "/entities/" . $id . "/_all?" . http_build_query($url_params), "GET");
    }
    public function addEntries($id, $entries) {
        if(!is_array($entries)) {
            throw new Exception('TextRazor Error: Entries must be a List of dicts corresponding to properties of the new DictionaryEntry objects.');
        }
        if (empty($entries)) {
            throw new Exception('TextRazor Error: Array of new entries cannot be empty.');
        }
        return $this->sendRequest(json_encode($entries), "/entities/" . $id . "/", "POST");
    }
    public function getEntry($dictionary_id, $entry_id) {
        if(!is_string($dictionary_id)) {
            throw new Exception('TextRazor Error: Custom Entity Dictionaries must have an ID.');
        }
        if(!is_string($entry_id)) {
            throw new Exception('TextRazor Error: Custom Entity Dictionary Entries can only be retrieved by ID.');
        }
        return $this->sendRequest("", "/entities/" . $dictionary_id . "/" . $entry_id, "GET");
    }
    public function deleteEntry($dictionary_id, $entry_id) {
        if(!is_string($dictionary_id)) {
            throw new Exception('TextRazor Error: Custom Entity Dictionaries must have an ID.');
        }
        if(!is_string($entry_id)) {
            throw new Exception('TextRazor Error: Custom Entity Dictionary Entries can only be deleted by ID.');
        }
        return $this->sendRequest("", "/entities/" . $dictionary_id . "/" . $entry_id, "DELETE");
    }
}
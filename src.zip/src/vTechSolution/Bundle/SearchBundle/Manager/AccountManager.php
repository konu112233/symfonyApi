<?php
namespace vTechSolution\Bundle\SearchBundle\Manager;

class AccountManager extends TextRazorConnection {
    public function __construct($apiKey = NULL) {
        parent::__construct($apiKey);
    }
    public function getAccount() {
        return $this->sendRequest("", "/account/", "GET");
    }
}
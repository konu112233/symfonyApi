<?php
namespace vTechSolution\Bundle\SearchBundle\Manager;

/**
* Represents global settings common to all TextRazor operations. Settings can be
* enabled here, or with each request.
*/
class TextRazorSettings {
    private static $apiKey;
    private static $endPoint = 'http://api.textrazor.com/';
    private static $secureEndPoint = 'https://api.textrazor.com/';
    private static $enableEncryption = true;
    private static $enableCompression = true;
    public static function setApiKey($apiKey) {
        if(!is_string($apiKey)) {
            throw new Exception('TextRazor Error: Invalid API Key');
        }
        self::$apiKey = $apiKey;
    }
    public static function getApiKey() {
        return self::$apiKey;
    }
    public static function setEndPoint($endPoint) {
        if(!is_string($endPoint)) {
            throw new Exception('TextRazor Error: Invalid HTTP Endpoint');
        }
        self::$endPoint = $endPoint;
    }
    public static function getEndPoint() {
        return self::$endPoint;
    }
    public static function setSecureEndPoint($endPoint) {
        if(!is_string($endPoint)) {
            throw new Exception('TextRazor Error: Invalid HTTPS Endpoint');
        }
        self::$secureEndPoint = $endPoint;
    }
    public static function getSecureEndPoint() {
        return self::$secureEndPoint;
    }
    public static function setEnableCompression($enableCompression) {
        if(!is_bool($enableCompression)) {
            throw new Exception('TextRazor Error: enableCompression must be a bool');
        }
        self::$enableCompression = $enableCompression;
    }
    public static function getEnableCompression() {
        return self::$enableCompression;
    }
    public static function setEnableEncryption($enableEncryption) {
        if(!is_bool($enableEncryption)) {
            throw new Exception('TextRazor Error: enableEncryption must be a bool');
        }
        self::$enableEncryption = $enableEncryption;
    }
    public static function getEnableEncryption() {
        return self::$enableEncryption;
    }
}
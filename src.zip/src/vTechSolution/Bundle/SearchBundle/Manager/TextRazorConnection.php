<?php
namespace vTechSolution\Bundle\SearchBundle\Manager;

class TextRazorConnection {
    private $apiKey;
    private $endPoint;
    private $secureEndPoint;
    private $enableEncryption;
    private $enableCompression;
    function __construct($apiKey) {
        $this->apiKey = TextRazorSettings::getApiKey();
        $this->endPoint = TextRazorSettings::getEndPoint();
        $this->secureEndPoint = TextRazorSettings::getSecureEndpoint();
        $this->enableEncryption = TextRazorSettings::getEnableEncryption();
        $this->enableCompression = TextRazorSettings::getEnableCompression();
        if (isset($apiKey)) {
            $this->apiKey = $apiKey;
        }
        if(!is_string($this->apiKey)) {
            throw new Exception('TextRazor Error: Invalid API key');
        }
        if(!function_exists('curl_version')) {
            throw new Exception('TextRazor Error: TextRazor requires cURL support to be enabled on your PHP installation');
        }
    }
    public function setAPIKey($apiKey) {
        if(!is_string($apiKey)) {
            throw new Exception('TextRazor Error: Invalid API key');
        }
        $this->apiKey = $apiKey;
    }
    public function setEndPoint($endPoint) {
        if(!is_string($endPoint)) {
            throw new Exception('TextRazor Error: Invalid HTTP Endpoint');
        }
        $this->endPoint = $endPoint;
    }
    public function setSecureEndPoint($endPoint) {
        if(!is_string($endPoint)) {
            throw new Exception('TextRazor Error: Invalid HTTPS Endpoint');
        }
        $this->secureEndPoint = $endPoint;
    }
    public function setEnableCompression($enableCompression) {
        if(!is_bool($enableCompression)) {
            throw new Exception('TextRazor Error: enableCompression must be a bool');
        }
        $this->enableCompression = $enableCompression;
    }
    public function setEnableEncryption($enableEncryption) {
        if(!is_bool($enableEncryption)) {
            throw new Exception('TextRazor Error: enableEncryption must be a bool');
        }
        $this->enableEncryption = $enableEncryption;
    }
    public function sendRequest($textrazorParams, $path = '', $method = 'POST', $contentType = NULL) {
        $ch = curl_init();
        if ($this->enableEncryption) {
            curl_setopt($ch, CURLOPT_URL, $this->secureEndPoint . $path);
        }
        else {
            curl_setopt($ch, CURLOPT_URL, $this->endPoint . $path);
        }
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        if ($this->enableCompression) {
            curl_setopt($ch, CURLOPT_ENCODING, 'gzip,deflate');
        }
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method );
        curl_setopt($ch, CURLOPT_POSTFIELDS, $textrazorParams);
        $headers = array();
        $headers[] = 'X-TextRazor-Key: ' . trim($this->apiKey);
        if ($contentType) {
            $headers[] = 'Content-Type: ' . $contentType;
        }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $reply = curl_exec ($ch);
        $rc = curl_errno($ch);
        if (0 != $rc) {
            throw new Exception('TextRazor Error: Network problem connecting to TextRazor. CURL Error Code:' . $rc);
        }
        $httpStatus = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if (200 != $httpStatus) {
            throw new Exception('TextRazor Error: TextRazor returned HTTP code: ' . $httpStatus . ' Message:' . $reply);
        }
        curl_close ($ch);
        unset($ch);
        $jsonReply = json_decode($reply,true);
        return $jsonReply;
    }
}
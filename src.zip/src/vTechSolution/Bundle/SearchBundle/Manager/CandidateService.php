<?php


namespace vTechSolution\Bundle\SearchBundle\Manager;

use Symfony\Component\DependencyInjection\ContainerInterface as Container;
use vTechSolution\Bundle\SearchBundle\Document\SaveSearch;
use vTechSolution\Bundle\SearchBundle\Document\RelevanceCandidate;
use vTechSolution\Bundle\SearchBundle\Document\PotentialCandidate;
use vTechSolution\Bundle\SearchBundle\Document\JobParseData;
use vTechSolution\Bundle\SearchBundle\Document\MatchedJobOrders;
use vTechSolution\Bundle\SearchBundle\Document\SuggestedKeyStrings;
use vTechSolution\Bundle\SearchBundle\Document\KeyStringUsage;
use vTechSolution\Bundle\SearchBundle\Document\RequiredSkillsParseData;
use vTechSolution\Bundle\SearchBundle\Document\OptionalSkillsParseData;

class CandidateService
{
    private $container;
    private $doctrine;
    private $request;
    private $solrClient;
    private $responseArray;
    private $saveSearchRepository;
    private $relevanceCandidateRepository;
    private $potentialCandidateRepository;

    public function __construct(Container $container) {
        $this->container = $container;
        $this->solrClient = $this->container->get('solarium.client');
        if (PHP_SAPI == 'cli') {
          $this->container->enterScope('request');
            $this->container->set('request', new \Symfony\Component\HttpFoundation\Request(), 'request');
        } else {
            $this->request = $this->container->get('request');
        }
        $this->catsDatabase = $this->container->get('v_tech_solution_search.cats')->getPDO();
        $this->responseArray = array();
        $this->saveSearchRepository = $this->container->get('doctrine_mongodb')->getRepository('vTechSolutionSearchBundle:SaveSearch');
        $this->relevanceCandidateRepository = $this->container->get('doctrine_mongodb')->getRepository('vTechSolutionSearchBundle:RelevanceCandidate');
        $this->potentialCandidateRepository = $this->container->get('doctrine_mongodb')->getRepository('vTechSolutionSearchBundle:PotentialCandidate');
        $this->jobParseDataRepository = $this->container->get('doctrine_mongodb')->getRepository('vTechSolutionSearchBundle:JobParseData');
        $this->matchedJobOrdersRepository = $this->container->get('doctrine_mongodb')->getRepository('vTechSolutionSearchBundle:MatchedJobOrders');
        $this->suggestedKeyStringsRepository = $this->container->get('doctrine_mongodb')->getRepository('vTechSolutionSearchBundle:SuggestedKeyStrings');
        $this->keyStringUsageRepository = $this->container->get('doctrine_mongodb')->getRepository('vTechSolutionSearchBundle:KeyStringUsage');
        $this->requiredSkillsParseDataRepository = $this->container->get('doctrine_mongodb')->getRepository('vTechSolutionSearchBundle:RequiredSkillsParseData');
        $this->optionalSkillsParseDataRepository = $this->container->get('doctrine_mongodb')->getRepository('vTechSolutionSearchBundle:OptionalSkillsParseData');
        $this->careerBuilderService = $this->container->get('v_tech_solution_career_builder.cb');

     }

    public function searchCandidate() {

        $this->addCandidateDocument();

    }

// /////////////////////// class for pull out  data from ats database start ////////////////////////////

public function atsToSolrMigrate()
    {

    // /////////////////    select monster,ATS,vtech_tools  ///////////////////

    $this->vtech_toolsDatabase = $this->container->get('v_tech_solution_search.vtech_tools')->getPDO();
    $this->catsDatabase = $this->container->get('v_tech_solution_search.cats')->getPDO();
    $this->monsterDatabase = $this->container->get('v_tech_solution_search.monster')->getPDO();
    $userchk = $this->vtech_toolsDatabase->prepare("SELECT  `candidate_id` FROM `candidate_search`  ORDER BY `candidate_id` desc limit 1");
    $userchk->execute();
    $rowchk=$userchk->fetch();
    $rowchkid=$rowchk['candidate_id'];
    $user = $this->catsDatabase->prepare("SELECT  `candidate_id` FROM `candidate` where `candidate_id` >= $rowchkid ORDER BY `candidate_id`");
    $user->execute();
    while ($row = $user->fetch())
        {


        $solr_candidate_id = $row['candidate_id'];
        $userchkinng = $this->vtech_toolsDatabase->prepare("SELECT  count(`candidate_id`) as `numbers` FROM `candidate_search`  where  `candidate_id`='solr_candidate_id'");
        $userchkinng->execute();
        $num_rows_f_count = $userchkinng->fetch();
        $solr_internal_num_row_f_count = $num_rows_f_count['numbers'];
        if($solr_internal_num_row_f_count<1)
        {

        // /////////// check whether candidcandidate is already added in our internal serch database or not  /////////

        $solr_internal_resume = $this->vtech_toolsDatabase->prepare('SELECT COUNT(`candidate_id`) as `counting` FROM `candidate_search` where `candidate_id`=' . $solr_candidate_id . '');
        $solr_internal_resume->execute();
        $num_rows = $solr_internal_resume->fetch();
        $solr_internal_num_row = $num_rows['counting'];

        // //////////  check if candidate id is exist or not in database ///////////////

        if ($solr_internal_num_row > 0)
            {
            continue;
            }

        // ////////////////////    select the candidate id from the vtechtool  ////////////////////////

        $solr_vtech_resume_user_count = $this->vtech_toolsDatabase->prepare("SELECT  count(`candidate_id`) as `solrcount` FROM `vtech_resume` where `candidate_id`=" . $row['candidate_id'] . "");
        $solr_vtech_resume_user_count->execute();
        $solr_vtech_resume_user_count_result = $solr_vtech_resume_user_count->fetch();
        if ($solr_vtech_resume_user_count_result['solrcount'] > 0)
            {
            $solr_vtech_resume_user = $this->vtech_toolsDatabase->prepare("SELECT  `candidate_id`,`id` FROM `vtech_resume` where `candidate_id`=" . $row['candidate_id'] . "");
            $solr_vtech_resume_user->execute();
            $solr_vtech_resume_user_result = $solr_vtech_resume_user->fetch();
            $solr_vtech_resume_sec_user = $this->vtech_toolsDatabase->prepare("SELECT  count(`resume_id`) as `count1` FROM `vtech_skill` where `resume_id`=" . $solr_vtech_resume_user_result['id'] . "");
            $solr_vtech_resume_sec_user->execute();
            $num_rowss = $solr_vtech_resume_sec_user->fetch();
            $solr_vtech_resume_skill_num_row = $num_rowss['count1'];
            if ($solr_vtech_resume_skill_num_row > 0)
                {
                $solr_vtech_resume_third_user = $this->vtech_toolsDatabase->prepare("SELECT  `resume_id`,`meta_value` FROM `vtech_skill` where `resume_id`=" . $solr_vtech_resume_user_result['id'] . "");
                $solr_vtech_resume_third_user->execute();
                while ($solr_vtech_resume_user_result3 = $solr_vtech_resume_third_user->fetch())
                    {
                    $skill[] = preg_replace('/[^A-Za-z0-9\. -]/', '', $solr_vtech_resume_user_result3['meta_value']);
                    }
                }
              else
                {
                $skill[] = '';
                }

            $solr_secondaryskill = implode(",", $skill);
            $solr_primaryskill = preg_replace('/[^A-Za-z0-9\. -]/', '', $solr_secondaryskill);

            // ///////////////////////// select the work experience related information //////////////////////

            $solr_vtech_experience_user = $this->vtech_toolsDatabase->prepare("SELECT  `jobtitle`,`total_experience`,`text_detail` FROM `vtech_experience` where `resume_id`=" . $solr_vtech_resume_user_result['id'] . "");
            $solr_vtech_experience_user->execute();
            $result1 = $solr_vtech_experience_user->fetch();
            $solr_total_experience = $result1['total_experience'];
            $solr_text_detail = preg_replace('/[^A-Za-z0-9\. -]/', '', str_replace("'", "", $result1['text_detail']));
            $solr_vtech_experience_sec_user = $this->vtech_toolsDatabase->prepare("SELECT  `meta_value` FROM `vtech_education_and_training` where `resume_id`=" . $solr_vtech_resume_user_result['id'] . "");
            $solr_vtech_experience_sec_user->execute();
            $result2 = $solr_vtech_experience_sec_user->fetch();
            $education = preg_replace('/[^A-Za-z0-9\. -]/', '', str_replace("'", "", $result2['meta_value']));

            // ///////////////////// select candidate info from the cats /////////////////////////

            $vtech_ats_user = $this->catsDatabase->prepare("SELECT `source`,`phone_home`,`email1`,`city`,`state`,`zip`,`first_name`,`last_name`,`date_created`,`current_pay`,`desired_pay` FROM `candidate` where `candidate_id`=" . $solr_candidate_id . "");
            $vtech_ats_user->execute();
            $vtech_ats_user_result = $vtech_ats_user->fetch();
            $city = $vtech_ats_user_result['city'];
            $state = $vtech_ats_user_result['state'];
            $zip = $vtech_ats_user_result['zip'];
            $email = $vtech_ats_user_result['email1'];
            $phone = $vtech_ats_user_result['phone_home'];
            $cname = $vtech_ats_user_result['first_name'] . ' ' . $vtech_ats_user_result['last_name'];
            $dcreates = explode(" ", $vtech_ats_user_result['date_created']);
            $dcreate = $dcreates[0];
            $solr_source = ucfirst($vtech_ats_user_result['source']);
            $solr_minimum_salary = $vtech_ats_user_result['current_pay'];
            $solr_maximum_salary = $vtech_ats_user_result['desired_pay'];

            if (filter_var($solr_minimum_salary, FILTER_VALIDATE_INT) === 0 || filter_var($solr_minimum_salary, FILTER_VALIDATE_INT)) {
            $solr_minimum_salary = $vtech_ats_user_result['current_pay'];
            } else {
            $solr_minimum_salary = '';
            }

            if (filter_var($solr_maximum_salary, FILTER_VALIDATE_INT) === 0 || filter_var($solr_maximum_salary, FILTER_VALIDATE_INT)) {
            $solr_maximum_salary = $vtech_ats_user_result['desired_pay'];
            } else {
            $solr_maximum_salary = '';
            }

            // ////////////// select additional info of candidate from monster if it is exist ///////////////////////

            $monster_user = $this->monsterDatabase->prepare("SELECT `jobstatus`,`citizen`,`jtitle`,`jauth` FROM `resume` where `cid`=" . $solr_candidate_id . "");
            $monster_user->execute();
            $monster_user_result = $monster_user->fetch();
            $citizen = $monster_user_result['citizen'];
            $jtitle = preg_replace('/[^A-Za-z0-9\. -]/', '', $monster_user_result['jtitle']);
            $solr_job_auth = $monster_user_result['jauth'];
            $jobstatus = $monster_user_result['jobstatus'];
            $job_title = preg_replace('/[^A-Za-z0-9\. -]/', '', $result1['jobtitle'] . ' , ' . $jtitle);

            // //////////////   empty the skill array //////////////

            $candidatedata = array(
                'candidate_id' => $solr_candidate_id,
                'candidate_name' => $cname,
                'email' => $email,
                'phone' => $phone,
                'job_title' => $job_title,
                'city' => $city,
                'state' => $state,
                'zip' => $zip,
                'skill' => $solr_primaryskill,
                'experience' => $solr_total_experience,
                'work_authhority' => $solr_job_auth,
                'education' => $education,
                'resume' => $solr_text_detail,
                'source' => $solr_source,
                'citizen' => $citizen,
                'minsal' => $solr_minimum_salary,
                'maxsal' => $solr_maximum_salary,
                'jobstatus' => $jobstatus,
                'date_created' => $dcreate
            );
            $this->addCandidateToSolr($candidatedata);

            // /////unset skill array //////

            unset($skill);

            }
        }
    }

    // /////////////////////// class for pull out  data from ats database end ////////////////////////////

    }

// /////////////////////// class for insertig data into solr system start ////////////////////////

public function addCandidateToSolr($candidatedata)
    {

    // ///////////////////// push schema in solr caandidate core  //////////////////////////////////

    $update = $this->solrClient->createUpdate();
    $document = $update->createDocument();
    $document->id = $candidatedata['candidate_id'];
    $document->candidate_id_i = $candidatedata['candidate_id'];
    $document->name_txt = $candidatedata['candidate_name'];
    $document->email_txt = $candidatedata['email'];
    $document->phone = $candidatedata['phone'];
    $document->job_title_txt = $candidatedata['job_title'];
    $document->city_txt = $candidatedata['city'];
    $document->state_txt = $candidatedata['state'];
    $document->zip_s = $candidatedata['zip'];
    $document->skill_txt_en_swose = $candidatedata['skill'];
    $document->experience_i = $candidatedata['experience'];
    $document->work_authority_s = $candidatedata['work_authhority'];
    $document->ats_join_date = $candidatedata['date_created'];
    $document->eduction__txt_en_swose = $candidatedata['education'];
    $document->search_keyword_txt_en_swose = $candidatedata['resume'];
    $document->resource_s = $candidatedata['source'];
    $document->citizen_s = $candidatedata['citizen'];
    $document->min_salary_i = $candidatedata['minsal'];
    $document->max_salary_i = $candidatedata['maxsal'];
    $document->employee_type_txt = $candidatedata['jobstatus'];

    $update->addDocuments(array(
        $document
    ));
    $update->addCommit();
    $result = $this->solrClient->update($update);
    $solrupdates = $this->vtech_toolsDatabase->prepare("INSERT INTO `candidate_search` (`candidate_id`, `status`) VALUES ('" . $candidatedata['candidate_id'] . "','1')");

    // ////////// this executes the query and insert data to the database status //////////////

    $solarexecute = $solrupdates->execute();

    // /////////////  if data migrate sucessfuly to solr and database got update message displayed ///////////////

    if ($solarexecute)
        {
        echo "candidate id: " . $candidatedata['candidate_id'] . " inserted sucessfully ";
        }
    }

// /////////////////////// class for insertig data into solr system end ////////////////////////


            /////////////////  class for Add schema in candidate core in solr end ////////////////////

    public function searchsolrCandidate() {
      $return = array();
      $id = $this->request->query->get('id');
      $experience = $this->request->query->get('experience');
      $keyword = $this->request->query->get('keyword');
      $cityForSearch = $this->request->query->get('city');
      $stateForSearch = $this->request->query->get('state');
      $zipcodeForSearch = $this->request->query->get('zipcode');
      $jobTitleForSearch = $this->request->query->get('jobTitle');

      $page = $this->request->query->get('page');
      // get a select query instance
      $query = $this->solrClient->createSelect();

      $searchExtraParameters = array();

      if($experience != '')
      {
          $searchExtraParameters[] = 'experience_i:'. $experience;
      }

      if($id != '')
      {
          $searchExtraParameters[] = 'id:'. $id;
      }

      if($keyword != '')
      {
          $searchExtraParameters[] = 'search_keyword_txt_en_swose:'. $keyword;
      }

      if($cityForSearch != ''){
          $searchExtraParameters[] = 'city_txt:'. $cityForSearch;
        }
      if($stateForSearch != ''){
          $searchExtraParameters[] = 'state_txt:'. $stateForSearch;
        }
      if($zipcodeForSearch != ''){
          $searchExtraParameters[] = 'zip_s:'. $zipcodeForSearch;
        }
      if($jobTitleForSearch != ''){
          $searchExtraParameters[] = 'skill_txt_en_swose:'. $jobTitleForSearch;
        }

      if ($page == '') {
        $page = 1;
      }

      $keyword = preg_replace(array('/ or /', '/ and /'), array(' || ', ' && '), strtolower($keyword));

      // create a filterquery
      //$query->createFilterQuery('fq')->setQuery('id:('.$id.') AND experience_i:('.$experience.') AND search_keyword_txt_en_swose:('.$keyword.')'.(count($searchExtraParameters) > 0 ? (' AND '. implode(" AND ", $searchExtraParameters)) : '' ));

      $query->createFilterQuery('fq')->setQuery(implode(" AND ", $searchExtraParameters));

      $query->setStart(($page - 1) * 15)->setRows(15);
      $query->addSort('id', $query::SORT_DESC);
      // this executes the query and returns the result
      $resultset = $this->solrClient->select($query);

      // display the total number of documents found by solr
      //echo 'NumFound: '.$resultset->getNumFound();

      foreach ($resultset as $document) {
        $return[] = array(
                      "candidate_id" => $document->id,
                      "job_title" => $document->job_title_txt,
                      "name" => $document->name_txt,
                      "email" => $document->email_txt,
                      "zip" => $document->zip_s,
                      "phone" => $document->phone,
                      "city" => $document->city_txt,
                      "state" => $document->state_txt,
                      "min_salary" => $document->min_salary_i,
                      "max_salary" => $document->max_salary_i,
                      "employee_type" => $document->employee_type_txt,
                      "source" => $document->resource_s,
                      "ats_join_date" => $document->ats_join_date
                    );
      }

      return array('total_records' => $resultset->getNumFound(), "candidate_list" => $return);
    }

    function saveSearchData() {
      $saveSearch = new SaveSearch();
      $saveSearch->setUserId($this->request->get('user_id', 0));
      $saveSearch->setResouce($this->request->get('resouce', ''));
      $saveSearch->setkeyString($this->request->get('key_string', ''));
      $saveSearch->setSearchResult($this->request->get('search_result', ''));
      $saveSearch->setTotalCount($this->request->get('result_count', ''));
      $saveSearch->setCreatedAt(new \DateTime());
      $saveSearch->setUpdatedAt(new \DateTime());
      $this->saveSearchRepository->commit($saveSearch);

      return $saveSearch;
    }

    function recentSearch() {
      $saveSearch = $this->saveSearchRepository->findByProperty('userId', 1426);

      foreach ($saveSearch as $search) {
        $this->responseArray['recent_search'][] = array("key_string" => $search->getKeyString(), "search_result" => $search->getSearchResult(), "resouce" => $search->getResouce());
      }

      return $this->responseArray;
    }

        //////////////////////// Parse job Order funcion starts    ///////////////////

    public function jobOrderParse()
    {

           ///////////////  Get the joborder id , page starting and ending rows      ////////////

        $id = $this->request->get('id');
        $pageStart = $this->request->get('start');
        $pageEnd = $this->request->get('end');
        $getSkill = $this->request->get('skill');
        $getCity = $this->request->get('city');

        if($getSkill=='1')
        {

            ///////////////  Get the joborder id , page starting and ending rows end     ////////////
            ///////////////  connect to ats database to fetch job description detail //////////////

            $this->catsDatabase = $this->container->get('v_tech_solution_search.cats')->getPDO();
            $catsJobOrder = $this->catsDatabase->prepare("select `city`,`joborder_id`,`state`,`title`,`description` from `joborder` where `joborder_id`='" . $id . "'");
            $catsJobOrder->execute();
            $catsJobOrderRows = $catsJobOrder->fetch();
            $jobDetailData = preg_replace('/\\s+/', ' ', preg_replace('/  */', ' ', preg_replace('/[^A-Za-z0-9\. -]/', ' ', str_replace('#','sharp',str_replace(',','',strip_tags($catsJobOrderRows['description']))))));
            $locationCity=$catsJobOrderRows['city'];
            $locationState=$catsJobOrderRows['state'];
            ////////////////////  parsing joborder dataa via python script   ////////////////

            ////////////////////  call python file  ///////////////////////
            $jobParseLocation = $this->container->getParameter('jobParseLocation');
             ////////////////////  call python file  /////////////////////
            $parseFilter = shell_exec("$jobParseLocation $jobDetailData");

        ////////////////  textrazor ////////////////////
            $curls = curl_init();
         // ////////////////// pass data through API  //////////////////////
            curl_setopt_array($curls, array(
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_URL => 'https://saas.vtechsolution.com/search/candidate/textrazor',
            curl_setopt($curls, CURLOPT_POSTFIELDS,"jobdata=".$jobDetailData."")
            ));

        // //////////// Send the request & save response to $resp //////////////////////
            $textResponse = curl_exec($curls);
            $textResponsepArray = json_decode($textResponse, true);
            $booleanString='';
            $booleanStrings='';
            $intersectArrayApi=array();
            if(!empty($textResponsepArray['parseresult']['prioritydata']))
            {
                foreach ($textResponsepArray['parseresult']['prioritydata'] as $textKey => $textValue)
                {
                    if($textValue!='')
                    {

                        $booleanString.=' OR '.'"'.$textValue.'" ';
                        $intersectArrayApi[]=rtrim(str_replace(" (software development)","",strtolower($textValue)));
                    }
                }
            }
            if(!empty($textResponsepArray['parseresult']['highprioritydata']))
            {
                foreach ($textResponsepArray['parseresult']['highprioritydata'] as $textKeys => $textValues)
                {
                    if($textValues!='')
                    {
                        $booleanString.=' OR '.'"'.$textValues.'" ';
                        $intersectArrayApi[]=rtrim(str_replace(" (software development)","",strtolower($textValues)));
                    }
                }
            }
            if(!empty($textResponsepArray['parseresult']['secondaryprioritydata']))
            {
                foreach ($textResponsepArray['parseresult']['secondaryprioritydata'] as $textKeyss => $textValuess)
                {
                    if($textValuess!='')
                    {
                        $booleanStrings.=' OR '.'"'.$textValuess.'" ';
                        $intersectArrayApi[]=rtrim(str_replace(" (software development)","",strtolower($textValuess)));
                    }
                }
            }
                ////////////////   textrazor  //////////////////

            //////////////////////   filter out the common odd data used in job description start ///////////////////////

            $parseFilterData = explode("(NPu", $parseFilter);
            $parseFilterFinalData = array_unique($parseFilterData);

            foreach($parseFilterFinalData as $parseKey => $parseValue)
            {
                ///////////////////////  filter dictionary /////////////////////

                $parseArray = explode("/NNP)", $parseValue);
                $filter = array("/JJ","/NNP","/NNS","/NN","/CC","/TO","/VB","/DT","/POS",",/,","/Title","Descriptive","Adaptable","Preparation","Assistance","Description","Skype","WebEx","F2F","Preferred","Desired","Minimum","Programer","Program","Project","Maximum","No","Job","Provide","Ability","will","Experience","Required","Years","education","problem solving","grammar","overview","Skills","".$locationCity."","".$locationState."");

            ///////////////////////  filter dictionary /////////////////////

                $finalString = str_replace($filter, '', $parseArray[0]);
                if (($finalString != ' ')&&($finalString != '')&&($finalString != '  ')&&($finalString != ' s ')&&($finalString != 'ing')&&($finalString != 'ity')&&($finalString!=' r')&&($finalString!='s')&&($finalString!='s')&&($finalString!=' Analyst')&&($finalString!='Data'))
                {
                    if ($parseValue != $parseArray[0])
                    {
                        $finalParseTag[] = str_replace(" bull", " ", str_replace(" nbsp", " ", $finalString));
                ///////////////  find string //////////////
                        $stringFilter=array("Csharp","Asp.Net",".Net","Java ","J2EE","BLS","Nursing","RN ","html","css","jquery","ajax","soap","rest","json","trauma","medical","bcls","NRP","Nursys","PACU","Javascript","AngularJS","Python","ACLS");
                        foreach ($stringFilter as $stringFilterKey => $stringFilterValue)
                        {
                            if (stripos($finalString, $stringFilterValue) !== false)
                            {
                                $finalParseTag[] = $stringFilterValue;
                            }
                        }

                        if (stripos($finalString, 'Csharp') !== false) {
                        $finalParseTag[] = 'Csharp';
                        }
                        if (stripos($finalString, '.Net') !== false) {
                        $finalParseTag[] = '.Net';
                        }
                        if (stripos($finalString, 'Asp.Net') !== false) {
                        $finalParseTag[] = 'Asp.Net';
                        }
                        if (stripos($finalString, 'Java ') !== false) {
                        $finalParseTag[] = 'Java';
                        }
                        if (stripos($finalString, 'J2EE') !== false) {
                        $finalParseTag[] = 'J2EE';
                        }
                        if (stripos($finalString, 'BLS') !== false) {
                        $finalParseTag[] = 'BLS';
                        }
                        if (stripos($finalString, 'Nursing') !== false) {
                        $finalParseTag[] = 'Nursing';
                        }
                        if (stripos($finalString, 'RN ') !== false) {
                        $finalParseTag[] = 'RN';
                        }
                        if (stripos($finalString, 'html') !== false) {
                        $finalParseTag[] = 'html';
                        }
                        if (stripos($finalString, 'css') !== false) {
                        $finalParseTag[] = 'css';
                        }
                        if (stripos($finalString, 'jquery') !== false) {
                        $finalParseTag[] = 'jquery';
                        }
                        if (stripos($finalString, 'ajax') !== false) {
                        $finalParseTag[] = 'ajax';
                        }
                        if (stripos($finalString, 'soap') !== false) {
                        $finalParseTag[] = 'soap';
                        }
                        if (stripos($finalString, 'rest') !== false) {
                        $finalParseTag[] = 'rest';
                        }
                        if (stripos($finalString, 'json') !== false) {
                        $finalParseTag[] = 'json';
                        }
                        if (stripos($finalString, 'Trauma') !== false) {
                        $finalParseTag[] = 'Trauma';
                        }
                        if (stripos($finalString, 'Medical') !== false) {
                        $finalParseTag[] = 'Medical';
                        }
                        if (stripos($finalString, 'BCLS') !== false) {
                        $finalParseTag[] = 'BCLS';
                        }
                        if (stripos($finalString, 'NRP') !== false) {
                        $finalParseTag[] = 'NRP';
                        }
                        if (stripos($finalString, 'Nursys') !== false) {
                        $finalParseTag[] = 'Nursys';
                        }
                       if (stripos($finalString, 'PACU') !== false) {
                        $finalParseTag[] = 'PACU';
                        }
                        if (stripos($finalString, 'Javascript') !== false) {
                        $finalParseTag[] = 'Javascript';
                        }
                        if (stripos($finalString, 'AngularJS') !== false) {
                        $finalParseTag[] = 'AngularJS';
                        }
                        if (stripos($finalString, 'Python') !== false) {
                        $finalParseTag[] = 'Python';
                        }
                        if (stripos($finalString, 'ACLS') !== false) {
                        $finalParseTag[] = 'ACLS';
                        }
                /////////////  find string ////////////////
                    }
                }
            }

            ////////////   filter out the odd data used in job description  end  ///////////////////////
            ///////////////////////////    create array of parse data   /////////////////////
            $finalTags = array_unique(array_merge($finalParseTag));
            //////////////////////////    Generate boolean search string start //////////////////////
            $countSecondaryArray = count($finalTags);
            if ($countSecondaryArray > 1)
            {
                $myFinalTags = '';
                foreach($finalTags as $mySecondaryValue)
                {
                    $stringWordCount=strlen($mySecondaryValue);
                    $stringSetenceCount=str_word_count($mySecondaryValue);
                    if($stringWordCount>=3)
                    {
                        if($mySecondaryValue!='Data')
                        {
                            $myFinalTags.= str_replace('" ', '"', '"' . $mySecondaryValue . '"  OR ');
                            $intersectArrayPython[]=rtrim(str_replace("or ","",str_replace("or  ","",str_replace(" or","",str_replace("  or","",strtolower("OR ".$mySecondaryValue." OR"))))));
                        }
                    }
                }
            }
            //////////////////////////    Generate boolean search string end //////////////////////

            ////////////////////    advance boolean generation ////////////////////////////////
            if(!empty($intersectArrayApi))
            {
                $simm_str=array();
                foreach ($intersectArrayApi as $apikey => $apivalue)
                {
                    foreach ($intersectArrayPython as $pythonkey => $pythonvalue)
                    {
                        $sim = similar_text($apivalue,$pythonvalue,$perc);
                        if(($apivalue!='management')&&($apivalue!='management ')&&($apivalue!='data ')&&($apivalue!='data')&&($apivalue!='microsoft office')&&($apivalue!='database ')&&($apivalue!='database'))
                        {
                            if($perc>55)
                            {
                                $simm_str[]=$apivalue;
                            }
                        }
                    }
                }

                $simillar_str=array_unique($simm_str);
                if(!empty($simillar_str))
                {
                    $advancebooleanStrings='';
                    foreach ($simillar_str as $advkey => $advvalue)
                    {
                        $advancebooleanStrings.=' OR '.'"'.$advvalue.'" ';
                    }
                }
            }
            /////////////////////////////////   advance boolean generation ////////////////

            $myFinalTags.= ' ""';
            if($booleanString!='')
            {
                if(!empty($simm_str))
                {
                    $myFinalTags = str_replace('()', '',str_replace('AND (  )', '',str_replace(' (software development)','',str_replace(' (programming language)','',str_replace('(software development)','',str_replace('(  OR','( ','('.str_replace(' OR  ""', '', str_replace('OR " "', '', str_replace(',  ,',',',str_replace(',,',',',str_replace('python ag.py',',',str_replace(' r,',',',str_replace(' s,',',',str_replace(',s,',',',str_replace('ing,',',',str_replace(' ,',',',str_replace(', ',',',str_replace(', ',',',str_replace(', ',',',str_replace(', ',',',str_replace(',     ',',',str_replace(',    ,',',',$myFinalTags)))))))))))))))).') AND ( '.$booleanString.' ) AND ( '.$booleanStrings.' ) AND ( '.$advancebooleanStrings.' )'))))));
                }
                if(empty($simm_str))
                {
                    $myFinalTags = str_replace('()', '',str_replace('AND (  )', '',str_replace(' (software development)','',str_replace(' (programming language)','',str_replace('(software development)','',str_replace('(  OR','( ','('.str_replace(' OR  ""', '', str_replace('OR " "', '', str_replace(',  ,',',',str_replace(',,',',',str_replace('python ag.py',',',str_replace(' r,',',',str_replace(' s,',',',str_replace(',s,',',',str_replace('ing,',',',str_replace(' ,',',',str_replace(', ',',',str_replace(', ',',',str_replace(', ',',',str_replace(', ',',',str_replace(',     ',',',str_replace(',    ,',',',$myFinalTags)))))))))))))))).') AND ( '.$booleanString.' ) AND ( '.$booleanStrings.' )'))))));
                }

            }
            else
            {
                $myFinalTags = str_replace('()', '',str_replace('AND (  )', '',str_replace(' (software development)','',str_replace(' OR  ""', '', str_replace('OR " "', '', str_replace(',  ,',',',str_replace(',,',',',str_replace('python ag.py',',',str_replace(' r,',',',str_replace(' s,',',',str_replace(',s,',',',str_replace('ing,',',',str_replace(' ,',',',str_replace(', ',',',str_replace(', ',',',str_replace(', ',',',str_replace(', ',',',str_replace(',     ',',',str_replace(',    ,',',',$myFinalTags)))))))))))))))))));
            }

            $finalData = implode(", ", $finalTags);
        }

        else
        {
            $myFinalTags=urldecode($getSkill);
            $locationCity=urldecode($getCity);
        }

            ////////////////////    call   solr  API   //////////////////////////////

        $this->solrClient->setAdapter('Solarium\Core\Client\Adapter\Curl');
        $query = $this->solrClient->createSelect();
                //////////////////  pass the parse joborder data into solr search   ////////////////////
        $query->setQuery('search_keyword_txt_en_swose:('.$myFinalTags.') AND city_txt:('.$locationCity.')');
        $query->addSort('search_keyword_txt_en_swose', $query::SORT_DESC);
        $query->setStart($pageStart)->setRows($pageEnd);
            // this executes the query and returns the result
        $resultset = $this->solrClient->select($query);
            // display the total number of documents found by solr
            // show documents using the resultset iterator
        $records = $resultset->getNumFound();
        foreach($resultset as $document)
        {

            //////////////  create array candidate id to store candidate detail  ///////////////////////

            $this->responseArray[] = array(
            "id" => $document->id,
            "name" => $document->name_txt,
            "zip" => $document->zip_s,
            "city" => $document->city_txt,
            "state" => $document->state_txt,
            "source" => $document->resource_s);
            $candidate_Name[] = $document->name_txt;

        }
            //////////////////  store candidate skill, page record start and end in the same array  /////////////////////////

        $this->responseArray[] = array(
        "joborder_id" => $id,
        "title"=>'',
        "keyskill" => $myFinalTags,
        "jobcity" => $locationCity,
        "records" => $records,
        "page_start" => $pageStart,
        "page_end" => $pageEnd);

            //////////////////  return candidateid array   /////////////////////
        return $this->responseArray;
    }

            ///////////////// Parse Job Order function ends //////////////////////////


    public function jobDescriptionParse()
    {

            ///////////////  connect to ats database to fetch job description detail //////////////

            $this->catsDatabase = $this->container->get('v_tech_solution_search.cats')->getPDO();
            $catsJobOrder = $this->catsDatabase->prepare("select `joborder_id`,`title`,`description` from `joborder` order by `joborder_id` desc limit 70 ");
            $catsJobOrder->execute();
            $catsJobOrderResult = $catsJobOrder->fetchAll();

            foreach($catsJobOrderResult as $key => $catsJobOrderRows) {
              $cJId = $catsJobOrderRows['joborder_id'];
              $cJd = $catsJobOrderRows['description'];
              $cTitle = $catsJobOrderRows['title'];

              $cJdTitle = $cJd.' '.$cTitle;

              $jobParsedId = $this->jobParseDataRepository->findOneByProperty('joborderId', $cJId);
              if(isset($jobParsedId)) {
                  continue;
                }

            $jobDetailData = strip_tags($cJdTitle);

            $tag = ["&nbsp;","&bull;","&amp;","&middot;"];
            $tagReplace = ["","","",""];
            $fileString = str_replace($tag, $tagReplace, $jobDetailData);
            $fileName = $cJId.".txt";
            $clientJobIdLocation = $this->container->getParameter('clientJobIdLocation');
             $file = fopen($clientJobIdLocation.$fileName,"w");
               fwrite($file, $fileString);
               fclose($file);
            ////////////////////  parsing joborder dataa via python script   ////////////////

            ////////////////////  call python file  ///////////////////////
            $jobParseLocation = $this->container->getParameter('jobParseLocation');
             ////////////////////  call python file  /////////////////////
            $parseFilter = shell_exec('python '."$jobParseLocation $clientJobIdLocation$fileName");
            unlink($clientJobIdLocation.$fileName);
            $result = str_replace(array( "(",")","[","]","'" ), '', $parseFilter);
            if($result == null || $result == '' ) {
              continue;
              }
            $explodeResult = explode(",",$result);
            $chunkArray = array_chunk($explodeResult, 3) ;

            foreach($chunkArray as $ca) {
              $finalArray[] = array("word" => trim($ca[0]), "POS" => trim($ca[1]), "count" => trim($ca[2]) );
            }


            $jobParseData = new JobParseData();
            $jobParseData->setJoborderId($cJId);
            $jobParseData->setDescription(json_encode($finalArray));

            $jobParseData->setCreatedAt(new \DateTime());
            $this->jobParseDataRepository->commit($jobParseData);
            unset($finalArray);
            }


            return $this->responseArray;
    }

    // public function jobParseDataMatch(){
    //
    //   ini_set('max_execution_time', 0 );
    //
    // 	$catsJobOrderId = $this->catsDatabase->prepare("SELECT * FROM `joborder` WHERE status = 'Active'");
    // 	$catsJobOrderId->execute();
    // 	$catsJobOrderIDResult = $catsJobOrderId->fetchAll();
    // 	foreach($catsJobOrderIDResult as $key => $jobParseRow) {
    // 		$jPJobId[] = $jobParseRow['joborder_id'];
    // 	}
    //
    //   $jobParseResult = $this->jobParseDataRepository->fetchAll();
    // 	foreach($jobParseResult as $key => $jPvalue ){
    // 		$jPValueId = $jPvalue->getJoborderId();
    // 		$jPValueDescription = $jPvalue->getDescription();
    //
    // 		if (in_array($jPValueId, $jPJobId)) {
    // 			$resultArray[$jPValueId] = array("matched_job_list" => array(), "words" => $jPValueDescription, "total_words" => count(json_decode($jPValueDescription, 'ARRAY')) );
    // 		}
    // 	}
    //
    //
    //   // $counter = 0;
    // 	// foreach ($resultArray as $key => $rAValue) {
    // 	// 	$sourceWordList = json_decode($rAValue['words'], 'ARRAY');
    //   //
    // 	// 	foreach ($jobParseResult as $subKey => $subValue) {
    // 	// 		$joborderId = $subValue->getJoborderId();
    // 	// 		if ($joborderId != $key) {
    //   //     if((isset($resultArray[$key]['matched_job_list'][$joborderId])) || (isset($resultArray[$joborderId]['matched_job_list'][$key]))) {
    //   //       continue;
    //   //
    //   //       } else {
    // 	// 			$targetWordList = json_decode($subValue->getDescription(),'ARRAY');
    //   //
    // 	// 			$findUnique = array_map('strtolower', array_column($targetWordList, 'word'));
    // 	// 			$unique = array_unique($findUnique);
    //   //
    // 	// 			foreach($sourceWordList as $singleWord) {
    //   //
    //   //
    // 	// 				//  foreach($targetWordList as $subWordSearch){
    // 	// 				if(in_array($singleWord['word'], array_column($targetWordList, 'word'))){
    // 	// 					//if($singleWord['word'] == $subWordSearch['word']){
    // 	// 					if (!isset($resultArray[$key]['matched_job_list'][$joborderId])) {
    // 	// 						$resultArray[$key]['matched_job_list'][$joborderId] = array("exat_match" => 1, "all_match" => 1);
    // 	// 					} else {
    // 	// 						$resultArray[$key]['matched_job_list'][$joborderId]['exat_match']++;
    // 	// 						$resultArray[$key]['matched_job_list'][$joborderId]['all_match']++;
    // 	// 					}
    // 	// 				}
    //   //
    //   //          elseif (in_array($singleWord['word'], $unique)) {
    // 	// 					if (!isset($resultArray[$key]['matched_job_list'][$joborderId])) {
    // 	// 						$resultArray[$key]['matched_job_list'][$joborderId] = array("exat_match" => 0, "all_match" => 1);
    // 	// 					} else {
    // 	// 						$resultArray[$key]['matched_job_list'][$joborderId]['all_match']++;
    // 	// 					}
    // 	// 				}
    // 	// 				//}
    //   //       }
    //   //     }
    // 	// 		}
    //   //
    // 	// 	}
    //   //
    //   //
    //   //   $counter++;
    //   //   if($counter == 5) {
    //   //     break;
    //   //     }
    // 	// }
    //
    //
    //   foreach ($resultArray as $key => $rAValue) {
    //   	$sourceWordList = json_decode($rAValue['words'], 'ARRAY');
    //
    //   	foreach ($jobParseResult as $subKey => $subValue) {
    //   		$joborderId = $subValue->getJoborderId();
    //       if ($joborderId != $key) {
    //         $targetWord = $subValue->getDescription();
    //   			$targetWordList = json_decode($targetWord,'ARRAY');
    //
    //   		  $unique = array_unique(array_column(json_decode(strtolower($targetWord),'ARRAY'), 'word'));
    //         $exactArray = array_intersect(array_column($sourceWordList, 'word'), array_column($targetWordList, 'word'));
    //         $AllArray = array_intersect(array_column($sourceWordList, 'word'), $unique);
    //
    //   			$resultArray[$key]['matched_job_list'][$joborderId] = array("exat_match" => count($exactArray), "all_match" => count(array_unique(array_merge($AllArray,$exactArray))));
    //
    //   		}
    //
    //   	}
    //   }
    //
    //
    //   foreach($resultArray as $key => $sortArray) {
    //     $tmpResult = array();
    //
    //     foreach ($sortArray["matched_job_list"] as $jobId => $value) {
    //       $tmpResult[] = array_merge($value, array('job_id' => $jobId, 'exat_match' =>  $value['exat_match'], 'all_match' => $value['all_match']));
    //     }
    //     array_multisort(array_column($tmpResult, 'exat_match'), SORT_DESC,array_column($tmpResult, 'all_match'),SORT_DESC,$tmpResult);
    //
    //     $resultArray[$key]['matched_job_list'] = array();
    //     foreach ($tmpResult as $tmpKey => $value) {
    //       $resultArray[$key]['matched_job_list'][$value['job_id']] = array('exat_match' => $value['exat_match'], 'all_match' => $value['all_match']);
    //     }
    //     unset($resultArray[$key]['words']);
    //   }
    //
    //   $this->matchedJobOrdersRepository->removeAll();
    //
    //   foreach($resultArray as $keyJobId => $rArrayRow){
    //
    //     $matchedJobOrders = new MatchedJobOrders();
    //     $matchedJobOrders->setJoborderId($keyJobId);
    //     $matchedJobOrders->setMatchedJobOrderList(json_encode($rArrayRow['matched_job_list']));
    //     $matchedJobOrders->setTotalWords($rArrayRow['total_words']);
    //     $matchedJobOrders->setCreatedAt(new \DateTime());
    //     $this->matchedJobOrdersRepository->commit($matchedJobOrders);
    //
    //   }
    // 	return $this->responseArray;
    // }

    public function textParsing($jobId, $jobText) {

      $jobDetailData = strip_tags($jobText);
      $tag = ["&nbsp;","&bull;","&amp;","&middot;"];
      $tagReplace = ["","","",""];
      $fileString = str_replace($tag, $tagReplace, $jobDetailData);
      $fileName = $jobId.".txt";
      $clientJobIdLocation = $this->container->getParameter('clientJobIdLocation');
       $file = fopen($clientJobIdLocation.$fileName,"w");
               fwrite($file, $fileString);
               fclose($file);
      $jobParseLocation = $this->container->getParameter('jobParseLocation');
      $parseFilter = shell_exec('python '."$jobParseLocation $clientJobIdLocation$fileName");
      unlink($clientJobIdLocation.$fileName);
      $result = str_replace(array( "(",")","[","]","'" ), '', $parseFilter);
      return $result;
      }

    public function findKeyStringForSingleJob()
     {
        $singleJobId = $this->request->get('joborderId');

        $jobFlag = $requireSkillsFlag = $optionalSkillsFlag = null;

        if ($singleJobId != null) {
          $jobParsedId = $this->jobParseDataRepository->findOneByProperty('joborderId', $singleJobId);
                   if(isset($jobParsedId)) {
                       die;
                     }
        }

       ///////////////  connect to ats database to fetch job description detail //////////////

       $this->catsDatabase = $this->container->get('v_tech_solution_search.cats')->getPDO();
       $catsSingleJobOrder = $this->catsDatabase->prepare("SELECT `joborder_id`,`title`,`description`,`require_skills`,`optional_skills` FROM `joborder` WHERE `joborder_id` =".$singleJobId);
       $catsSingleJobOrder->execute();
       $catsSingleJobOrderRows = $catsSingleJobOrder->fetch();

          $cSJId = $catsSingleJobOrderRows['joborder_id'];
          $cSJd = $catsSingleJobOrderRows['description'];
          $cSRs = $catsSingleJobOrderRows['require_skills'];
          $cSOs = $catsSingleJobOrderRows['optional_skills'];
          $cSTitle = $catsSingleJobOrderRows['title'];

          $cSJdTitle = $cSJd.' '.$cSTitle;

          if ($cSJd != '') {
            $jobFlag = true;
            $descriptionResult = $this->textParsing($cSJId,$cSJdTitle);
            if ($descriptionResult != null || $descriptionResult != '' ) {
              $explodeDescriptionResult = explode(",",$descriptionResult);
              $chunkDescriptionArray = array_chunk($explodeDescriptionResult, 3) ;

              foreach ($chunkDescriptionArray as $cda) {
                $finalDescriptionArray[] = array("word" => trim($cda[0]), "POS" => trim($cda[1]), "count" => trim($cda[2]) );
              }

           $jobParseData = new JobParseData();
           $jobParseData->setJoborderId($cSJId);
           $jobParseData->setDescription(json_encode($finalDescriptionArray));
           $jobParseData->setCreatedAt(new \DateTime());
           $this->jobParseDataRepository->commit($jobParseData);
           unset($finalDescriptionArray);
              }

            }

          if ($cSRs != '') {
            $requireSkillsFlag = true;
            $requiredSkillsResult = $this->textParsing($cSJId,$cSRs);
            if ($requiredSkillsResult != null || $requiredSkillsResult != '' ) {
              $explodeRequiredSkillsResult = explode(",",$requiredSkillsResult);
              $chunkRequiredArray = array_chunk($explodeRequiredSkillsResult, 3) ;

              foreach($chunkRequiredArray as $caa) {
                $finalRequireArray[] = array("word" => trim($caa[0]), "POS" => trim($caa[1]), "count" => trim($caa[2]) );
                }

                 $requiredSkillsParseData = new RequiredSkillsParseData();
                 $requiredSkillsParseData->setJoborderId($cSJId);
                 $requiredSkillsParseData->setRequiredSkills(json_encode($finalRequireArray));
                 $requiredSkillsParseData->setCreatedAt(new \DateTime());
                 $this->requiredSkillsParseDataRepository->commit($requiredSkillsParseData);
                 unset($finalRequireArray);
                 }
              }

          if ($cSOs != '') {
            $optionalSkillsFlag = true;
            $optionalSkillsResult = $this->textParsing($cSJId,$cSOs);
            if ($optionalSkillsResult != null || $optionalSkillsResult != '' ) {
              $explodeOptionalSkillsResult = explode(",",$optionalSkillsResult);
              $chunkOptionalArray = array_chunk($explodeOptionalSkillsResult, 3) ;

              foreach ($chunkOptionalArray as $coa) {
                $finalOptionalArray[] = array("word" => trim($coa[0]), "POS" => trim($coa[1]), "count" => trim($coa[2]) );
                }

                 $optionalSkillsParseData = new OptionalSkillsParseData();
                 $optionalSkillsParseData->setJoborderId($cSJId);
                 $optionalSkillsParseData->setOptionalSkills(json_encode($finalOptionalArray));
                 $optionalSkillsParseData->setCreatedAt(new \DateTime());
                 $this->optionalSkillsParseDataRepository->commit($optionalSkillsParseData);
                 unset($finalOptionalArray);
                 }
            }
          $parsedMatchedResult = $this->jobParseDataMatch($singleJobId, $jobFlag, $requireSkillsFlag, $optionalSkillsFlag);
          $outputStrings = $this->findCandidateFromMatchedJoborders($singleJobId);

       // return $this->responseArray;
     }

     public function jobParseDataMatch($singleJobId = null, $jobFlag = null, $requireSkillsFlag = null, $optionalSkillsFlag = null) {

       ini_set('max_execution_time', 0 );

      if($singleJobId != null) {
         $jPJobId[] = $singleJobId;
       } else {
           $catsJobOrderId = $this->catsDatabase->prepare("SELECT * FROM `joborder` WHERE status = 'Active'");
           $catsJobOrderId->execute();
           $catsJobOrderIDResult = $catsJobOrderId->fetchAll();
           foreach($catsJobOrderIDResult as $key => $jobParseRow) {
             $jPJobId[] = $jobParseRow['joborder_id'];
           }
        }


       if ($jobFlag == true || $singleJobId == null) {

       $jobParseResult = $this->jobParseDataRepository->fetchAll();
       foreach ($jobParseResult as $key => $jPvalue ) {
         $jPValueId = $jPvalue->getJoborderId();
         $jPValueDescription = $jPvalue->getDescription();

         if (in_array($jPValueId, $jPJobId)) {
           $resultArray[$jPValueId] = array("matched_job_list" => array(), "words" => $jPValueDescription, "total_words" => count(json_decode($jPValueDescription, 'ARRAY')) );
         }
       }

       foreach ($resultArray as $key => $rAValue) {
         $sourceWordList = json_decode($rAValue['words'], 'ARRAY');

         foreach ($jobParseResult as $subKey => $subValue) {
           $joborderId = $subValue->getJoborderId();
           if ($joborderId != $key) {
             $targetWord = $subValue->getDescription();
             $targetWordList = json_decode($targetWord,'ARRAY');

             $unique = array_unique(array_column(json_decode(strtolower($targetWord),'ARRAY'), 'word'));
             $exactArray = array_intersect(array_column($sourceWordList, 'word'), array_column($targetWordList, 'word'));
             $AllArray = array_intersect(array_column($sourceWordList, 'word'), $unique);

             $resultArray[$key]['matched_job_list'][$joborderId] = array("exat_match" => count($exactArray), "all_match" => count(array_unique(array_merge($AllArray,$exactArray))));

           }

         }
       }

      }


      if ($requireSkillsFlag == true || $singleJobId == null) {

        $jobParseResult = $this->requiredSkillsParseDataRepository->fetchAll();
        foreach ($jobParseResult as $key => $jPvalue ){
          $jPValueId = $jPvalue->getJoborderId();
          $jPValueDescription = $jPvalue->getRequiredSkills();

          if (in_array($jPValueId, $jPJobId)) {
            $resultRSArray[$jPValueId] = array("matched_require_skills" => array(), "words" => $jPValueDescription, "total_rs_words" => count(json_decode($jPValueDescription, 'ARRAY')) );
          }
        }

        foreach ($resultRSArray as $key => $rAValue) {
          $sourceWordList = json_decode($rAValue['words'], 'ARRAY');

          foreach ($jobParseResult as $subKey => $subValue) {
            $joborderId = $subValue->getJoborderId();
            if ($joborderId != $key) {
              $targetWord = $subValue->getRequiredSkills();
              $targetWordList = json_decode($targetWord,'ARRAY');

              $unique = array_unique(array_column(json_decode(strtolower($targetWord),'ARRAY'), 'word'));
              $exactArray = array_intersect(array_column($sourceWordList, 'word'), array_column($targetWordList, 'word'));
              $AllArray = array_intersect(array_column($sourceWordList, 'word'), $unique);

              $resultRSArray[$key]['matched_require_skills'][$joborderId] = array("exat_match" => count($exactArray), "all_match" => count(array_unique(array_merge($AllArray,$exactArray))));

            }

          }
        }
     }

      if ($optionalSkillsFlag == true || $singleJobId == null) {

      $jobParseResult = $this->optionalSkillsParseDataRepository->fetchAll();
      foreach ($jobParseResult as $key => $jPvalue ) {
        $jPValueId = $jPvalue->getJoborderId();
        $jPValueDescription = $jPvalue->getOptionalSkills();

        if (in_array($jPValueId, $jPJobId)) {
          $resultOSArray[$jPValueId] = array("matched_optional_skills" => array(), "words" => $jPValueDescription, "total_os_words" => count(json_decode($jPValueDescription, 'ARRAY')) );
        }
      }

      foreach ($resultOSArray as $key => $rAValue) {
        $sourceWordList = json_decode($rAValue['words'], 'ARRAY');

        foreach ($jobParseResult as $subKey => $subValue) {
          $joborderId = $subValue->getJoborderId();
          if ($joborderId != $key) {
            $targetWord = $subValue->getOptionalSkills();
            $targetWordList = json_decode($targetWord,'ARRAY');

            $unique = array_unique(array_column(json_decode(strtolower($targetWord),'ARRAY'), 'word'));
            $exactArray = array_intersect(array_column($sourceWordList, 'word'), array_column($targetWordList, 'word'));
            $AllArray = array_intersect(array_column($sourceWordList, 'word'), $unique);

            $resultOSArray[$key]['matched_optional_skills'][$joborderId] = array("exat_match" => count($exactArray), "all_match" => count(array_unique(array_merge($AllArray,$exactArray))));

          }

        }
      }

     }

        foreach($resultArray as $key => $rAj) {

        foreach($resultArray[$key]['matched_job_list'] as $mKey => $rm) {

          $requireMatch = $optionalMatch = 0;
           $totalRequireWordSum = $totalOptionalWordSum = 0;

            if (isset($resultOSArray[$key]['matched_optional_skills'][$mKey]['exat_match']) && isset($resultRSArray[$key]['matched_require_skills'][$mKey]['exat_match'])) {
               $totalExatSum = $rm['exat_match'] + $resultOSArray[$key]['matched_optional_skills'][$mKey]['exat_match'] + $resultRSArray[$key]['matched_require_skills'][$mKey]['exat_match'];
              } elseif (isset($resultRSArray[$key]['matched_require_skills'][$mKey]['exat_match'])) {
                 $totalExatSum = $rm['exat_match'] + $resultRSArray[$key]['matched_require_skills'][$mKey]['exat_match'];
                 $requireMatch = $resultRSArray[$key]['matched_require_skills'][$mKey]['exat_match'];
                 $totalRequireWordSum = $resultRSArray[$key]['total_rs_words'];
                } elseif (isset($resultOSArray[$key]['matched_optional_skills'][$mKey]['exat_match'])) {
                   $totalExatSum = $rm['exat_match'] + $resultOSArray[$key]['matched_optional_skills'][$mKey]['exat_match'];
                   $optionalMatch = $resultOSArray[$key]['matched_optional_skills'][$mKey]['exat_match'];
                   $totalOptionalWordSum = $resultOSArray[$key]['total_os_words'];
                  } else {
                    $totalExatSum = $rm['exat_match'];
                    }


            if (isset($resultOSArray[$key]['matched_optional_skills'][$mKey]['all_match']) && isset($resultRSArray[$key]['matched_require_skills'][$mKey]['all_match'])){
               $totalAllSum = $rm['all_match'] + $resultOSArray[$key]['matched_optional_skills'][$mKey]['all_match'] + $resultRSArray[$key]['matched_require_skills'][$mKey]['all_match'];
              } elseif (isset($resultRSArray[$key]['matched_require_skills'][$mKey]['all_match'])){
                $totalAllSum = $rm['all_match'] + $resultRSArray[$key]['matched_require_skills'][$mKey]['all_match'];
                } elseif (isset($resultOSArray[$key]['matched_optional_skills'][$mKey]['all_match'])){
                  $totalAllSum = $rm['all_match'] + $resultOSArray[$key]['matched_optional_skills'][$mKey]['all_match'];
                  } else {
                    $totalAllSum = $rm['all_match'];
                    }
            $totalWordSum = $resultArray[$key]['total_words'] + $totalRequireWordSum + $totalOptionalWordSum;
            $percentageCriteria = ($totalAllSum * 100) / $totalWordSum;
            if (round($percentageCriteria) >= 50 ) {
              $allTogether[$key][] = array("job_id" => $mKey, "exat_match" => $totalExatSum, "all_match" => $totalAllSum, "require_skills" => $requireMatch, "optional_skills" => $optionalMatch, "job_description" => $rm['exat_match'], "total_count" => $totalWordSum );
              }
            }
        }

            if (round($percentageCriteria) >= 50 ) {
            array_multisort(array_column($allTogether[$key], 'require_skills'), SORT_DESC,array_column($allTogether[$key], 'job_description'),SORT_DESC,$allTogether[$key]);
            }
            foreach ($allTogether as $activeKey => $sort) {
              foreach ($sort as $sortAT) {
                $togetherSorting[$activeKey][$sortAT['job_id']] = array("exat_match" => $sortAT['exat_match'], "all_match" => $sortAT['all_match']);
                $totalCount[$activeKey] = $sortAT['total_count'];
                }
              }

              if ($singleJobId == null) {
                $this->matchedJobOrdersRepository->removeAll();
                }

               foreach ($togetherSorting as $keyJobId => $rArrayRow) {

                 $matchedJobOrders = new MatchedJobOrders();
                 $matchedJobOrders->setJoborderId($keyJobId);
                 $matchedJobOrders->setMatchedJobOrderList(json_encode($rArrayRow));
                 $matchedJobOrders->setTotalWords($totalCount[$keyJobId]);
                 $matchedJobOrders->setCreatedAt(new \DateTime());
                 $this->matchedJobOrdersRepository->commit($matchedJobOrders);

               }


       }

       public function findCandidateFromMatchedJoborders($singleJobId = null)
       {
         // find joborder matching percentage //
         if ($singleJobId != null) {
           $activeMatchJobLIst = $this->matchedJobOrdersRepository->findOneByProperty("joborderId",$singleJobId);
           } else {
         $activeMatchJobLIst = $this->matchedJobOrdersRepository->fetchAll();
         }
       	foreach ($activeMatchJobLIst as $key => $activeMatchJobRow ) {
       		$activeMatchJobId = $activeMatchJobRow->getJoborderId();
       		$activeMatchJobData = json_decode($activeMatchJobRow->getMatchedJobOrderList(), 'ARRAY');
           $activeMatchJobCount = $activeMatchJobRow->getTotalWords();
           foreach ($activeMatchJobData as $index => $activeMatchJobDataRow) {
             $exactCount = $activeMatchJobDataRow['exat_match'];
             $percentageCount = ($exactCount*100)/$activeMatchJobCount;
             if (round($percentageCount) >= 80 ) {
               $percentageArray[$activeMatchJobId][] = array("joborder_id" => $index, "percentage" => round($percentageCount) );
               }
             }
           }
           if (!isset($percentageArray)) {
             echo "no match found more than 80%";
             die;
             }
           /// end//

           // find submitted, offered, placed candidates for matched job-orders /////
         foreach ($percentageArray as $key => $percentageRow) {
             foreach ($percentageRow as $index => $percentageRR) {
               $singleMatchJoborder = $percentageRR['joborder_id'];
               $allJobOrder[] = $percentageRR['joborder_id'];
               $matchJobCount[$singleMatchJoborder]  = $percentageRR['percentage'];
               }
             $jobString = implode(",",$allJobOrder);
             unset($allJobOrder);
              $findPlaceAndOffer = $this->catsDatabase->prepare("select candidate_id,joborder_id,status FROM candidate_joborder WHERE status IN (400,600,800,500) AND joborder_id IN (".$jobString.") ORDER BY status DESC");
             	$findPlaceAndOffer->execute();
             	$findPlaceAndOfferResult = $findPlaceAndOffer->fetchAll();
               foreach ($findPlaceAndOfferResult as $identity => $foundCandidate) {
                 $candidateIdemtity = $foundCandidate['candidate_id'];
                 $joborderIdentity = $foundCandidate['joborder_id'];
                 $candidateStatus = $foundCandidate['status'];
                 if (array_key_exists($joborderIdentity,$matchJobCount)) {
                   $percentMatchCount = $matchJobCount[$joborderIdentity];
                   }
                 $finalOutput[$key][] = array("joborder_id" => $joborderIdentity,"candidate_id"=> $candidateIdemtity, "status" => $candidateStatus, "percentage" => $percentMatchCount );
                 }
           }
           //  end ///
             /// find monster and next id for found candidates ////
             foreach ($finalOutput as $MNkey => $findMNId) {
               $memberCId = $foundNId = $foundId = $totalMNId = array();
               foreach ($findMNId as $findInDatabase) {
                 $singleCandidate = $findInDatabase['candidate_id'];
                 $allCanId[] = $findInDatabase['candidate_id'];
                 $allStatus[$singleCandidate] = $findInDatabase['status'];
                 $allPercentage[$singleCandidate] = $findInDatabase['percentage'];
                 }
                 $candidateString = implode(",",$allCanId);
                 $candidateCount = count($allCanId);

                 $this->monsterDatabase = $this->container->get('v_tech_solution_search.monster')->getPDO();
                 $findMonsterId = $this->monsterDatabase->prepare("select cid,ssid from `resume` where cid in (".$candidateString.")");
                 $findMonsterId->execute();
                 $foundId = $findMonsterId->fetchAll();

                 if (count($foundId) > 0) {
                   foreach($foundId as $foundMonId) {
                     $memberCId[] = $foundMonId['cid'];
                   }
                 }

                 if ($candidateCount > count($memberCId)) {
                   $nexxtVal = array_diff($allCanId,$memberCId);
                   if (count($nexxtVal) > 0 ) {
                     $candidateNexxtString = implode(",",$nexxtVal);
                     $this->nexxtDatabase = $this->container->get('v_tech_solution_search.nexxt')->getPDO();
                     $findNexxtId = $this->nexxtDatabase->prepare("select cid,mid from `resume` where cid in (".$candidateNexxtString.")");
                     $findNexxtId->execute();
                     $foundNId = $findNexxtId->fetchAll();
                   }
                 }

                   if (count($foundId) > 0 && count($foundNId) == 0) {
                     $totalMNId = $foundId;
                     }
                   if (count($foundId) == 0 && count($foundNId) > 0) {
                     $totalMNId = $foundNId;
                     }
                   if (count($foundId) > 0 && count($foundNId) > 0) {
                     $totalMNId = $foundNId + $foundId;
                     }

                   unset($allCanId);
                   unset($memberCId);
                 foreach ($totalMNId as $mId => $foundMId) {
                 $memberCanId = $foundMId['cid'];

                 if (array_key_exists($memberCanId,$allStatus)) {
                   $statusId = $allStatus[$memberCanId];
                   }

                   if (array_key_exists($memberCanId,$allPercentage)) {
                     $percentageId = $allPercentage[$memberCanId];
                     }

                 if (array_key_exists("ssid",$foundMId)) {
                   $memberSsId = $foundMId['ssid'];
                   }
                   if (array_key_exists("mid",$foundMId)) {
                   $memberSsId = $foundMId['mid'];
                   }
                 $memberOutput[$MNkey][$memberCanId] = array("member_id" => $memberSsId, "status" => $statusId, "percentage" => $percentageId ) ;

                 }
                 }

                 //. find key strings for fetched candidates from save search ///
                 //
                 // if ($singleJobId == null) {
                 //     $this->suggestedKeyStringsRepository->removeAll();
                 //   }

                 foreach ($memberOutput as $key => $memberDetails) {
                   $existingKeyString = array();
                   $existsJobId = $this->suggestedKeyStringsRepository->findByProperty('joborderId', (int)$key);
                   if(count($existsJobId) > 0) {
                     foreach ($existsJobId as $existsKey => $existsValue) {
                       $existingKeyString[] = $existsValue->getkeyString();
                     }
                     }

                   foreach ($memberDetails as $member) {
                   $arraySingleMemberId = $member['member_id'];
                   $statusMember = array("status" => $member['status']);
                   $percentageMember = array("percentage" => $member['percentage']);
                   $saveSearchResult = $this->saveSearchRepository->findById('searchResult',$arraySingleMemberId);

                   if ($saveSearchResult != null || $saveSearchResult != '') {
                      $jobBoardSource = $saveSearchResult->getResouce();
                      $onlyKeystring = json_decode($saveSearchResult->getkeyString(), "ARRAY");
                      $keystring = $onlyKeystring + $statusMember + $percentageMember;

                      if (!in_array(json_encode($keystring), $existingKeyString)) {
                        $suggestedKeyStrings = new SuggestedKeyStrings();
                        $suggestedKeyStrings->setJoborderId($key);
                        $suggestedKeyStrings->setResouce($jobBoardSource);
                        $suggestedKeyStrings->setkeyString(json_encode($keystring));
                        $suggestedKeyStrings->setCreatedAt(new \DateTime());
                        $this->suggestedKeyStringsRepository->commit($suggestedKeyStrings);
                        //$keyStringArray[$key][] = array("key_string" => $keystring, "source" => $jobBoardSource);
                        }

                      }

                     }
                     unset($existingKeyString);

                   }

                   // end //

       }

       public function findSuggestedKeyStrings()
       {

           $joborderId = $this->request->get('joborder_id');
           $atsUserId = $this->request->get('user_id');
           $this->catsDatabase = $this->container->get('v_tech_solution_search.cats')->getPDO();
           if (isset($joborderId)) {
             $catsJobOrder = $this->catsDatabase->prepare("select `joborder_id`,`title` from `joborder` where `joborder_id`='".$joborderId."'");
             $catsJobOrder->execute();
             $catsJobOrderResult = $catsJobOrder->fetchAll();
             }
             if (isset($atsUserId)) {
               $catsJobOrder = $this->catsDatabase->prepare("select `joborder_id`,`title` from `joborder` where `status` = 'Active' and `recruiter`='".$atsUserId."'");
               $catsJobOrder->execute();
               $catsJobOrderResult = $catsJobOrder->fetchAll();
               }

           foreach ($catsJobOrderResult as $catsJobResult) {
             $catsJobOId = $catsJobResult['joborder_id'];
             $suggestedJobId = $this->suggestedKeyStringsRepository->findByProperty('joborderId', (int)$catsJobOId);

           foreach ($suggestedJobId as $key => $suggestedRow) {
             $suggestJobId = $suggestedRow->getJoborderId();
             $suggestResource = $suggestedRow->getResouce();
             $suggestKeystring = $suggestedRow->getkeyString();
             $returnArray[$suggestJobId][$suggestResource][] = array("key_string" => $suggestKeystring );
             }
             }

             return $returnArray;
       }


    public function keyStringUsage()
    {
      $clickedName = $this->request->get('clicked_name');
      $clickedJoborderId = $this->request->get('clicked_joborder_id');
      $clickedUserId = $this->request->get('clicked_user_id');
      $clickedKeyString = $this->request->get('clicked_keystring');

      $keyStringUsage = new KeyStringUsage();
      $keyStringUsage->setUserId($clickedUserId);
      $keyStringUsage->setJoborderId($clickedJoborderId);
      $keyStringUsage->setSource($clickedName);
      $keyStringUsage->setkeyString(json_encode($clickedKeyString));
      $keyStringUsage->setCreatedAt(new \DateTime());
      $this->keyStringUsageRepository->commit($keyStringUsage);
    }

    public function findCandidateFromKeystring()
    {
      $this->potentialCandidateRepository->removeAll();

      $jobId = $this->request->get('job_id');
       $atsSingleJobOrder = $this->catsDatabase->prepare("SELECT `joborder_id`,`title`,`notes` FROM `joborder` WHERE `status` = 'Active' ORDER BY `joborder_id` DESC");
       //$atsSingleJobOrder = $this->catsDatabase->prepare("SELECT `joborder_id`,`title`,`notes` FROM `joborder` WHERE `joborder_id` =".$jobId);
       $atsSingleJobOrder->execute();
       $atsAllJobOrderRows = $atsSingleJobOrder->fetchAll();

       foreach ($atsAllJobOrderRows as $key => $atsSingleJobOrderRows) {
       $usaZipcode = null;
       $monsterDetailsArray = $cbDetailsArray = $nexxtDetailsArray = array();
       $addressZip = $atsSingleJobOrderRows['notes'];
       $jobId = $atsSingleJobOrderRows['joborder_id'];
       $atsJobOrderTitle = $atsSingleJobOrderRows['title'];
       $zipcodeFind = preg_match("/\b[A-Z]{2}\s+\d{5}(-\d{4})?\b/", $addressZip, $matches);
       if ($zipcodeFind != null) {
       $usZipCode = explode(" ",$matches[0]);
       $usaZipcode = $usZipCode[1];
       }
       $resultKeyStrings = $this->suggestedKeyStringsRepository->findByProperty('joborderId', (int)$jobId);
       if (count($resultKeyStrings) == 0) {
         continue;
         }

       foreach ($resultKeyStrings as $key => $resultRow) {
         $suggestJobId = $resultRow->getJoborderId();
         $suggestResource = $resultRow->getResouce();
         $suggestKeystring = $resultRow->getkeyString();
         $jsonArray = json_decode($suggestKeystring,'ARRAY');
         $returnArray[] = array("key_string" => $jsonArray['keyword'], "status" => $jsonArray['status'], "percentage" => $jsonArray['percentage']);
         }
         array_multisort(array_column($returnArray, 'status'), SORT_DESC,array_column($returnArray, 'percentage'),SORT_DESC,$returnArray);

         // print_r(urldecode($returnArray[0]['key_string']));                   // Initiate cURL
         $ch = curl_init();
         $url = "http://rsx.monster.com/query.ashx?q=" . urlencode(urldecode($returnArray[0]['key_string'])) . "&qajt=&mdateminage=&mdatemaxage=&rpcr=".$usaZipcode."&clv=&edulv=&tsni=&tnsalmin=&tnsalmax=&tsalcur=&tsaltyp=&relo=&wa=&yrsexpid=&rlid=&sort=&twindus=&co=&ver=1.7&pagesize=15&page=&cat=1:EAAQ2nW0B.nZ0FBgg8N5X.rikMnznDqOh90plPeSgumSKBSwpiFKt5oqY8rIdVyp7AUfNk1J899ftx78S.UYJRiKDLx4DIYQvr_quACPKJxhKVn6GJqxbuYyUP47UCdQ8s0O";
         curl_setopt($ch, CURLOPT_URL, $url);
         curl_setopt($ch, CURLOPT_POST, true); // Tell cURL you want to post something
         curl_setopt($ch, CURLOPT_HTTPHEADER, array(
             'Content-Type: text/xml',
             'Content-Length: 0'
         ));

         curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); // Return the output in string format
         $output = curl_exec($ch); // Execute

         curl_close($ch); // Close cURL handle

         $xml = simplexml_load_string($output);
         $json = json_encode($xml);
         $monsterArray = json_decode($json, TRUE);

         // echo "<pre>";
         // print_r($monsterArray); die;
         //
         //

          $cbArray = $this->careerBuilderService->getUserDetail(urlencode(urldecode($returnArray[0]['key_string'])), $usaZipcode, 1);

          $nexxtResultUrl = "k=".urlencode(urldecode($returnArray[0]['key_string']))."&l=".$usaZipcode."&r=&rcw=&el=&p=&smin=&smax=&xpmin=&xpmax=&hr=true&ct=&cl=&et=&rp=&tb=1&s=&aw=&ps=15";
          $username="Konu1992";
          $password="Sonu@123456";
          $loginUser = "konarchp@vtechsolution.us";
          $loginPassword = "Vtech2018";
          $companyId = "4739627";

          $nexxtUrlTokenGeneration="https://svc.nexxt.com/api/v1.0/nexxt.com/token/get";
          $nexxtTokenGenerationPostInfo = "userKey=".$username."&password=".$password;

          $nexxtAuthLogin="https://svc.nexxt.com/api/v1.0/nexxt.com/authentication/loginemployer";
          $nexxtAuthLoginPostInfo = "email=".$loginUser."&password=".$loginPassword."&companyId=".$companyId;

          $nexxtResumeFetchURL = "https://svc.nexxt.com/api/v1.0/nexxt.com/jobseeker/search"; // Where you want to post data

          $cookie_file_path = dirname(__FILE__).'/cookie.txt';
          $ch_nexxt = curl_init();
          curl_setopt($ch_nexxt, CURLOPT_HEADER, false);
          curl_setopt($ch_nexxt, CURLOPT_NOBODY, false);
          curl_setopt($ch_nexxt, CURLOPT_URL, $nexxtUrlTokenGeneration);
          curl_setopt($ch_nexxt, CURLOPT_SSL_VERIFYHOST, 0);

          curl_setopt($ch_nexxt, CURLOPT_COOKIEJAR, $cookie_file_path);
          //set the cookie the site has for certain features, this is optional
          curl_setopt($ch_nexxt, CURLOPT_COOKIE, "cookiename=0");
          curl_setopt($ch_nexxt, CURLOPT_USERAGENT,
              "Mozilla/5.0 (Windows; U; Windows NT 5.0; en-US; rv:1.7.12) Gecko/20050915 Firefox/1.0.7");
          curl_setopt($ch_nexxt, CURLOPT_RETURNTRANSFER, 1);
          curl_setopt($ch_nexxt, CURLOPT_REFERER, $_SERVER['REQUEST_URI']);
          curl_setopt($ch_nexxt, CURLOPT_SSL_VERIFYPEER, 0);
          curl_setopt($ch_nexxt, CURLOPT_FOLLOWLOCATION, 0);

          curl_setopt($ch_nexxt, CURLOPT_CUSTOMREQUEST, "POST");
          curl_setopt($ch_nexxt, CURLOPT_POST, 1);
          curl_setopt($ch_nexxt, CURLOPT_POSTFIELDS, $nexxtTokenGenerationPostInfo);


           $nexxtToken =curl_exec($ch_nexxt);
           //echo $nexxtToken;

          $cookie_file_path1 = dirname(__FILE__).'/cookie.txt';
          curl_setopt($ch_nexxt, CURLOPT_HEADER, false);
          curl_setopt($ch_nexxt, CURLOPT_NOBODY, false);
          curl_setopt($ch_nexxt, CURLOPT_URL, $nexxtAuthLogin);
          curl_setopt($ch_nexxt, CURLOPT_SSL_VERIFYHOST, 0);

          curl_setopt($ch_nexxt, CURLOPT_COOKIEJAR, $cookie_file_path1);
          //set the cookie the site has for certain features, this is optional
          curl_setopt($ch_nexxt, CURLOPT_COOKIE, "cookiename=0");
          curl_setopt($ch_nexxt, CURLOPT_USERAGENT,
              "Mozilla/5.0 (Windows; U; Windows NT 5.0; en-US; rv:1.7.12) Gecko/20050915 Firefox/1.0.7");
          curl_setopt($ch_nexxt, CURLOPT_RETURNTRANSFER, 1);
          curl_setopt($ch_nexxt, CURLOPT_REFERER, $_SERVER['REQUEST_URI']);
          curl_setopt($ch_nexxt, CURLOPT_SSL_VERIFYPEER, 0);
          curl_setopt($ch_nexxt, CURLOPT_FOLLOWLOCATION, 0);

          curl_setopt($ch_nexxt, CURLOPT_CUSTOMREQUEST, "POST");
          curl_setopt($ch_nexxt, CURLOPT_POST, 1);
          curl_setopt($ch_nexxt, CURLOPT_POSTFIELDS, $nexxtAuthLoginPostInfo);

          $nexxtAuthToken=curl_exec($ch_nexxt);
          //echo $nexxtAuthToken;

          curl_setopt($ch_nexxt, CURLOPT_URL,$nexxtResumeFetchURL);
          curl_setopt($ch_nexxt, CURLOPT_POST, true);  // Tell cURL you want to post something
          curl_setopt($ch_nexxt, CURLOPT_POSTFIELDS, $nexxtResultUrl); // Define what you want to post
          curl_setopt($ch_nexxt, CURLOPT_RETURNTRANSFER, true); // Return the output in string format
          $resultData_nexxt = curl_exec ($ch_nexxt); // Execute

          curl_close ($ch_nexxt); // Close cURL handle
          //print_r($resultData_nexxt);

          $nexxtArray = json_decode($resultData_nexxt, TRUE);
                   // echo "<pre>";
                   // print_r($nexxtArray); die;

                   if (isset($monsterArray['Resumes']['Resume'])) {
                     if (isset($monsterArray['Resumes']['Resume']['@attributes']['SID'])) {
                        $monsterDetailsArray = array("member_id" => $monsterArray['Resumes']['Resume']['@attributes']['SID'], "resume_created_date" => $monsterArray['Resumes']['Resume']['DateCreated'], "resume_modified_date" => $monsterArray['Resumes']['Resume']['DateModified'], "first_name" => $monsterArray['Resumes']['Resume']['PersonalData']['Name']['First'], "last_name" => $monsterArray['Resumes']['Resume']['PersonalData']['Name']['Last'], "city" => $monsterArray['Resumes']['Resume']['PersonalData']['Address']['City'], "zip_code" => $monsterArray['Resumes']['Resume']['PersonalData']['Address']['PostalCode'], "target_job_title" => $monsterArray['Resumes']['Resume']['Target']['JobTitle'], "relocation" => $monsterArray['Resumes']['Resume']['Target']['Relocation'], "min_salary" => $monsterArray['Resumes']['Resume']['Target']['Salary']['Min'], "max_salary" => $monsterArray['Resumes']['Resume']['Target']['Salary']['Max'], "salary_type" => $monsterArray['Resumes']['Resume']['Target']['Salary']['Type'], "job_type" => $monsterArray['Resumes']['Resume']['Target']['JobTypes'], "education" => $monsterArray['Resumes']['Resume']['Educations'], "current_job_details" => $monsterArray['Resumes']['Resume']['Experiences'], "work_authorization" => $monsterArray['Resumes']['Resume']['WorkAuths']);
                       } else {
                         foreach ($monsterArray['Resumes']['Resume'] as $monsterKey => $monsterArrayRow) {
                           $monsterDetailsArray[] = array("member_id" => $monsterArrayRow['@attributes']['SID'], "resume_created_date" => $monsterArrayRow['DateCreated'], "resume_modified_date" => $monsterArrayRow['DateModified'], "first_name" => $monsterArrayRow['PersonalData']['Name']['First'], "last_name" => $monsterArrayRow['PersonalData']['Name']['Last'], "city" => $monsterArrayRow['PersonalData']['Address']['City'], "zip_code" => $monsterArrayRow['PersonalData']['Address']['PostalCode'], "target_job_title" => $monsterArrayRow['Target']['JobTitle'], "relocation" => $monsterArrayRow['Target']['Relocation'], "min_salary" => $monsterArrayRow['Target']['Salary']['Min'], "max_salary" => $monsterArrayRow['Target']['Salary']['Max'], "salary_type" => $monsterArrayRow['Target']['Salary']['Type'], "job_type" => $monsterArrayRow['Target']['JobTypes'], "education" => $monsterArrayRow['Educations'], "current_job_details" => $monsterArrayRow['Experiences'], "work_authorization" => $monsterArrayRow['WorkAuths']);
                         }
                        }
                     }

                       if ($cbArray['Hits'] > 0) {
                         if (isset($cbArray['Results']['ResumeResultItem_V3']['ResumeID'])) {
                           $cbDetailsArray = array("member_id" => $cbArray['Results']['ResumeResultItem_V3']['ResumeID'], "full_name" => $cbArray['Results']['ResumeResultItem_V3']['ContactName'], "location" => $cbArray['Results']['ResumeResultItem_V3']['HomeLocation'], "last_update_date" => $cbArray['Results']['ResumeResultItem_V3']['LastUpdate'], "target_job_title" => $cbArray['Results']['ResumeResultItem_V3']['JobTitle'], "current_company" => $cbArray['Results']['ResumeResultItem_V3']['RecentEmployer'], "current_jobtitle" => $cbArray['Results']['ResumeResultItem_V3']['RecentJobTitle'], "education" => $cbArray['Results']['ResumeResultItem_V3']['HighestDegree'], "experience" => $cbArray['Results']['ResumeResultItem_V3']['MonthsOfExperience']);
                           } else {
                             foreach ($cbArray['Results']['ResumeResultItem_V3'] as $cbKey => $cbArrayRow ) {
                               if($cbArrayRow != null) {
                                 $cbDetailsArray[] = array("member_id" => $cbArrayRow['ResumeID'], "full_name" => $cbArrayRow['ContactName'], "location" => $cbArrayRow['HomeLocation'], "last_update_date" => $cbArrayRow['LastUpdate'], "target_job_title" => $cbArrayRow['JobTitle'], "current_company" => $cbArrayRow['RecentEmployer'], "current_jobtitle" => $cbArrayRow['RecentJobTitle'], "education" => $cbArrayRow['HighestDegree'], "experience" => $cbArrayRow['MonthsOfExperience']);
                                 }
                               }
                             }
                       }


                            if($nexxtArray['Total'] > 0) {
                                if (isset($nexxtArray['JobSeekers']['MemberNumber'])) {
                                $nexxtDetailsArray = array("member_id" => $nexxtArray['JobSeekers']['MemberNumber'], "first_name" => $nexxtArray['JobSeekers']['FirstName'], "last_name" => $nexxtArray['JobSeekers']['Last'], "minimum_salary" => $nexxtArray['JobSeekers']['SalaryMin'], "maximum_salary" => $nexxtArray['JobSeekers']['SalaryMax'], "location" => $nexxtArray['JobSeekers']['Location'], "portfolio" => $nexxtArray['JobSeekers']['ResumeTextSnippet'], "experience" => $nexxtArray['JobSeekers']['ExperienceLevelId'], "citizen" => $nexxtArray['JobSeekers']['CitizenshipTypeId'], "resume_created_date" => $nexxtArray['JobSeekers']['CreationDateValidResume'], "education" => $nexxtArray['JobSeekers']['EducationLevelId'], "job_title" => $nexxtArray['JobSeekers']['JobTitle'], "last_modify_date" => $nexxtArray['JobSeekers']['LastUpdatedDate'], "location" => $nexxtArray['JobSeekers']['Location'], "relocation" => $nexxtArray['JobSeekers']['RelocationPreferenceId'], "partner" => $nexxtArray['JobSeekers']['PartnerName'], "resume_valid" => $nexxtArray['JobSeekers']['IsResumeValid'],  "valid_number" => $nexxtArray['JobSeekers']['HasPhoneNumber'], "image" => $nexxtArray['JobSeekers']['ProfileImageUrl'], "last_activity" => $nexxtArray['JobSeekers']['LastActivityDate'], "last_updated" => $nexxtArray['JobSeekers']['LastUpdatedDate']);
                                } else {
                                  foreach ($nexxtArray['JobSeekers'] as $nexxtKey => $nexxtArrayRow) {
                                    if (isset($nexxtArrayRow['SalaryMin']) && isset($nexxtArrayRow['SalaryMax']) && isset($nexxtArrayRow['FirstName']) && isset($nexxtArrayRow['LastName'])) {
                                      $nexxtDetailsArray[] = array("member_id" => $nexxtArrayRow['MemberNumber'], "first_name" => $nexxtArrayRow['FirstName'], "last_name" => $nexxtArrayRow['LastName'], "minimum_salary" => $nexxtArrayRow['SalaryMin'], "maximum_salary" => $nexxtArrayRow['SalaryMax'], "location" => $nexxtArrayRow['Location'], "portfolio" => $nexxtArrayRow['ResumeTextSnippet'], "experience" => $nexxtArrayRow['ExperienceLevelId'], "citizen" => $nexxtArrayRow['CitizenshipTypeId'], "resume_created_date" => $nexxtArrayRow['CreationDateValidResume'], "education" => $nexxtArrayRow['EducationLevelId'], "job_title" => $nexxtArrayRow['JobTitle'], "last_modify_date" => $nexxtArrayRow['LastUpdatedDate'], "relocation" => $nexxtArrayRow['RelocationPreferenceId'], "partner" => $nexxtArrayRow['PartnerName'], "resume_valid" => $nexxtArrayRow['IsResumeValid'],  "valid_number" => $nexxtArrayRow['HasPhoneNumber'], "image" => $nexxtArrayRow['ProfileImageUrl'], "last_updated" => $nexxtArrayRow['LastUpdatedDate']);
                                      }
                                    }
                                  }
                              }

                    $sourceResult = array("key_string" => urldecode($returnArray[0]['key_string']), "monster" => $monsterDetailsArray, "cb" => $cbDetailsArray, "nexxt" => $nexxtDetailsArray);

           $candidateList = new PotentialCandidate();
           $candidateList->setJoborderId($jobId);
           $candidateList->setTitle($atsJobOrderTitle);
           $candidateList->setCandidateList(json_encode($sourceResult));
           $candidateList->setMonster($monster = null);
           $candidateList->setNexxt($next = null);
           $candidateList->setCandidates($candidate = null);
           $candidateList->setCreatedAt(date('Y-m-d H:i:s'));
           $this->potentialCandidateRepository->commit($candidateList);

           unset($returnArray);
           unset($monsterDetailsArray);
           unset($cbDetailsArray);
           unset($nexxtDetailsArray);


           }

      }

      public function candidatesList()
      {
        $jobId = $this->request->get('job_id');
        $resultCandidateList = $this->potentialCandidateRepository->findByProperty('joborderId', $jobId);
        foreach ($resultCandidateList as $key => $resultRow) {
          $candidateListJobId = $resultRow->getJoborderId();
          $candidateListJobTitle = $resultRow->getTitle();
          $candidateList = $resultRow->getCandidateList();
          $returnArray = array("job_id" => $candidateListJobId, "title" => $candidateListJobTitle, "candidate_list" => $candidateList);
          }

          return $returnArray;
        }

           ///////////////// Potential candidate function starts //////////////////////////

    public function potentialCandidate()
    {

        $id = $this->request->get('id');
        $this->catsDatabase = $this->container->get('v_tech_solution_search.cats')->getPDO();
        $recruiterJobId = $this->catsDatabase->prepare("SELECT can.candidate_id, concat(can.first_name,' ',can.last_name) AS canName, job.joborder_id, job.title FROM candidate AS can JOIN candidate_joborder_status_history AS cjsh ON cjsh.candidate_id = can.candidate_id JOIN joborder AS job ON cjsh.joborder_id = job.joborder_id WHERE job.recruiter = '".$id."' and job.status='active' GROUP BY job.joborder_id ORDER BY canName");
        $recruiterJobId->execute();
        $recruiterJobIdCounts = $recruiterJobId->rowCount();
        $curl = curl_init();

        while ($recruiterJobIdResult = $recruiterJobId->fetch())
        {
            $jobId = $recruiterJobIdResult['joborder_id'];
            ///////////////////// pass data jobparser function  starts//////////////////////
            curl_setopt_array($curl, array(
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_URL => 'https://saas.vtechsolution.com/app_dev.php/search/candidate/keystringsearch/' . $jobId . ''));
            /////////////// pass data jobparser function ends//////////////////////
            $response[] = curl_exec($curl);
        }
        return $response;
    }

            ///////////////// Potential candidate function ends //////////////////////////

        //////////////////////// keysearch funcion starts    ///////////////////

    public function keyStringSearch()
    {
        ///////////////  Get the joborder id , page starting and ending rows      ////////////
        $id = $this->request->get('id');
        ///////////////  Get the joborder id , page starting and ending rows end     ////////////
        ///////////////  connect to ats database to fetch job description detail //////////////
        $this->monsterDatabase = $this->container->get('v_tech_solution_search.monster')->getPDO();
        $this->nexxtDatabase = $this->container->get('v_tech_solution_search.nexxt')->getPDO();
        $this->catsDatabase = $this->container->get('v_tech_solution_search.cats')->getPDO();
        $catsJobOrder = $this->catsDatabase->prepare("select `city`,`joborder_id`,`title`,`description` from `joborder` where `joborder_id`='" . $id . "'");
        $catsJobOrder->execute();
        $catsJobOrderRows = $catsJobOrder->fetch();
        $jobDetailData = preg_replace('/\\s+/', ' ', preg_replace('/  */', ' ', preg_replace('/[^A-Za-z0-9\. -]/', ' ', str_replace('#','sharp',str_replace(',','',strip_tags($catsJobOrderRows['description']))))));

            ////////////////////  parsing joborder dataa via python script   ////////////////
        $jobParseLocation = $this->container->getParameter('jobParseLocation');
        $parseFilter = shell_exec("$jobParseLocation $jobDetailData");
            //////////////////////   filter out the common odd data used in job description start ///////////////////////
        $parseFilterData = explode("(NPu", $parseFilter);
        $parseFilterFinalData = array_unique($parseFilterData);

        foreach($parseFilterFinalData as $parseKey => $parseValue)
        {
                ///////////////////////  filter dictionary /////////////////////
            $parseArray = explode("/NNP)", $parseValue);
            $filter = array("/JJ","/NNP","/NNS","/NN","/CC","/TO","/VB","/DT","/POS",",/,","/Title","Description","Skype","WebEx","F2F","Preferred","Desired","Minimum","Programer","Program","Project","Maximum","No","Job","Provide","Ability","will","Experience","Required","Years","Skills","".$locationCity."","".$locationState."","Highly","Last","Used","DAYS","Great","Graduate","Focus","Takes","Ownership","Resolve","Perform","Participate","Apply","Efficiently","Able","Demonstrate","Contract","Start Date","Areas","son","Balances","NoDetails","Any","Specialization","\python\tag.py ","Year","Positive","/[0-9]+/","Requires","required","Education","Exp","a ","Must","Certs","Consistent","NO","Proficient","Reviews","Knowledge","Recommends","Develops","Familiar","Public Sector","Writes","Will","Request","Level","Possess","Gather","New","Please","Date","Skill Section","Skill Amount","Work Location ","Requirement","Candidate","Question","Selected","python\tag.py","strong "," Work","other ","Strong"," Excellent ","Self","Nice","Duration","DESCRIPTION","Keylight","Practical","Agency","State","intended","Engineering","Technical","Skill","Amount","1","2","0","3","4","5","6","7","8","9","10","Monday","Tuesday","Wednesday","Thursday","Friday","Saturdy","Sunday","January","February","March","April","May","June","July","August","September","Octomber","November","December","Submit Received","Certification","Valid ","Location","XX"," Details","Status ","open","the "," Client Information","Openings","Open"," This","Assume","Act","Characteristics"," Achieved","Rating","ertise ","JOB TITLE","Sr","Complete ","Local","Create","Solid","Holidays","Shift","Start","Weekends","Additional Info","IV","Upto","Serves","DOE","Patient","VA","Have ","Video Call","Thanks","ASAP ","Top","Subcon","Development","Target ","Feb","Visa","ASAP","s Needed","Process","Customer","CONTRACT ","Short ","an ","The ","Maintains","-JOB DESCRIPTION","Responsibilities","Installs"," -","Day ","Tasks ","District","Meets","Follows","this ","Learn","Attendance","Communicates","both ","Paid","Overtime","Schedule","Certificate","Production","Version","Utilizes","Understanding","Collect","Absolute","ALL","MUST","OnBase","Large","Tools"," Needed","Senior","Scope","Criminal","Keep","Abuse","Have ","Managed","Aug","skills ","any","new ","Background","Client","Plan","Release ","Comments","Team","skills ","live","Prior","Sep","Build","Need","Good ","Training","Should"," skills","Have","Thorough","Accurately","Refers","Written ","Information","Category ","Lead","Communication","Automotive","good ","Design","Oral","Interview ","Onshore","plus ","Offshore"," d ","Establishing","Ensuring","InDesign ","Exceptional","Good","Helping","Member","Values","Makes","CLAIMS","Database","daily","able","Holiday ","On-call","Dept","REQUIREMENTS"," N A","years","RESPONSIBILITIES","monthly ","DESIRED ","SKILLS","Excellent","Install"," years","PROJECT NAME","Stay","Fix","Assist","Summary","Duties ","Maintain","Department","Coordinate","Proven","Consult","Develop"," Application","Time","Helps","Mandatory ","Monitor","Communicate","Desktop","Facilities","Degree","Maintenance","Vendor","Bachelor","Current","direct","Additional","Primarily","Obtains","directed ","Using","Supervisor","Licenses","AUDIT ","AUDITS ","Conduct","Identify","Review","Implement","Determine","Responsible","Deploy","Researches","A ","System","Demonstrating","Others.","Research","Importance","Order"," Or ","Similar ","Advise ","Less","Subject ","Matter","Months ","Languages","Relevant","Mixed ","Similar ","Months","Yes","Rank","Advanced","Within","Other ","Efforts","standard ","advanced ","Duties","Search","Capture","Permit","Examples","approved ","Allow","Catalog","Functional","Collaborate","Serve","Migrate","Qualification","School","Facilitate","Equivalent","Supply","Diplom","Speak","Write","Read","English","License","program ","Extensive","Includes","Users.","Modify","JOB ","Series","Manage","appropriate ","Evaluate","such ","Accepts","Follow","Detail","Your","Execute","Environment","an ","Roles","experienced ","large ","Function","Ensure","Understands","Soft ","Information s","Coordinating","environment.","Basic s"," Interface","peripheral","Number"," s","Complete"," Confirm","Meeting","starting","efforts","Value","Page","Criteria","preferred ","progress ","Submissions","DESIRABLE "," , ","Interviews","Email","Escalate","Office","Once","Reference","Mandatory","current ","Use","verbal ",". ","Interviewing","Convert","Cases","Superb","Miscellaneous","Average ","Represent","Federal","Partner","mandatory","Five","Automating","work ","Attend","General","Teach","Arizon","Travel","STRONGLY","City","complex ","LOCAL","MAX","Richmond","Summarizing","Validation","Train","multiple ","assigned ","Industry","Oct","Jan","Transformations ","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Nov","Dec","experience","Involve","optiSpecificmal","Prime","Secondary ","Elementary","Submit","the ","Fulfill","Primary Tasks","Abilities","utilizing","understand","requests","Specific","needs","those","Flexibility","Continue","Overview"," ment"," Seven"," Benefits","Successful","Engaging"," ertise","IT.","IT ","Guide"," ing","Incident ","Formulate","Columbia","Support","Networking","Government","Report","Tier","Adept","Complex","Cost","Criteri ","Primary","Prepare","Respond","University","various","Understand","Gas"," an ","Penetration","Educate","Response","Integrate","Dynamic","Has"," ystems","Information Technology","Enterprise","technology","TECHNICAL ","REQUIRED ","Records","HP ","Nights","Night","Possibility","Police","Programmer","Dating","Peer","Analyzes","High","Mon","Epic","Division","Committee","Strategic","Root Cause","Hours","External","Critical","Include ","Hrs","EPIC","Day","PLEASE","FEEDBACK","FROM","PREVIOUS","REGARDING","attached","Cover","SEE ","all ","Our","Important","Others","Per","Week","Length","Midnight","others ","Float","Bill Rate","Call","Change","Social","actual","Holiday","Patterns","Source Control","ative","Broad","Include","Control","Key ","Upgrade","Instructions","Assembles","Conforms","Affixes","Associate","user"," Ms","yr ","eligible","Handles","Identifies","Establishes","Enhance","RESPONDENCE","TRAINING","PAYMENTS","Document","Creating","Position","EXPERT","Run","Sponsor","Full","Anticipate","Operation","Suspend","NEW ","HIRES","Professional","yrs ","Role","Define","effective","Passionate","Extract","Individual","Sat","Sun","Could","female","FEMALE","Independently","programmer ","Average","Standard","-","pages","Approx","Course","Intermediate","Past","Meet","All","Payment","Legacy","Classification","DESIRABLE","Claimed","Software","Mode","Utilize","applications","Windows","minor","Pref ","Req ","Data","Check","Due","Hands","Practice","Major","White","NY","Microsoft ","Business","Plans","Plan","Compliances","Compliance","Article");

            ///////////////////////  filter dictionary /////////////////////

            $finalString = str_replace($filter, '', $parseArray[0]);
                if (($finalString != ' ')&&($finalString != '')&&($finalString != '  ')&&($finalString != ' s ')&&($finalString != 'ing')&&($finalString != 'ity')&&($finalString!=' r')&&($finalString!='s'))
                {
                    if ($parseValue != $parseArray[0])
                    {
                        $finalParseTag[] = str_replace(" bull", " ", str_replace(" nbsp", " ", $finalString));
                    }
                }
        }

            ////////////   filter out the odd data used in job description  end  ///////////////////////
            ///////////////////////////    create array of parse data   /////////////////////
        $finalTags = array_unique(array_merge($finalParseTag));
            //////////////////////////    Generate boolean search string start //////////////////////
        $countSecondaryArray = count($finalTags);
            if ($countSecondaryArray > 1)
            {
                $myFinalTags = '';
                foreach($finalTags as $mySecondaryValue)
                {
                    $stringWordCount=strlen($mySecondaryValue);
                    if($stringWordCount>3)
                    {
                        $myFinalTags.= str_replace('" ', '"', '"' . $mySecondaryValue . '"  OR ');
                    }
                }
            }

            //////////////////////////    Generate boolean search string end //////////////////////
        $myFinalTags.= ' ""';
        $myFinalTags = str_replace(' OR  ""', '', str_replace('OR " "', '', str_replace(',  ,',',',str_replace(',,',',',str_replace('python ag.py',',',str_replace(' r,',',',str_replace(' s,',',',str_replace(',s,',',',str_replace('ing,',',',str_replace(' ,',',',str_replace(', ',',',str_replace(', ',',',str_replace(', ',',',str_replace(', ',',',str_replace(',     ',',',str_replace(',    ,',',',$myFinalTags))))))))))))))));
        $finalData = implode(", ", $finalTags);
        $catsCandidateId = $this->catsDatabase->prepare("SELECT `candidate_id` FROM `candidate_joborder` WHERE `joborder_id` IN ('".$id."')");
        $catsCandidateId->execute();

            while($catsCandidateIdRows = $catsCandidateId->fetch())
            {
                $catsCandidateArrayList[]=$catsCandidateIdRows['candidate_id'];
                $catsCandidateMonsterArrayList[]=$catsCandidateIdRows['candidate_id'];
            }

        $catsCandidateList=implode(",",$catsCandidateArrayList);
        $catsCandidateMonsterList="'".implode("','",$catsCandidateMonsterArrayList)."'";

            ///  fetch monster ids  ////
        $catsMonsterId = $this->monsterDatabase->prepare("SELECT `ssid` FROM `resume` WHERE `cid` IN (".$catsCandidateMonsterList.")");
        $catsMonsterId->execute();
        $monsterCount = $catsMonsterId->rowCount();
            if($monsterCount>0)
            {
                while($catsMonsterIdRows = $catsMonsterId->fetch())
                {
                    $catsMonsterArrayList[]=$catsMonsterIdRows['ssid'];
                }

                $catsMonsterArrayList[]="i7vcxsnbqfirmezr";
                $catsMonsterArrayList[]="ufafmybcj2qvptet";
                $catsMonsterIdList=implode(",",$catsMonsterArrayList);
            }

        ///  fetch monster ids  ////
        ///  fetch nexxt ids  ////
            $catsNexxtId = $this->nexxtDatabase->prepare("SELECT `mid` FROM `resume` WHERE `cid` IN ('50679','34855','217544')");
            $catsNexxtId->execute();
            $nexxtCount = $catsNexxtId->rowCount();
            if($nexxtCount>0)
            {
                while($catsznexxtIdRows = $catsNexxtId->fetch())
                {
                   $catsNexxtArrayList[]=$catsznexxtIdRows['mid'];
                }

                if(is_array($catsNexxtArrayList))
                {
                    $catsNexxtIdList=implode(",",$catsNexxtArrayList);
                }
            }

                /////////////////////////////////////////////////////
            foreach ($catsMonsterArrayList as $catsMonsterArrayListValue)
            {

                $saveSearch = $this->saveSearchRepository->findByProperty('keyString', $catsMonsterArrayListValue);
                foreach ($saveSearch as $search)
                {
                    $searchInfo[] = array("key_string" => $search->getKeyString(), "search_result" => $search->getSearchResult(), "resouce" => $search->getResouce());
                }
            }

            foreach ($catsNexxtArrayList as $catsNexxtArrayListValue)
            {
                $nexxtSaveSearch = $this->saveSearchRepository->findByProperty('keyString', $catsNexxtArrayListValue);
                foreach ($nexxtSaveSearch as $nexxtSearch)
                {
                    $searchInfo[] = array("key_string" => $nexxtSearch->getKeyString(), "search_result" => $nexxtSearch->getSearchResult(), "resouce" => $nexxtSearch->getResouce());
                }
            }
                        //return $this->responseArray;
            ///////////////////////////////////////////////////
            ///  fetch nexxt ids  ////
            $candidate_Id[] = array("joborder_id" => $id,
                "title"=>$catsJobOrderRows['title'],
                "candidate_id"=>$catsCandidateList,
                "monster"=>$catsMonsterIdList,
                "nexxt"=>$catsNexxtIdList,
                "keyskill" => str_replace('OR  ""','',str_replace('\python\tag.py','',$myFinalTags))
                );
            ///////////////////////////////////////////////////////////////////

            $hotList = new HotList();
            $hotList >setData($this->request->get('Data', $candidate_Id));
            $hotList >setSearchInfo($this->request->get('SearchInfo', $searchInfo));
            $this->HotListRepository->commit($hotList);

            ///////////////////////////////////////////////////////////////////
            $searchInfo=array();
            $catsCandidateArrayList=array();
            $catsCandidateMonsterArrayList=array();
            $catsMonsterArrayList=array();
            $catsNexxtArrayList=array();
            //////////////////  return candidateid array   /////////////////////
            return $candidate_Id;
    }
            ///////////////// keysearch function ends //////////////////////////

            //////////////////  textrazor API  ////////////////////////
    public function textRazorParse()
    {
        error_reporting(0);
        TextRazorSettings::setApiKey($this->container->getParameter('textRazzorApiKey'));
        $text = $this->request->get('jobdata');
        $textRazor = new TextRazor();
        $textRazor->addExtractor('entities');
        $response = $textRazor->analyze($text);
        $priorityData[]='';
        foreach ($response['response']['entities'] as $key => $value)
        {
            if($response['response']['entities'][$key]['confidenceScore']>3.00)
            {
                if(($response['response']['entities'][$key]['confidenceScore']>3.00)&&($response['response']['entities'][$key]['confidenceScore']<5.999))
                {
                    if(($response['response']['entities'][$key]['entityId']!='Language')&&($response['response']['entities'][$key]['entityId']!='Knowledge')&&($response['response']['entities'][$key]['entityId']!='Communication'))
                    {
                        $priorityData[]=str_replace("bachelor's degree","",str_replace(" (web framework)","",str_replace(" (United States)","",str_replace(" (programming)","",str_replace('Technology','',str_replace('Computer','',str_replace('Architecture','',str_replace('Information','',str_replace(' (computing)','',str_replace(' (development)','',str_replace(' Sharp','sharp',$response['response']['entities'][$key]['entityId'])))))))))));
                    }
                }
                if(($response['response']['entities'][$key]['confidenceScore']>6.0)&&($response['response']['entities'][$key]['confidenceScore']<7.9))
                {
                    if(($response['response']['entities'][$key]['entityId']!='Language')&&($response['response']['entities'][$key]['entityId']!='Knowledge')&&($response['response']['entities'][$key]['entityId']!='Communication'))
                    {
                        $secondaryPriorityData[]=str_replace("bachelor's degree","",str_replace(" (web framework)","",str_replace(" (United States)","",str_replace(" (programming)","",str_replace('Technology','',str_replace('Computer','',str_replace('Architecture','',str_replace('Information','',str_replace(' (computing)','',str_replace(' (development)','',str_replace(' Sharp','sharp',$response['response']['entities'][$key]['entityId'])))))))))));
                    }
                }
                $mainDataCount=count($priorityData);
                if($mainDataCount==1)
                {
                    if(($response['response']['entities'][$key]['confidenceScore']>18.1)&&($response['response']['entities'][$key]['confidenceScore']<22.5))
                    {
                        if(($response['response']['entities'][$key]['entityId']!='Language')&&($response['response']['entities'][$key]['entityId']!='Knowledge')&&($response['response']['entities'][$key]['entityId']!='Communication'))
                        {
                            $highPriorityData[]=str_replace("bachelor's degree","",str_replace(" (web framework)","",str_replace(" (United States)","",str_replace(" (programming)","",str_replace('Technology','',str_replace('Computer','',str_replace('Architecture','',str_replace('Information','',str_replace(' (computing)','',str_replace(' (development)','',str_replace(' Sharp','sharp',$response['response']['entities'][$key]['entityId'])))))))))));
                        }
                    }
                }
            }
        }
        $TextRazorPriorityData=array("prioritydata"=>array_unique($priorityData));
        $TextRazorHighPriorityData=array("highprioritydata"=>array_unique($highPriorityData));
        $TextRazorSecondaryPriorityData=array("secondaryprioritydata"=>array_unique($secondaryPriorityData));
        $this->responseArray =array_merge($TextRazorPriorityData,$TextRazorHighPriorityData,$TextRazorSecondaryPriorityData);
        return $this->responseArray;
    }
            /////////////////  textrazor API  //////////////////////

///////////////////////////    script for relevant search for given joborders ////////////////////
    public function relevantCandidate()
    {

        $date=date('m-d-Y');
        $createdDate=date('Y-m-d');
        $this->catsDatabase = $this->container->get('v_tech_solution_search.cats')->getPDO();
        //$recruiterJobId = $this->catsDatabase->prepare("SELECT  job.joborder_id FROM candidate AS can JOIN candidate_joborder_status_history AS cjsh ON cjsh.candidate_id = can.candidate_id JOIN joborder AS job ON cjsh.joborder_id = job.joborder_id WHERE job.status='active' GROUP BY job.joborder_id");
        $recruiterJobId=$this->catsDatabase->prepare("SELECT (job.joborder_id) AS joborderId, (job.title) AS `catsjobtitle`,date_format(job.date_created, '$createdDate') AS createDate, (SELECT value FROM extra_field WHERE field_name = 'Due Date' AND data_item_id = job.joborder_id) AS dueDate FROM user AS u JOIN joborder AS job ON job.recruiter = u.user_id WHERE job.status = 'Active' GROUP BY job.joborder_id ORDER BY dueDate, job.title ASC");
        $recruiterJobId->execute();
        $recruiterJobIdCounts = $recruiterJobId->rowCount();
        $curl = curl_init();

        //////////////////////////   Calculate Date and Time ///////////////////////////

        date_default_timezone_set('America/New_york');
        $currentTime=date("h:i:s");
        $currentTimeStamp = strtotime($currentTime);

        ///////////////////////////////  clculate date time end /////////////////////////
        while ($recruiterJobIdResult = $recruiterJobId->fetch())
        {
            $jobOrderId = $recruiterJobIdResult['joborderId'];
            $jobOrderCount = $this->relevanceCandidateRepository->findByProperty('joborderId', $jobOrderId);
            $jobOrderCountNumber=count($jobOrderCount);
            if($jobOrderCountNumber!=0)
            {
            ///////////////////////////////////////////// Mongo delete Functions /////////////////////////////////////
                foreach($jobOrderCount as $index => $fetchStatus)
                {
                    $skillSetArray[]= $fetchStatus->getSkill();
                    $cityArray[]= $fetchStatus->getCity();
                    $existTimeStamp= strtotime($fetchStatus->getUpdatedTime());
                    $createdTime[]= $fetchStatus->getCreatedTime();
                    $timeDifference = ($currentTimeStamp - $existTimeStamp) / 60;
                    $minuteDifference[] = ($currentTimeStamp - $existTimeStamp) / 60;
                  //  if($timeDifference>180)
                  //  {
                        $this->relevanceCandidateRepository->deleteByObject($fetchStatus);
                  //  }
                }
            ////////////////////////////////////////////  Mongo delete Functions /////////////////////////////////////
               // if($minuteDifference[0]>180)
              //  {
                //////////////////// pass data through API  //////////////////////
                    curl_setopt_array($curl, array(
                    CURLOPT_RETURNTRANSFER => 1,
                    CURLOPT_URL => 'http://saas.vtechsolution.com/search/candidate/joborderparse/'.$jobOrderId.'/0/2000/'.urlencode($skillSetArray[0]).'/'.urlencode($cityArray[0]).''
                    ));
                    $skillSetArray=array();
                    $cityArray=array();
                ////////////// Send the request & save response to $resp //////////////////////
                    $resp         = curl_exec($curl);
                    $respArray    = json_decode($resp, true);
                    $myCountArray = count($respArray['parseresult']);
                //////////////////////////   parse key skill from the job order description  ////////////////
                    $skillSet=$respArray["parseresult"][$myCountArray-1]["keyskill"];
                    $jobCity=$respArray["parseresult"][$myCountArray-1]["jobcity"];
                    $records=$respArray["parseresult"][$myCountArray-1]["records"];
                    if(($skillSet!='""')&&($skillSet!='" "')&&($skillSet!='"  "'))
                    {
                        if ($respArray['parseresult'][$myCountArray - 1]['records'] >= 1)
                        {
                            $i = 0;
                            while ($i < $myCountArray - 1)
                            {

                                $catsAll[] = array(
                                "id" => $respArray['parseresult'][$i]['id'],
                                "name" => $respArray['parseresult'][$i]['name'],
                                "city" => $respArray['parseresult'][$i]['city'],
                                "state" => $respArray['parseresult'][$i]['state'],
                                "zip" => $respArray['parseresult'][$i]['zip'],
                                "source" => $respArray['parseresult'][$i]['source']
                                );
                                $i++;
                            }
                        }

            ////////////////////////////////////////////  Mongo insert Functions /////////////////////////////////////
                        $saveSearch = new RelevanceCandidate();
                        $saveSearch->setJoborderId($jobOrderId);
                        $saveSearch->setRecords($records);
                        $saveSearch->setCity($jobCity);
                        $saveSearch->setSkill($skillSet);
                        $saveSearch->setCandidates(json_encode($catsAll));
                        $saveSearch->setCreatedAt($date);
                        $saveSearch->setUpdatedAt($date);
                        $saveSearch->setCreatedTime($createdTime[0]);
                        $saveSearch->setUpdatedTime($currentTime);
                        $this->relevanceCandidateRepository->commit($saveSearch);
                        $jobStatus[]="job order id ".$jobOrderId." inserted";
                        $catsAll=array();
            /////////////////////////////////  Mongo insert Functions Ends /////////////////////////////////////
                    }
               // }
                $minuteDifference=array();
                $createdTime=array();
            }

            if($jobOrderCountNumber==0)
            {
                //////////////////// pass data through API  //////////////////////
                curl_setopt_array($curl, array(
                CURLOPT_RETURNTRANSFER => 1,
                CURLOPT_URL => 'http://saas.vtechsolution.com/search/candidate/joborderparse/'.$jobOrderId.'/0/2000/1/1'
                ));
                ////////////// Send the request & save response to $resp //////////////////////
                $resp         = curl_exec($curl);
                $respArray    = json_decode($resp, true);
                $myCountArray = count($respArray['parseresult']);
                //////////////////////////   parse key skill from the job order description  ////////////////
                $skillSet=$respArray["parseresult"][$myCountArray-1]["keyskill"];
                $jobCity=$respArray["parseresult"][$myCountArray-1]["jobcity"];
                $records=$respArray["parseresult"][$myCountArray-1]["records"];
                if(($skillSet!='""')&&($skillSet!='" "')&&($skillSet!='"  "'))
                {
                    if ($respArray['parseresult'][$myCountArray - 1]['records'] >= 1)
                    {
                        $i = 0;
                        while ($i < $myCountArray - 1)
                        {

                            $catsAll[] = array(
                                "id" => $respArray['parseresult'][$i]['id'],
                                "name" => $respArray['parseresult'][$i]['name'],
                                "city" => $respArray['parseresult'][$i]['city'],
                                "state" => $respArray['parseresult'][$i]['state'],
                                "zip" => $respArray['parseresult'][$i]['zip'],
                                "source" => $respArray['parseresult'][$i]['source']
                                );
                            $i++;
                        }
                    }

            ////////////////////////////////////////////  Mongo insert Functions /////////////////////////////////////
                    $saveSearch = new RelevanceCandidate();
                    $saveSearch->setJoborderId($jobOrderId);
                    $saveSearch->setRecords($records);
                    $saveSearch->setCity($jobCity);
                    $saveSearch->setSkill($skillSet);
                    $saveSearch->setCandidates(json_encode($catsAll));
                    $saveSearch->setCreatedAt($date);
                    $saveSearch->setUpdatedAt($date);
                    $saveSearch->setCreatedTime($currentTime);
                    $saveSearch->setUpdatedTime($currentTime);
                    $this->relevanceCandidateRepository->commit($saveSearch);
                    $jobStatus[]="job order id ".$jobOrderId." inserted";
                    $catsAll=array();
            /////////////////////////////////  Mongo insert Functions Ends /////////////////////////////////////
                }
            }
        }
        curl_close($curl);
        $this->responseArray=$jobStatus;
        return $this->responseArray;
    }
////////////////////////////////////////////  script for relevant search for given joborders Ends /////////////////////////////////////
///////////////////////////    script for count relevant search for given joborders ////////////////////
    public function relevantCandidateCount()
    {
                   date_default_timezone_set('America/New_york');
        $currentTime=date("h:i:s");
        $currentTimeStamp = strtotime($currentTime);
           $jobOrderCount = $this->relevanceCandidateRepository->findByProperty('joborderId', '27764');
            $jobOrderCountNumber=count($jobOrderCount);
            if($jobOrderCountNumber!=0)
            {
            ///////////////////////////////////////////// Mongo delete Functions /////////////////////////////////////
                foreach($jobOrderCount as $index => $fetchStatus)
                {
                    $skillSetArray[]= $fetchStatus->getSkill();
                    $cityArray[]= $fetchStatus->getCity();
                    $existTimeStamp= strtotime($fetchStatus->getUpdatedTime());
                    $createdTime[]= $fetchStatus->getCreatedTime();
                    $timeDifference = ($currentTimeStamp - $existTimeStamp) / 60;
                    $minuteDifference[] = ($currentTimeStamp - $existTimeStamp) / 60;
                    if($timeDifference>180)
                    {
                        $this->relevanceCandidateRepository->deleteByObject($fetchStatus);
                    }
                }
            ////////////////////////////////////////////  Mongo delete Functions /////////////////////////////////////
                if($minuteDifference[0]>180)
                {
        //////////////  query  ////////////////


                    $result="greater1";
                }

                                if($minuteDifference[0]<180)
                {

 $result="greater2";
                }

            }
echo $timeDifference;
            echo $result;
            echo $minuteDifference[0];
            die;
        $this->responseArray=$result;
        return $this->responseArray;
        ///////////////  fetch relevance  ///////////////

    }


///////////////////////////    script for relevant search for given joborders ////////////////////
    public function relevantCandidateList()
    {

        $date=date('m-d-Y');
        $curl = curl_init();
        $jobOrderId = $this->request->get('id');
        $jobOrderCount = $this->relevanceCandidateRepository->findByProperty('joborderId', $jobOrderId);
        $jobOrderCountNumber=count($jobOrderCount);

        //////////////////////////   Calculate Date and Time ///////////////////////////

        date_default_timezone_set('America/New_york');
        $currentTime=date("h:i:s");
        $currentTimeStamp = strtotime($currentTime);

        ///////////////////////////////  clculate date time end /////////////////////////

        if($jobOrderCountNumber!=0)
        {
            ///////////////////////////////////////////// Mongo delete Functions /////////////////////////////////////
            foreach($jobOrderCount as $index => $fetchStatus)
            {
                $skillSetArray[]= $fetchStatus->getSkill();
                $cityArray[]= $fetchStatus->getCity();
                $recordArray[]= $fetchStatus->getRecords();
                $candidatesArray= $fetchStatus->getCandidates();
                $candidates=json_decode($candidatesArray,true);

                foreach($candidates as $candidateKey => $candidateValue)
                {
                    $this->responseArray[] = array(
                    "id" => $candidates[$candidateKey]['id'],
                    "name" => $candidates[$candidateKey]['name'],
                    "zip" => $candidates[$candidateKey]['zip'],
                    "city" => $candidates[$candidateKey]['city'],
                    "state" => $candidates[$candidateKey]['state'],
                    "source" => $candidates[$candidateKey]['source']);
                }
            }
                            //////////////////  store candidate skill, page record start and end in the same array  /////////////////////////
            $this->responseArray[] = array(
            "joborder_id" => $jobOrderId,
            "title"=>'',
            "keyskill" => $skillSetArray[0],
            "jobcity" => $cityArray[0],
            "records" => $recordArray[0],
            "page_start" => 1,
            "page_end" => 2000);
            $skillSetArray=array();
            $cityArray=array();
            $recordArray=array();
        }

        if($jobOrderCountNumber==0)
        {
                //////////////////// pass data through API  //////////////////////
            curl_setopt_array($curl, array(
            CURLOPT_RETURNTRANSFER => 1,
            CURLOPT_URL => 'http://saas.vtechsolution.com/search/candidate/joborderparse/'.$jobOrderId.'/0/2000/1/1'
            ));
                ////////////// Send the request & save response to $resp //////////////////////
            $resp         = curl_exec($curl);
            $respArray    = json_decode($resp, true);
            $myCountArray = count($respArray['parseresult']);
                //////////////////////////   parse key skill from the job order description  ////////////////
            $skillSet=$respArray["parseresult"][$myCountArray-1]["keyskill"];
            $jobCity=$respArray["parseresult"][$myCountArray-1]["jobcity"];
            $records=$respArray["parseresult"][$myCountArray-1]["records"];
            if(($skillSet!='""')&&($skillSet!='" "')&&($skillSet!='"  "'))
            {
                if ($respArray['parseresult'][$myCountArray - 1]['records'] >= 1)
                {
                    $i = 0;
                    while ($i < $myCountArray - 1)
                    {
                        $this->responseArray[] = array(
                        "id" => $respArray['parseresult'][$i]['id'],
                        "name" => $respArray['parseresult'][$i]['name'],
                        "city" => $respArray['parseresult'][$i]['city'],
                        "state" => $respArray['parseresult'][$i]['state'],
                        "zip" => $respArray['parseresult'][$i]['zip'],
                        "source" => $respArray['parseresult'][$i]['source']
                        );
                        $i++;
                    }
                }

            ////////////////////////////////////////////  Mongo insert Functions /////////////////////////////////////
                $saveSearch = new RelevanceCandidate();
                $saveSearch->setJoborderId($jobOrderId);
                $saveSearch->setRecords($records);
                $saveSearch->setCity($jobCity);
                $saveSearch->setSkill($skillSet);
                $saveSearch->setCandidates(json_encode($this->responseArray));
                $saveSearch->setCreatedAt($date);
                $saveSearch->setUpdatedAt($date);
                $saveSearch->setCreatedTime($currentTime);
                $saveSearch->setUpdatedTime($currentTime);
                $this->relevanceCandidateRepository->commit($saveSearch);
            /////////////////////////////////  Mongo insert Functions Ends /////////////////////////////////////
            }
            $this->responseArray[] = array(
            "joborder_id" => $jobOrderId,
            "title"=>'',
            "keyskill" => $skillSet,
            "jobcity" => $jobCity,
            "records" => $records,
            "page_start" => 1,
            "page_end" => 2000);
        }

        curl_close($curl);
        return $this->responseArray;
    }
////////////////////////////////////////////  script for relevant search for given joborders Ends /////////////////////////////////////

////////////////////////    potential candidate list   //////////////////////////

    public function potentialCandidateList()
    {
        error_reporting(0);
        $id = $this->request->get('id');
        $date = date('m-d-Y');
        $createdDate=date('Y-m-d');
        $this->catsDatabase = $this->container->get('v_tech_solution_search.cats')->getPDO();
        //$recruiterJobId = $this->catsDatabase->prepare("SELECT can.candidate_id, concat(can.first_name,' ',can.last_name) AS canName, job.joborder_id AS joborderId, job.title  AS catsjobtitle FROM candidate AS can JOIN candidate_joborder_status_history AS cjsh ON cjsh.candidate_id = can.candidate_id JOIN joborder AS job ON cjsh.joborder_id = job.joborder_id WHERE job.recruiter = '".$id."' and job.status='active' GROUP BY job.joborder_id ORDER BY canName");
        $recruiterJobId=$this->catsDatabase->prepare("SELECT (job.joborder_id) AS joborderId, (job.title) AS `catsjobtitle`,date_format(job.date_created, '$createdDate') AS createDate, (SELECT value FROM extra_field WHERE field_name = 'Due Date' AND data_item_id = job.joborder_id) AS dueDate FROM user AS u JOIN joborder AS job ON job.recruiter = u.user_id WHERE job.status = 'Active' AND u.user_id = '".$id."' GROUP BY job.joborder_id ORDER BY dueDate, job.title ASC");
        $recruiterJobId->execute();
        $recruiterJobIdCounts = $recruiterJobId->rowCount();
        $this->nexxtDatabase = $this->container->get('v_tech_solution_search.nexxt')->getPDO();
        $this->monsterDatabase = $this->container->get('v_tech_solution_search.monster')->getPDO();
        $this->catsDatabase = $this->container->get('v_tech_solution_search.cats')->getPDO();
        while ($recruiterJobIdResult = $recruiterJobId->fetch())
        {
    ///////////////////////    check whether joborderid exist or not in potentialcandidate documentt wth current date ////////
            $jobOrderCount = $this->potentialCandidateRepository->findByJobid('joborderId', $recruiterJobIdResult['joborderId'],'createdAt',$date);
            $jobOrderCountNumber=count($jobOrderCount);
            if($jobOrderCountNumber==0)
            {
                $relevanceJobOrderCount = $this->relevanceCandidateRepository->findByProperty('joborderId', $recruiterJobIdResult['joborderId']);
                $monsterStringData=array();
                $nexxtStringData=array();
                foreach($relevanceJobOrderCount as $jobIndex => $fetchJobStatus)
                {
                    $jobBoardSkill= $fetchJobStatus->getSkill();
                //    $monsterStringData[]="https://ats.vtechsolution.com/index.php?m=candidates&a=CasResult1&jt=".urlencode(urlencode($jobBoardSkill))."&qrjt=&datef=&datet=&zip=&miles=20&clv=&edulv=&tjtidtjts=&tsni=1&tsalmin=&tsalmax=&tsalcur=1&tsaltyp=1&relo=&co1=&wa=&yrsexpid=&rlid=&sort=Rank&twindus=&co=&page=1";
                //    $nexxtStringData[]="https://ats.vtechsolution.com/index.php?m=candidates&a=nexxt_search&k=".urlencode(urlencode($jobBoardSkill))."&l=&r=&xpmax=&el=&rcw=&smin=&smax=&hr=true&ct=&cl=&et=&rp=&tb=&xpmin=&aw=&p=1&pageno=1";
                }

    ///////////////////////    check whether joborderid exist or not in potentialcandidate documentt wth current date end ////////

                $recruiterCandidateId = $this->catsDatabase->prepare("SELECT (canj.candidate_id) AS canid,(canj.candidate_id) AS canid, (can.source) AS source FROM candidate_joborder AS canj JOIN candidate AS can on canj.candidate_id=can.candidate_id WHERE canj.joborder_id = ".$recruiterJobIdResult['joborderId']." and (can.source='monster' OR can.source='nexxt')");
                $recruiterCandidateId->execute();
                $candidateResult=array();
                while ($recruiterCandidateResult = $recruiterCandidateId->fetch())
                {
                    if($recruiterCandidateResult['source']=='monster')
                    {
                        $monsterData = $this->monsterDatabase->prepare("SELECT `ssid` from `resume` where `cid`=".$recruiterCandidateResult['canid']."");
                        $monsterData->execute();
                        $monsterResult = $monsterData->fetch();
                        $candidateResult[]=$monsterResult['ssid'];

                    }
                    if($recruiterCandidateResult['source']=='nexxt')
                    {
                        $monsterData = $this->nexxtDatabase->prepare("SELECT `mid` from `resume` where `mid`=".$recruiterCandidateResult['canid']."");
                        $monsterData->execute();
                        $monsterResult = $monsterData->fetch();
                        $candidateResult[]=$monsterResult['mid'];
                    }
                }

                        ///////////////  fetch relevance ///////////////

                $cursorJobSkillFinder =  $this->relevanceCandidateRepository->findByProperty('joborderId',$recruiterJobIdResult['joborderId']);
                foreach ($cursorJobSkillFinder as $cursorremoteIndex => $cursorremotedocument)
                {
                    $skillPrimaryJob=strtolower(str_replace('AND,','',str_replace(' AND ','',str_replace(' ( ','',str_replace(') ','',str_replace(',,',',',str_replace(' ,',',',str_replace(',  )',',',str_replace('"',',',str_replace('("','',str_replace(' OR ',',',str_replace('AND ( "',',', $cursorremotedocument->getSkill()))))))))))));

                    $skillSecondaryJob=explode(",", $skillPrimaryJob);
                    $primarySkilllCursors = $this->relevanceCandidateRepository->findByAll();
                    foreach ($primarySkilllCursors as  $remotePrimaryIndex => $remotePrimaryDocument)
                    {
                        if($remotePrimaryDocument->getJoborderId()!=$recruiterJobIdResult['joborderId'])
                        {

                            $secondarySkills=strtolower(str_replace('AND,','',str_replace(' AND ','',str_replace(' ( ','',str_replace(') ','',str_replace(',,',',',str_replace(' ,',',',str_replace(',  )',',',str_replace('"',',',str_replace('("','',str_replace(' OR ',',',str_replace('AND ( "',',', $remotePrimaryDocument->getSkill()))))))))))));
                            $secondarySkillsArray=explode(",", $secondarySkills);
                            $arrayFilters=array_filter(array_intersect($skillSecondaryJob, $secondarySkillsArray));
                            $countArrayFilter=count($arrayFilters);
                            if($countArrayFilter>=6)
                            {
                                $skillResult[]=array("jobid"=> $remotePrimaryDocument->getJoborderId(),"matchskill"=>$arrayFilters);
                            }
                        }
                    }
                }

        //////////////// query //////////////////////

                foreach ($skillResult as $skillResulKkey => $skillResultValue)
                {
                    $recruiterSkillCandidateId = $this->catsDatabase->prepare("SELECT (canj.candidate_id) AS canid,(canj.candidate_id) AS canid, (can.source) AS source FROM candidate_joborder AS canj JOIN candidate AS can on canj.candidate_id=can.candidate_id WHERE canj.joborder_id = ".$skillResult[$skillResulKkey]['jobid']." and (can.source='monster' OR can.source='nexxt')");
                    $recruiterSkillCandidateId->execute();

                    while ($recruiterSkillCandidateResult = $recruiterSkillCandidateId->fetch())
                    {
                        if($recruiterSkillCandidateResult['source']=='monster')
                        {

                            $monsterSkillData = $this->monsterDatabase->prepare("SELECT `ssid` from `resume` where `cid`=".$recruiterSkillCandidateResult['canid']."");
                            $monsterSkillData->execute();
                            $monsterSkillDataResult = $monsterSkillData->fetch();
                            $candidateResult[]=$monsterSkillDataResult['ssid'];
                        }
                        if($recruiterSkillCandidateResult['source']=='nexxt')
                        {
                            $monsterSkillData = $this->nexxtDatabase->prepare("SELECT `mid` from `resume` where `mid`=".$recruiterSkillCandidateResult['canid']."");
                            $monsterSkillData->execute();
                            $monsterSkillDataResult = $monsterSkillData->fetch();
                            $candidateResult[]=$monsterSkillDataResult['mid'];
                        }
                    }
                }

        //////////////  query  ////////////////
        ///////////////  fetch relevance  ///////////////
             /////////////////////////////   fetch from save search data  /////////////////////////////
                if(!empty($candidateResult))
                {
                    $candidateResultValue=array_unique($candidateResult);
                    $jobBoardCounter=1;
                    $jobBoardPrimaryCounter=1;
                    foreach ($candidateResultValue as $resultValue)
                    {

                    //////////// search from save search ///////////
                            $saveSearchCount = $this->saveSearchRepository->findById($resultValue);
                    ///////////  search from save search  starts //////////
                            foreach ($saveSearchCount as $remoteIndex => $remotedocument)
                            {
                                $jobBoardKeyString= $remotedocument->getkeyString();
                                $jobBoardSource= $remotedocument->getResouce();
                                $keystring = json_decode($jobBoardKeyString, true);
                                if ($jobBoardSource == "monster")
                                {
                                    $tempMonsterArray[]=$jobBoardCounter;
                                    $tempMonsterArrayCount=count($tempMonsterArray);
                                    if($tempMonsterArrayCount<=5)
                                    {
                                    $monsterStringData[] = "https://ats.vtechsolution.com/index.php?m=candidates&a=CasResult1&jt=" . urlencode($keystring['keyword']) . "&qrjt=" . $keystring['job_title'] . "&datef=&datet=&zip=" . $keystring['zip'] . "&miles=" . $keystring['radius'] . "&clv=&edulv=" . $keystring['education'] . "&tjtid=" . $keystring['Target_Job'] . "&tsni=1&tsalmin=" . $keystring['minimum_salary'] . "&tsalmax=" . $keystring['maximum_salary'] . "&tsalcur=1&tsaltyp=1&relo=&co1=&wa=&yrsexpid=" . $keystring['experience'] . "&rlid=&sort=Rank&twindus=&co=&page=1";
                                    }
                                }

                                if ($jobBoardSource == "nexxt")
                                {
                                    $tempNexxtArray[]=$jobBoardPrimaryCounter;
                                    $tempNexxtArrayCount=count($tempNexxtArray);
                                    if($tempNexxtArrayCount<=5)
                                    {
                                       $nexxtStringData[] = "https://ats.vtechsolution.com/index.php?m=candidates&a=nexxt_search&k=" . urlencode($keystring['keyword']) . "&l=" . $keystring['location'] . "&r=" . $keystring['radius'] . "&xpmax=" . $keystring['maximum_year'] . "&el=" . $keystring['education'] . "&rcw=&smin=" . $keystring['minimum_salary'] . "&smax=" . $keystring['maximum_salary'] . "&hr=&ct=&cl=&et=&rp=&tb=&xpmin=" . $keystring['minimum_year'] . "&aw=&p=1&pageno=1";
                                    }
                                }
                            }
                            $jobBoardPrimaryCounter++;
                            $jobBoardCounter++;
                        }
                    }


             /////////////////////////////   fetch from save search data ends //////////////////////////

            ////////////////////////////////////////////  Mongo insert Functions starts /////////////////////////////////////
                $saveSearch = new PotentialCandidate();
                $saveSearch->setJoborderId($recruiterJobIdResult['joborderId']);
                $saveSearch->setTitle($recruiterJobIdResult['catsjobtitle']);
                $saveSearch->setCandidates(json_encode($candidateResultValue));
                $saveSearch->setMonster(json_encode($monsterStringData));
                $saveSearch->setNexxt(json_encode($nexxtStringData));
                $saveSearch->setCreatedAt($date);
                $this->potentialCandidateRepository->commit($saveSearch);

                $this->responseArray[] = array(
                "jobid" => $recruiterJobIdResult['joborderId'],
                "title" => $recruiterJobIdResult['catsjobtitle'],
                "monster" => json_encode($monsterStringData),
                "nexxt" => json_encode($nexxtStringData));

            /////////////////////////////////  Mongo insert Functions Ends /////////////////////////////////////
                $candidateResultValue=array();
                $tempNextArray=array();
                $tempMonsterArray=array();
                $candidateResult=array();
                $monsterStringData=array();
                $nexxtStringData=array();
            }

            if($jobOrderCountNumber!=0)
            {
                $relevanceJobOrderCount = $this->potentialCandidateRepository->findByJobidDate($recruiterJobIdResult['joborderId'],$date);
                foreach($relevanceJobOrderCount as $relevanceIndex => $fetchDataStatus)
                {
                    $jobId= $fetchDataStatus->getJoborderId();
                    $title= $fetchDataStatus->getTitle();
                    $monsterSkill= $fetchDataStatus->getMonster();
                    $nexxtSkill= $fetchDataStatus->getNexxt();
                    $this->responseArray[] = array(
                    "jobid" => $jobId,
                    "title" => $title,
                    "monster" => $monsterSkill,
                    "nexxt" => $nexxtSkill);
                }

            }
        }
        return $this->responseArray;
    }

///////////////////      potential candidate list   //////////////////////////

}

<?php
namespace vTechSolution\Bundle\SearchBundle\Manager;

// http_build_query has its own ideas about how to serialize different types, so we use our own version here.
class TextRazorQueryBuilder {
    private $params = array();
    public function add($key, $value) {
            if (is_null($value)) {
                return;
            }
            else if (is_array($value)) {
                foreach ($value as $listItem) {
                    $this->add($key, $listItem);
                }
            }
            else if (is_bool($value)) {
                $this->add($key, $value ? "true" : "false");
            }
            else {
                $this->params[] = urlencode($key) . '=' . urlencode($value);
            }
    }
    public function build() {
        return implode("&", $this->params);
    }
}
<?php

namespace vTechSolution\Bundle\UserManagementBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\JsonResponse;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;

/**
   * @Route("/usermanagement")
   */

class UserManagementController extends Controller
{
    private $responseArray;
    private $request;
    private $screeningService;

    private function initAction()
    {
      $this->responseArray = array();
      $this->request = $this->getRequest();

      $this->userManagementService = $this->get('v_tech_solution_user_management.usermanagement');
    }

	/**
   * @Route("/list", name="vtech_solution_bundle_user_management_list")
   * @Method({"GET"} )
   * @Template("vTechSolutionUserManagementBundle:UserManagement:list.html.twig")
   */

	public function userList() {

		$this->initAction();

		$this->responseArray["usersRecord"] = $this->userManagementService->listAllName();

		return $this->responseArray;

	}

    /**
   * @Route("/listresolution", name="vtech_solution_bundle_user_management_list_resolution")
   * @Method({"GET"} )
   * @Template("vTechSolutionUserManagementBundle:Resolution:list.html.twig")
   */

  public function resolutionList() {

    $this->initAction();

    $this->responseArray["resolutionArray"] = $this->userManagementService->listAllResolution();

    return $this->responseArray;

  }

  /**
   * @Route("/{id}", name="vtech_solution_bundle_user_management_view")
   * @Method("GET")
   * @Template("vTechSolutionUserManagementBundle:UserManagement:view.html.twig")
   */
  public function showUser()
  {
      $this->initAction();

      $this->responseArray["userById"] = $this->userManagementService->viewUserRecord();

      return $this->responseArray;
  }

  /**
   * @Route("/resolution/{rid}", name="vtech_solution_bundle_user_management_view_resolution")
   * @Method("GET")
   * @Template("vTechSolutionUserManagementBundle:Resolution:view.html.twig")
   */
  public function showResolution()
  {
      $this->initAction();

      $this->responseArray["resolutionById"] = $this->userManagementService->viewResolutionRecord();

      return $this->responseArray;
  }

}

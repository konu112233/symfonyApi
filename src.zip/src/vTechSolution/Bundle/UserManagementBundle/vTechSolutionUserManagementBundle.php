<?php

namespace vTechSolution\Bundle\UserManagementBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class vTechSolutionUserManagementBundle extends Bundle
{
}

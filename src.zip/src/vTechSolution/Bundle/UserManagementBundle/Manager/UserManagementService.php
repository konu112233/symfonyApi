<?php

namespace vTechSolution\Bundle\UserManagementBundle\Manager;

use Symfony\Component\DependencyInjection\ContainerInterface as Container;
use Symfony\Component\HttpFoundation\Request;



class UserManagementService
{

  private $container;
  private $request;
  private $responseArray;
  private $vtechhrminDatabase;

  const HTTP_METHOD_GET    = 'GET';
	const HTTP_METHOD_POST   = 'POST';

	public function __construct(Container $container) {
        $this->container = $container;
        $this->request = $this->container->get('request');
        $this->responseArray = array();
        $this->vtechhrminDatabase = $this->container->get('v_tech_solution_user_management.vtechhrm_in')->getPDO();
    }


    public function __destructor()
    {
        unset($this->container);
        unset($this->request);
        unset($this->responseArray);
        unset($this->vtechhrminDatabase);
    }

	public function listAllName() {
    $finalResult = array();
    $selectUsers = 'SELECT
                        mu.id as userId,
                        mu.userfullname as userFullName,
                        mu.emailaddress as userEmail,
                        mu.contactnumber as userPhone,
                        mu.employeeId as employeeId,
                        mu.jobtitle_id as employeeJobTitle,
                        mu.createddate as createdOn,
                        mj.jobtitlecode as jobTitleCode,
                        mj.jobtitlename as jobTitleName,
                        mj.jobdescription as jobDescription,
                        mr.rolename as roleName
                    FROM main_users as mu
                    LEFT JOIN
                         main_jobtitles as mj
                    ON
                         mu.jobtitle_id = mj.id
                    LEFT JOIN
                         main_roles as mr
                    ON
                         mu.emprole = mr.id
                    WHERE
                    mu.isactive="1" ';
    $fetchedResult = $this->vtechhrminDatabase->query($selectUsers)->fetchAll();

    foreach($fetchedResult as $singleResult ) {
      $finalResult[] = array("userId" => $singleResult["userId"], "userFullName" => $singleResult["userFullName"], "userEmail" => $singleResult["userEmail"], "userPhone" => $singleResult["userPhone"], "employeeId" => $singleResult["employeeId"], "roleName" => $singleResult["roleName"], "jobTitleCode" => $singleResult["jobTitleCode"], "jobTitleName" => $singleResult["jobTitleName"], "jobDescription" => $singleResult["jobDescription"], "createdOn" => $singleResult["createdOn"]);
    }
    return $finalResult;
	}

  public function viewUserRecord() {
    $viewFinalResult = array();
    $getId = $this->request->get('id');
    $selectUserById = 'SELECT
                        mu.id as userId,
                        mu.userfullname as userFullName,
                        mu.emailaddress as userEmail,
                        mu.contactnumber as userPhone,
                        mu.employeeId as employeeId,
                        mu.jobtitle_id as employeeJobTitle,
                        mu.createddate as createdOn,
                        mj.jobtitlecode as jobTitleCode,
                        mj.jobtitlename as jobTitleName,
                        mj.jobdescription as jobDescription,
                        mr.rolename as roleName
                    FROM main_users as mu
                    LEFT JOIN
                         main_jobtitles as mj
                    ON
                         mu.jobtitle_id = mj.id
                    LEFT JOIN
                         main_roles as mr
                    ON
                         mu.emprole = mr.id
                    WHERE
                    mu.isactive="1" AND mj.isactive="1" AND mu.id="'.$getId.'" ';

    $fetchedResultById = $this->vtechhrminDatabase->query($selectUserById)->fetchAll();

    foreach($fetchedResultById as $singleResultById ) {
      $viewFinalResult = array("userId" => $singleResultById["userId"], "userFullName" => $singleResultById["userFullName"], "userEmail" => $singleResultById["userEmail"], "userPhone" => $singleResultById["userPhone"], "employeeId" => $singleResultById["employeeId"], "roleName" => $singleResultById["roleName"], "jobTitleCode" => $singleResultById["jobTitleCode"], "jobTitleName" => $singleResultById["jobTitleName"], "jobDescription" => $singleResultById["jobDescription"], "createdOn" => $singleResultById["createdOn"]);
    }
    return $viewFinalResult;
  }

  public function listAllResolution() {
    $finalResult = array();
    $selectResolution = 'SELECT
                        vc.id as rId,
                        vc.Initiative as Initiative,
                        vc.BusinessImpact as BusinessImpact,
                        vc.Type as Type,
                        vc.DeparatmentName as DeptId,
                        vc.Challenges as Challenges,
                        vc.Suggestions as Suggestions,
                        md.deptname as DeparatmentName
                        
                    FROM vtech_tools.vtech_common_resolution as vc
                    LEFT JOIN
                        main_departments as md  
                        ON 
                        vc.DeparatmentName = md.id';
    $fetchedResult = $this->vtechhrminDatabase->query($selectResolution)->fetchAll();

    foreach($fetchedResult as $singleResult ) {
      $finalResult[] = array("rId" => $singleResult["rId"],"DeparatmentName" => $singleResult["DeparatmentName"], "Challenges" => $singleResult["Challenges"], "Initiative" => $singleResult["Initiative"], "Type" => $singleResult["Type"], "BusinessImpact" => $singleResult["BusinessImpact"], "Suggestions" => $singleResult["Suggestions"]);
    }
    return $finalResult;
  }

  public function viewResolutionRecord() {
    $viewFinalResult = array();
    $getId = $this->request->get('rid');
    $selectResolutionById = 'SELECT
                        vc.id as rId,
                        vc.Initiative as Initiative,
                        vc.BusinessImpact as BusinessImpact,
                        vc.Type as Type,
                        vc.DeparatmentName as DeptId,
                        vc.Challenges as Challenges,
                        vc.Suggestions as Suggestions,
                        md.deptname as DeparatmentName
                        
                    FROM vtech_tools.vtech_common_resolution as vc
                    LEFT JOIN
                        main_departments as md  
                        ON 
                        vc.DeparatmentName = md.id
                    WHERE
                    vc.id="'.$getId.'" ';

    $fetchedResultById = $this->vtechhrminDatabase->query($selectResolutionById)->fetchAll();

    foreach($fetchedResultById as $singleResultById ) {
      $viewFinalResult = array("Initiative" => $singleResultById["Initiative"], "BusinessImpact" => $singleResultById["BusinessImpact"], "Type" => $singleResultById["Type"], "DeparatmentName" => $singleResultById["DeparatmentName"], "Challenges" => $singleResultById["Challenges"], "Suggestions" => $singleResultById["Suggestions"]);
    }
    return $viewFinalResult;
  }


}
